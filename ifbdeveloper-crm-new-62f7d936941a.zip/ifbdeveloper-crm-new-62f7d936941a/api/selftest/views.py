from rest_framework import viewsets
from app01 import models
from . import serializers
from utils.pagination import DefaultPagination
from django_filters.rest_framework import DjangoFilterBackend
from rest_framework.filters import SearchFilter, OrderingFilter
from .permissions import CardViewSetPermission
from django.conf import settings # new
from django.views.generic.base import TemplateView
import stripe # new
from django.shortcuts import render # new
from rest_framework.permissions import AllowAny
from rest_framework.decorators import api_view,authentication_classes,permission_classes
from rest_framework.response import Response
from django.http import HttpResponse
import json
import time
from app01 import models
from .utils import check_server
#from .cron import record_wallet_balance
import requests
import threading
from django.db import connection
import datetime
stripe.api_key = settings.STRIPE_SECRET_KEY # new


from check import file_utils
from invicode import utils
from utils.message_manage import send_message_to_token
import os
from member.utils import dispatch_invicode
from .cron import count_purchase,record_wallet_balance
from outlet.cron import auto_confirm,modify_opening_time

class CardViewSet(viewsets.ModelViewSet):
    permission_classes = (CardViewSetPermission,)
    queryset = models.Card.objects.all()
    serializer_class = serializers.CardSerializer
    pagination_class = DefaultPagination
    filter_backends = (
        DjangoFilterBackend,
        SearchFilter,
        OrderingFilter,
    )
    filter_fields = ('card_no', 'member')
    search_fields = ('card_no', 'member')
    ordering_fields = ('card_no', 'member')

    def get_queryset(self):
        ret = super(CardViewSet, self).get_queryset()
        if self.request.user.role.name in (0, 1):
            return ret
        else:
            return ret.filter(member=self.request.user)


@api_view(['GET'])
@authentication_classes([])
@permission_classes((AllowAny,))

def check(request, *args, **kwargs):
    #check server status
    checks_1 = file_utils.check_server('47.74.208.48', 3000,'login')
    #checks_1 = file_utils.check_server('47.74.156.85', 3000, 'login')
    checks_2 = file_utils.check_server('47.74.208.48', 8000, 'api/v1/outlet/')
    #checks_3 = file_utils.check_server('47.74.156.85', 7000, 'api/getcode//')

    check_result_3=None
    check_result_1=checks_1.check()
    check_result_2 = checks_2.check()
    #check_result_3 = checks_3.check()


    #check project file valid
    exclude_path = {'path_1': 'node_modules', 'path_2': '.idea', 'path_3': 'migrations', 'path_4': '__pycache__','path_5':'.git'}
    fileHandler = file_utils.FileHandler(**exclude_path)
    #file_list = fileHandler.list_all_files(os.path.abspath(os.path.dirname(settings.BASE_DIR)))
    file_list = fileHandler.list_all_files(os.path.abspath(os.path.dirname(os.path.dirname(os.path.dirname(__file__)))))
    print(os.path.abspath(os.path.dirname(os.path.dirname(os.path.dirname(os.path.dirname(__file__))))))
    #file_list = fileHandler.list_all_files(settings.BASE_DIR)
    now = datetime.datetime.now()
    file_modify_dict={}
    file_modify_arr=[]
    for file in file_list:
        modify_time_str=time.strftime('%Y-%m-%d %H:%M:%S',time.localtime(os.stat(file).st_ctime))
        modify_time=datetime.datetime.strptime(modify_time_str, '%Y-%m-%d %H:%M:%S')
        previous_day_time=now-datetime.timedelta(hours=24)
        #print(modify_time)
        #print(previous_day_time)
        if (modify_time>previous_day_time and previous_day_time<now):
            file_modify_arr.append({'file':file.title(),'modify_time':time.strftime('%Y-%m-%d %H:%M:%S',time.localtime(os.stat(file).st_ctime))})

        #print(file.title()  + '      modify time:' + time.strftime('%Y-%m-%d %H:%M:%S',time.localtime(os.stat(file).st_ctime)))
    content=''
    if check_result_1:
        content='<p>'+check_result_1['result']+'</p>'
    if check_result_2:
        content=content+'<p>'+check_result_2['result']+'</p>'
    if check_result_3:
        content=content+'<p>'+check_result_3['result']+'</p>'
    if  file_modify_arr:
        for i in file_modify_arr:
            content=content+'<p>'+i['file']+'  modify:'+i['modify_time']+'</p>'
    utils.send_register_email(utils.RECEIVE_MAIL, content, send_type="check")


    #request server 47.74.156.85
    try:

        response = requests.get("http://47.74.156.85:8008/api/v1/payments/check/")

        #return json.loads(response.text)
    except Exception as e:
        return {'msg': 'error'}

    return HttpResponse(json.dumps({'Status': 'Ok'}))

@api_view(['GET','POST'])
@authentication_classes([])
@permission_classes((AllowAny,))

def sendMessage(request, *args, **kwargs):
      title=request.data.get('title')
      message=request.data.get('message')
      type=request.data.get('type')
      mobile = request.data.get('mobile_no')
      if type=='0':
          member=models.Member.objects.all().filter(mobile_no=mobile).first()
          if member:
              if member.device_token is not None:
                        send_message_to_token(member.device_token, title, message)
      if type=='1':
          member_list=models.Member.objects.all().filter(id__gt=0).order_by('id')
          if member_list:
              messThread = MessThread()
              messThread.member_list=member_list
              messThread.title=title
              messThread.message=message
              messThread.start()


      return HttpResponse(json.dumps({'Status': 'Ok'}))
class MessThread(threading.Thread):
    member_list=[]
    title=''
    message=''

    def run(self):
        if self.member_list:
            i = 0

            for member in self.member_list:
                '''
                send_message_to_token(
                    'cWi1yYd_Lfk:APA91bH_qqfdC07TyRN5g9anVYhNt7P27ZHTbg13APKHQUkt2_rNUJMUCPdSenQUvCdztmYIyLMyEK8F1jm6RSJD85Bj8KNnSsrqOK-fk6jvXfQyq0uDjNNr05kFdbf2Yb8jReIuXJYH',
                   title,
                    message)
                return Response({'message':'ok'})
                '''
                if member.device_token is not None:

                    send_message_to_token(member.device_token, self.title,self.message)
                    # send_message_to_token('d_UghULZIzc:APA91bGRDDvRNnz0SVW61crRauippT2gB7rAiy3VCEWBVSC-_1hQ6IDt-uwGMfG9vnm1ejQze6L-8NIUk5JIrv4bY6JX5UhBGv1xmI7gKAx4P5aE7R4YP4_RJgNoseK5gmBS_XxSCMtF', 'Taro Bobo Promotion',"30% off for all Taro Bobo products for APP ordering, during 19/2-25/2.Don't miss it.")
                    time.sleep(1)
                    i = i + 1
                    print(member.mobile_no + '    id:' + str(member.id) + '    count:' + str(i))


@api_view(['GET','POST'])
@authentication_classes([])
@permission_classes((AllowAny,))

def balance(request, *args, **kwargs):
    record_wallet_balance()
    return HttpResponse(json.dumps({'Status': 'Ok'}))

@api_view(['GET','POST'])
@authentication_classes([])
@permission_classes((AllowAny,))

def balance_record(request, *args, **kwargs):
    record_wallet_balance()
    '''
    # wirecard
    sql = "select sum(money) from app01_RechargeRecord where type=0 and status=1 and (request_id is not null and \"grab_txID\" is null) and (money=10 or money=20 or money=50) and to_char(created,'yyyy-mm-dd')=to_char(current_date,'yyyy-mm-dd')"
    cursor = connection.cursor()
    cursor.execute(sql)
    row = cursor.fetchall()
    if row:
        if row[0][0] is not None:
            wirecard_topup_money = row[0][0]
        else:
            wirecard_topup_money = 0.0
    else:
        wirecard_topup_money = 0.0

    # grabpay
    sql = "select sum(money) from app01_RechargeRecord where type=0 and status=1 and (request_id is not null and \"grab_txID\" is not null) and (money=10 or money=20 or money=50) and to_char(created,'yyyy-mm-dd')=to_char(current_date,'yyyy-mm-dd')"
    cursor = connection.cursor()
    cursor.execute(sql)
    row = cursor.fetchall()
    if row:
        if row[0][0] is not None:
            grabpay_topup_money = row[0][0]
        else:
            grabpay_topup_money = 0.0
    else:
        grabpay_topup_money = 0.0

    # outlet
    sql = "select sum(money) from app01_topuprecord where to_char(created_date,'yyyy-mm-dd')=to_char(current_date,'yyyy-mm-dd')"
    cursor = connection.cursor()
    cursor.execute(sql)
    row = cursor.fetchall()
    if row:
        if row[0][0] is not None:
            outlet_topup_money = row[0][0]
        else:
            outlet_topup_money = 0.0
    else:
        outlet_topup_money = 0.0
    sum_topup_money = wirecard_topup_money + grabpay_topup_money + outlet_topup_money

    # wallet sumAmount
    #sql="select  sum(app01_transaction.total_money)  from app01_transaction   where to_char(app01_transaction.payment_datetime,'yyyy-mm-dd')=to_char(current_date,'yyyy-mm-dd')  and app01_transaction.transaction_status in (4,5) and  payment_modes=8 "
    sql = "select sum(money) from app01_rechargerecord where type in (1) and to_char(created,'yyyy-mm-dd')=to_char(current_date ,'yyyy-mm-dd') "
    cursor = connection.cursor()
    cursor.execute(sql)
    row = cursor.fetchall()
    if row:
        if row[0][0] is not None:
            sum_payment = row[0][0]
        else:
            sum_payment = 0.0
    else:
        sum_payment = 0.0
    # cashback
    sql = "select sum(money) from app01_rechargerecord where type in (3) and to_char(created,'yyyy-mm-dd')=to_char(current_date ,'yyyy-mm-dd') "
    cursor = connection.cursor()
    cursor.execute(sql)
    row = cursor.fetchall()
    if row:
        if row[0][0] is not None:
            cashback = row[0][0]
        else:
            cashback = 0.0
    else:
        cashback = 0.0
    # cashback deduction
    sql = "select sum(money) from app01_rechargerecord where type in (4) and to_char(created,'yyyy-mm-dd')=to_char(current_date ,'yyyy-mm-dd') "
    cursor = connection.cursor()
    cursor.execute(sql)
    row = cursor.fetchall()
    if row:
        if row[0][0] is not None:
            cashback_deduction = row[0][0]
        else:
            cashback_deduction = 0.0
    else:
        cashback_deduction = 0.0
    cashback=cashback-cashback_deduction
    # refund
    sql = "select sum(money) from app01_rechargerecord where type in (2) and to_char(created,'yyyy-mm-dd')=to_char(current_date ,'yyyy-mm-dd') "
    cursor = connection.cursor()
    cursor.execute(sql)
    row = cursor.fetchall()
    if row:
        if row[0][0] is not None:
            refund = row[0][0]
        else:
            refund = 0.0
    else:
        refund = 0.0

    increase_decrease_value = sum_topup_money + cashback+refund - sum_payment

    # yesterday iPay wallet balance
    sql = "select balance from app01_walletbalance where to_char(record_date,'yyyy-mm-dd')=to_char(current_date-interval '1' day ,'yyyy-mm-dd')"
    cursor = connection.cursor()
    cursor.execute(sql)
    row = cursor.fetchall()
    if row:
        if row[0][0] is not None:
            yesterday_wallet_balance = row[0][0]
        else:
            yesterday_wallet_balance = 0.0
    else:
        yesterday_wallet_balance = 0.0
    # iPay wallet  balance(test)
    sql = "select sum(balance) from app01_wallet where member_id in (95,383,822,27,881,529,2749,102,1028,3458,621,952) "
    cursor = connection.cursor()
    cursor.execute(sql)
    row = cursor.fetchall()
    if row:
        if row[0][0] is not None:
            wallet_test_balance = row[0][0]
        else:
            wallet_test_balance = 0.0
    else:
        wallet_test_balance = 0.0

    # iPay wallet balance
    sql = "select sum(balance) from app01_wallet "
    cursor = connection.cursor()
    cursor.execute(sql)
    row = cursor.fetchall()
    if row:
        if row[0][0] is not None:
            wallet_balance = row[0][0]
        else:
            wallet_balance = 0.0
    else:
        wallet_balance = 0.0
    add_redecue_balance = getFloat(increase_decrease_value)
    if (add_redecue_balance > 0):
        incre_decre_value = '+' + str(add_redecue_balance)
    else:
        incre_decre_value = '' + str(add_redecue_balance)
    different_value=getFloat(wallet_balance - (yesterday_wallet_balance + add_redecue_balance))
    if different_value>0:
        str_different_value='+'+str(different_value)
    else:
        str_different_value = '' + str(different_value)
    table = "<table border='1' cellspacing='0' style='text-align:center' ><tr><td colspan='11'  style='text-align:center' >Wallet Balance</td><td rowspan='2'>Test Account Balance</td></tr><tr><td>topup (GrabPay)</td><td>topup (CreditCard)</td><td>topup (outlet)</td><td>topup (all)</td><td>wallet payment</td><td>cash back</td><td>refund</td><td>Change Amount</td><td>Yesterday Balance</td><td>Today Balance</td><td>Differential Amount</td></tr>" + "<tr><td>" + str(
        getFloat(grabpay_topup_money)) + "</td><td>" + str(
        getFloat(wirecard_topup_money)) + "</td><td>" + str(
        getFloat(outlet_topup_money)) + "</td><td>" + str(
        getFloat(sum_topup_money)) + "</td><td>" + str(getFloat(sum_payment)) + "</td><td>" + str(
        getFloat(cashback)) + "</td><td>"+str(getFloat(refund))+"</td><td>" + incre_decre_value + "</td><td>" + str(
        getFloat(yesterday_wallet_balance)) + "</td><td>" + str(getFloat(wallet_balance)) + "</td><td><font color='red'>" + str_different_value + "</font></td><td>" + str(
        getFloat(wallet_test_balance)) + "</tr></table>"
    utils.send_register_email(utils.RECEIVE_MAIL, table, send_type="balance", promotion='')
'''
    return HttpResponse(json.dumps({'Status': 'Ok'}))

def getFloat(f):

    g = '%.2f' % f
    return float(g)

def getdate( beforeOfDay):
    today = datetime.datetime.now()
    # 计算偏移量
    offset = datetime.timedelta(days=-beforeOfDay)
    # 获取想要的日期的时间
    re_date = (today + offset).strftime('%Y-%m-%d')
    return re_date


@api_view(['GET','POST'])
@authentication_classes([])
@permission_classes((AllowAny,))

def count_purchase_1(request, *args, **kwargs):
    count_purchase()
    '''
    week_day=[7,6,5,4,3,2,1,0]
    query_times=[1,2,3,4,5]
    table="<table border='1' cellspacing='0' style='text-align:center' ><tr><td colspan='9'  style='text-align:center' >Purchase Times Count</td></tr>"
    thead="<tr><td>times</td>"
    for day in week_day:
        thead=thead+"<td>"+getdate(day)+"</td>"
    thead=thead+"</tr>"
    table=table+thead

    for times in query_times:
         tbody = ""
         if times!=5:
             tbody = "<tr><td>"+str(times)+"</td>"
         else:
             tbody = "<tr><td>" + '>='+str(times) + "</td>"
         for day in week_day:
             if times!=5:
                 sql = "select count(temp.m_count) from (select count(*) as m_count,member_id from app01_transaction where  transaction_status in (4,5)  and to_char(app01_transaction.payment_datetime,'yyyy-mm-dd')<='"+getdate(day)+"'  group by member_id order by member_id asc) as temp where temp.m_count="+str(times)
             else:
                 sql = "select count(temp.m_count) from (select count(*) as m_count,member_id from app01_transaction where  transaction_status in (4,5)  and to_char(app01_transaction.payment_datetime,'yyyy-mm-dd')<='"+getdate(day)+"'  group by member_id order by member_id asc) as temp where temp.m_count>="+str(times)

             cursor = connection.cursor()
             cursor.execute(sql)
             row = cursor.fetchall()
             if row:
                 if row[0][0] is not None:
                     p_times = row[0][0]
                 else:
                     p_times = 0.0
             tbody=tbody+"<td>"+str(p_times)+"</td>"
         tbody=tbody+"</tr>"
         table =table+tbody
    table=table+"</table>"
    #print(table)
    utils.send_register_email(utils.RECEIVE_MAIL, table, send_type="purchase", promotion='')
'''
    return HttpResponse(json.dumps({'Status': 'Ok'}))

@api_view(['GET','POST'])
@authentication_classes([])
@permission_classes((AllowAny,))

def bind_voucher(request, *args, **kwargs):
    member_id=request.query_params.get('member_id')
    if member_id:
        member=models.Member.objects.filter(id=member_id).first()
        if member:
            dispatch_invicode(member)

    return HttpResponse(json.dumps({'Status': 'Ok'}))

@api_view(['GET','POST'])
@authentication_classes([])
@permission_classes((AllowAny,))

def erpGoodsCount(request, *args, **kwargs):

    try:

        #response = requests.get("http://47.74.156.85:8008/api/v1/card/sendMessage/")
        response = requests.get("http://127.0.0.1:8008/api/v1/card/sendMessage/",headers={'Authorization':'Token fa3c5db850ada70422a02e4638984dc08822f010'})

        #return json.loads(response.text)
    except Exception as e:
        return {'msg': 'error'}
    return HttpResponse(json.dumps({'Status': 'Ok'}))

@api_view(['GET','POST'])
@authentication_classes([])
@permission_classes((AllowAny,))

def erpOrderCount(request, *args, **kwargs):

    try:

        #response = requests.get("http://47.74.156.85:8008/api/v1/card/getPos/")
        checks = check_server('47.74.156.85', 8008, 'api/v1/card/getPosCompare/')
        check_result_1 = checks.check()
        #response = requests.get("http://127.0.0.1:8008/api/v1/card/getPos/",headers={'Authorization':'Token fa3c5db850ada70422a02e4638984dc08822f010'})

        #return json.loads(response.text)
    except Exception as e:
        return {'msg': 'error'}
    return HttpResponse(json.dumps({'Status': 'Ok'}))
@api_view(['GET','POST'])
@authentication_classes([])
@permission_classes((AllowAny,))

def testConfirm(request, *args, **kwargs):

    auto_confirm()
    #modify_opening_time()
    return HttpResponse(json.dumps({'Status': 'Ok'}))

@api_view(['GET','POST'])
@authentication_classes([])
@permission_classes((AllowAny,))

def dealInvitationCode(request, *args, **kwargs):
        pass















