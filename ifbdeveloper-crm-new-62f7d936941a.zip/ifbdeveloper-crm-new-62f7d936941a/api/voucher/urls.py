from django.urls import path, include
from rest_framework.routers import DefaultRouter
from . import views



voucher_router = DefaultRouter()
voucher_router.register('reward_voucher_list', views.RewardVoucherViewSet, base_name='reward_voucher_list')
voucher_router.register('', views.VoucherViewSet)

urlpatterns = [
    path('', include(voucher_router.urls)),
]
