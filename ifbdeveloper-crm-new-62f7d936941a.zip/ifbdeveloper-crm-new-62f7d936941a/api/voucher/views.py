from rest_framework import viewsets
from utils.pagination import DefaultPagination
from app01 import models
from . import serializers
from django_filters.rest_framework import DjangoFilterBackend
from rest_framework.filters import SearchFilter, OrderingFilter
from .permissions import VoucherViewSetPermission
from django_filters import rest_framework as filters
from django_filters import Filter,FilterSet
from django_filters.fields import Lookup
from django.db import connection
import json
import qrcode


class IntegerListFilter(Filter):
    def filter(self,qs,value):
     if value not in (None,''):
      integers = [int(v) for v in value.split(',')]
      return qs.filter(**{'%s__%s'%(self.field_name, self.lookup_expr):integers})
     return qs
class MyFilter(FilterSet):
    min_effective_date = filters.DateTimeFilter(field_name="effective_date", lookup_expr='gte')
    max_effective_date = filters.DateTimeFilter(field_name="effective_date", lookup_expr='lte')
    min_expiring_date = filters.DateTimeFilter(field_name="expiring_date", lookup_expr='gte')
    max_expiring_date = filters.DateTimeFilter(field_name="expiring_date", lookup_expr='lte')
    type = IntegerListFilter(field_name='type',lookup_expr='in')
    state = IntegerListFilter(field_name='state', lookup_expr='in')
    class Meta:
        model = models.Voucher
        fields = ('state', 'type', 'min_effective_date', 'max_effective_date', 'min_expiring_date',
               'max_expiring_date')
class ListFilter(Filter):
    def filter(self, qs, value):
        #修改
        #value_list = value.split(u',')
        '''
        value_list = value.split(u',')
        return super(ListFilter, self).filter(qs, Lookup(value_list, 'in'))
       '''
        if value not in (None,''):
            value_list = value.split(u',')
            return super(ListFilter, self).filter(qs, Lookup(value_list, 'in'))

        return  qs



class VoucherFilter(filters.FilterSet):
    #修改name为field_name
    min_effective_date = filters.DateTimeFilter(field_name="effective_date", lookup_expr='gte')
    max_effective_date = filters.DateTimeFilter(field_name="effective_date", lookup_expr='lte')
    min_expiring_date = filters.DateTimeFilter(field_name="expiring_date", lookup_expr='gte')
    max_expiring_date = filters.DateTimeFilter(field_name="expiring_date", lookup_expr='lte')
    type = ListFilter(field_name="type", lookup_expr='icontains')
    state = ListFilter(field_name="state", lookup_expr='icontains')


    class Meta:
        model = models.Voucher
        fields = ('state', 'type', 'min_effective_date', 'max_effective_date', 'max_expiring_date',
                  'max_expiring_date')


class VoucherViewSet(viewsets.ModelViewSet):
    permission_classes = (VoucherViewSetPermission,)
    queryset = models.Voucher.objects.all()
    serializer_class = serializers.VoucherSerializer
    pagination_class = DefaultPagination
    filter_backends = (
        DjangoFilterBackend,
        SearchFilter,
        OrderingFilter,
    )
    #filter_class = VoucherFilter
    filter_class = MyFilter
    search_fields = ('name',)
    ordering_fields = ['id']

    def get_queryset(self):
        self.queryset = self.queryset.prefetch_related(
            #'redemption_toppings',
            'redemption_products',
            'redemption_products_category',
            # 'size_upgrade_unparticipated_products',
            # 'discount_per_unparticipated_products',
            # 'discount_price_unparticipated_products',
            'unparticipated_outlets',
            #'limit_memberships'
        )

        return super(VoucherViewSet, self).get_queryset()
class RewardVoucherViewSet(viewsets.ModelViewSet):
    permission_classes = (VoucherViewSetPermission,)
    queryset = models.Voucher.objects.all()
    serializer_class = serializers.VoucherSerializer
    pagination_class = DefaultPagination
    filter_backends = (
        DjangoFilterBackend,
        SearchFilter,
        OrderingFilter,
    )
    #filter_class = VoucherFilter
    filter_class = MyFilter
    search_fields = ('name',)
    ordering_fields = ['id']

    def get_queryset(self):
        member_ship_list=models.Membership.objects.order_by('id')
        reward_voucher_list=[]
        if member_ship_list:
            for member_ship in member_ship_list:
                voucher_list=member_ship.complimentary_vouchers.all()
                if voucher_list:
                    for voucher in voucher_list:
                        reward_voucher_list.append(voucher.id)
            return self.queryset.filter(id__in=tuple(reward_voucher_list))
        return []
