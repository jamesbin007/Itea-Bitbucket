from django.urls import path, include
from rest_framework.routers import DefaultRouter
from . import views


#outlet url
router = DefaultRouter()
# add product status to outlet ---ff
router.register('outlet-product', views.OTProductViewSet, base_name='outlet-product')
router.register('outlet-name', views.OutletNameViewSet, base_name='outlet_name')
router.register('outlet-simple', views.OutletSimpleViewSet, base_name='outlet_simple')
router.register('outlet-category', views.OutletCategoryViewSet, base_name='outlet-category')
router.register('outlet-simple-cat', views.OutletSimpleCatViewSet, base_name='outlet-simple-cat')
router.register('outlet-simple-cat-test', views.OutletTestSimpleCatViewSet, base_name='outlet-simple-cat')
router.register('outlet-district', views.OutletDistrictViewSet, base_name='outlet_district')
router.register('size_topping_list', views.SizeToppingViewSet, base_name='size_topping_list')
router.register('outlet_opening_hours', views.Outlet_OpeningViewSet, base_name='outlet_opening_hours')
router.register('', views.OutletViewSet)

urlpatterns = [
    path('login_outlet/', views.LoginView.as_view(), name="login"),
    path('check_week/', views.modify_opening_time, name="check_week"),
    path('reward_mess/', views.reward_mess, name="reward_mess"),
    path('delivery_set/', views.delivery_set, name="delivery_set"),
    path('transfer_outlet/', views.transfer_outlet, name="transfer_outlet"),
    path('checkStock/', views.checkStock, name='checkStock'),
    path('get_size_topping_list/', views.size_topping_list, name='size_topping_list'),

    path('addDevice_token/', views.addDevice_token, name="addDevice_token"),
    path('register_machine_code/', views.register_machine_code, name="register_machine_code"),
    path('open_close_outlet/', views.open_close_outlet, name="open_close_outlet"),
    path('update_opening_hours/', views.update_opening_hours, name="update_opening_hours"),
    path('', include(router.urls)),

]
