from rest_framework import viewsets
from rest_framework.decorators import api_view
from rest_framework.response import Response

from utils.pagination import DefaultPagination
from app01 import models
from . import serializers
from django_filters.rest_framework import DjangoFilterBackend
from rest_framework.filters import SearchFilter, OrderingFilter
from .permissions import OutletViewSetPermission
from django_filters import rest_framework as filters
from django.db.models.functions import Coalesce
from django.db.models import Sum, Count, Avg,Q
from django_filters import Filter
from utils.permissions import IsAdmin
from rest_framework import generics
from rest_framework import status
from rest_framework.permissions import AllowAny
import datetime
from django.db import transaction
from rest_framework.decorators import api_view,authentication_classes,permission_classes
from utils.message_manage import send_message_to_token
from django.http import HttpResponse
import json

from django.core.serializers import serialize
from . import  serializers
from product.serializers import ProductSimpleSerializer
class ProductFilter(filters.FilterSet):
    category_name = filters.CharFilter(field_name="category__name", lookup_expr='icontains')

    tea_base = filters.CharFilter(field_name="tea_base", lookup_expr='icontains')

    class Meta:
        model = models.Product

        fields = ['category__name' ,'tea_base',]
class ListFilter(Filter):
    def filter(self, qs, value):
        if value not in (None,''):
            value_list = [v for v in value.split(',')]
            return qs.filter(**{'%s__%s' % (self.field_name, self.lookup_expr): value_list})
        return qs


class OutletFilter(filters.FilterSet):
    outlet_name = ListFilter(field_name="outlet_name", lookup_expr='icontains')
    id = filters.CharFilter(field_name="id", lookup_expr='exact')
    outlet_district = filters.CharFilter(field_name="outlet_district", lookup_expr='icontains')
    outlet_has_spicy_pot= filters.CharFilter(field_name="outlet_has_spicy_pot", lookup_expr='exact')
    pickup_choice=filters.CharFilter(field_name="pickup_choice", lookup_expr='exact')
    pickup_choice_list = ListFilter(field_name="pickup_choice", lookup_expr='in')
    can_transfer=filters.CharFilter(field_name="can_transfer", lookup_expr='exact')
    class Meta:
        model = models.Outlet
        fields = ('outlet_name', 'outlet_district','outlet_has_spicy_pot','id','pickup_choice','can_transfer')


class OutletOpeningFilter(filters.FilterSet):

    outlet_id = filters.CharFilter(field_name="outlet__id", lookup_expr='exact')

    class Meta:
        model = models.Outlet_Opening
        fields = ('outlet_id', )
# add  product status to Outlet Filter  -- ff
class OTProductFilter(filters.FilterSet):

    class Meta:
        model = models.Product
        fields = "__all__"


# add  product status to outlet ---ff
class OTProductViewSet(viewsets.ModelViewSet):
    permission_classes = (OutletViewSetPermission,)
    queryset = models.Product.objects.all().order_by('id')
    serializer_class = serializers.OTProductSerializer
    pagination_class = DefaultPagination
    filter_backends = (
        DjangoFilterBackend,
        SearchFilter,
    )
    filter_class = OTProductFilter
    search_fields = ('outlet',)

    def get_queryset(self):
        return super(OTProductViewSet, self).get_queryset()

    def get_serializer_class(self):
        if self.request.method == "GET":
            return serializers.OTProductSerializer
        else:
            return super(OTProductViewSet, self).get_serializer_class()

    def create(self, request, *args, **kwargs):
        if self.request.method == "POST":
            product = request.data.get('id')
            instance = models.Product.objects.get(id=product)
            if (instance):
                instance.product_status = request.data.get('product_status')
                instance.save()
            else:
                instance = None
            return Response(serializers.OTProductSerializer(instance).data)


class Outlet_OpeningViewSet(viewsets.ModelViewSet):
    permission_classes = (OutletViewSetPermission,)
    queryset = models.Outlet_Opening.objects.all()
    serializer_class = serializers.Outlet_OpeningSerializer
    pagination_class = DefaultPagination
    filter_backends = (
        DjangoFilterBackend,
        SearchFilter,
        OrderingFilter,
    )
    filter_class = OutletOpeningFilter
    search_fields = ('outlet',)

#for mobile ordering
class OutletSimpleViewSet(viewsets.ModelViewSet):
    permission_classes = (OutletViewSetPermission,)
    authentication_classes=[]
    queryset = models.Outlet.objects.all()
    serializer_class = serializers.OutletSerializer
    pagination_class = DefaultPagination
    filter_backends = (
        DjangoFilterBackend,
        SearchFilter,
        OrderingFilter,
    )
    filter_class = OutletFilter
    search_fields = ('outlet_name',)

class OutletCategoryViewSet(viewsets.ModelViewSet):
    permission_classes = (OutletViewSetPermission,)
    authentication_classes = []
    queryset = models.Outlet.objects.all()
    serializer_class = serializers.OutletCategorySerializer
    pagination_class = DefaultPagination
    filter_backends = (
        DjangoFilterBackend,
        SearchFilter,
        OrderingFilter,
    )
    filter_class = OutletFilter
    search_fields = ( 'id','outlet_name',)
    def get_queryset(self):

        if (self.request.data.get('id')):
            list= models.Outlet.objects.filter(id=self.request.data.get('id'))
            if list:
                obj=list[0]
                return serializers.OutletCategorySerializer(obj)

        return super(OutletCategoryViewSet, self).get_queryset()

class OutletTestSimpleCatViewSet(viewsets.ModelViewSet):
    permission_classes = (OutletViewSetPermission,)
    authentication_classes=[]
    #queryset = models.Outlet.objects.all().filter(Q(id=13) | Q(id=31)| Q(id=12)| Q(id=11) | Q(id=15)| Q(id=34)| Q(id=14)| Q(id=21)| Q(id=20)| Q(id=23)| Q(id=16)| Q(id=35))
    #queryset = models.Outlet.objects.all()
    #queryset = models.Outlet.objects.all().filter(id=13)
    queryset = models.Outlet.objects.all()
    serializer_class = serializers.OutletCatSerializer
    pagination_class = DefaultPagination
    filter_backends = (
        DjangoFilterBackend,
        SearchFilter,
        OrderingFilter,
    )
    filter_class = OutletFilter
    search_fields = ('outlet_name',)

class OutletSimpleCatViewSet(viewsets.ModelViewSet):
    permission_classes = (OutletViewSetPermission,)
    authentication_classes = []
    #queryset = models.Outlet.objects.all().filter(Q(id=13) | Q(id=31)| Q(id=12)| Q(id=11) | Q(id=15)| Q(id=34)| Q(id=14)| Q(id=21)| Q(id=20)| Q(id=23)| Q(id=16)| Q(id=35))
    #queryset = models.Outlet.objects.all()
    #queryset = models.Outlet.objects.all().filter(id=13)
    queryset = models.Outlet.objects.all().filter(visiable=True)
    serializer_class = serializers.OutletCatSerializer
    pagination_class = DefaultPagination
    filter_backends = (
        DjangoFilterBackend,
        SearchFilter,
        OrderingFilter,
    )
    filter_class = OutletFilter
    search_fields = ('outlet_name',)
    '''
    def get_queryset(self):

        if (self.request.GET.get('id')):
            list= models.Outlet.objects.filter(id=self.request.GET.get('id'))
            if list:
                obj=list[0]
                return serializers.OutletCatSerializer(obj)
        if (self.request.GET.get('outlet_name')):
            list= models.Outlet.objects.filter(outlet_name=self.request.GET.get('outlet_name'))
            if list:
                obj=list[0]
                return serializers.OutletCatSerializer(obj)
        if (self.request.GET.get('outlet_district')):
            list= models.Outlet.objects.filter(id=self.request.GET.get('outlet_district'))
            if list:
                obj=list[0]
                return serializers.OutletCatSerializer(obj)
        if (self.request.GET.get('outlet_has_spicy_pot')):
            list= models.Outlet.objects.filter(id=self.request.GET.get('outlet_has_spicy_pot'))
            if list:
                obj=list[0]
                return serializers.OutletCatSerializer(obj)
        return super(OutletSimpleCatViewSet, self).get_queryset()
'''

class OutletViewSet(viewsets.ModelViewSet):
    permission_classes = (OutletViewSetPermission,)
    queryset = models.Outlet.objects.all()
    serializer_class = serializers.OutletSerializer
    pagination_class = DefaultPagination
    filter_backends = (
        DjangoFilterBackend,
        SearchFilter,
        OrderingFilter,
    )
    filter_class = OutletFilter
    search_fields = ('outlet_name',)

    def get_queryset(self):
        #self.queryset = self.queryset.prefetch_related('transaction__evaluation','outlet_scheme').annotate(satisfaction=Coalesce(Avg('transaction__evaluation__service_satisfaction'), 0))
        return super(OutletViewSet, self).get_queryset()


class OutletNameViewSet(viewsets.ReadOnlyModelViewSet):
    permission_classes = (IsAdmin,)
    queryset = models.Outlet.objects.all().only('id', 'outlet_name').distinct('outlet_name')
    serializer_class = serializers.OutletNameSerializer
    pagination_class = DefaultPagination
    filter_backends = (
        DjangoFilterBackend,
        SearchFilter,
        OrderingFilter,
    )


class OutletDistrictViewSet(viewsets.ReadOnlyModelViewSet):
    permission_classes = (IsAdmin,)
    queryset = models.Outlet.objects.all().only('id', 'outlet_district').distinct('outlet_district')
    serializer_class = serializers.OutletDistrictSerializer
    pagination_class = DefaultPagination
    filter_backends = (
        DjangoFilterBackend,
        SearchFilter,
        OrderingFilter,
    )

class LoginView(generics.GenericAPIView):
    authentication_classes = ()
    permission_classes = (AllowAny,)
    serializer_class = serializers.OutletSerializer

    def post(self, request, *args, **kwargs):
        #serializer = self.get_serializer(data=request.data)
        #serializer.is_valid(raise_exception=True)
        #token = serializer.save()

        username = request.data.get("username")
        password = request.data.get("password")
        outlet_list=models.Outlet.objects.filter(outlet_manager__iexact=username.strip(),outlet_pass__iexact=password.strip())
        if outlet_list:
            outlet=outlet_list[0]
            return Response({'id':outlet.id,'outlet_name':outlet.outlet_name,'outlet_tel':outlet.outlet_tel,'outlet_address':outlet.outlet_address})
        else:
            return  Response(None)

class SizeToppingViewSet(viewsets.ModelViewSet):
    permission_classes = (OutletViewSetPermission,)
    queryset = models.Product.objects.all()
    serializer_class = ProductSimpleSerializer
    pagination_class = DefaultPagination
    filter_backends = (
        DjangoFilterBackend,
        SearchFilter,
        OrderingFilter,
    )
    filter_class = ProductFilter
    search_fields = ('name',)

    def get_queryset(self):
        outlet_id = self.request.GET.get('outlet_id')
        if (self.request.GET.get('outlet_id') != ''):
                list = models.Product.objects.filter((Q(group_name='Size') | Q(group_name='Topping')| Q(group_name='Ice')),outlet__id=outlet_id)
                return list
        return super(SizeToppingViewSet, self).get_queryset()

@api_view(['GET', 'POST'])
@authentication_classes([])
@permission_classes((AllowAny,))
def reward_mess(request, *args, **kwargs):
    if request.method=="POST":
        mobile_no = request.data.get("mobile_no")
        mess_title = request.data.get("mess_title")
        mess_content = request.data.get("mess_content")
        member = models.Member.objects.filter(mobile_no=mobile_no).first()
        if member:
            print(member.device_token)
            send_message_to_token(member.device_token,mess_title,mess_content)
            return Response({'msg':'ok'})

    return Response({'msg': 'error'})

@api_view(['GET', 'POST'])
@authentication_classes([])
@permission_classes((AllowAny,))
def modify_opening_time(request, *args, **kwargs):
    #models.Product.objects.all().update(product_status=True)
    now=datetime.datetime.now()
    day_week = now.weekday()
    now_date=now.date()
    now_date_str=datetime.datetime.strftime(now_date, "%Y-%m-%d")
    now_month_day=now_date_str[5:]
    print(now_date)
    print(now_month_day)
    print(day_week)
    holiday_flag=False
    is_holiday=models.Holiday.objects.filter(holiday=now_month_day)
    if is_holiday:
        holiday_flag=True
    outlet_list=models.Outlet.objects.all()
    print(holiday_flag)
    if outlet_list:
        with transaction.atomic():
            for item in outlet_list:
                outlet_id=item.id
                week_data=models.Outlet_Opening.objects.filter(outlet__id=outlet_id,week_num=day_week).first()

                if week_data:
                    if holiday_flag:
                        holiday_data = models.Outlet_Opening.objects.filter(outlet__id=outlet_id, week_num=7).first()
                        if holiday_data:
                            item.outlet_opentime = holiday_data.open_time
                            item.outlet_closetime = holiday_data.close_time
                            item.save()
                        else:
                            item.outlet_opentime = week_data.open_time
                            item.outlet_closetime = week_data.close_time
                            item.save()
                    else:


                        item.outlet_opentime=week_data.open_time
                        item.outlet_closetime=week_data.close_time
                        item.save()




    return Response(None)

@api_view(['GET', 'POST'])
@authentication_classes([])
@permission_classes((AllowAny,))
def delivery_set(request, *args, **kwargs):
    amount = request.GET.get('amount')
    distance = request.GET.get('distance')
    outlet_id = request.GET.get('outlet_id')
    delivery_amount=0
    set={}
    if outlet_id:
        delivery_set=models.DeliverySet.objects.filter(outlet__id=outlet_id).first()
    else:
        delivery_set = models.DeliverySet.objects.all().first()
    if delivery_set is None:
        delivery_set = models.DeliverySet.objects.all().first()

    return Response(serializers.DeliverySetSerializer(delivery_set).data)

@api_view(['GET', 'POST'])
@authentication_classes([])
@permission_classes((AllowAny,))
def transfer_outlet(request, *args, **kwargs):
    order_id = request.GET.get('order_id')
    transfer_id = request.GET.get('transfer_id')

    trans_obj=models.Transaction.objects.filter(id=order_id).first()
    if trans_obj:
        if trans_obj.outlet:
             temp_outlet=trans_obj.outlet
             transfer_to_obj=models.Outlet.objects.filter(id=transfer_id).first()
             if transfer_to_obj:
                 if(trans_obj.transaction_status==4):
                     trans_obj.transaction_status=2
                 trans_obj.print_status=False
                 trans_obj.outlet=transfer_to_obj
                 trans_obj.transfer_outlet=temp_outlet

                 trans_obj.save()
                 return Response({'msg':'ok'})
             #trans_obj.outlet=

    return Response({'msg':'error'})

@api_view(['GET','POST'])
@authentication_classes([])
@permission_classes((AllowAny,))
def checkStock(request, *args, **kwargs):
    order_id = request.GET.get('order_id')
    if order_id:
        product_list=[]
        size_list=[]
        topping_list=[]
        transaction = models.Transaction.objects.filter(id=order_id).first()

        if transaction:
            outlet=transaction.outlet
            if outlet:
                size_topping_list=models.Product.objects.filter((Q(group_name='Size') | Q(group_name='Topping')),outlet__id=outlet.id)
            transact_list=models.TransactDetails.objects.filter(transaction__id=transaction.id)
            if transact_list:
                for item in transact_list:
                    if item.transactDetails_type==0:
                        product=item.product
                        if product:
                            if product.tea_base is not None and product.tea_base!='':
                                pass
                            else:
                                size_list.append(item.size)
                                sel_topping_list=item.toppings.all()
                                if sel_topping_list:
                                    for sel_topping in sel_topping_list:
                                         topping_list.append(sel_topping)
                            product_list.append(product)
            size_list=list(set(size_list))
            topping_list=list(set(topping_list))
            if product_list:
                for p_item in product_list:
                    if p_item.product_status==False:
                        return HttpResponse(json.dumps({'msg': p_item.name+' sold out!'}))
            if size_topping_list:
                if size_list:
                    for size in size_list:
                        if size==0:
                            size_name='size_medium'
                        elif size==1:
                            size_name='size_large'
                        elif size==2:
                            size_name = 'size_tall'
                        else:
                            size_name=''
                        if size_name!='':
                            for size_product in size_topping_list:
                                if size_product.name==size_name:
                                    if size_product.product_status==False:
                                        return HttpResponse(json.dumps({'msg': 'Size '+size_product.description + ' sold out!'}))
                if topping_list:
                    topping_relation_list=[]
                    for topping_item in topping_list:
                        topping_relation_list.append(topping_item.relation_name)
                    if topping_relation_list:
                        for relation_name in topping_relation_list:
                            for topping_product in size_topping_list:
                                if relation_name==topping_product.name:
                                    if topping_product.product_status==False:
                                        return HttpResponse(
                                            json.dumps({'msg': 'Topping ' + topping_product.description + ' sold out!'}))






    return HttpResponse(json.dumps({'msg': 'ok'}))
@api_view(['GET','POST'])
@authentication_classes([])
@permission_classes((AllowAny,))
def size_topping_list(request, *args, **kwargs):
    outlet_id = request.GET.get('outlet_id')
    if outlet_id:
        size_topping_list = models.Product.objects.filter((Q(group_name='Size') | Q(group_name='Topping')),outlet__id=outlet_id)
        json_data = serialize('json', size_topping_list)  # str
        json_data = json.loads(json_data)
        return Response(json_data)

# add outlet tablet device token for message push

@api_view(['GET', 'POST'])
@authentication_classes([])
@permission_classes((AllowAny,))
def addDevice_token(request, *args, **kwargs):

    if request.method == 'POST':
        outlet_id=request.data.get('outlet_id')
        device_token = request.data.get('device_token')

        if outlet_id:
            outlet = models.Outlet.objects.get(id=outlet_id)

            if outlet:
                outlet.device_token=device_token

                outlet.save()
                return Response({
                    'msg': 'ok',
                    'device_token':device_token,

                }, status=status.HTTP_201_CREATED)
            else:
                return Response({
                    'msg': 'error'
                }, status=status.HTTP_201_CREATED)

@api_view(['GET', 'POST'])
@authentication_classes([])
@permission_classes((AllowAny,))
def register_machine_code(request, *args, **kwargs):
    if request.method == 'POST':
        outlet_name = request.data.get('outlet_name')
        machine_code = request.data.get('machine_code')
        if outlet_name is not None and machine_code is not None:
            if machine_code!='':
                machine_code_obj=models.TabletMachineCode.objects.filter(machine_code=machine_code).first()
                if machine_code_obj:
                    return Response({
                        'msg': 'ok',

                    }, status=status.HTTP_201_CREATED)
                else:
                    tablet_login_status_obj=models.TabletLoginStatus.objects.filter(status=True).first()
                    if tablet_login_status_obj:
                        models.TabletMachineCode.objects.create(outlet_name=outlet_name,machine_code=machine_code)
                        return Response({
                            'msg': 'ok',

                        }, status=status.HTTP_201_CREATED)
    return Response({'msg': 'error'}, status=status.HTTP_200_OK)

@api_view(['GET', 'POST'])
@authentication_classes([])
@permission_classes((AllowAny,))
def open_close_outlet(request, *args, **kwargs):

    if request.method == 'POST':
        outlet_id=request.data.get('outlet_id')
        outlet_status = request.data.get('outlet_status')

        if outlet_id:
            outlet = models.Outlet.objects.get(id=outlet_id)

            if outlet:
                outlet.closed=outlet_status

                outlet.save()
                return Response({
                    'msg': 'ok',
                    'closed':outlet_status,

                }, status=status.HTTP_201_CREATED)
            else:
                return Response({
                    'msg': 'error'
                }, status=status.HTTP_201_CREATED)
        return Response({'msg': 'error'}, status=status.HTTP_201_CREATED)

@api_view(['GET', 'POST'])
@authentication_classes([])
@permission_classes((AllowAny,))
def update_opening_hours(request, *args, **kwargs):

    if request.method == 'GET':
        week_day=datetime.datetime.now().weekday()
        print(week_day)
        outlet_id = request.GET.get('outlet_id')
        week_num = request.GET.get('week_num')
        open_time = request.GET.get('open_time')
        close_time = request.GET.get('close_time')

        if str(week_day)==week_num:
            outlet_item = models.Outlet.objects.filter(id=outlet_id).first()
            if open_time:
                temp_close_time=outlet_item.outlet_closetime
                if temp_close_time:
                    if temp_close_time<=open_time:
                        return Response({'msg': 'Close hours must more than open hours'},status=status.HTTP_201_CREATED)
                outlet_item.outlet_opentime=open_time
            if close_time:
                temp_open_time=outlet_item.outlet_opentime
                if temp_open_time:
                    if close_time<=temp_open_time:
                        return Response({'msg': 'Close hours must more than open hours'}, status=status.HTTP_201_CREATED)
                outlet_item.outlet_closetime=close_time
            outlet_item.save()
        if outlet_id:
            outlet_opening = models.Outlet_Opening.objects.filter(outlet__id=outlet_id,week_num=week_num).first()

            if outlet_opening:
                if open_time:
                    temp_close_time = outlet_opening.close_time
                    if temp_close_time:
                        if temp_close_time <= open_time:
                            return Response({'msg': 'Close hours must more than open hours'},
                                            status=status.HTTP_201_CREATED)
                    outlet_opening.open_time = open_time
                if close_time:
                    temp_open_time = outlet_opening.open_time
                    if temp_open_time:
                        if close_time <= temp_open_time:
                            return Response({'msg': 'Close hours must more than open hours'},
                                            status=status.HTTP_201_CREATED)
                    outlet_opening.close_time = close_time
                outlet_opening.save()
                return Response({
                    'msg': 'ok',


                }, status=status.HTTP_201_CREATED)
            else:
                outlet=models.Outlet.objects.filter(id=outlet_id).first()
                if open_time:
                    temp_open_time=open_time
                else:
                    temp_open_time="10:00"
                if close_time:
                    temp_close_time=close_time
                else:
                    temp_close_time="21:00"
                outlet_opening=models.Outlet_Opening(outlet=outlet,open_time=temp_open_time,close_time=temp_close_time,week_num=week_num)
                outlet_opening.save()
                return Response({
                    'msg': 'ok',
                }, status=status.HTTP_201_CREATED)
        return Response({'msg': 'error'}, status=status.HTTP_201_CREATED)
