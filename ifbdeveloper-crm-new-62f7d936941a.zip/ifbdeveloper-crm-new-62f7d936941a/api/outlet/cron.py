from app01 import models
import datetime

from django.db.models import Count
from django.db import transaction
from member.services import update_membership, update_points,deal_electric_sign,update_member_points
from django.db import connection
from django.db.models import Q
import time

import os
import requests
import random
#from member.services import update_member_points *
def modify_opening_time():
    models.Product.objects.filter(~Q(long_sold_out=True),group_name='Product').update(product_status=True)
    #modify transaction_status=0
    now = datetime.datetime.now()
    list = models.Transaction.objects.filter(transaction_status=0,transact_datetime__lte=now+datetime.timedelta(days=-3))
    if list:
        for trans in list:
            if trans.redeem_invicode is not None and trans.redeem_invicode != 0:
                invicode = models.Invicode.objects.filter(id=trans.redeem_invicode).first()
                if invicode:
                    invicode.status = 1
                    invicode.save()
    models.Transaction.objects.filter(transaction_status=0,transact_datetime__lte=now+datetime.timedelta(days=-3)).update(transaction_status=1)

    day_week = now.weekday()
    now_date=now.date()
    now_date_str=datetime.datetime.strftime(now_date, "%Y-%m-%d")
    now_month_day=now_date_str[5:]
    print(now_date)
    print(now_month_day)
    print(day_week)
    holiday_flag=False
    is_holiday=models.Holiday.objects.filter(holiday=now_month_day)
    if is_holiday:
        holiday_flag=True
    outlet_list=models.Outlet.objects.all()
    print(holiday_flag)
    if outlet_list:
        with transaction.atomic():
            for item in outlet_list:
                outlet_id=item.id
                week_data=models.Outlet_Opening.objects.filter(outlet__id=outlet_id,week_num=day_week).first()

                if week_data:
                    if holiday_flag:
                        holiday_data = models.Outlet_Opening.objects.filter(outlet__id=outlet_id, week_num=7).first()
                        if holiday_data:
                            item.outlet_opentime = holiday_data.open_time
                            item.outlet_closetime = holiday_data.close_time
                            item.save()
                        else:
                            item.outlet_opentime = week_data.open_time
                            item.outlet_closetime = week_data.close_time
                            item.save()
                    else:


                        item.outlet_opentime=week_data.open_time
                        item.outlet_closetime=week_data.close_time
                        item.save()

def auto_confirm():

    now = datetime.datetime.now()
    with transaction.atomic():
        #pass
        #modify delay_time for delivery
        #result = models.Transaction.objects.filter(  transaction_status__in=(2,4,), print_status=False,delay_time__date=now.date()).update(delay_time=now)

        recent_list = models.Transaction.objects.filter(pick_up_type=0,transaction_status=2,delay_time__lte=datetime.datetime.now()+datetime.timedelta(minutes=3)).order_by('delay_time')
        if recent_list:
            for item in recent_list:
                receipt_no = ''
                '''
                isPot = False

                transDetailsList = models.TransactDetails.objects.filter(transaction__id=item.id)
                if transDetailsList:
                    for details in transDetailsList:
                        if details.transactDetails_type != 0:
                            isPot = True
                            break
                if not isPot:
                    receipt_no = ''
                else:
                    if item.outlet and item.outlet.id:
                        outlet = models.Outlet.objects.get(id=item.outlet.id)
                        if outlet:
                            
                            if outlet.outlet_count_date:
                                
                                if outlet.outlet_count_date == now.date():
                                    outlet_count = outlet.outlet_count
                                    
                                else:
                                    outlet.outlet_count_date = now.date()
                                    outlet.outlet_count = 1
                                    outlet.save()
                                    outlet_count = 1
                            else:
                                outlet.outlet_count_date = now.date()
                                outlet.outlet_count = 1
                                outlet.save()
                                outlet_count = 1
                            outlet_count_str = str(outlet_count) + ''
                            if len(outlet_count_str) == 1:
                                receipt_no = '000' + outlet_count_str
                            elif len(outlet_count_str) == 2:
                                receipt_no = '00' + outlet_count_str
                            elif len(outlet_count_str) == 3:
                                receipt_no = '0' + outlet_count_str

                            else:
                                receipt_no = outlet_count_str
                '''
                result = models.Transaction.objects.filter(id=item.id,transaction_status=2).update(receipt_no=receipt_no, transaction_status=4, confirm_time=now)
                '''
                if result:
                    # member update membership thread
                    #member=item.member
                    #update_member_points(member, item.total_money, 1, None, None)
                    if  isPot:
                        outlet_count += 1
                        outlet.outlet_count = outlet_count
                        outlet.save()
                '''
    auto_update()

def auto_update():
    with transaction.atomic():
        transas_list=models.Transaction.objects.filter(transaction_status=4,member_updated=False, delay_time__lt=datetime.datetime.now())
        if transas_list:
            for trans in transas_list:
                if trans.pick_up_type==0:

                    amount=trans.total_money
                    member=trans.member
                    deal_electric_sign(member, trans)
                    if amount>0:
                        if member:

                            update_member_points(member, amount, 1, None, None)
                    trans.member_updated = True
                    trans.save()
def prize_random():
    #prize_random_activity()
    #delete prize log yesterday
    models.PrizeCacheLog.objects.filter( created__date__lt=datetime.datetime.now().date() ).delete()
    #delete otp yesterday
    models.LoginOtp.objects.filter(expire_time__lt=datetime.datetime.now()).delete()
    # delete data
    models.PrizeProbability.objects.all().delete()
    number_list=[]
    for i in range(100):
        number_list.append(i+1)

    prizeClassSet = models.PrizeClassSet.objects.filter(activity_flag=False).order_by('id')
    if prizeClassSet:
        for item in prizeClassSet:
            probability=item.probability
            generate_number=int(probability*100)

            recent_list=random.sample(number_list,generate_number )

            if recent_list:
                for i in recent_list:
                    models.PrizeProbability.objects.create(prize_class_set=item,rand_number=i)
            temp_list = list(set(number_list) - set(recent_list))
            number_list=temp_list

def prize_random_activity():
    number_list=[]
    for i in range(100):
        number_list.append(i+1)

    prizeClassSet = models.PrizeClassSet.objects.filter(activity_flag=True).order_by('id')
    if prizeClassSet:
        for item in prizeClassSet:
            probability=item.probability
            generate_number=int(probability*100)

            recent_list=random.sample(number_list,generate_number )
            #delete data
            models.PrizeProbabilityActivity.objects.filter(prize_class_set__id=item.id).delete()
            if recent_list:
                for i in recent_list:
                    models.PrizeProbabilityActivity.objects.create(prize_class_set=item,rand_number=i)
            temp_list = list(set(number_list) - set(recent_list))
            number_list=temp_list

def puzzle_random():
    with transaction.atomic():
        # delete data
        models.PuzzleProbability.objects.all().delete()
        number_list=[]
        for i in range(100):
            number_list.append(i+1)

        puzzleClassSet = models.PuzzleImage.objects.filter(status=True).order_by('id')
        if puzzleClassSet:
            for item in puzzleClassSet:
                probability=item.probability
                generate_number=int(probability*100)

                recent_list=random.sample(number_list,generate_number )

                if recent_list:
                    for i in recent_list:
                        models.PuzzleProbability.objects.create(puzzle_image=item,rand_number=i)
                temp_list = list(set(number_list) - set(recent_list))
                number_list=temp_list