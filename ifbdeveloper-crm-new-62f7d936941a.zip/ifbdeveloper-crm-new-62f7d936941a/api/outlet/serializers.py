from rest_framework import serializers
from app01 import models
from django.db.models import Min,Avg,Max,Sum
import datetime
import time

# add  product status to Outlet (OutletProductSerializer, ProductStatusSerializer) -- ff
class OTProductSerializer(serializers.ModelSerializer):

    class Meta:
        model = models.Product
        fields = ('id', "name", "chinese_name", 'item_code', 'product_status', 'outlet_id')


class OutletSerializer(serializers.ModelSerializer):
    satisfaction = serializers.FloatField(required=False, allow_null=True)
    system_time = serializers.SerializerMethodField()
    class Meta:
        model = models.Outlet
        exclude = ('category',)

    def get_system_time(self, obj):
        dttime=datetime.datetime.now()
        return  int(time.mktime(dttime.timetuple())*1000)

class Outlet_OpeningSerializer(serializers.ModelSerializer):


    class Meta:
        model = models.Outlet_Opening
        fields = '__all__'


class OutletCategorySerializer(serializers.ModelSerializer):


    class Meta:
        model = models.Outlet
        fields = '__all__'
        depth=2


class OutletCatSerializer(serializers.ModelSerializer):
    top_category_id=serializers.SerializerMethodField()

    milk_top_id=models.Category.objects.filter(category_type=0).aggregate(minId=Min('id'))
    spicy_top_id=models.Category.objects.filter(category_type=1).aggregate(minId=Min('id'))

    class Meta:
        model = models.Outlet
        fields = '__all__'
    def get_top_category_id(self, obj):
        if obj.outlet_has_spicy_pot==0:
            return self.milk_top_id['minId']
        else:
            return self.milk_top_id['minId']
           # return self.spicy_top_id['minId']

class OutletNameSerializer(serializers.ModelSerializer):
    class Meta:
        model = models.Outlet
        fields = ['id', 'outlet_name']


class OutletDistrictSerializer(serializers.ModelSerializer):
    class Meta:
        model = models.Outlet
        fields = ['id', 'outlet_district']


class OutletPerformanceSerializer(serializers.ModelSerializer):
    products_sold = serializers.FloatField(required=False, allow_null=True)
    products_sold_incr = serializers.FloatField(required=False, allow_null=True)
    turnover = serializers.FloatField(required=False, allow_null=True)
    turnover_incr = serializers.FloatField(required=False, allow_null=True)

    class Meta:
        model = models.Outlet
        fields = '__all__'
class DeliverySetSerializer(serializers.ModelSerializer):


    class Meta:
        model = models.DeliverySet
        exclude=('outlet',)
        #fields = '__all__'
        depth=2

class DeliveryWeekTimesSerializer(serializers.ModelSerializer):


    class Meta:
        model = models.DeliveryWeekTimes
        fields = '__all__'
        depth=2
class DeliveryTimesSerializer(serializers.ModelSerializer):


    class Meta:
        model = models.DeliveryTimes
        fields = '__all__'