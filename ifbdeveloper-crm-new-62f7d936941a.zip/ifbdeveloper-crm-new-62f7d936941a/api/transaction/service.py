from utils.utils import transaction_wrapper
from app01 import models
from outlet.serializers import OutletSerializer
from django.db.models import Q,Sum,Count
from wallet.serializers import RechargeRecordCreateSerializer
from django.db import transaction
from utils.message_manage import send_message_to_token
import datetime,time
'''
@transaction_wrapper
def get_or_create_outlet(initial_data):
    if models.Outlet.objects.filter(outlet_code=initial_data.get('outlet_code')).exists():
        return models.Outlet.objects.get(outlet_code=initial_data.get('outlet_code'))
    serializer = OutletSerializer(data=initial_data)
    serializer.is_valid(raise_exception=True)
    instance = serializer.save()
    return instance
'''
@transaction_wrapper
def get_or_create_transact_details(id):
    # if models.TransactDetails.objects.filter(pk=id).exists():
        return models.TransactDetails.objects.get(pk=id)
    # return None
#first payment cash back
def first_payment_cash_back(trans_id,member_id):
    member = models.Member.objects.get(id=member_id)
    if member:
        count = models.Transaction.objects.filter(member__id=member_id, transaction_status=5).aggregate(count=Count('id'))
        if count:
            if (count['count']==1):
                trans=models.Transaction.objects.get(id=trans_id)
                if trans:
                    with transaction.atomic():
                        total_money=trans.total_money+trans.discount_amount
                        cash_back=total_money*0.1
                        cash_back_str = '%.2f' % cash_back
                        campaign_return = float(cash_back_str)
                        if (campaign_return > 0):
                            wallet = models.Wallet.objects.get(member__id=member_id)
                            wallet.balance += campaign_return
                            wallet.save()
                            serializer = RechargeRecordCreateSerializer(
                                data={'money': float(campaign_return),
                                      'wallet': wallet.id, 'type': 3,

                                      'status': 1})
                            if serializer.is_valid():
                                instance = models.RechargeRecord.objects.create(
                                    **serializer.validated_data)
                            # add campaign return cash to transaction record
                            if trans.campaign_return_wallet_cash:
                                trans.campaign_return_wallet_cash += campaign_return
                            else:
                                trans.campaign_return_wallet_cash = campaign_return
                            trans.save()
                            # send notification
                            device_token = member.device_token
                            if device_token:
                                send_message_to_token(device_token, 'First order successful', 'Reward 10% amount cash back')
                                return True

    return False

#payment send mail
def get_payment_mail_table(transactionObj,member,wallet_id,pay_method):
    now = datetime.datetime.now()
    # send mail
    # datetime.datetime.strftime('%Y-%m-%d %H:%M:%S',member.registration_date)  time.strftime("%Y-%m-%d %H:%M:%S", time.localtime())
    payment_count=models.Transaction.objects.filter(member__id=member.id, transaction_status__in=(2, 4, 5)).count()
    #print(member.id)
    member_register_code=''
    if member.register_code is None:
        member_register_code=''
    else:
        member_register_code = member.register_code

    details_list=models.TransactDetails.objects.filter(transaction__id=transactionObj.id)
    quantity=0
    if details_list:
        for details in details_list:
            quantity+=details.quantity

    wallet_obj=models.Wallet.objects.filter(member__id=transactionObj.member.id).first()
    if wallet_obj:
        wallet_balance=wallet_obj.balance
    else:
        wallet_balance=0


    origin_amount= transactionObj.total_money+transactionObj.discount_amount
    if transactionObj.redeem_invicode is not None and transactionObj.redeem_invicode!=0:
          invicode_obj=models.Invicode.objects.filter(id=transactionObj.redeem_invicode).first()
          if invicode_obj:
               voucher_name=invicode_obj.voucher.name
    else:
          voucher_name=''
    receipt_no=''
    if transactionObj.receipt_no:
        receipt_no = transactionObj.receipt_no

    delivery_time=''
    delivery_address=''
    if transactionObj.pick_up_type==1:
        if transactionObj.delivery_time:
            delivery_time=transactionObj.delivery_time
            delivery_address=transactionObj.delivery_address


    countTable = "<h4 style='text-align:center'  >Mobile ordering payment</h4><table border='1' cellspacing='0' style='text-align:center' ><tr><td colspan='13'  style='text-align:left' >order no:" + transactionObj.order_no + "</td></tr>"
    if delivery_address:
        countTable=countTable+"<tr><td colspan='13'  style='text-align:left' >delivery address:" + delivery_address + "</td></tr>"
    countTable=countTable+"<tr><td>member mobile</td><td>outlet</td><td>origin amount</td><td>amount</td><td>voucher</td><td>quantity</td><td>payment method</td><td>payment time </td><td>register time</td><td>delivery time</td><td>receipt_no</td><td>purchase times(sum)</td><td>wallet balance</td></tr><tr>" + \
    "<td>" + member.mobile_no + "</td><td>" + transactionObj.outlet.outlet_name + "</td><td>"+str(origin_amount)+"</td><td>" + str(
        transactionObj.total_money) + "</td><td>"+voucher_name+"</td><td>"+str(quantity)+"</td><td>" + \
                 pay_method + "</td><td>" + datetime.datetime.strftime(now,
                                                                         "%Y-%m-%d %H:%M:%S") + "</td><td>" + datetime.datetime.strftime(member.registration_date+datetime.timedelta(hours=8),
                                                                                      "%Y-%m-%d %H:%M:%S") + "</td><td>"+delivery_time+"</td><td>"+receipt_no+"</td><td>"+str(payment_count)+"</td><td>"+str(wallet_balance)+"</td></tr></table></br></br>"
    # 3 times purchase record
    third_purchase_table = "<table border='1' cellspacing='0' style='text-align:center' ><tr><td colspan='8'  style='text-align:center' >the latest 20 times payment</td></tr><tr><td>times</td><td>voucher</td><td>outlet</td><td>origin amount</td><td>amount</td><td>quantity</td><td>payment method</td><td>payment time </td></tr>"
    payment_list = models.Transaction.objects.filter(member__id=member.id, transaction_status__in=(2, 4, 5)).order_by(
        '-payment_datetime')[:20]
    payment_table_row = ""
    voucher = ""
    if payment_list:
        index = 1

        for item in payment_list:
            o_amount=item.total_money+item.discount_amount
            voucher = ''
            details_list = models.TransactDetails.objects.filter(transaction__id=item.id)
            quantity_1 = 0
            if details_list:
                for details in details_list:
                    quantity_1 += details.quantity
            #print(quantity_1)
            if item.redeem_invicode is not None and item.redeem_invicode != 0:
                invicode = models.Invicode.objects.filter(id=item.redeem_invicode).first()
                if invicode:
                    voucher = invicode.voucher.name
            if item.payment_modes == 8:
                payment_method="Wallet"
            elif  item.payment_modes == 9:
                payment_method = "Wirecard"
            elif  item.payment_modes == 12:
                payment_method = "GrabPay"
            payment_table_row = payment_table_row + "<tr><td>" + str(
                index) + "</td><td>" + voucher + "</td><td>" + item.outlet.outlet_name + "</td><td>"+str(o_amount)+"</td><td>" + str(
                item.total_money) + "</td><td>"+str(quantity_1)+"</td><td>"+payment_method+"</td><td>" + datetime.datetime.strftime(item.payment_datetime+datetime.timedelta(hours=8),
                                                                                            "%Y-%m-%d %H:%M:%S") + "</td></tr>"
            index = index + 1

    third_purchase_table = third_purchase_table + payment_table_row + "</table></br></br>"

    # 3 times topup record
    topup_count = models.RechargeRecord.objects.filter(wallet__id=wallet_id, type=0, money__gte=10).count()
    topup_table = "<table border='1' cellspacing='0' style='text-align:center' ><tr><td colspan='5'  style='text-align:center' >The latest 5 times top up</td></tr><tr><td>times</td><td>amount</td><td>payment method</td><td>payment time </td></tr>"
    topup_list = models.RechargeRecord.objects.filter(wallet__id=wallet_id, type=0, money__gte=10).order_by('-created')[
                 0:5]
    topup_row = ""
    topup_method = ""
    if topup_list:
        index_topup = 1
        for item in topup_list:
            if item.request_id is not None and item.grab_txID is not None:
                topup_method = "GrabPay"
            elif item.request_id is not None and item.grab_txID is None:
                topup_method = "Wirecard"
            elif item.request_id is None and item.grab_txID is None:
                topup_method = "Outlet"


            topup_row = topup_row + "<tr><td>" + str(index_topup) + "</td><td>" + str(
                item.money) + "</td>" + topup_method + "</td><td>" + datetime.datetime.strftime(item.created+datetime.timedelta(hours=8),
                                                                                                "%Y-%m-%d %H:%M:%S") + "</td></tr>"
            index_topup = index_topup + 1
    topup_table = topup_table + topup_row + "</table></br></br>"
    countTable = countTable + third_purchase_table + topup_table
    return countTable

#topup(mobile) send mail
def get_topup_mail_table(transactionObj,member,wallet_id,pay_method,amount):
    now = datetime.datetime.now()
    # send mail
    member_register_code = ''
    if member.register_code is None:
        member_register_code = ''
    else:
        member_register_code = member.register_code
    post_code = ''
    if member.post_code:
        post_code = member.post_code
    topup_count = models.RechargeRecord.objects.filter(wallet__id=wallet_id, type=0, money__gte=10).count()
    countTable = "<table border='1' cellspacing='0' style='text-align:center' ><tr><td colspan='7'  style='text-align:center' >Mobile top up payment</td></tr><tr><td>member mobile</td><td>amount</td><td>payment method</td><td>payment time </td><td>register time</td><td>post code</td><td>topup times(sum)</td></tr><tr>" + \
                 "<td>" + member.mobile_no + "</td><td>" + str(
        amount) + "</td><td>" + \
                 pay_method + "</td><td>" + time.strftime("%Y-%m-%d %H:%M:%S",
                                                              time.localtime()) + "</td><td>" + datetime.datetime.strftime(member.registration_date+datetime.timedelta(hours=8),
                                                                                      "%Y-%m-%d %H:%M:%S") +"</td><td>"+post_code+"</td><td>"+str(topup_count)+"</td></tr></table>"


    # 5 times topup record(Non Outlet)

    topup_table = "<table border='1' cellspacing='0' style='text-align:center' ><tr><td colspan='5'  style='text-align:center' >The latest 5 times top up(Non Outlet)</td></tr><tr><td>times</td><td>amount</td><td>payment method</td><td>payment time </td></tr>"
    topup_list = models.RechargeRecord.objects.filter(wallet__id=wallet_id, type=0, money__gte=10).order_by('-created')[
                 0:25]
    topup_row = ""
    topup_method = ""
    if topup_list:
        index_topup = 1
        for item in topup_list:
            if item.request_id is not None and item.grab_txID is not None:
                topup_method = "GrabPay"
                topup_row = topup_row + "<tr><td>" + str(index_topup) + "</td><td>" + str(
                    item.money) + "</td>" + topup_method + "</td><td>" + datetime.datetime.strftime(
                    item.created + datetime.timedelta(hours=8),
                    "%Y-%m-%d %H:%M:%S") + "</td></tr>"
            elif item.request_id is not None and item.grab_txID is None:
                topup_method = "Wirecard"
                topup_row = topup_row + "<tr><td>" + str(index_topup) + "</td><td>" + str(
                    item.money) + "</td>" + topup_method + "</td><td>" + datetime.datetime.strftime(
                    item.created + datetime.timedelta(hours=8),
                    "%Y-%m-%d %H:%M:%S") + "</td></tr>"
            elif item.request_id is None and item.grab_txID is None:
                topup_method = "Outlet"
            '''
            topup_row = topup_row + "<tr><td>" + str(index_topup) + "</td><td>" + str(
                item.money) + "</td>" + topup_method + "</td><td>" + datetime.datetime.strftime(item.created+datetime.timedelta(hours=8),
                                                                                                "%Y-%m-%d %H:%M:%S") + "</td></tr>"
            '''
            if index_topup==5:
                  break
            index_topup = index_topup + 1
    topup_table = topup_table + topup_row + "</table></br></br>"
    countTable = countTable  + topup_table

    # 5 times topup record(Outlet)

    topup_table_1 = "<table border='1' cellspacing='0' style='text-align:center' ><tr><td colspan='5'  style='text-align:center' >The latest 5 times top up(Outlet)</td></tr><tr><td>times</td><td>amount</td><td>outlet</td><td>payment time </td></tr>"
    topup_list_1 = models.TopupRecord.objects.filter(member__id=member.id,  money__gte=10).order_by('-created')[
                 0:5]
    topup_row_1 = ""
    topup_method = ""
    if topup_list_1:
        index_topup = 1
        for item in topup_list_1:

            topup_row_1 = topup_row_1 + "<tr><td>" + str(index_topup) + "</td><td>" + str(
                item.money) + "</td>" + item.outlet_name + "</td><td>" + datetime.datetime.strftime(item.created+datetime.timedelta(hours=8),
                                                                                                "%Y-%m-%d %H:%M:%S") + "</td></tr>"

            index_topup = index_topup + 1
    topup_table_1 = topup_table_1 + topup_row_1 + "</table></br></br>"
    countTable = countTable + topup_table_1






    return countTable

#topup(outlet) send mail
def get_topup_outlet_mail_table(outlet_name,member,wallet_id,pay_method,amount):
    now = datetime.datetime.now()
    # send mail
    member_register_code = ''
    if member.register_code is None:
        member_register_code = ''
    else:
        member_register_code = member.register_code
    post_code = ''
    if member.post_code:
        post_code = member.post_code
    topup_count = models.RechargeRecord.objects.filter(wallet__id=wallet_id, type=0, money__gte=10).count()
    countTable = "<table border='1' cellspacing='0' style='text-align:center' ><tr><td colspan='7'  style='text-align:center' >Mobile top up payment</td></tr><tr><td>member mobile</td><td>amount</td><td>outlet</td><td>payment time </td><td>register time</td><td>post code</td><td>topup times(sum)</td></tr><tr>" + \
                 "<td>" + member.mobile_no + "</td><td>" + str(
        amount) + "</td><td>" + \
                 outlet_name + "</td><td>" + time.strftime("%Y-%m-%d %H:%M:%S",
                                                              time.localtime()) + "</td><td>" + datetime.datetime.strftime(member.registration_date+datetime.timedelta(hours=8),
                                                                                      "%Y-%m-%d %H:%M:%S") +"</td><td>"+post_code+"</td><td>"+str(topup_count)+"</td></tr></table>"


    # 5 times topup record(Non Outlet)

    topup_table = "<table border='1' cellspacing='0' style='text-align:center' ><tr><td colspan='5'  style='text-align:center' >The latest 5 times top up(Non Outlet)</td></tr><tr><td>times</td><td>amount</td><td>payment method</td><td>payment time </td></tr>"
    topup_list = models.RechargeRecord.objects.filter(wallet__id=wallet_id, type=0, money__gte=10).order_by('-created')[
                 0:25]
    topup_row = ""
    topup_method = ""
    if topup_list:
        index_topup = 1
        for item in topup_list:
            if item.request_id is not None and item.grab_txID is not None:
                topup_method = "GrabPay"
                topup_row = topup_row + "<tr><td>" + str(index_topup) + "</td><td>" + str(
                    item.money) + "</td>" + topup_method + "</td><td>" + datetime.datetime.strftime(
                    item.created + datetime.timedelta(hours=8),
                    "%Y-%m-%d %H:%M:%S") + "</td></tr>"
            elif item.request_id is not None and item.grab_txID is None:
                topup_method = "Wirecard"
                topup_row = topup_row + "<tr><td>" + str(index_topup) + "</td><td>" + str(
                    item.money) + "</td>" + topup_method + "</td><td>" + datetime.datetime.strftime(
                    item.created + datetime.timedelta(hours=8),
                    "%Y-%m-%d %H:%M:%S") + "</td></tr>"
            elif item.request_id is None and item.grab_txID is None:
                topup_method = "Outlet"
            '''
            topup_row = topup_row + "<tr><td>" + str(index_topup) + "</td><td>" + str(
                item.money) + "</td>" + topup_method + "</td><td>" + datetime.datetime.strftime(item.created+datetime.timedelta(hours=8),
                                                                                                "%Y-%m-%d %H:%M:%S") + "</td></tr>"
            '''
            if index_topup==5:
                  break
            index_topup = index_topup + 1
    topup_table = topup_table + topup_row + "</table></br></br>"
    countTable = countTable  + topup_table

    # 5 times topup record(Outlet)

    topup_table_1 = "<table border='1' cellspacing='0' style='text-align:center' ><tr><td colspan='5'  style='text-align:center' >The latest 5 times top up(Outlet)</td></tr><tr><td>times</td><td>amount</td><td>outlet</td><td>payment time </td></tr>"
    topup_list_1 = models.TopupRecord.objects.filter(member__id=member.id,  money__gte=10).order_by('-created')[
                 0:5]
    topup_row_1 = ""
    topup_method = ""
    if topup_list_1:
        index_topup = 1
        for item in topup_list_1:

            topup_row_1 = topup_row_1 + "<tr><td>" + str(index_topup) + "</td><td>" + str(
                item.money) + "</td>" + item.outlet_name + "</td><td>" + datetime.datetime.strftime(item.created+datetime.timedelta(hours=8),
                                                                                                "%Y-%m-%d %H:%M:%S") + "</td></tr>"

            index_topup = index_topup + 1
    topup_table_1 = topup_table_1 + topup_row_1 + "</table></br></br>"
    countTable = countTable + topup_table_1






    return countTable

#payment send mail
def get_cancel_mail_table(transactionObj,member,wallet_id,pay_method):
    now = datetime.datetime.now()
    # send mail
    # datetime.datetime.strftime('%Y-%m-%d %H:%M:%S',member.registration_date)  time.strftime("%Y-%m-%d %H:%M:%S", time.localtime())
    payment_count=models.Transaction.objects.filter(member__id=member.id, transaction_status__in=(2, 4, 5)).count()
    #print(member.id)
    member_register_code=''
    if member.register_code is None:
        member_register_code=''
    else:
        member_register_code = member.register_code

    details_list=models.TransactDetails.objects.filter(transaction__id=transactionObj.id)
    quantity=0
    if details_list:
        for details in details_list:
            quantity+=details.quantity

    wallet_obj=models.Wallet.objects.filter(member__id=transactionObj.member.id).first()
    if wallet_obj:
        wallet_balance=wallet_obj.balance
    else:
        wallet_balance=0


    origin_amount= transactionObj.total_money+transactionObj.discount_amount
    if transactionObj.redeem_invicode is not None and transactionObj.redeem_invicode!=0:
          invicode_obj=models.Invicode.objects.filter(id=transactionObj.redeem_invicode).first()
          if invicode_obj:
               voucher_name=invicode_obj.voucher.name
    else:
          voucher_name=''
    post_code = ''
    if member.post_code:
        post_code = member.post_code


    countTable = "<h4 style='text-align:center'  >Mobile ordering cancel</h4><table border='1' cellspacing='0' style='text-align:center' ><tr><td colspan='13'  style='text-align:left' >order no:" + transactionObj.order_no + "</td></tr><tr><td>member mobile</td><td>outlet</td><td>origin amount</td><td>amount</td><td>voucher</td><td>quantity</td><td>payment method</td><td>payment time </td><td>cancel time </td><td>register time</td><td>post code</td><td>purchase times(sum)</td><td>wallet balance</td></tr><tr>" + \
                 "<td>" + member.mobile_no + "</td><td>" + transactionObj.outlet.outlet_name + "</td><td>"+str(origin_amount)+"</td><td>" + str(
        transactionObj.total_money) + "</td><td>"+voucher_name+"</td><td>"+str(quantity)+"</td><td>" + \
                 pay_method + "</td><td>"+datetime.datetime.strftime(transactionObj.payment_datetime+datetime.timedelta(hours=8),
                                                                         "%Y-%m-%d %H:%M:%S")+"</td><td>" + datetime.datetime.strftime(now,
                                                                         "%Y-%m-%d %H:%M:%S") + "</td><td>" + datetime.datetime.strftime(member.registration_date+datetime.timedelta(hours=8),
                                                                                      "%Y-%m-%d %H:%M:%S") + "</td><td>"+post_code+"</td><td>"+str(payment_count)+"</td><td>"+str(wallet_balance)+"</td></tr></table></br></br>"
    # 3 times purchase record
    third_purchase_table = "<table border='1' cellspacing='0' style='text-align:center' ><tr><td colspan='8'  style='text-align:center' >the latest 20 times payment</td></tr><tr><td>times</td><td>voucher</td><td>outlet</td><td>origin amount</td><td>amount</td><td>quantity</td><td>payment method</td><td>payment time </td></tr>"
    payment_list = models.Transaction.objects.filter(member__id=member.id, transaction_status__in=(2, 4, 5)).order_by(
        '-payment_datetime')[:20]
    payment_table_row = ""
    voucher = ""
    if payment_list:
        index = 1

        for item in payment_list:
            o_amount=item.total_money+item.discount_amount
            voucher = ''
            details_list = models.TransactDetails.objects.filter(transaction__id=item.id)
            quantity_1 = 0
            if details_list:
                for details in details_list:
                    quantity_1 += details.quantity
            #print(quantity_1)
            if item.redeem_invicode is not None and item.redeem_invicode != 0:
                invicode = models.Invicode.objects.filter(id=item.redeem_invicode).first()
                if invicode:
                    voucher = invicode.voucher.name
            if item.payment_modes == 8:
                payment_method="Wallet"
            elif  item.payment_modes == 9:
                payment_method = "Wirecard"
            elif  item.payment_modes == 12:
                payment_method = "GrabPay"
            payment_table_row = payment_table_row + "<tr><td>" + str(
                index) + "</td><td>" + voucher + "</td><td>" + item.outlet.outlet_name + "</td><td>"+str(o_amount)+"</td><td>" + str(
                item.total_money) + "</td><td>"+str(quantity_1)+"</td><td>"+payment_method+"</td><td>" + datetime.datetime.strftime(item.transact_datetime+datetime.timedelta(hours=8),"%Y-%m-%d %H:%M:%S") + "</td></tr>"
            index = index + 1

    third_purchase_table = third_purchase_table + payment_table_row + "</table></br></br>"

    # 3 times topup record
    topup_count = models.RechargeRecord.objects.filter(wallet__id=wallet_id, type=0, money__gte=10).count()
    topup_table = "<table border='1' cellspacing='0' style='text-align:center' ><tr><td colspan='5'  style='text-align:center' >The latest 5 times top up</td></tr><tr><td>times</td><td>amount</td><td>payment method</td><td>payment time </td></tr>"
    topup_list = models.RechargeRecord.objects.filter(wallet__id=wallet_id, type=0, money__gte=10).order_by('-created')[
                 0:5]
    topup_row = ""
    topup_method = ""
    if topup_list:
        index_topup = 1
        for item in topup_list:
            if item.request_id is not None and item.grab_txID is not None:
                topup_method = "GrabPay"
            elif item.request_id is not None and item.grab_txID is None:
                topup_method = "Wirecard"
            elif item.request_id is None and item.grab_txID is None:
                topup_method = "Outlet"


            topup_row = topup_row + "<tr><td>" + str(index_topup) + "</td><td>" + str(
                item.money) + "</td>" + topup_method + "</td><td>" + datetime.datetime.strftime(item.created+datetime.timedelta(hours=8),
                                                                                                "%Y-%m-%d %H:%M:%S") + "</td></tr>"
            index_topup = index_topup + 1
    topup_table = topup_table + topup_row + "</table></br></br>"
    countTable = countTable + third_purchase_table + topup_table
    return countTable



