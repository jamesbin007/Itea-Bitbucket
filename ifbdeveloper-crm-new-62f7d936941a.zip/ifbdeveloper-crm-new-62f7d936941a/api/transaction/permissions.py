from rest_framework.permissions import BasePermission


class TransactionAndTransactDetailsViewSetPermission(BasePermission):
    def has_permission(self, request, view):
        if request.method in ('POST', 'DELETE', 'PUT', 'PATCH'):

            return request.user.role.name in (0, 1, 4)

        else:
            return True

class WirecardLogViewSetPermission(BasePermission):
    def has_permission(self, request, view):
        if request.method in ('POST'):

            return True

        else:
            return False

class GrabPayPosViewSetPermission(BasePermission):
    def has_permission(self, request, view):
        if request.method in ('POST', 'GET'):

            return True

        else:
            return False

class TopupRecordPermission(BasePermission):
    def has_permission(self, request, view):
        if request.method in ('POST', 'GET'):

            return True

        else:
            return False

class EvaluationViewSetPermission(BasePermission):
    def has_permission(self, request, view):
        if request.method in ('DELETE', 'PUT', 'PATCH'):
            print(request.user.role.name)
            return request.user.role.name in (0, 1, 4)
        else:
            return True


# add TransactionAndTransactHistoryViewSetPermission(--ff)
class TransactionAndTransactHistoryViewSetPermission(BasePermission):
    def has_permission(self, request, view):
        if request.method in ('POST', 'DELETE', 'PUT', 'PATCH'):

            return request.user.role.name in (0, 1, 4)

        else:
            return True


# add PrepaidViewSetPermission(已支付订单)---ff
class PrepaidViewSetPermission(BasePermission):
    def has_permission(self, request, view):
        if request.method in ('POST', 'DELETE', 'PUT', 'PATCH'):
            return True
            #print(request.user.role.name)
            #return request.user.role.name in (0, 1, 4)
        else:
            return True
