from app01 import models
import datetime
from member.services import update_membership, update_points
from django.db.models import Count
from django.db import transaction
from invicode.service import record_reward_member_invicode
from invicode import utils
from django.db import connection
from check import file_utils
import time
from utils.message_manage import send_message_to_token
from member.views import getRegisterCount
from card.cron import check_long_sold_product
import os
import requests
def daily():
    """ Executed at 00:00:02 every day"""
    # 1.Check campaign state

    # countUnit = {'outlet_name': '', 'c10': 0, 'c12': 0, 'c14': 0, 'c16': 0, 'c18': 0, 'c20': 0, 'c22': 0}
    #if request.method == 'GET':
    data = []
    total10 = 0
    total12 = 0
    total14 = 0
    total16 = 0
    total18 = 0
    total20 = 0
    total22 = 0
    totalsum = 0
    outlet_list = models.Outlet.objects.all()
    if outlet_list:
        for outlet in outlet_list:
            data.append({'outlet_name': outlet.outlet_name, 'c10': 0, 'c12': 0, 'c14': 0, 'c16': 0, 'c18': 0, 'c20': 0,
                         'c22': 0, 'sum': 0})
    # 8:00-10:00
    sql = "select app01_outlet.outlet_name, count(app01_campaignoneredeemtionperday.ic_number) from app01_campaignoneredeemtionperday join  app01_outlet on app01_campaignoneredeemtionperday.redeemtion_outlet_id=app01_outlet.id  where app01_campaignoneredeemtionperday.redeemtion_date=current_date and date_part('hour',app01_campaignoneredeemtionperday.redeemtion_time)>=8 and date_part('hour',app01_campaignoneredeemtionperday.redeemtion_time)<10 group by app01_outlet.outlet_name,app01_campaignoneredeemtionperday.redeemtion_outlet_id order by app01_outlet.outlet_name ,app01_campaignoneredeemtionperday.redeemtion_outlet_id desc"
    cursor = connection.cursor()
    cursor.execute(sql)
    row = cursor.fetchall()
    if row:
        num = 0

        for i in data:
            for j in row:
                if ((i['outlet_name'] == j[0])):
                    data[num]["c10"] = j[1]
                    total10 = total10 + j[1]
                    break
            num += 1
    # 10:00-12:00
    sql = "select app01_outlet.outlet_name, count(app01_campaignoneredeemtionperday.ic_number) from app01_campaignoneredeemtionperday join  app01_outlet on app01_campaignoneredeemtionperday.redeemtion_outlet_id=app01_outlet.id  where app01_campaignoneredeemtionperday.redeemtion_date=current_date and date_part('hour',app01_campaignoneredeemtionperday.redeemtion_time)>=10 and date_part('hour',app01_campaignoneredeemtionperday.redeemtion_time)<12 group by app01_outlet.outlet_name,app01_campaignoneredeemtionperday.redeemtion_outlet_id order by app01_outlet.outlet_name ,app01_campaignoneredeemtionperday.redeemtion_outlet_id desc"
    cursor = connection.cursor()
    cursor.execute(sql)
    row = cursor.fetchall()
    if row:
        num = 0
        for i in data:
            for j in row:
                if ((i['outlet_name'] == j[0])):
                    data[num]["c12"] = j[1]
                    total12 = total12 + j[1]
                    break
            num += 1
    # 12:00-14:00
    sql = "select app01_outlet.outlet_name, count(app01_campaignoneredeemtionperday.ic_number) from app01_campaignoneredeemtionperday join  app01_outlet on app01_campaignoneredeemtionperday.redeemtion_outlet_id=app01_outlet.id  where app01_campaignoneredeemtionperday.redeemtion_date=current_date and date_part('hour',app01_campaignoneredeemtionperday.redeemtion_time)>=12 and date_part('hour',app01_campaignoneredeemtionperday.redeemtion_time)<14 group by app01_outlet.outlet_name,app01_campaignoneredeemtionperday.redeemtion_outlet_id order by app01_outlet.outlet_name ,app01_campaignoneredeemtionperday.redeemtion_outlet_id desc"
    cursor = connection.cursor()
    cursor.execute(sql)
    row = cursor.fetchall()
    if row:
        num = 0
        for i in data:
            for j in row:
                if ((i['outlet_name'] == j[0])):
                    data[num]["c14"] = j[1]
                    total14 = total14 + j[1]
                    break
            num += 1

    # 14:00-16:00
    sql = "select app01_outlet.outlet_name, count(app01_campaignoneredeemtionperday.ic_number) from app01_campaignoneredeemtionperday join  app01_outlet on app01_campaignoneredeemtionperday.redeemtion_outlet_id=app01_outlet.id  where app01_campaignoneredeemtionperday.redeemtion_date=current_date and date_part('hour',app01_campaignoneredeemtionperday.redeemtion_time)>=14 and date_part('hour',app01_campaignoneredeemtionperday.redeemtion_time)<16 group by app01_outlet.outlet_name,app01_campaignoneredeemtionperday.redeemtion_outlet_id order by app01_outlet.outlet_name ,app01_campaignoneredeemtionperday.redeemtion_outlet_id desc"
    cursor = connection.cursor()
    cursor.execute(sql)
    row = cursor.fetchall()
    if row:
        num = 0
        for i in data:
            for j in row:
                if ((i['outlet_name'] == j[0])):
                    data[num]["c16"] = j[1]
                    total16 = total16 + j[1]
                    break
            num += 1

    # 16:00-18:00
    sql = "select app01_outlet.outlet_name, count(app01_campaignoneredeemtionperday.ic_number) from app01_campaignoneredeemtionperday join  app01_outlet on app01_campaignoneredeemtionperday.redeemtion_outlet_id=app01_outlet.id  where app01_campaignoneredeemtionperday.redeemtion_date=current_date and date_part('hour',app01_campaignoneredeemtionperday.redeemtion_time)>=16 and date_part('hour',app01_campaignoneredeemtionperday.redeemtion_time)<18 group by app01_outlet.outlet_name,app01_campaignoneredeemtionperday.redeemtion_outlet_id order by app01_outlet.outlet_name ,app01_campaignoneredeemtionperday.redeemtion_outlet_id desc"
    cursor = connection.cursor()
    cursor.execute(sql)
    row = cursor.fetchall()
    if row:
        num = 0
        for i in data:
            for j in row:
                if ((i['outlet_name'] == j[0])):
                    data[num]["c18"] = j[1]
                    total18 = total18 + j[1]
                    break
            num += 1

    # 18:00-20:00
    sql = "select app01_outlet.outlet_name, count(app01_campaignoneredeemtionperday.ic_number) from app01_campaignoneredeemtionperday join  app01_outlet on app01_campaignoneredeemtionperday.redeemtion_outlet_id=app01_outlet.id  where app01_campaignoneredeemtionperday.redeemtion_date=current_date and date_part('hour',app01_campaignoneredeemtionperday.redeemtion_time)>=18 and date_part('hour',app01_campaignoneredeemtionperday.redeemtion_time)<20 group by app01_outlet.outlet_name,app01_campaignoneredeemtionperday.redeemtion_outlet_id order by app01_outlet.outlet_name ,app01_campaignoneredeemtionperday.redeemtion_outlet_id desc"
    cursor = connection.cursor()
    cursor.execute(sql)
    row = cursor.fetchall()
    if row:
        num = 0
        for i in data:
            for j in row:
                if ((i['outlet_name'] == j[0])):
                    data[num]["c20"] = j[1]
                    total20 = total20 + j[1]
                    break
            num += 1

    # 20:00-22:00
    sql = "select app01_outlet.outlet_name, count(app01_campaignoneredeemtionperday.ic_number) from app01_campaignoneredeemtionperday join  app01_outlet on app01_campaignoneredeemtionperday.redeemtion_outlet_id=app01_outlet.id  where app01_campaignoneredeemtionperday.redeemtion_date=current_date and date_part('hour',app01_campaignoneredeemtionperday.redeemtion_time)>=20 and date_part('hour',app01_campaignoneredeemtionperday.redeemtion_time)<22 group by app01_outlet.outlet_name,app01_campaignoneredeemtionperday.redeemtion_outlet_id order by app01_outlet.outlet_name ,app01_campaignoneredeemtionperday.redeemtion_outlet_id desc"
    cursor = connection.cursor()
    cursor.execute(sql)
    row = cursor.fetchall()
    if row:
        num = 0
        for i in data:
            for j in row:
                if ((i['outlet_name'] == j[0])):
                    data[num]["c22"] = j[1]
                    total22 = total22 + j[1]
                    break
            num += 1

    # count sum
    num = 0
    line = ""
    for i in data:
        data[num]["sum"] = data[num]["c10"] + data[num]["c12"] + data[num]["c14"] + data[num]["c16"] + data[num][
            "c18"] + data[num]["c20"] + data[num]["c22"]
        totalsum = totalsum + data[num]["sum"]
        line = line + "<tr><td>" + data[num]["outlet_name"] + "</td><td>" + str(data[num]["c10"]) + "</td><td>" + str(
            data[num]["c12"]) + "</td><td>" + str(data[num]["c14"]) + "</td><td>" + str(
            data[num]["c16"]) + "</td><td>" + str(data[num]["c18"]) + "</td><td>" + str(
            data[num]["c20"]) + "</td><td>" + str(data[num]["c22"]) + "</td><td>" + str(data[num]["sum"]) + "</td></tr>"
        num += 1

    # total:
    line = line + "<tr><td>Total</td><td>" + str(total10) + "</td><td>" + str(total12) + "</td><td>" + str(
        total14) + "</td><td>" + str(total16) + "</td><td>" + str(total18) + "</td><td>" + str(
        total20) + "</td><td>" + str(total22) + "</td><td>" + str(totalsum) + "</td></tr>"

    # send mail
    countTable = "<table border='1' cellspacing='0' style='text-align:center' ><tr ><td colspan='9'>Promotion Count</td></tr><tr><td>Outlet</td><td>8:00-10:00</td><td>10:00-12:00</td><td>12:00-14:00</td><td>14:00-16:00</td><td>16:00-18:00</td><td>18:00-20:00</td>20:00-22:00</td><td>sum</td></tr>"
    table = countTable + line + "</table>"

    utils.send_register_email(utils.RECEIVE_MAIL, table, send_type="active", promotion='')


def monthly():
    """ Execute at 00:00:02 every month on the 1st"""
    # 1.Birthday voucher for the month of the month
    with transaction.atomic():
        if datetime.now().day == 1:
            members = models.Member.objects.filter(dob__month=datetime.now().month).all()
            for member in members:
                vouchers = member.membership.birthday_vouchers.all()
                record_reward_member_invicode(member, vouchers)
def test():
    utils.send_register_email(utils.RECEIVE_MAIL, "<p>Test OK</p>", send_type="check")

def check():
    # check server status
    #checks_1 = file_utils.check_server('47.74.208.48', 3000, 'login')
    # checks_1 = file_utils.check_server('47.74.156.85', 3000, 'login')
    #checks_2 = file_utils.check_server('47.74.208.48', 8000, 'api/v1/outlet/')
    # checks_3 = file_utils.check_server('47.74.156.85', 7000, 'api/getcode//')

    #check_result_3 = None
    #check_result_1 = checks_1.check()
    #check_result_2 = checks_2.check()
    # check_result_3 = checks_3.check()
    checks_1 = file_utils.check_server('47.74.156.85', 3000, 'login')
    checks_2 = file_utils.check_server('47.74.156.85', 8008, 'api/v1/outlet/')
    checks_3 = file_utils.check_server('47.74.156.85', 8010, 'api/v1/outlet/')

    check_result_1=checks_1.check()
    check_result_2 = checks_2.check()
    check_result_3 = checks_3.check()

    # check project file valid
    exclude_path = {'path_1': 'node_modules', 'path_2': '.idea', 'path_3': 'migrations', 'path_4': '__pycache__',
                    'path_5': '.git'}
    fileHandler = file_utils.FileHandler(**exclude_path)
    # file_list = fileHandler.list_all_files(os.path.abspath(os.path.dirname(settings.BASE_DIR)))
    file_list = fileHandler.list_all_files(os.path.abspath(os.path.dirname(os.path.dirname(os.path.dirname(__file__)))))
    print(os.path.abspath(os.path.dirname(os.path.dirname(os.path.dirname(os.path.dirname(__file__))))))
    # file_list = fileHandler.list_all_files(settings.BASE_DIR)
    now = datetime.datetime.now()
    file_modify_dict = {}
    file_modify_arr = []
    for file in file_list:
        modify_time_str = time.strftime('%Y-%m-%d %H:%M:%S', time.localtime(os.stat(file).st_ctime))
        modify_time = datetime.datetime.strptime(modify_time_str, '%Y-%m-%d %H:%M:%S')
        previous_day_time = now - datetime.timedelta(hours=24)
        # print(modify_time)
        # print(previous_day_time)
        if (modify_time > previous_day_time and previous_day_time < now):
            file_modify_arr.append({'file': file.title(), 'modify_time': time.strftime('%Y-%m-%d %H:%M:%S',
                                                                                       time.localtime(
                                                                                           os.stat(file).st_ctime))})

        # print(file.title()  + '      modify time:' + time.strftime('%Y-%m-%d %H:%M:%S',time.localtime(os.stat(file).st_ctime)))
    content = ''
    if check_result_1:
        content = '<p>' + check_result_1['result'] + '</p>'
    if check_result_2:
        content = content + '<p>' + check_result_2['result'] + '</p>'
    if check_result_3:
        content = content + '<p>' + check_result_3['result'] + '</p>'
    if file_modify_arr:
        content=content+'<p>Linux server(47.74.208.48) modify file(the past 24 hours):</p>'
        for i in file_modify_arr:
            content = content + '<p>' + i['file'] + '  modify:' + i['modify_time'] + '</p>'
    utils.send_register_email(utils.RECEIVE_MAIL, content, send_type="check")

    # request server 47.74.156.85
    try:

        response = requests.get("http://47.74.156.85:8008/api/v1/payments/check/")

        # return json.loads(response.text)
    except Exception as e:

        print(e)
        #return {'msg': 'error'}

    #return HttpResponse(json.dumps({'Status': 'Ok'}))

def get_member_count():
    promotionCount = getRegisterCount()
    countTable = "<table border='1' cellspacing='0' style='text-align:center' ><tr ><td colspan='4'>Register Count</td></tr><tr><td>Today Registered(invitation)</td><td>Today Registered</td><td>Registered(invitation)</td><td>Registered</td></tr><tr><td>" + \
                 promotionCount['reg_code_today_count'] + "</td><td>" + promotionCount[
                     'reg_today_count'] + "</td><td>" + \
                 promotionCount['reg_code_count'] + "</td><td>" + promotionCount['sum_count'] + "</td></tr></table>"

    utils.send_register_email(utils.RECEIVE_MAIL, countTable, send_type="registered_count", promotion='')

def countOutletPayment_lemon():
    data=[]
    walletTimes=0
    grabPayTimes=0
    creditCardTimes=0
    totalTimes=0
    walletAmount=0
    grabPayAmount=0
    creditCardAmount=0
    totalsum=0
    topup=0
    #countUnit = {'outlet_name': '', 'c10': 0, 'c12': 0, 'c14': 0, 'c16': 0, 'c18': 0, 'c20': 0, 'c22': 0}



    outlet_list=models.Outlet.objects.all()
    if outlet_list:
        for outlet in outlet_list:

           data.append({'outlet_name': outlet.outlet_name, 'c10': 0, 'c12': 0, 'c14': 0, 'c16': 0, 'c18': 0, 'c20': 0, 'c22': 0,'sum':0,'topup':0})
    #wallet times
    sql="select app01_outlet.outlet_name, count(*)  from app01_transaction join  app01_outlet on app01_transaction.outlet_id=app01_outlet.id  where to_char(app01_transaction.payment_datetime,'yyyy-mm-dd')=to_char(current_date,'yyyy-mm-dd')  and app01_transaction.transaction_status in (4,5) and payment_modes=8 group by app01_outlet.outlet_name,app01_transaction.outlet_id order by app01_outlet.outlet_name ,app01_transaction.outlet_id desc"
    cursor = connection.cursor()
    cursor.execute(sql)
    row = cursor.fetchall()
    if row:
        num = 0

        for i in data:
            for j in row:
                if ((i['outlet_name'] == j[0])):
                    data[num]["c10"] = j[1]
                    walletTimes =walletTimes+j[1]
                    break
            num += 1
    # grabPayTimes
    sql = "select app01_outlet.outlet_name, count(*)  from app01_transaction join  app01_outlet on app01_transaction.outlet_id=app01_outlet.id  where to_char(app01_transaction.payment_datetime,'yyyy-mm-dd')=to_char(current_date,'yyyy-mm-dd')  and app01_transaction.transaction_status in (4,5) and payment_modes=12  group by app01_outlet.outlet_name,app01_transaction.outlet_id order by app01_outlet.outlet_name ,app01_transaction.outlet_id desc"
    cursor = connection.cursor()
    cursor.execute(sql)
    row = cursor.fetchall()
    print(row)
    if row:
        num = 0
        for i in data:
            for j in row:
                 if ((i['outlet_name'] == j[0])):
                       data[num]["c12"] = j[1]
                       grabPayTimes= grabPayTimes + j[1]
                       break
            num += 1
    # creditCardTimes
    sql = "select app01_outlet.outlet_name, count(*)  from app01_transaction join  app01_outlet on app01_transaction.outlet_id=app01_outlet.id  where to_char(app01_transaction.payment_datetime,'yyyy-mm-dd')=to_char(current_date,'yyyy-mm-dd')  and app01_transaction.transaction_status in (4,5) and payment_modes=9  group by app01_outlet.outlet_name,app01_transaction.outlet_id order by app01_outlet.outlet_name ,app01_transaction.outlet_id desc"
    cursor = connection.cursor()
    cursor.execute(sql)
    row = cursor.fetchall()
    if row:
        num = 0
        for i in data:
            for j in row:
                if ((i['outlet_name'] == j[0])):
                    data[num]["c14"] = j[1]
                    creditCardTimes = creditCardTimes + j[1]
                    break
            num += 1

    # totalTimes
    sql = "select app01_outlet.outlet_name, count(*)  from app01_transaction join  app01_outlet on app01_transaction.outlet_id=app01_outlet.id  where to_char(app01_transaction.payment_datetime,'yyyy-mm-dd')=to_char(current_date,'yyyy-mm-dd')  and app01_transaction.transaction_status in (4,5)   group by app01_outlet.outlet_name,app01_transaction.outlet_id order by app01_outlet.outlet_name ,app01_transaction.outlet_id desc"
    cursor = connection.cursor()
    cursor.execute(sql)
    row = cursor.fetchall()
    if row:
        num = 0
        for i in data:
            for j in row:
                if ((i['outlet_name'] == j[0])):
                    data[num]["c16"] = j[1]
                    totalTimes = totalTimes + j[1]
                    break
            num += 1

    # walletAmount
    sql = "select app01_outlet.outlet_name, sum(app01_transaction.total_money)  from app01_transaction join  app01_outlet on app01_transaction.outlet_id=app01_outlet.id  where to_char(app01_transaction.payment_datetime,'yyyy-mm-dd')=to_char(current_date,'yyyy-mm-dd')  and app01_transaction.transaction_status in (4,5) and  payment_modes=8  group by app01_outlet.outlet_name,app01_transaction.outlet_id order by app01_outlet.outlet_name ,app01_transaction.outlet_id desc"
    cursor = connection.cursor()
    cursor.execute(sql)
    row = cursor.fetchall()
    if row:
        num = 0
        for i in data:
            for j in row:
                if ((i['outlet_name'] == j[0])):
                    data[num]["c18"] = j[1]
                    walletAmount = walletAmount + j[1]
                    break
            num += 1

    # grabPayAmount
    sql = "select app01_outlet.outlet_name, sum(app01_transaction.total_money)  from app01_transaction join  app01_outlet on app01_transaction.outlet_id=app01_outlet.id  where to_char(app01_transaction.payment_datetime,'yyyy-mm-dd')=to_char(current_date,'yyyy-mm-dd')  and app01_transaction.transaction_status in (4,5) and  payment_modes=12  group by app01_outlet.outlet_name,app01_transaction.outlet_id order by app01_outlet.outlet_name ,app01_transaction.outlet_id desc"
    cursor = connection.cursor()
    cursor.execute(sql)
    row = cursor.fetchall()
    if row:
        num = 0
        for i in data:
            for j in row:
                if ((i['outlet_name'] == j[0])):
                    data[num]["c20"] = j[1]
                    grabPayAmount = grabPayAmount + j[1]
                    break
            num += 1

    # creditCardAmount
    sql = "select app01_outlet.outlet_name, sum(app01_transaction.total_money)  from app01_transaction join  app01_outlet on app01_transaction.outlet_id=app01_outlet.id  where to_char(app01_transaction.payment_datetime,'yyyy-mm-dd')=to_char(current_date,'yyyy-mm-dd')  and app01_transaction.transaction_status in (4,5) and  payment_modes=9  group by app01_outlet.outlet_name,app01_transaction.outlet_id order by app01_outlet.outlet_name ,app01_transaction.outlet_id desc"
    cursor = connection.cursor()
    cursor.execute(sql)
    row = cursor.fetchall()
    if row:
        num = 0
        for i in data:
            for j in row:
                if ((i['outlet_name'] == j[0])):
                    data[num]["c22"] = j[1]
                    creditCardAmount= creditCardAmount + j[1]
                    break
            num += 1
    # sumAmount
    sql = "select app01_outlet.outlet_name, sum(app01_transaction.total_money)  from app01_transaction join  app01_outlet on app01_transaction.outlet_id=app01_outlet.id  where to_char(app01_transaction.payment_datetime,'yyyy-mm-dd')=to_char(current_date,'yyyy-mm-dd')  and app01_transaction.transaction_status in (4,5)   group by app01_outlet.outlet_name,app01_transaction.outlet_id order by app01_outlet.outlet_name ,app01_transaction.outlet_id desc"
    cursor = connection.cursor()
    cursor.execute(sql)
    row = cursor.fetchall()
    if row:
        num = 0
        for i in data:
            for j in row:
                if ((i['outlet_name'] == j[0])):
                    data[num]["sum"] = j[1]
                    totalsum = totalsum + j[1]
                    break
            num += 1
    # topup
    sql = "select outlet_name, sum(money)  from app01_topuprecord   where created_date=current_date  group by outlet_name order by outlet_name  desc"
    cursor = connection.cursor()
    cursor.execute(sql)
    row = cursor.fetchall()
    if row:
        num = 0
        for i in data:
            for j in row:
                if ((i['outlet_name'] == j[0])):
                    data[num]["topup"] = j[1]
                    topup = topup + j[1]
                    break
            num += 1
    #count sum
    num=0
    line=""
    for i in data:
        #data[num]["sum"]=data[num]["c10"]+data[num]["c12"]+data[num]["c14"]+data[num]["c16"]+data[num]["c18"]+data[num]["c20"]+data[num]["c22"]
        #totalsum=totalsum+data[num]["sum"]
        line=line+"<tr><td>"+data[num]["outlet_name"]+"</td><td>"+str(data[num]["c10"])+"</td><td>"+str(data[num]["c12"])+"</td><td>"+str(data[num]["c14"])+"</td><td>"+str(data[num]["c16"])+"</td><td>"+str(data[num]["c18"])+"</td><td>"+str(data[num]["c20"])+"</td><td>"+str(data[num]["c22"])+"</td><td>"+str(data[num]["sum"])+"</td><td>"+str(data[num]["topup"])+"</td></tr>"
        num+=1

    #total:
    line=line+"<tr><td>Total</td><td>"+str(walletTimes)+"</td><td>"+str(grabPayTimes)+"</td><td>"+str(creditCardTimes)+"</td><td>"+str(totalTimes)+"</td><td>"+str(getFloat(walletAmount))+"</td><td>"+str(getFloat(grabPayAmount))+"</td><td>"+str(getFloat(creditCardAmount))+"</td><td>"+str(getFloat(totalsum))+"</td><td>"+str(getFloat(topup))+"</td></tr>"


    #send mail
    countTable = "<table border='1' cellspacing='0' style='text-align:center' ><tr ><td colspan='9'>Outlet Payment Count</td></tr><tr><td>Outlet</td><td>iPay(times)</td><td>GrabPay(times)</td><td>CreditCard(times)</td><td>Total(times)</td><td>iPay(amount)</td><td>GrabPay(amount)</td>CreditCard(amount)</td><td>Sum(amount)</td><td>Topup(amount)</td></tr>"
    table=countTable+line+"</table>"

    # wirecard
    sql = "select sum(money) from app01_RechargeRecord where type=0 and status=1 and (request_id is not null and \"grab_txID\" is null) and (money=10 or money=20 or money=50) and to_char(created,'yyyy-mm-dd')=to_char(current_date,'yyyy-mm-dd')"
    cursor = connection.cursor()
    cursor.execute(sql)
    row = cursor.fetchall()
    if row:
        if row[0][0] is not None:
            wirecard_topup_money = row[0][0]
        else:
            wirecard_topup_money = 0.0
    else:
        wirecard_topup_money = 0.0

    # grabpay
    sql = "select sum(money) from app01_RechargeRecord where type=0 and status=1 and (request_id is not null and \"grab_txID\" is not null) and (money=10 or money=20 or money=50) and to_char(created,'yyyy-mm-dd')=to_char(current_date,'yyyy-mm-dd')"
    cursor = connection.cursor()
    cursor.execute(sql)
    row = cursor.fetchall()
    if row:
        if row[0][0] is not None:
            grabpay_topup_money = row[0][0]
        else:
            grabpay_topup_money = 0.0
    else:
        grabpay_topup_money = 0.0

    # iPay wallet balance
    sql = "select sum(balance) from app01_wallet where member_id not in (95,383,822,27,881,529,2749,102) and balance>1  "
    cursor = connection.cursor()
    cursor.execute(sql)
    row = cursor.fetchall()
    if row:
        if row[0][0] is not None:
            wallet_balance = row[0][0]
        else:
            wallet_balance = 0.0
    else:
        wallet_balance = 0.0

    # invite code
    sql = "select count(*) from app01_invite_code where activate_status=False "
    cursor = connection.cursor()
    cursor.execute(sql)
    row = cursor.fetchall()
    if row:
        if row[0][0] is not None:
            remain_invite_code = row[0][0]
        else:
            remain_invite_code = 0
    else:
        remain_invite_code = 0
    # $1 for login
    sql = "select count(*) from app01_invicode where status=0 and voucher_id=95 "
    cursor = connection.cursor()
    cursor.execute(sql)
    row = cursor.fetchall()
    if row:
        if row[0][0] is not None:
            remain_1_login = row[0][0]
        else:
            remain_1_login = 0
    else:
        remain_1_login = 0
    # $2 for regiser
    sql = "select count(*) from app01_invicode where status=0 and voucher_id=96 "
    cursor = connection.cursor()
    cursor.execute(sql)
    row = cursor.fetchall()
    if row:
        if row[0][0] is not None:
            remain_2_regiser = row[0][0]
        else:
            remain_2_regiser = 0
    else:
        remain_2_regiser = 0




    topup_mobile_table="<p>Remain Invitation Code: "+str(remain_invite_code)+"</p><p>Remain $1 for login(voucher): "+str(remain_1_login)+"</p><p>Remain $2 for register(voucher): "+str(remain_2_regiser)+"</p><p>WireCard top up: $"+str(wirecard_topup_money)+"</p><p>GrabPay top up: $"+str(grabpay_topup_money)+"</p><p>iPay wallet balance(sum): $"+str(wallet_balance)+"</p></br></br>"
    table = topup_mobile_table + table



    utils.send_register_email(utils.RECEIVE_MAIL, table, send_type="paymentCount", promotion='')



def getFloat(f):

    g = '%.2f' % f
    return float(g)

def countOutletPayment():
    data=[]
    walletTimes=0
    grabPayTimes=0
    creditCardTimes=0
    totalTimes=0
    walletAmount=0
    grabPayAmount=0
    creditCardAmount=0
    totalsum=0
    topup=0
    lemon = 0
    #countUnit = {'outlet_name': '', 'c10': 0, 'c12': 0, 'c14': 0, 'c16': 0, 'c18': 0, 'c20': 0, 'c22': 0}



    outlet_list=models.Outlet.objects.all()
    if outlet_list:
        for outlet in outlet_list:

           data.append({'outlet_name': outlet.outlet_name,'outlet_id': outlet.id, 'c10': 0, 'c12': 0, 'c14': 0, 'c16': 0, 'c18': 0, 'c20': 0, 'c22': 0,'sum':0,'topup':0,'lemon':0})
    #wallet times
    sql="select app01_outlet.outlet_name, count(*)  from app01_transaction join  app01_outlet on app01_transaction.outlet_id=app01_outlet.id  where to_char(app01_transaction.payment_datetime,'yyyy-mm-dd')=to_char(current_date,'yyyy-mm-dd')  and app01_transaction.transaction_status in (4,5) and payment_modes=8 group by app01_outlet.outlet_name,app01_transaction.outlet_id order by app01_outlet.outlet_name ,app01_transaction.outlet_id desc"
    cursor = connection.cursor()
    cursor.execute(sql)
    row = cursor.fetchall()
    if row:
        num = 0

        for i in data:
            for j in row:
                if ((i['outlet_name'] == j[0])):
                    data[num]["c10"] = j[1]
                    walletTimes =walletTimes+j[1]
                    break
            num += 1
    # grabPayTimes
    sql = "select app01_outlet.outlet_name, count(*)  from app01_transaction join  app01_outlet on app01_transaction.outlet_id=app01_outlet.id  where to_char(app01_transaction.payment_datetime,'yyyy-mm-dd')=to_char(current_date,'yyyy-mm-dd')  and app01_transaction.transaction_status in (4,5) and payment_modes=12  group by app01_outlet.outlet_name,app01_transaction.outlet_id order by app01_outlet.outlet_name ,app01_transaction.outlet_id desc"
    cursor = connection.cursor()
    cursor.execute(sql)
    row = cursor.fetchall()
    print(row)
    if row:
        num = 0
        for i in data:
            for j in row:
                 if ((i['outlet_name'] == j[0])):
                       data[num]["c12"] = j[1]
                       grabPayTimes= grabPayTimes + j[1]
                       break
            num += 1
    # creditCardTimes
    sql = "select app01_outlet.outlet_name, count(*)  from app01_transaction join  app01_outlet on app01_transaction.outlet_id=app01_outlet.id  where to_char(app01_transaction.payment_datetime,'yyyy-mm-dd')=to_char(current_date,'yyyy-mm-dd')  and app01_transaction.transaction_status in (4,5) and payment_modes=9  group by app01_outlet.outlet_name,app01_transaction.outlet_id order by app01_outlet.outlet_name ,app01_transaction.outlet_id desc"
    cursor = connection.cursor()
    cursor.execute(sql)
    row = cursor.fetchall()
    if row:
        num = 0
        for i in data:
            for j in row:
                if ((i['outlet_name'] == j[0])):
                    data[num]["c14"] = j[1]
                    creditCardTimes = creditCardTimes + j[1]
                    break
            num += 1

    # totalTimes
    sql = "select app01_outlet.outlet_name, count(*)  from app01_transaction join  app01_outlet on app01_transaction.outlet_id=app01_outlet.id  where to_char(app01_transaction.payment_datetime,'yyyy-mm-dd')=to_char(current_date,'yyyy-mm-dd')  and app01_transaction.transaction_status in (4,5)   group by app01_outlet.outlet_name,app01_transaction.outlet_id order by app01_outlet.outlet_name ,app01_transaction.outlet_id desc"
    cursor = connection.cursor()
    cursor.execute(sql)
    row = cursor.fetchall()
    if row:
        num = 0
        for i in data:
            for j in row:
                if ((i['outlet_name'] == j[0])):
                    data[num]["c16"] = j[1]
                    totalTimes = totalTimes + j[1]
                    break
            num += 1

    # walletAmount
    sql = "select app01_outlet.outlet_name, sum(app01_transaction.total_money)  from app01_transaction join  app01_outlet on app01_transaction.outlet_id=app01_outlet.id  where to_char(app01_transaction.payment_datetime,'yyyy-mm-dd')=to_char(current_date,'yyyy-mm-dd')  and app01_transaction.transaction_status in (4,5) and  payment_modes=8  group by app01_outlet.outlet_name,app01_transaction.outlet_id order by app01_outlet.outlet_name ,app01_transaction.outlet_id desc"
    cursor = connection.cursor()
    cursor.execute(sql)
    row = cursor.fetchall()
    if row:
        num = 0
        for i in data:
            for j in row:
                if ((i['outlet_name'] == j[0])):
                    data[num]["c18"] = j[1]
                    walletAmount = walletAmount + j[1]
                    break
            num += 1

    # grabPayAmount
    sql = "select app01_outlet.outlet_name, sum(app01_transaction.total_money)  from app01_transaction join  app01_outlet on app01_transaction.outlet_id=app01_outlet.id  where to_char(app01_transaction.payment_datetime,'yyyy-mm-dd')=to_char(current_date,'yyyy-mm-dd')  and app01_transaction.transaction_status in (4,5) and  payment_modes=12  group by app01_outlet.outlet_name,app01_transaction.outlet_id order by app01_outlet.outlet_name ,app01_transaction.outlet_id desc"
    cursor = connection.cursor()
    cursor.execute(sql)
    row = cursor.fetchall()
    if row:
        num = 0
        for i in data:
            for j in row:
                if ((i['outlet_name'] == j[0])):
                    data[num]["c20"] = j[1]
                    grabPayAmount = grabPayAmount + j[1]
                    break
            num += 1

    # creditCardAmount
    sql = "select app01_outlet.outlet_name, sum(app01_transaction.total_money)  from app01_transaction join  app01_outlet on app01_transaction.outlet_id=app01_outlet.id  where to_char(app01_transaction.payment_datetime,'yyyy-mm-dd')=to_char(current_date,'yyyy-mm-dd')  and app01_transaction.transaction_status in (4,5) and  payment_modes=9  group by app01_outlet.outlet_name,app01_transaction.outlet_id order by app01_outlet.outlet_name ,app01_transaction.outlet_id desc"
    cursor = connection.cursor()
    cursor.execute(sql)
    row = cursor.fetchall()
    if row:
        num = 0
        for i in data:
            for j in row:
                if ((i['outlet_name'] == j[0])):
                    data[num]["c22"] = j[1]
                    creditCardAmount= creditCardAmount + j[1]
                    break
            num += 1
    # sumAmount
    sql = "select app01_outlet.outlet_name, sum(app01_transaction.total_money)  from app01_transaction join  app01_outlet on app01_transaction.outlet_id=app01_outlet.id  where to_char(app01_transaction.payment_datetime,'yyyy-mm-dd')=to_char(current_date,'yyyy-mm-dd')  and app01_transaction.transaction_status in (4,5)   group by app01_outlet.outlet_name,app01_transaction.outlet_id order by app01_outlet.outlet_name ,app01_transaction.outlet_id desc"
    cursor = connection.cursor()
    cursor.execute(sql)
    row = cursor.fetchall()
    if row:
        num = 0
        for i in data:
            for j in row:
                if ((i['outlet_name'] == j[0])):
                    data[num]["sum"] = j[1]
                    totalsum = totalsum + j[1]
                    break
            num += 1
    # topup
    sql = "select outlet_name, sum(money)  from app01_topuprecord   where created_date=current_date  group by outlet_name order by outlet_name  desc"
    cursor = connection.cursor()
    cursor.execute(sql)
    row = cursor.fetchall()
    if row:
        num = 0
        for i in data:
            for j in row:
                if ((i['outlet_name'] == j[0])):
                    data[num]["topup"] = j[1]
                    topup = topup + j[1]
                    break
            num += 1
    # lemon
    sql = "select app01_transaction.outlet_id, sum(app01_transactdetails.quantity) from app01_transactdetails join app01_transaction on app01_transaction.id=app01_transactdetails.transaction_id where to_char(app01_transaction.payment_datetime,'yyyy-mm-dd')=to_char(current_date,'yyyy-mm-dd')  and app01_transaction.transaction_status in (4,5) and app01_transactdetails.product_id in (select id from app01_product where name like '%Taro Bobo%') group by app01_transaction.outlet_id  "
    #sql = "select app01_transaction.outlet_id, count(app01_transaction.redeem_invicode) from app01_transaction join app01_invicode on app01_transaction.redeem_invicode=app01_invicode.id where to_char(app01_transaction.payment_datetime,'yyyy-mm-dd')=to_char(current_date,'yyyy-mm-dd')  and app01_transaction.transaction_status in (4,5) and app01_transaction.redeem_invicode is not null and  app01_transaction.redeem_invicode in (select id from app01_invicode where voucher_id in (108,127)) group by app01_transaction.outlet_id"
    cursor = connection.cursor()
    cursor.execute(sql)
    row = cursor.fetchall()
    if row:
        num = 0

        for i in data:
            for j in row:
                if ((i['outlet_id'] == j[0])):
                    data[num]["lemon"] = j[1]
                    lemon = lemon + j[1]
                    break
            num += 1
    #count sum
    num=0
    line=""
    for i in data:
        #data[num]["sum"]=data[num]["c10"]+data[num]["c12"]+data[num]["c14"]+data[num]["c16"]+data[num]["c18"]+data[num]["c20"]+data[num]["c22"]
        #totalsum=totalsum+data[num]["sum"]
        line=line+"<tr><td>"+data[num]["outlet_name"]+"</td><td>"+str(data[num]["c10"])+"</td><td>"+str(data[num]["c12"])+"</td><td>"+str(data[num]["c14"])+"</td><td>"+str(data[num]["c16"])+"</td><td>"+str(data[num]["c18"])+"</td><td>"+str(data[num]["c20"])+"</td><td>"+str(data[num]["c22"])+"</td><td>"+str(data[num]["sum"])+"</td><td>"+str(data[num]["topup"])+"</td><td>"+str(data[num]["lemon"])+"</td></tr>"
        num+=1

    #total:
    line=line+"<tr><td>Total</td><td>"+str(walletTimes)+"</td><td>"+str(grabPayTimes)+"</td><td>"+str(creditCardTimes)+"</td><td>"+str(totalTimes)+"</td><td>"+str(getFloat(walletAmount))+"</td><td>"+str(getFloat(grabPayAmount))+"</td><td>"+str(getFloat(creditCardAmount))+"</td><td>"+str(getFloat(totalsum))+"</td><td>"+str(getFloat(topup))+"</td><td>"+str(lemon)+"</td></tr>"


    #send mail
    countTable = "<table border='1' cellspacing='0' style='text-align:center' ><tr ><td colspan='10'>Outlet Payment Count</td></tr><tr><td>Outlet</td><td>iPay(times)</td><td>GrabPay(times)</td><td>CreditCard(times)</td><td>Total(times)</td><td>iPay(amount)</td><td>GrabPay(amount)</td>CreditCard(amount)</td><td>Sum(amount)</td><td>Topup(amount)</td><td>Tara Bobo(count)</td></tr>"
    table=countTable+line+"</table>"

    # wirecard
    sql = "select sum(money) from app01_RechargeRecord where type=0 and status=1 and (request_id is not null and \"grab_txID\" is null) and (money=10 or money=20 or money=50) and to_char(created+interval '8' hour,'yyyy-mm-dd')=to_char(current_date,'yyyy-mm-dd')"
    cursor = connection.cursor()
    cursor.execute(sql)
    row = cursor.fetchall()
    if row:
        if row[0][0] is not None:
            wirecard_topup_money = row[0][0]
        else:
            wirecard_topup_money = 0.0
    else:
        wirecard_topup_money = 0.0

    # grabpay
    sql = "select sum(money) from app01_RechargeRecord where type=0 and status=1 and (request_id is not null and \"grab_txID\" is not null) and (money=10 or money=20 or money=50) and to_char(created+interval '8' hour,'yyyy-mm-dd')=to_char(current_date,'yyyy-mm-dd')"
    cursor = connection.cursor()
    cursor.execute(sql)
    row = cursor.fetchall()
    if row:
        if row[0][0] is not None:
            grabpay_topup_money = row[0][0]
        else:
            grabpay_topup_money = 0.0
    else:
        grabpay_topup_money = 0.0

    # iPay wallet balance
    sql = "select sum(balance) from app01_wallet  "
    cursor = connection.cursor()
    cursor.execute(sql)
    row = cursor.fetchall()
    if row:
        if row[0][0] is not None:
            wallet_balance = row[0][0]
        else:
            wallet_balance = 0.0
    else:
        wallet_balance = 0.0

    # invite code
    sql = "select count(*) from app01_invite_code where activate_status=False "
    cursor = connection.cursor()
    cursor.execute(sql)
    row = cursor.fetchall()
    if row:
        if row[0][0] is not None:
            remain_invite_code = row[0][0]
        else:
            remain_invite_code = 0
    else:
        remain_invite_code = 0
    # $1 for login
    sql = "select count(*) from app01_invicode where status=0 and voucher_id=95 "
    cursor = connection.cursor()
    cursor.execute(sql)
    row = cursor.fetchall()
    if row:
        if row[0][0] is not None:
            remain_1_login = row[0][0]
        else:
            remain_1_login = 0
    else:
        remain_1_login = 0
    # $2 for regiser
    sql = "select count(*) from app01_invicode where status=0 and voucher_id=96 "
    cursor = connection.cursor()
    cursor.execute(sql)
    row = cursor.fetchall()
    if row:
        if row[0][0] is not None:
            remain_2_regiser = row[0][0]
        else:
            remain_2_regiser = 0
    else:
        remain_2_regiser = 0

    topup_mobile_table="<p>Remain Invitation Code: "+str(remain_invite_code)+"</p><p>Remain $1 for login(voucher): "+str(remain_1_login)+"</p><p>Remain $2 for register(voucher): "+str(remain_2_regiser)+"</p><p>WireCard top up: $"+str(wirecard_topup_money)+"</p><p>GrabPay top up: $"+str(grabpay_topup_money)+"</p><p>iPay wallet balance(sum): $"+str(wallet_balance)+"</p></br></br>"
    table = topup_mobile_table + table



    utils.send_register_email(utils.RECEIVE_MAIL, table, send_type="paymentCount", promotion='')