from django.urls import path, include
from rest_framework.routers import DefaultRouter
from . import views


router = DefaultRouter()
router.register('order-query', views.OrderQueryViewSet, base_name='order-query')
router.register('transact-details', views.TransactDetailsViewSet, base_name='transact_details')
router.register('take-transact-details', views.TakeTransactDetailsViewSet, base_name='transact_details')
router.register('transact-history', views.TransactHistoryViewSet, base_name='transact_history')
router.register('prepaid', views.PrepaidViewSet, base_name='prepaid')
router.register('receipt_update', views.ReceiptNoViewSet, base_name='receipt_update')
router.register('sales_record', views.SalesRecordViewSet, base_name='sales_record')
router.register('evaluation', views.EvaluationViewSet, base_name='evaluation')
router.register('create_order', views.OrderViewSet, base_name='create_order')
router.register('order_list', views.OrderListViewSet, base_name='order_list')
router.register('take_order_list', views.TakeOrderListViewSet, base_name='take_order_list')
router.register('new_take_order_list', views.NewTakeOrderListViewSet, base_name='new_take_order_list')
router.register('grab_pay_pos', views.GrabPayPosViewSet, base_name='grab_pay_pos')
router.register('wirecard_log', views.WirecardLogViewSet, base_name='wirecard_log')
router.register('manual_topup', views.TopupRecordViewSet, base_name='manual_topup')
router.register('manual_refund', views.RefundRecordViewSet, base_name='manual_refund')
router.register('', views.TransactionViewSet)

urlpatterns = [
    #android url prevent android decompile
    path('test_example/', views.modOrder, name="modOrder"),
    path('modPickup/', views.modPickuptime, name="modOrder"),
    path('modDelivery/', views.modDeliverytime, name="modDelivery"),
    path('modAddress/', views.modAddress, name="modAddress"),
    #android url prevent android decompile
    path('get_member_class/', views.wallet_pay, name="wallet_pay"),
    #android url prevent android decompile
    path('get_product_status/', views.wirecard_pay, name="wirecard_pay"),
    #android url prevent android decompile
    path('orders_list_show/', views.topup, name="topup"),
    path('chart/', views.getChartData, name="chart"),
    path('chart_year/', views.getChartData_year, name="chart_year"),
    path('chart_hot/', views.getChartHot_sell, name="chart_hot"),
    path('chart_single/', views.getChartSingle_sell, name="chart_single"),
    path('chart_hours/', views.getChartData_hour, name="chart_hours"),
    path('count/', views.ProductCountViewSet.as_view({'get': 'list'}), name="count"),
    path('countPromotion/', views.countPromotion, name="countPromotion"),
    path('countPayment/', views.countPayment, name="countPromotion"),
    path('countOutletPayment/', views.countOutletPayment, name="countOutletPayment"),
    path('auto_confirm/', views.auto_confirm, name="auto_confirm"),
    path('confirmOrder/', views.confirmOrder, name="confirmOrder"),
    path('freeCancel/', views.freeCancel, name="freeCancel"),
    path('dealTopRootId/', views.dealTopRootId, name="dealTopRootId"),
    path('sumManualTopup/', views.sumManualTopup, name="sumManualTopup"),
    path('getTopupCount/', views.getTopupCount, name="getTopupCount"),
    path('clone_order/', views.clone_order, name="clone_order"),

    path('', include(router.urls)),


]
