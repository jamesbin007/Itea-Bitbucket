from app01 import models
import threading
import time
from invicode import utils
from django.db.models import Q,Sum,Count
import datetime
def checkTransAmount(transactionObj):
    if transactionObj:
        transaction_id=transactionObj.id
        if transaction_id:
            if transactionObj.total_money<0:
                return False
            elif transactionObj.total_money==0:
                if transactionObj.redeem_invicode==0 or transactionObj.redeem_invicode is None:
                    return False
                else:
                    if transactionObj.discount_amount==0:
                        return False
                    else:
                        transaction_real_amount=transactionObj.discount_amount
                        transactionDetailsObj=transactionObj.filter(transaction__id=transaction_id)
                        transaction_details_amount=0
                        if transactionDetailsObj:
                            for transactionDet in transactionDetailsObj:
                                if(transactionDet.price<=0):
                                    return False
                                else:
                                    product=transactionDet.product
                                    if (int(transactionDet.price)<int(product.price)):
                                        return False
                                    if transactionDet.transactDetails_type==1:
                                        if int(transactionDet.price)<8:
                                            return False
                                transaction_details_amount+=transactionDet.price*transactionDet.quantity

                            if int(transaction_real_amount)< int(transaction_details_amount):
                                return False
            else:

                transaction_real_amount =transactionObj.total_money+ transactionObj.discount_amount
                transactionDetailsObj = transactionObj.filter(transaction__id=transaction_id)
                transaction_details_amount = 0
                if transactionDetailsObj:
                    for transactionDet in transactionDetailsObj:
                        if (transactionDet.price <= 0):
                            return False
                        else:
                            product = transactionDet.product
                            if (int(transactionDet.price) < int(product.price)):
                                return False
                            if transactionDet.transactDetails_type == 1:
                                if int(transactionDet.price) < 8:
                                    return False
                        transaction_details_amount += transactionDet.price * transactionDet.quantity

                    if int(transaction_real_amount) < int(transaction_details_amount):
                        return False


class MailThread(threading.Thread):
    mail=''
    send_type=''

    def run(self):
        utils.send_register_email(utils.RECEIVE_MAIL, self.mail, send_type=self.send_type, promotion='')

def thread_send_mail(mail,send_type):
    mailThread = MailThread()
    mailThread.mail = mail
    mailThread.send_type = send_type
    mailThread.start()

def check_invicode_quantity(transactionObj):
    voucher_dict = {}
    has_voucher = False
    if transactionObj:
        transactionDetails_list=models.TransactDetails.objects.filter(transaction__id=transactionObj.id)
        if transactionDetails_list:
            for transactionDetails in transactionDetails_list:

                productObj = models.Product.objects.get(id=transactionDetails.product.id)
                if productObj:

                    if productObj.voucher:
                        has_voucher = True
                        voucher_id = productObj.voucher.id
                        if voucher_dict:
                            if str(voucher_id) in voucher_dict:
                                voucher_dict[str(voucher_id)] = voucher_dict[str(voucher_id)] + transactionDetails.quantity
                            else:
                                voucher_dict[str(voucher_id)] =  transactionDetails.quantity
                        else:
                            voucher_dict[str(voucher_id)] = + transactionDetails.quantity
                    # limit voucher max quantity
    if has_voucher:
        if voucher_dict:
            for item in voucher_dict.keys():
                voucher_set = models.Voucher_Set.objects.filter(voucher__id=int(item)).first()
                if voucher_set:
                    max_quantity = voucher_set.max_quantity
                    if voucher_set.all_limit:
                        invicode_amount = models.Invicode.objects.filter(
                            voucher__id=int(item)).aggregate(count=Count('id'))
                    if voucher_set.today_limit:
                        invicode_amount = models.Invicode.objects.filter(voucher__id=int(item),register_date__date=datetime.datetime.now().date()).aggregate(count=Count('id'))
                    recent_quantity = voucher_dict[item] + invicode_amount['count']
                    if recent_quantity > max_quantity:
                        remain_quantity = max_quantity - invicode_amount['count']
                        if remain_quantity < 0:
                            remain_quantity = 0
                        voucher = voucher_set.voucher
                        if voucher:
                            voucher_name = voucher.name
                            return {'msg': voucher_name + ' max quantity ' + str(
                                max_quantity) + ' ,remain ' + str(remain_quantity) + ' can buy'}
    else:
        return None
    return None

def send_mooncake_payment(transactionObj):
    line=''
    paymentTable=''
    if transactionObj:
        outlet=transactionObj.outlet
        if outlet:
            if outlet.id:
                 outlet_count_sales = models.Outlet_Count_Sales.objects.filter(outlet__id=outlet.id,status=True).first()
                 if outlet_count_sales:
                     member=transactionObj.member
                     if member:
                            mobile_no=member.mobile_no
                            address=transactionObj.delivery_address
                            delivery_times=transactionObj.delivery_time
                            delivery_remark=transactionObj.delivery_remark

                            transactDetails_list=models.TransactDetails.objects.filter(transaction__id=transactionObj.id)
                            if transactDetails_list:
                                for transactDetails in transactDetails_list:
                                    remark=transactDetails.remark
                                    if remark and remark!='':
                                        remark='remark:'+remark
                                    else:
                                        remark=''
                                    line=line+'<p>'+transactDetails.product.name+'  *'+str(transactDetails.quantity)+remark+'</p>'
                                paymentTable = "<h4 style='text-align:center'  >iDelivery  purchase</h4><table border='1' cellspacing='0' style='text-align:center' ><tr><td colspan='6'  style='text-align:left' >order no:" + transactionObj.order_no + "</td></tr><tr><td>member mobile</td><td>payment time</td><td>address</td><td>delivery times</td><td>delivery remark</td><td>order details</td></tr><tr>" + \
                                                     "<td>" + mobile_no + "</td><td>" + datetime.datetime.strftime(datetime.datetime.now(),"%Y-%m-%d %H:%M:%S") + "</td><td>"+address+"</td><td>" + delivery_times + "</td><td>"+delivery_remark+"</td><td>"+line+"</td></tr></table></br></br>"
        if paymentTable!='':
                thread_send_mail(paymentTable, "iDelivery")



