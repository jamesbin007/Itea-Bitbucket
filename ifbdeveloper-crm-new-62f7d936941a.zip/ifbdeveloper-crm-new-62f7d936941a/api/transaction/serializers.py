from rest_framework import serializers
from app01 import models
from utils.utils import except_validation_error
from outlet.service import get_or_create_outlet
from product.service import get_or_create_product, get_or_create_toppings,get_product_from_PLU,get_topping_from_PLU
from campaign.service import insert_member_campaigntype
from voucher.service import record_reward_member_voucher, record_redeemed_member_voucher
from member.services import update_points, update_member_last_purchase_date
from invicode.service import record_reward_member_invicode
from outlet.serializers import OutletSerializer
from .service import get_or_create_transact_details
from django.db.models import Min,Avg,Max,Sum

# add Order Query ---ff(19/6/13)
class OrderQuerySerializer(serializers.ModelSerializer):

    class Meta:
        model = models.Transaction
        fields = ('id', 'member', 'outlet', 'payment_modes', 'payment_datetime')


class TransactionRSerializer(serializers.ModelSerializer):
    class TransactDetailsSerializer(serializers.ModelSerializer):
        # if qball_selection is exist change ice_level=None ---ff
        #models.TransactDetails.objects.filter(qball_selection='No Ice').update(ice_level=None)
        #models.TransactDetails.objects.filter(qball_selection='No Ice/No Bean').update(ice_level=None)
        class Meta:
            model = models.TransactDetails
            exclude = ('transaction',)
            depth = 2

    # add mobile_no to MemberSerializer ----ff
    class MemberSerializer(serializers.ModelSerializer):
        class Meta:
            model = models.Member
            fields = ('id', 'mobile_no')

    transact_details = TransactDetailsSerializer(many=True, read_only=True)
    # member = serializers.PrimaryKeyRelatedField(queryset=models.Member.objects.all())
    # change member to list ---ff
    member = MemberSerializer(many=False, read_only=True)
    campaigns = serializers.PrimaryKeyRelatedField(queryset=models.Campaign.objects.all(), many=True)
    campaigntypes = serializers.PrimaryKeyRelatedField(queryset=models.CampaignType.objects.all(), many=True)
    reward_vouchers = serializers.PrimaryKeyRelatedField(queryset=models.Voucher.objects.all(), many=True)
    redeemed_vouchers = serializers.PrimaryKeyRelatedField(queryset=models.Voucher.objects.all(), many=True)

    class Meta:
        model = models.Transaction
        fields = '__all__'
        depth = 2


class OrderSerializer(serializers.ModelSerializer):
    class Meta:
        model = models.Transaction
        fields = '__all__'

class TakeOrderListSerializer(serializers.ModelSerializer):
    # 修改添加TransactionDetails outlet
    list = serializers.SerializerMethodField()
    itme_count=serializers.SerializerMethodField()
    outlet_name = serializers.SerializerMethodField()
    transfer_outlet_name = serializers.SerializerMethodField()
    outlet_list=models.Outlet.objects.all()
    member_phone=serializers.SerializerMethodField()

    class Meta:
        model = models.Transaction
        exclude=('campaigns','campaigntypes','reward_vouchers','redeemed_vouchers',)
        #fields = '__all__'

    def get_list(self, obj):
        '''
        ret = models.TransactDetails.objects.filter(transaction=obj.id)
        if (ret is not None):
            return [TransactDetailsSerializer(i).data for i in ret]
        else:
        '''
        return []

    def get_itme_count(self, obj):

        item_count=models.TransactDetails.objects.filter(transaction=obj.id).aggregate(Sum('quantity'))
        if item_count:
           return item_count['quantity__sum']
    def get_outlet_name(self, obj):
        outlet_id = obj.outlet_id
        outlet_name = ''
        for item in self.outlet_list:
            if item.id ==outlet_id:
                outlet_name = item.outlet_name
                break
        if outlet_name:
            return outlet_name
        else:
            return ''
    def get_transfer_outlet_name(self, obj):
        outlet_id = obj.transfer_outlet_id
        outlet_name = ''
        for item in self.outlet_list:
            if item.id ==outlet_id:
                outlet_name = item.outlet_name
                break
        if outlet_name:
            return outlet_name
        else:
            return ''
    def get_member_phone(self, obj):
        member_id = obj.member_id
        member_phone = ''
        member= models.Member.objects.filter(id=member_id).first()
        if member:
            member_phone=member.mobile_no
        if member_phone:
            return member_phone
        else:
            return ''


class OrderListSerializer(serializers.ModelSerializer):
    # 修改添加TransactionDetails outlet
    list = serializers.SerializerMethodField()
    outlet_name = serializers.SerializerMethodField()
    outlet_list=models.Outlet.objects.all()
    member_phone=serializers.SerializerMethodField()
    class Meta:
        model = models.Transaction
        fields = '__all__'

    def get_list(self, obj):
        ret = models.TransactDetails.objects.filter(transaction=obj.id)
        if (ret is not None):
            return [TransactDetailsSerializer(i).data for i in ret]
        else:
            return []

    def get_outlet_name(self, obj):
        if(obj.origin_outlet_name is not None):
            return obj.origin_outlet_name
        else:
            outlet_id = obj.outlet_id
            outlet_name = ''
            for item in self.outlet_list:
                if item.id ==outlet_id:
                    outlet_name = item.outlet_name
                    break
            if outlet_name:
                return outlet_name
            else:
                return ''

    def get_member_phone(self, obj):
        member_id = obj.member_id
        member_phone = ''
        member= models.Member.objects.filter(id=member_id).first()
        if member:
            member_phone=member.mobile_no
        if member_phone:
            return member_phone
        else:
            return ''

        '''
        ret = models.Outlet.objects.get(id=obj.outlet.id)
        if (ret is not None):
            return ret.outlet_name
        else:
            return ''
         '''

class TransactionCSerializer(serializers.ModelSerializer):
    class Meta:
        model = models.Transaction
        exclude = ('outlet',)

    @except_validation_error
    def create(self, validated_data):
        # Insert the outlet information in the transaction record
        outlet = get_or_create_outlet(self.initial_data.get('outlet'))
        if outlet == None:
            return None
        validated_data['outlet'] = outlet
        instance = super(TransactionCSerializer, self).create(validated_data)
        # Insert the campaign type record that the member has participated in
        insert_member_campaigntype(instance.member, instance.campaigntypes.all())
        # Record the voucher obtained by this member
        record_reward_member_invicode(instance.member, instance.reward_vouchers.all())
        # Record the voucher redeemed by this member
        record_redeemed_member_voucher(instance.member, instance.redeemed_vouchers.all())
        # Record the points earned and redeemed by this member
        for count, campaign_type in enumerate(instance.campaigntypes.all()):
            if count == 0:
                update_points(instance.member, instance.reward_points, 2, campaigntype=campaign_type)
                update_points(instance.member, -instance.redeemed_points, 3, campaigntype=campaign_type)
            else:
                update_points(instance.member, 0, 2, campaigntype=campaign_type)
                update_points(instance.member, -0, 3, campaigntype=campaign_type)
        # update member last_purchase_date
        update_member_last_purchase_date(instance.member, instance.transact_datetime)
        return instance


class TransactDetailsRSerializer(serializers.ModelSerializer):
    class TransactionSerializer1(serializers.ModelSerializer):
        # 修改添加outlet获取outlet_name
        outlet = serializers.SerializerMethodField()

        def get_outlet(self, obj):
            outlets = models.Outlet.objects.filter(id=obj.outlet_id)
            if outlets is not None and len(outlets) > 0:
                return OutletSerializer(outlets[0]).data
            else:
                return ""

        class Meta:
            model = models.Transaction
            fields = ('receipt_no', 'transact_datetime', 'member', 'outlet')

    transaction = TransactionSerializer1(read_only=True)

    class Meta:
        model = models.TransactDetails
        fields = '__all__'
        depth = 2


class SalesRecordSerializer(serializers.ModelSerializer):
    amount = serializers.FloatField(required=False, allow_null=True)
    category_name = serializers.CharField(required=False, allow_null=True)

    class Meta:
        model = models.Product
        fields = "__all__"

class GrabPayPosSerializer(serializers.ModelSerializer):

    class Meta:
        model = models.GrabPayPos
        fields = "__all__"

class TopupRecordSerializer(serializers.ModelSerializer):

    class Meta:
        model = models.TopupRecord
        fields = "__all__"

class RefundRecordSerializer(serializers.ModelSerializer):

    class Meta:
        model = models.RefundRecord
        fields = "__all__"

class WirecardLogSerializer(serializers.ModelSerializer):

    class Meta:
        model = models.WirecardLog
        fields = "__all__"
class TransactDetailsCSerializer(serializers.ModelSerializer):
    # if qball_selection is exist change ice_level=None ---ff
    #models.TransactDetails.objects.filter(qball_selection='No Ice').update(ice_level=None)
    #models.TransactDetails.objects.filter(qball_selection='No Ice/No Bean').update(ice_level=None)
    class Meta:
        model = models.TransactDetails
        exclude = ('product', 'toppings')

    @except_validation_error
    def create(self, validated_data):
        # Insert the product information in the transaction details
        product = get_or_create_product(self.initial_data.get('product'))
        # product = get_product_from_PLU(self.initial_data.get('product'))
        validated_data['product'] = product
        # Insert the toppings information in the transaction details
        toppings = get_or_create_toppings(self.initial_data.get('toppings'))
        # toppings = get_topping_from_PLU(self.initial_data.get('toppings'))
        validated_data['toppings'] = toppings
        instance = super(TransactDetailsCSerializer, self).create(validated_data)
        return instance

class TakeTransactDetailsCSerializer(serializers.ModelSerializer):
    # if qball_selection is exist change ice_level=None ---ff
    #models.TransactDetails.objects.filter(qball_selection='No Ice').update(ice_level=None)
    #models.TransactDetails.objects.filter(qball_selection='No Ice/No Bean').update(ice_level=None)

    class Meta:
        model = models.TransactDetails
        fields = '__all__'



class TransactDetailsSerializer(serializers.ModelSerializer):
    #productName = serializers.SerializerMethodField()
    spicy_list = serializers.SerializerMethodField()
    group_attribute_list = serializers.SerializerMethodField()
    product_url=serializers.SerializerMethodField()
    # if qball_selection is exist change ice_level=None ---ff
    #models.TransactDetails.objects.filter(qball_selection='No Ice').update(ice_level=None)
    #models.TransactDetails.objects.filter(qball_selection='No Ice/No Bean').update(ice_level=None)
    class Meta:
        model = models.TransactDetails
        fields = '__all__'
        # exclude = ('transaction', 'toppings')
        # depth = 2

    def get_product_url(self, obj):
      ret = models.Product.objects.get(id=obj.product.id)
      if (ret is not None):
         return ret.thumb_image_path
      else:
         return ""

    #def get_productName(self, obj):
     #   ret = models.Product.objects.get(id=obj.product.id)
      #  if (ret is not None):
       #     return ret.name
        #else:
         #   return ""

    def get_spicy_list(self, obj):
        ret_list = models.TransactDetails_Spicy.objects.filter(transactdetails=obj.id)
        if (ret_list is not None):
            return [TransactDetailsSpicySerializer(i).data for i in ret_list]
        else:
            return []
    def get_group_attribute_list(self, obj):
        ret_list = models.TransactDetails_Group_Attribute.objects.filter(transactdetails=obj.id)
        if (ret_list is not None):
            return [TransactDetailsGroupAttributeSerializer(i).data for i in ret_list]
        else:
            return []

class TransactDetailsSpicySerializer(serializers.ModelSerializer):
    class Meta:
        model = models.TransactDetails_Spicy
        fields = '__all__'
class TransactDetailsGroupAttributeSerializer(serializers.ModelSerializer):
    class Meta:
        model = models.TransactDetails_Group_Attribute
        fields = '__all__'
class EvaluationSerializer(serializers.ModelSerializer):
    class Meta:
        model = models.Evaluation
        fields = '__all__'


# add TransactHistoryCSerializer ,TransactHistoryRSerializer (--ff)
class TransactHistoryCSerializer(serializers.ModelSerializer):
    class Meta:
        model = models.Transaction
        exclude = ('transact_details',)

    @except_validation_error
    def create(self, validated_data):
        # Insert the transaction information in the transact_details record
        transact_details = get_or_create_transact_details(self.initial_data.get('transact_details'))
        validated_data['transact_details'] = transact_details
        instance = super(TransactHistoryCSerializer, self).create(validated_data)
        return instance


class TransactHistoryRSerializer(serializers.ModelSerializer):

    class Meta:
        model = models.Transaction
        fields = '__all__'
        depth = 2


# add PrepaidSerializer(已支付订单订单)---ff
class PrepaidSerializer(serializers.ModelSerializer):
    list = serializers.SerializerMethodField()
    member_phone = serializers.SerializerMethodField()
    #address=serializers.SerializerMethodField()
    terminal= serializers.SerializerMethodField()


    class Meta:
        model = models.Transaction
        exclude=('campaigns','campaigntypes','reward_vouchers','redeemed_vouchers',)

    def get_list(self, obj):
        ret = models.TransactDetails.objects.filter(transaction=obj.id)
        if (ret is not None):

            return [TransactDetailsSerializer(i).data for i in ret]
        else:
            return []
    def get_address(self, obj):

        ret = models.TransactDetails.objects.filter(transaction=obj.id)
        temp_address=''
        if  (ret is not None):
            for item in ret:
                if item.product:
                    if item.product.id==9722:
                        temp_address=item.remark
                        break
            return temp_address
        else:
            return ''

    def get_member_phone(self, obj):
        member_id = obj.member_id
        member_phone = ''
        member= models.Member.objects.filter(id=member_id).first()
        if member:
            member_phone=member.mobile_no
        if member_phone:
            return member_phone
        else:
            return ''
    def get_terminal(self, obj):
        member_id = obj.member_id
        terminal = 0
        member= models.Member.objects.filter(id=member_id).first()
        if member:
            terminal=member.terminal
        if terminal:
            return terminal
        else:
            return 0
# add ReceiptNoSerializer(返回取单码)---ff
class ReceiptNoSerializer(serializers.ModelSerializer):

    class Meta:
        model = models.Transaction
        fields = ('id', 'member', 'order_no', 'receipt_no', 'transaction_status')

class SalesCountSerializer(serializers.ModelSerializer):
    id = serializers.IntegerField(required=False, allow_null=True)

    name = serializers.CharField(required=False, allow_null=True)
    sum_quantity= serializers.IntegerField(required=False, allow_null=True)
    sum_amount = serializers.DecimalField(max_digits=4, decimal_places=2,required=False, allow_null=True)

    class Meta:
        model = models.Transaction
        #fields = ("voucher_id","abbreviation")
        fields =("id","name","sum_quantity","sum_amount")











