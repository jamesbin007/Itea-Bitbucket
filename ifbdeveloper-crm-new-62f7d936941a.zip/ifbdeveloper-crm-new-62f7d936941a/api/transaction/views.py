import time
from datetime import datetime
import datetime
from django.db.models import Q,Sum,Count
from rest_framework import viewsets, request
from rest_framework.response import Response
from app01 import models
from . import serializers
from utils.pagination import DefaultPagination
from utils.permissions import IsAdmin
from rest_framework.filters import SearchFilter, OrderingFilter
from django_filters.rest_framework import DjangoFilterBackend
from django_filters import rest_framework as filters
from django_filters import Filter
from rest_framework.exceptions import PermissionDenied
from rest_framework import status
from utils.query_filter import get_page
from rest_framework.permissions import AllowAny
from rest_framework.decorators import api_view,authentication_classes,permission_classes
from django.db import transaction
from wallet.serializers import RechargeRecordCreateSerializer
from .permissions import EvaluationViewSetPermission, TransactionAndTransactDetailsViewSetPermission, \
    PrepaidViewSetPermission, TransactionAndTransactHistoryViewSetPermission,GrabPayPosViewSetPermission,WirecardLogViewSetPermission,TopupRecordPermission
from utils.message_manage import send_message_to_token
from .service import first_payment_cash_back,get_payment_mail_table,get_topup_mail_table,get_topup_outlet_mail_table,get_cancel_mail_table
from django.db import connection
from .utils import thread_send_mail,send_mooncake_payment
from payments.service import member_payment_cashback
from member.services import update_member_points
from member.services import update_member_points,deal_electric_sign
import pytz
import json
from wallet import service
from campaign.service import insert_member_campaigntype
from voucher.service import record_reward_member_voucher, record_redeemed_member_voucher
from member.services import update_points, update_member_last_purchase_date
from invicode.service import record_reward_member_invicode
from invicode import utils
from utils.campaign_function import campaign_return
from invicode.serializers import generate_random_str
from django.utils import timezone
#from product.cron import check_mooncake_order_quantity
class IntegerListFilter(Filter):
    def filter(self,qs,value):
     if value not in (None,''):
      integers = [int(v) for v in value.split(',')]
      return qs.filter(**{'%s__%s'%(self.field_name, self.lookup_expr):integers})
     return qs

# add TransactHistoryFilter(--ff)
class TransactHistoryFilter(filters.FilterSet):
    min_transact_datetime = filters.DateTimeFilter(field_name="transact_datetime", lookup_expr='gte')
    max_transact_datetime = filters.DateTimeFilter(field_name="transact_datetime", lookup_expr='lte')

    class Meta:
        model = models.Transaction
        # fields = "__all__"
        fields = ['member', 'outlet', 'receipt_no', 'pos_no', 'cashier_no', 'min_transact_datetime',
                  'max_transact_datetime']


# add PrepaidFilter(已支付订单)---ff
class PrepaidFilter(filters.FilterSet):
    outlet = filters.CharFilter(field_name="outlet__id", lookup_expr='exact')
    class Meta:
        model = models.Transaction
        fields = ['outlet',  ]


# add return receipt_no Filter(返回取单码)---ff
class ReceiptNoFilter(filters.FilterSet):

    class Meta:
        model = models.Transaction
        fields = ('id', 'member', 'order_no', 'receipt_no', 'transaction_status')


class TransactionFilter(filters.FilterSet):
    min_transact_datetime = filters.DateTimeFilter(field_name="transact_datetime", lookup_expr='gte')
    max_transact_datetime = filters.DateTimeFilter(field_name="transact_datetime", lookup_expr='lte')

    class Meta:
        model = models.Transaction
        fields = ['member', 'outlet', 'receipt_no', 'pos_no', 'cashier_no', 'min_transact_datetime',
                  'max_transact_datetime']


class OrderListFilter(filters.FilterSet):
    min_transact_datetime = filters.DateTimeFilter(field_name="transact_datetime", lookup_expr='gte')
    max_transact_datetime = filters.DateTimeFilter(field_name="transact_datetime", lookup_expr='lte')
    min_transaction_status=filters.NumberFilter(field_name="transaction_status", lookup_expr='gte')
    transaction_status_list=IntegerListFilter(field_name="transaction_status", lookup_expr='in')
    invicode_id=filters.NumberFilter(field_name="redeem_invicode", lookup_expr='exact')
    id = filters.NumberFilter(field_name="id", lookup_expr='exact')
    class Meta:
        model = models.Transaction
        fields = ['id','member', 'outlet', 'receipt_no', 'pos_no', 'cashier_no', 'min_transact_datetime',
                  'max_transact_datetime','transaction_status','min_transaction_status']

class TakeOrderListFilter(filters.FilterSet):
    min_transact_datetime = filters.DateTimeFilter(field_name="transact_datetime", lookup_expr='gte')
    max_transact_datetime = filters.DateTimeFilter(field_name="transact_datetime", lookup_expr='lte')
    min_transaction_status=filters.NumberFilter(field_name="transaction_status", lookup_expr='gte')
    transaction_status_list=IntegerListFilter(field_name="transaction_status", lookup_expr='in')
    invicode_id=filters.NumberFilter(field_name="redeem_invicode", lookup_expr='exact')
    id = filters.NumberFilter(field_name="id", lookup_expr='exact')
    class Meta:
        model = models.Transaction
        fields = ['id','member', 'receipt_no', 'pos_no', 'cashier_no', 'min_transact_datetime',
                  'max_transact_datetime','transaction_status','min_transaction_status']
class GrabPayPosFilter(filters.FilterSet):
    tx_type = filters.CharFilter(field_name="txType", lookup_expr='icontains')
    partner_id = filters.CharFilter(field_name="partnerID", lookup_expr='icontains')
    partner_tx_id= filters.CharFilter(field_name="partnerTxID", lookup_expr='icontains')
    tx_id = filters.CharFilter(field_name="txID", lookup_expr='icontains')
    orig_tx_id = filters.CharFilter(field_name="origTxID", lookup_expr='icontains')

    class Meta:
        model = models.GrabPayPos
        fields = ['txType', 'partnerID', 'partnerTxID', 'txID', 'origTxID']

class TopupRecordFilter(filters.FilterSet):
    outlet = filters.CharFilter(field_name="outlet__id", lookup_expr='exact')
    created_date = filters.DateTimeFilter(field_name="created_date", lookup_expr='exact')


    class Meta:
        model = models.TopupRecord
        fields = ['outlet', 'created_date', ]
class RefundRecordFilter(filters.FilterSet):
    outlet = filters.CharFilter(field_name="outlet__id", lookup_expr='exact')
    created_date = filters.DateTimeFilter(field_name="created_date", lookup_expr='exact')


    class Meta:
        model = models.RefundRecord
        fields = ['outlet', 'created_date', ]

class TransactDetailsFilter(filters.FilterSet):
    min_transact_datetime = filters.DateTimeFilter(field_name="transaction__transact_datetime", lookup_expr='gte')
    max_transact_datetime = filters.DateTimeFilter(field_name="transaction__transact_datetime", lookup_expr='lte')
    product_tea_base = filters.CharFilter(field_name="product__tea_base", lookup_expr='icontains')

    category_name = filters.CharFilter(field_name="product__category__name", lookup_expr='icontains')
    toppings_name = filters.CharFilter(field_name="toppings__name", lookup_expr='icontains')
    size = filters.NumberFilter(field_name="product__size")
    transaction_id= filters.CharFilter(field_name="transaction__id", lookup_expr='exact')

    class Meta:
        model = models.TransactDetails

        fields = ('method', 'ice_level', 'sugar_level', 'transaction__member', 'size', 'min_transact_datetime',
                  'max_transact_datetime', 'category_name', 'toppings_name', 'product_tea_base','transaction_id')


class EvaluationFilter(filters.FilterSet):
    min_created = filters.DateTimeFilter(field_name="created", lookup_expr='gte')
    max_created = filters.DateTimeFilter(field_name="created", lookup_expr='lte')

    class Meta:
        model = models.Evaluation
        fields = ['transaction', ]


# add OrderQueryFilter ---ff(19/6/13)
class OrderQueryFilter(filters.FilterSet):
    min_payment_datetime = filters.DateTimeFilter(field_name="payment_datetime", lookup_expr='gte')
    max_payment_datetime = filters.DateTimeFilter(field_name="payment_datetime", lookup_expr='lte')

    class Meta:
        model = models.Transaction
        fields = '__all__'


# add OrderQueryViewSet ---ff(19/6/13)
class OrderQueryViewSet(viewsets.ModelViewSet):
    permission_classes = (PrepaidViewSetPermission,)
    queryset = models.Transaction.objects.all()
    serializer_class = serializers.OrderQuerySerializer
    pagination_class = DefaultPagination
    filter_backends = (
        DjangoFilterBackend,
        SearchFilter,
        OrderingFilter,
    )
    filter_class = OrderQueryFilter
    search_fields = ('outlet', 'payment_modes', 'payment_datetime')

    def get_queryset(self):

        # if self.request.data.get('payment_datetime'):
        #     self.queryset = self.queryset.filter(payment_datetime__gte=(self.request.data.get('payment_datetime_start')),
        #                                          payment_datetime__lte=(self.request.data.get('payment_datetime_end')))
        return super(OrderQueryViewSet, self).get_queryset()

    def get_serializer_class(self):
        if self.request.method == "GET":
            return serializers.OrderQuerySerializer
        else:
            return super(OrderQueryViewSet, self).get_serializer_class()



# add TransactHistoryViewSet ---ff
class TransactHistoryViewSet(viewsets.ModelViewSet):
    permission_classes = (TransactionAndTransactHistoryViewSetPermission,)
    queryset = models.Transaction.objects.all()
    serializer_class = serializers.TransactHistoryCSerializer
    pagination_class = DefaultPagination
    filter_backends = (
        DjangoFilterBackend,
        SearchFilter,
        OrderingFilter,
    )
    filter_class = TransactHistoryFilter
    search_fields = ('member', 'outlet', 'transact_datetime')

    def get_queryset(self):

        self.queryset = self.queryset.prefetch_related(
            'transact_details',
        )
        if self.request.data.get('member_id'):
            self.queryset = self.queryset.filter(member=self.request.data.get('member_id'))
        if self.request.data.get('outlet_id'):
            self.queryset = self.queryset.filter(outlet=self.request.data.get('outlet_id'))
        if self.request.data.get('transact_datetime'):
            self.queryset = self.queryset.filter(transact_datetime__gte=(self.request.data.get('transact_datetime_start')),
                                                 transact_datetime__lte=(self.request.data.get('transact_datetime_end')))

        if self.request.user.role.name not in (0, 1, 4):
            self.queryset = self.queryset.filter(transaction__member=self.request.user)

        return super(TransactHistoryViewSet, self).get_queryset()

    def get_serializer_class(self):
        if self.request.method == "GET":
            return serializers.TransactHistoryRSerializer
        else:
            return super(TransactHistoryViewSet, self).get_serializer_class()


now = datetime.datetime.now()
zero = now - datetime.timedelta(hours=now.hour, minutes=now.minute, seconds=now.second, microseconds=now.microsecond)


# add PrepaidViewSet(已支付订单)---ff
class PrepaidViewSet(viewsets.ModelViewSet):
    now = datetime.datetime.now()
    zero = now - datetime.timedelta(hours=now.hour, minutes=now.minute, seconds=now.second,
                                    microseconds=now.microsecond)
    permission_classes = (PrepaidViewSetPermission,)
    queryset = models.Transaction.objects.order_by('payment_datetime')
    serializer_class = serializers.PrepaidSerializer
    pagination_class = DefaultPagination
    filter_backends = (
        DjangoFilterBackend,
        SearchFilter,
    )
    filter_class = PrepaidFilter
    search_fields = ('outlet', 'id', 'transaction_status', 'transaction_id')

    def get_queryset(self):
        now = datetime.datetime.now()
       # return self.queryset.filter(Q(transaction_status=4,print_status=False,delay_time__lte=now + datetime.timedelta(minutes=15))| Q(transaction_status=3,payment_datetime__gte=now,payment_datetime__lte=now + datetime.timedelta(minutes=15)))
        return self.queryset.filter(Q(pick_up_type=1, transaction_status__in = (4,), print_status = False) |
            #transaction_status__in=(4,), print_status=False,delay_time__date=now.date(), delay_time__lte=now + datetime.timedelta(minutes=10))
           Q(pick_up_type=0, transaction_status__in = (4,), print_status = False,  delay_time__lte = now + datetime.timedelta(minutes=10)))
        # start = time.time()
        '''
        cancel = self.queryset.filter(transaction_status=3)
        if len(cancel)>0:
            self.queryset = cancel
        else:
            delta_time_1 = now + datetime.timedelta(hours=00, minutes=14, seconds=59)
            all_tran = models.Transaction.objects.none()
            tran_list = []
            trans = self.queryset.filter(transaction_status=2)
            for i in trans:
                if i.delay_time != None and i.delay_time != '':
                    # print('----------delay_time-----------')
                    tran = self.queryset.filter(id=i.id).filter(delay_time__lte=delta_time_1)
                    tran_list.append(tran)
                else:
                    # print('*********pick_up_time************************')
                    # now-15min pick_up_time=0|1(15min内): payment_datetime + 15 - now  <= 15 取出
                    # 30min     pick_up_time=2(30min):     payment_datetime + 30 - now  <= 15 取出
                    # 45min     pick_up_time=3(45min):     payment_datetime + 45 - now  <= 15 取出
                    # 1h        pick_up_time=4(1h):        payment_datetime + 60 - now  <= 15 取出
                    delta_time_2 = now - datetime.timedelta(hours=00, minutes=14, seconds=59)
                    delta_time_3 = now - datetime.timedelta(hours=00, minutes=29, seconds=59)
                    delta_time_4 = now - datetime.timedelta(hours=00, minutes=44, seconds=59)

                    tran = self.queryset.filter(id=i.id).filter(
                        Q(payment_datetime__lte=delta_time_1, pick_up_time=0)
                        | Q(payment_datetime__lte=delta_time_1, pick_up_time=1)
                        | Q(payment_datetime__lte=delta_time_2, pick_up_time=2)
                        | Q(payment_datetime__lte=delta_time_3, pick_up_time=3)
                        | Q(payment_datetime__lte=delta_time_4, pick_up_time=4))
                    tran_list.append(tran)
            for list in tran_list:
                all_tran = all_tran | list
            # tran_list = chain(all_tran)
            self.queryset = all_tran
            # print('///////////////////////////')
            # end = time.time()
            # print('Running time: %s Seconds' % (end - start))
            # print('///////////////////////////')
       
        return super(PrepaidViewSet, self).get_queryset()

    '''
    def get_serializer_class(self):
        if self.request.method == "GET":
            return serializers.PrepaidSerializer
        else:
            return super(PrepaidViewSet, self).get_serializer_class()

def getIntervalTime(x):
    return {
        '0': 0,
        '1': 15,
        '2':30,
        '3':45,
        '4':60
    }[x]
# add return ReceiptNoViewSet (返回取单码)---ff
class ReceiptNoViewSet(viewsets.ModelViewSet):
    permission_classes = (PrepaidViewSetPermission,)
    queryset = models.Transaction.objects.all()
    serializer_class = serializers.ReceiptNoSerializer
    pagination_class = DefaultPagination
    filter_backends = (
        DjangoFilterBackend,
        SearchFilter,
        OrderingFilter,
    )
    filter_class = ReceiptNoFilter

    def get_queryset(self):
        self.queryset = self.queryset.filter(order_no='order_no')
        return super(ReceiptNoViewSet, self).get_queryset()

    def create(self, request, *args, **kwargs):
        order_no = request.data.get('order_no')
        receipt_no = request.data.get('receipt_no')
        print(order_no)
        if (order_no and receipt_no):

            update_val = models.Transaction.objects.filter(order_no=order_no).update(print_status=True,receipt_no=receipt_no)
            if(update_val>0):
                transactionObj=models.Transaction.objects.filter(order_no=order_no).first()
                wallet_id=0
                member=None
                pay_mode = 'Wallet'
                msg=''
                if transactionObj:
                    print(transactionObj.receipt_no)
                    member=transactionObj.member
                    if transactionObj.payment_modes==8:
                        pay_mode='Wallet'
                    elif  transactionObj.payment_modes==9:
                        pay_mode='Wirecard'
                    elif  transactionObj.payment_modes==12:
                        pay_mode = 'Grabpay'
                    if transactionObj.pick_up_type==0:
                        msg='Please collect your order at the counter with : ' + receipt_no
                    else:
                        msg='We will delivery your order  as soon as possible'
                if member:
                    wallet=models.Wallet.objects.filter(member__id=member.id).first()
                    if wallet:
                        wallet_id=wallet.id

                #countTable = get_payment_mail_table(transactionObj, member, wallet_id, pay_mode)

                #thread_send_mail(countTable, "confirm")
                #transactionObj=models.Transaction.objects.filter(order_no=order_no).first()
                #if transactionObj:
                    #member=transactionObj.member
                if member:
                    device_token = member.device_token
                    if device_token:
                        send_message_to_token(device_token, 'Order Confirmed',msg)
                instance={'status':'ok'}
            else:
                instance=None
            #print(request.data.get('transaction_status')=='5')
            #send push message to mobile
            '''
            if( request.data.get('transaction_status')=='4'):
                instance.receipt_no = request.data.get('receipt_no')
                instance.transaction_status = request.data.get('transaction_status')
                instance.save()
                member=instance.member
                if (member):
                    device_token=member.device_token
                    if(device_token):
                        transact_datetime=instance.transact_datetime
                        pick_up_time=instance.pick_up_time
                        delay_time=instance.delay_time
                        if(delay_time):
                            pickup_time=delay_time
                        else:
                            interval_time=getIntervalTime(str(pick_up_time))
                            pickup_time=transact_datetime+ datetime.timedelta(minutes=interval_time)
                        pickup_time=pickup_time+ datetime.timedelta(hours=8)
                        if device_token:
                             send_message_to_token(device_token,'Order Confirmed','Receipt NO.'+request.data.get('receipt_no')+'\n Order NO.'+order_no +'\nPick up time '+pickup_time.strftime("%Y-%m-%d %H:%M"))

            elif ( request.data.get('transaction_status')=='5'):
                if(instance.transaction_status==2 or instance.transaction_status==4):
                    instance.transaction_status = int(request.data.get('transaction_status'))
                    instance.save()
                    #insert_member_campaigntype(instance.member, instance.campaigntypes.all())
                    # Record the voucher obtained by this member
                    #record_reward_member_invicode(instance.member, instance.reward_vouchers.all())
                    # Record the voucher redeemed by this member
                    #record_redeemed_member_voucher(instance.member, instance.redeemed_vouchers.all())
                    # Record the points earned and redeemed by this member
                    #for count, campaign_type in enumerate(instance.campaigntypes.all()):
                        #if count == 0:
                         #   update_points(instance.member, instance.reward_points, 2, campaigntype=campaign_type)
                          #  update_points(instance.member, -instance.redeemed_points, 3, campaigntype=campaign_type)
                        #else:
                         #   update_points(instance.member, 0, 2, campaigntype=campaign_type)
                          #  update_points(instance.member, -0, 3, campaigntype=campaign_type)
                    # update member points
                    if (instance.discount_amount is  None or instance.discount_amount==0):
                         reward_points=instance.total_money*10
                         update_points(instance.member, reward_points, 2)
                    else:
                        reward_points = (instance.total_money-instance.discount_amount) * 10
                        update_points(instance.member, reward_points, 2)
                    # update member last_purchase_date
                    update_member_last_purchase_date(instance.member, instance.transact_datetime)
                else:
                    instance = None
            else:
                instance = None
                '''
        else:
            instance = None
        if(instance is None):
            return Response({'status':'error'},status=status.HTTP_401_UNAUTHORIZED)
        else:
            return Response(instance, status=status.HTTP_200_OK)


class TransactionViewSet(viewsets.ModelViewSet):
    permission_classes = (TransactionAndTransactDetailsViewSetPermission,)
    queryset = models.Transaction.objects.all()
    serializer_class = serializers.TransactionCSerializer
    pagination_class = DefaultPagination
    filter_backends = (
        DjangoFilterBackend,
        SearchFilter,
        OrderingFilter,
    )
    filter_class = TransactionFilter
    search_fields = ('member__id', 'outlet__id', 'receipt_no', 'pos_no', 'cashier_no')
    ordering_fields = ('member', 'outlet', 'receipt_no', 'pos_no', 'cashier_no', 'total_money', 'transact_datetime')

    def get_queryset(self):
        self.queryset = self.queryset.prefetch_related(
            'transact_details__product__category',
            'transact_details__toppings',
            'outlet', 'campaigns', 'campaigntypes',
            'reward_vouchers',
            'redeemed_vouchers',
        )
        if self.request.user.role.name not in (0, 1, 4):
            self.queryset = self.queryset.filter(member=self.request.user)
        return super(TransactionViewSet, self).get_queryset()

    def get_serializer_class(self):
        if self.request.method == "GET":
            return serializers.TransactionRSerializer
        else:
            return super(TransactionViewSet, self).get_serializer_class()


class TakeTransactDetailsViewSet(viewsets.ModelViewSet):
    permission_classes = (TransactionAndTransactDetailsViewSetPermission,)
    queryset = models.TransactDetails.objects.all().order_by('-id')
    #serializer_class = serializers.TakeTransactDetailsCSerializer
    serializer_class = serializers.TransactDetailsSerializer
    pagination_class = DefaultPagination
    filter_backends = (
        DjangoFilterBackend,
        SearchFilter,
        OrderingFilter,
    )
    filter_class = TransactDetailsFilter
    search_fields = ('transaction__receipt_no', 'product__name')



class TransactDetailsViewSet(viewsets.ModelViewSet):
    permission_classes = (TransactionAndTransactDetailsViewSetPermission,)
    queryset = models.TransactDetails.objects.all().order_by('-id')
    serializer_class = serializers.TransactDetailsCSerializer
    pagination_class = DefaultPagination
    filter_backends = (
        DjangoFilterBackend,
        SearchFilter,
        OrderingFilter,
    )
    filter_class = TransactDetailsFilter
    search_fields = ('transaction__receipt_no', 'product__name')

    def get_queryset(self):
        self.queryset = self.queryset.prefetch_related(
            'transaction',
            # 修改product__category为product__category
            'product',
            # 'product__category',
            'toppings',
        )
        if self.request.user.role.name not in (0, 1, 4):
            self.queryset = self.queryset.filter(transaction__member=self.request.user)
        return super(TransactDetailsViewSet, self).get_queryset()

    def get_serializer_class(self):
        if self.request.method == "GET":
            return serializers.TransactDetailsRSerializer
        else:
            return super(TransactDetailsViewSet, self).get_serializer_class()


def transaction_success(**data):
    data['transaction_commit'] = True


# add order (transaction,transactionDetails)
class OrderViewSet(viewsets.ModelViewSet):
    data={}
    data['transaction_commit']=False
    #permission_classes = ((AllowAny,))
    permission_classes = (WirecardLogViewSetPermission,)
    queryset = models.Transaction.objects.all()
    serializer_class = serializers.OrderSerializer
    pagination_class = DefaultPagination
    filter_backends = (
        DjangoFilterBackend,
        SearchFilter,
        OrderingFilter,
    )
    filter_class = TransactionFilter
    search_fields = ('transaction_status','member','outlet',)
    ordering_fields = ('transact_datetime', )

    def get_queryset(self):
        ret = super(OrderViewSet, self).get_queryset()
        if self.request.user.role.name in (0, 1, 4):
            return ret
        else:
            return ret.filter(transaction__member=self.request.user)

    def create(self, request, *args, **kwargs):
        try:
            with transaction.atomic():
                voucher_dict={}
                has_voucher=False
                serializer = self.get_serializer(data=request.data)
                serializer.is_valid(raise_exception=True)
                transaction_status=request.data.get('transaction_status')
                if(transaction_status>0):
                    return Response({'msg': 'no permission'})
                order_no=request.data.get('order_no')
                c_trs=models.Transaction.objects.filter(order_no=order_no).first()
                if c_trs:
                    return Response(serializers.OrderSerializer(c_trs).data, status=status.HTTP_201_CREATED)
                #delivery time
                '''
                delivery_time=request.data.get('delivery_time')
                if delivery_time:
                    time_arr=delivery_time.split(' ')
                    if time_arr:
                        delivery_date=time_arr[0]
                        now=datetime.datetime.now()
                        now_date=now.date()
                        now_date_str=now_date.strftime('%Y-%m-%d')
                        today_result = delivery_date in now_date_str
                        print ('delivery date'+delivery_date+ '  '+ now_date_str)
                        if not today_result:
                            return Response({'msg': 'Only today delivery order'})
                '''
                transactionDetails_list = request.data.get('list')
                invicode_id=request.data.get('redeem_invicode')
                outlet=request.data.get('outlet')
                outlet_obj=models.Outlet.objects.filter(id=outlet).first()
                if outlet_obj:
                    if outlet_obj.closed:
                        return Response({'msg': 'outlet temporary closed'})
                    if outlet_obj.pickup_choice==0:
                        if request.data.get('pick_up_type')==1:
                            return Response({'msg': 'This outlet only support to pick up'})
                    if outlet_obj.pickup_choice==1:
                        if request.data.get('pick_up_type')==0:
                            return Response({'msg': 'This outlet only support to delivery'})
                        #check order quantity in delivery times
                        #delivery_times=request.data.get('delivery_time')
                        #check_quantity=check_mooncake_order_quantity(delivery_times,request.data.get('outlet'))
                        #if check_quantity:
                        #    return Response({'msg': 'Deliveries for this hour are fully booked,please choose another time'})
                #order check enable
                if request.data.get('total_money')<=0 and (invicode_id ==0 or invicode_id is None or request.data.get('discount_amount')==0):
                    pass
                    #return Response({'msg': 'Order amount wrong'})

                recent_amount=request.data.get('total_money')+request.data.get('discount_amount')
                real_order_amount=0
                if  transactionDetails_list:
                    for transactionDetails in transactionDetails_list:

                        real_order_amount+=transactionDetails["price"]*transactionDetails["quantity"]
                        if transactionDetails["price"]<=0:
                            return Response({'msg': 'Order amount wrong'})
                        else:
                            productObj = models.Product.objects.get(id=transactionDetails['product'])
                            if productObj:
                                #limit mooncake purchase quantity
                                '''
                                if productObj.voucher:
                                    has_voucher =True
                                    voucher_id=productObj.voucher.id
                                    if voucher_dict:
                                        if str(voucher_id) in voucher_dict:
                                            voucher_dict[str(voucher_id)]=voucher_dict[str(voucher_id)]+transactionDetails["quantity"]
                                        else:
                                            voucher_dict[str(voucher_id)] =  transactionDetails["quantity"]
                                    else:
                                        voucher_dict[str(voucher_id)] = transactionDetails["quantity"]
                                '''
                                if int(transactionDetails["price"])<int(productObj.price):
                                    return Response({'msg': 'Order amount wrong'})
                                diff_amount=productObj.price-transactionDetails["price"]
                                if(diff_amount>0.1):
                                    pass
                                    #return Response({'msg': 'Item price changed since previous order,clear cart then order by menu'})
                        #check size price
                        if transactionDetails["transactDetails_type"]==0:
                            if transactionDetails["size"]>0 and transactionDetails["size"]<3:
                                if transactionDetails["size"]==1:
                                    size_large=models.Product.objects.filter(outlet__id=request.data.get('outlet'),name='size_large').first()
                                    if size_large:
                                        size_large_price=size_large.price
                                        if transactionDetails["price"]+0.05 <productObj.price+size_large_price:
                                            pass
                                            #return Response({'msg': 'Order size amount wrong,clear cart then order by menu'})

                                elif transactionDetails["size"]==2:
                                    size_tall = models.Product.objects.filter(outlet__id=request.data.get('outlet'),
                                                                               name='size_tall').first()
                                    if size_tall:
                                        size_tall_price = size_tall.price
                                        if transactionDetails["price"]+0.05 < productObj.price + size_tall_price:
                                            pass
                                            #return Response({'msg': 'Order size amount wrong,clear cart then order by menu'})
                    if int(recent_amount)<int(real_order_amount):
                        pass
                        #return Response({'msg': 'Order amount wrong'})
                    #limit voucher max quantity
                    '''
                    if has_voucher:
                        if voucher_dict:
                            for item in voucher_dict.keys():
                                voucher_set=models.Voucher_Set.objects.filter(voucher__id=int(item)).first()
                                if voucher_set:
                                    max_quantity=voucher_set.max_quantity
                                    if voucher_set.all_limit:
                                        invicode_amount = models.Invicode.objects.filter(voucher__id=int(item)).aggregate(count=Count('id'))
                                    if  voucher_set.today_limit:
                                        invicode_amount = models.Invicode.objects.filter(voucher__id=int(item),register_date__date=datetime.datetime.now().date()).aggregate(count=Count('id'))
                                    recent_quantity= voucher_dict[item]+ invicode_amount['count']
                                    if recent_quantity>max_quantity:
                                        remain_quantity=max_quantity-invicode_amount['count']
                                        if remain_quantity<0:
                                            remain_quantity=0
                                        voucher=voucher_set.voucher
                                        if voucher:
                                            voucher_name=voucher.name
                                            return Response({'msg': voucher_name+' max quantity '+str(max_quantity)+' ,remain '+str(remain_quantity)+' can buy' })
                    '''

                if(invicode_id):
                    invicodeObj=models.Invicode.objects.filter(id=invicode_id,status=1).first()
                    if(invicodeObj):
                        invicodeObj.status=3
                        invicodeObj.redeem_date=time.strftime("%Y-%m-%d %H:%M:%S", time.localtime())
                        invicodeObj.save()
                    else:
                        return Response({'msg': 'Invicode redeemed already'})
                self.perform_create(serializer)
                headers = self.get_success_headers(serializer.data)
                transaction_id=serializer.data['id']
                #save origin_outlet_name
                recent_transaction_obj=models.Transaction.objects.filter(id=transaction_id).first()
                if recent_transaction_obj:
                    recent_transaction_obj.total_money=getFloat(recent_transaction_obj.total_money+0.000001)
                    if recent_transaction_obj.outlet:
                        origin_out_obj=models.Outlet.objects.filter(id=recent_transaction_obj.outlet.id).first()
                        if origin_out_obj:
                            origin_outlet_name=origin_out_obj.outlet_name
                            recent_transaction_obj.origin_outlet_name=origin_outlet_name
                            outlet_count_date = origin_out_obj.outlet_count_date
                            if outlet_count_date is None:
                                recent_transaction_obj.send_mail_flag = 1

                            else:
                                now_str = datetime.datetime.now().date()
                                if now_str >= outlet_count_date:
                                    recent_transaction_obj.send_mail_flag = 1

                                else:
                                    recent_transaction_obj.send_mail_flag = 0
                            recent_transaction_obj.save()
                    recent_transaction_obj.save()
                for transactionDetails in transactionDetails_list:

                    transactionDetails["transaction"]=models.Transaction.objects.get(id=transaction_id)
                    productObj=models.Product.objects.get(id=transactionDetails['product'])
                    transactionDetails["product"] = productObj
                    if productObj:
                        transactionDetails["item_code"] = productObj.item_code
                    transactionDetails["productName"] =productObj.name if productObj else ""


                    if ('toppings' in transactionDetails.keys() and transactionDetails['toppings'] is not None):
                        toppings = models.Toppings.objects.filter(id__in=transactionDetails['toppings'])
                        transactionDetails.pop("toppings")
                    temp_spicy_list=None
                    if ('spicy_list' in transactionDetails.keys() ):
                        temp_spicy_list=transactionDetails['spicy_list']
                        transactionDetails.pop("spicy_list")
                    temp_group_attribute_list = None
                    if ('group_attribute_list' in transactionDetails.keys() ):
                        temp_group_attribute_list=transactionDetails['group_attribute_list']
                        transactionDetails.pop("group_attribute_list")
                    details=models.TransactDetails.objects.create(**transactionDetails)
                    #if (toppings is not None):
                    #    details.toppings.set(toppings)
                    if temp_spicy_list:
                        transactionDetails.update(spicy_list=temp_spicy_list)
                    if temp_group_attribute_list:
                        transactionDetails.update(group_attribute_list=temp_group_attribute_list)
                    details_id=details.id
                    if ( 'spicy_list' in transactionDetails.keys() and transactionDetails['spicy_list'] is not None):
                        for spicy_topping in transactionDetails['spicy_list']:
                            objs = []
                            topping=models.Toppings.objects.get(id=spicy_topping['topping'])
                            if topping:
                                #print(topping)
                                obj = models.TransactDetails_Spicy(**{'transactdetails': details, 'toppings': topping,'t_number':spicy_topping['t_number'],'topping_name':topping.name,'topping_chinese_name':topping.description})
                                objs.append(obj)
                                models.TransactDetails_Spicy.objects.bulk_create(objs)
                    if ( 'group_attribute_list' in transactionDetails.keys() and transactionDetails['group_attribute_list'] is not None):
                        for group_attribute in transactionDetails['group_attribute_list']:
                            objs = []
                            if 'group_id' in group_attribute.keys() and group_attribute['group_id'] is not None:
                                group=models.Group.objects.get(id=group_attribute['group_id'])
                            else:
                                group=None
                            attribute = models.Attribute.objects.get(id=group_attribute['attribute_id'])
                            if group and attribute:

                                obj = models.TransactDetails_Group_Attribute(**{'transactdetails': details, 'group': group,'group_name':group.group_name,'attribute':attribute,'attribute_name':attribute.name,'price':attribute.price})
                                objs.append(obj)
                                models.TransactDetails_Group_Attribute.objects.bulk_create(objs)

                return Response(serializer.data, status=status.HTTP_201_CREATED, headers=headers)
        except Exception as e:
            return Response( { "msg": str(e.args)}, status=status.HTTP_500_INTERNAL_SERVER_ERROR)

        #if(self.data['transaction_commit']):
            #return Response(serializer.data, status=status.HTTP_201_CREATED, headers=headers)
        #else:
            #return Response({'msg':'Server error'}, status=status.HTTP_201_CREATED, headers=headers)

    #transaction.on_commit(transaction_success(**data))
##get order
class OrderListViewSet(viewsets.ModelViewSet):
    data={}
    data['transaction_commit']=False
    permission_classes = ((AllowAny,))
    queryset = models.Transaction.objects.all().order_by('-transact_datetime')
    serializer_class = serializers.OrderListSerializer
    pagination_class = DefaultPagination
    filter_backends = (
        DjangoFilterBackend,
        SearchFilter,
        OrderingFilter,
    )
    filter_class = OrderListFilter
    search_fields = ('transaction_status','member','outlet',)
    ordering_fields = ('transact_datetime', )

class TakeOrderListViewSet(viewsets.ModelViewSet):
    data={}
    data['transaction_commit']=False
    permission_classes = ((AllowAny,))
    queryset = models.Transaction.objects.all().order_by('-transact_datetime')

    serializer_class = serializers.OrderListSerializer

    pagination_class = DefaultPagination
    filter_backends = (
        DjangoFilterBackend,
        SearchFilter,
        OrderingFilter,
    )
    filter_class = OrderListFilter
    search_fields = ('transaction_status','member','outlet',)
    ordering_fields = ('transact_datetime', )
    def get_queryset(self):
        now = datetime.datetime.now()
        #queryset = models.Transaction.objects.filter(delay_time__lte=now + datetime.timedelta(minutes=15)).order_by('-delay_time')
        queryset = models.Transaction.objects.all().order_by('-transact_datetime')

        return queryset

class NewTakeOrderListViewSet(viewsets.ModelViewSet):
    data={}
    data['transaction_commit']=False
    permission_classes = ((AllowAny,))
    queryset = models.Transaction.objects.all().order_by('transact_datetime')

    #serializer_class = serializers.OrderListSerializer
    serializer_class = serializers.TakeOrderListSerializer
    pagination_class = DefaultPagination
    filter_backends = (
        DjangoFilterBackend,
        SearchFilter,
        OrderingFilter,
    )
    filter_class = TakeOrderListFilter
    search_fields = ('transaction_status','member','outlet',)
    ordering_fields = ('transact_datetime', )
    def get_queryset(self):
        outlet_id=self.request.GET.get('outlet')
        if(self.request.GET.get('outlet')!=''):
            queryset = models.Transaction.objects.filter(Q(outlet__id=outlet_id) | Q(transfer_outlet__id=outlet_id)).order_by('-delay_time')
            return queryset


        #now = datetime.datetime.now()
        #queryset = models.Transaction.objects.filter(delay_time__lte=now + datetime.timedelta(minutes=15)).order_by('-delay_time')
        queryset = models.Transaction.objects.all().order_by('-transact_datetime')

        return queryset
class EvaluationViewSet(viewsets.ModelViewSet):
    permission_classes = (EvaluationViewSetPermission,)
    queryset = models.Evaluation.objects.all()
    serializer_class = serializers.EvaluationSerializer
    pagination_class = DefaultPagination
    filter_backends = (
        DjangoFilterBackend,
        SearchFilter,
        OrderingFilter,
    )
    filter_class = EvaluationFilter
    search_fields = ('transaction',)
    ordering_fields = ('transaction', 'created')

    def get_queryset(self):
        ret = super(EvaluationViewSet, self).get_queryset()
        if self.request.user.role.name in (0, 1, 4):
            return ret
        else:
            return ret.filter(transaction__member=self.request.user)

    def create(self, request, *args, **kwargs):
        serializer = self.get_serializer(data=request.data)
        serializer.is_valid(raise_exception=True)
        transaction = serializer.validated_data.get('transaction')
        if not transaction.member == request.user:
            raise PermissionDenied()
        self.perform_create(serializer)
        headers = self.get_success_headers(serializer.data)
        return Response(serializer.data, status=status.HTTP_201_CREATED, headers=headers)


class SalesRecordViewSet(viewsets.ReadOnlyModelViewSet):
    permission_classes = (IsAdmin,)
    queryset = models.Product.objects.all()
    serializer_class = serializers.SalesRecordSerializer
    pagination_class = DefaultPagination
    filter_backends = (
        DjangoFilterBackend,
        SearchFilter,
        OrderingFilter,
    )
    filter_fields = {'name': 'app01_product.name', 'tea_base': 'app01_product.tea_base',
                     'category_name': 'app01_category.name'}
    int_filter_fields = {'size': 'app01_product.size'}
    date_filter_fields = {'min_transact_datetime': ('app01_transaction.transact_datetime', '>='),
                          'max_transact_datetime': ('app01_transaction.transact_datetime', '<=')}
    search_fields = ['app01_product.name', 'app01_category.name']
    ordering_fields = {'price': 'app01_product.price', 'amount': 'amount'}

    def list(self, request, *args, **kwargs):
        sql = """SELECT "app01_category"."name" AS "category_name", "app01_product"."id", "app01_product"."name", "app01_product"."description", "app01_product"."price", "app01_product"."tea_base", "app01_product"."item_code", "app01_product"."category_id", "app01_product"."created", COALESCE(SUM("app01_transactdetails"."quantity"), 0) AS "amount"
 FROM "app01_product"
 INNER JOIN "app01_transactdetails" ON ("app01_product"."id" = "app01_transactdetails"."product_id")
 INNER JOIN "app01_transaction" ON ("app01_transactdetails"."transaction_id" = "app01_transaction"."id")
 INNER JOIN "app01_category" ON ("app01_product"."category_id" = "app01_category"."id")
 GROUP BY "app01_product"."id",  "app01_category"."id" """

        # filter sql
        filter_sql = ''
        total_filter_fields_keys = []
        filter_fields_keys = self.filter_fields.keys()
        date_filter_fields_keys = self.date_filter_fields.keys()
        int_filter_fields_keys = self.int_filter_fields.keys()
        total_filter_fields_keys.extend(filter_fields_keys)
        total_filter_fields_keys.extend(date_filter_fields_keys)
        total_filter_fields_keys.extend(int_filter_fields_keys)
        filter_fields_dict = {}
        for filter_field_key in total_filter_fields_keys:
            filter_field_value = request.GET.get(filter_field_key)
            if filter_field_value:
                filter_fields_dict[filter_field_key] = filter_field_value
        if filter_fields_dict:
            filter_sql += ' WHERE '
            for filter_field_key, filter_field_value in filter_fields_dict.items():
                if filter_sql != ' WHERE ':
                    filter_sql += ' AND '
                if filter_field_key in date_filter_fields_keys:
                    filter_sql += ' {0} {1} '.format(self.date_filter_fields[filter_field_key][0],
                                                     self.date_filter_fields[filter_field_key][
                                                         1]) + " '{0}'::timestamptz ".format(filter_field_value)
                elif filter_field_key in int_filter_fields_keys:
                    filter_sql += ' {0} = {1}'.format(self.int_filter_fields[filter_field_key], filter_field_value)
                else:
                    filter_sql += ' UPPER({0}) '.format(
                        self.filter_fields[filter_field_key]) + "LIKE UPPER('%%{0}%%') ".format(filter_field_value)

        # search sql
        search_sql = ''
        search_value = request.GET.get('search')
        if search_value:
            search_sql += ' WHERE ( ' if filter_sql == '' else ' AND ( '
            for search_field in self.search_fields:
                if search_sql not in (' WHERE ( ', ' AND ( '):
                    search_sql += ' OR '
                search_sql += ' UPPER({0}) '.format(search_field) + "LIKE UPPER('%%{0}%%') ".format(search_value)
            else:
                search_sql += ' ) '
        # where sql(filter sql + search sql)
        where_sql = filter_sql + search_sql
        # Order by products_sold, products_sold_incr, turnover, turnover_incr
        order_sql = ''
        order_field_key = request.GET.get('ordering')
        ordering_fields_keys = self.ordering_fields.keys()
        desc_ordering_fields_keys = ['-%s' % i for i in ordering_fields_keys]
        if order_field_key in ordering_fields_keys:
            order_sql = " order by %s " % self.ordering_fields[order_field_key]
        elif order_field_key in desc_ordering_fields_keys:
            order_sql = " order by %s desc " % self.ordering_fields[order_field_key[1:]]
        # get page
        page_size, page = get_page(request, self.paginator.page_size)
        # limit sql
        limit_sql = ' limit %s offset %s ' % (page_size, (page - 1) * page_size)
        # group by sql
        group_by_sql = ' GROUP BY "app01_product"."id",  "app01_category"."id" '
        # all sql
        if not where_sql == '':
            group_by_index = sql.index('GROUP BY')
            sql = sql[:group_by_index]
            all_sql = sql + where_sql + group_by_sql + order_sql + limit_sql
        else:
            all_sql = sql + where_sql + order_sql + limit_sql
        all_queryset = models.Product.objects.raw(all_sql)
        all_queryset = list(all_queryset)
        # for i in all_queryset:
        #     print(i.__dict__)
        serializer = self.get_serializer(all_queryset, many=True)
        # Pagination
        from collections import OrderedDict
        return Response(OrderedDict([
            ('count', len(all_queryset)),
            # ('next', self.get_next_link()),
            # ('previous', self.get_previous_link()),
            ('results', serializer.data)
        ]))
#free cancel because stockout
@api_view(['GET', 'POST'])
@authentication_classes([])
@permission_classes((AllowAny,))
def freeCancel(request, *args, **kwargs):

    if request.method == 'GET':
        #order_id
        order_id = request.query_params.get('product_status')
        #transaction_status

        transactionObj = models.Transaction.objects.filter(id=order_id)

        if(transactionObj):

                transactionTemp = transactionObj[0]
                #状态为4，已confirm

                if (transactionTemp.transaction_status == 4):
                    with transaction.atomic():

                        result = models.Transaction.objects.filter(id=transactionTemp.id, transaction_status=4).update(
                            transaction_status=3)
                        if result:
                            member_id = transactionTemp.member.id
                            wallet = models.Wallet.objects.get(member__id=member_id)
                            total_money=transactionTemp.total_money
                            discount_amount=transactionTemp.discount_amount
                            recharge_money = 0
                            if(total_money>0):
                                return_money = total_money
                                recharge_money = total_money
                                if (discount_amount is not None and discount_amount > 0):

                                    if ((transactionTemp.redeem_invicode) is not None and (
                                            transactionTemp.redeem_invicode != 0)):
                                        invicodeObj = models.Invicode.objects.get(id=transactionTemp.redeem_invicode)
                                        if (invicodeObj):
                                            invicodeObj.status = 1
                                            invicodeObj.save()


                                wallet.balance += return_money
                                wallet.save()



                            else:

                                if ((transactionTemp.redeem_invicode) is not None and (
                                        transactionTemp.redeem_invicode != 0)):
                                    invicodeObj = models.Invicode.objects.get(id=transactionTemp.redeem_invicode)
                                    if (invicodeObj):
                                        invicodeObj.status = 1
                                        invicodeObj.save()


                            if(recharge_money>0):
                                serializer = RechargeRecordCreateSerializer(
                                    data={'money': recharge_money, 'wallet': wallet.id, 'type': 2})
                                if serializer.is_valid():
                                    models.RechargeRecord.objects.create(**serializer.validated_data)
                            # if wallet pay campaign activity,dedute return amount
                            if transactionTemp.campaign_return_wallet_cash:
                                wallet.balance -= transactionTemp.campaign_return_wallet_cash
                                wallet.save()
                                serializer = RechargeRecordCreateSerializer(
                                    data={'money': transactionTemp.campaign_return_wallet_cash,
                                          'wallet': wallet.id, 'type': 4})
                                if serializer.is_valid():
                                    models.RechargeRecord.objects.create(**serializer.validated_data)
                        else:
                            return Response({'msg': 'error'})

                    return Response({'msg': 'ok'})
                else:

                    return Response({'msg': 'no permission'})


# 修改订单状态

@api_view(['GET', 'POST'])
@authentication_classes([])
@permission_classes((AllowAny,))
def modOrder(request, *args, **kwargs):

    if request.method == 'GET':
        #order_id
        order_id = request.query_params.get('product_status')
        #transaction_status
        #transaction_status=request.query_params.get('time_inteval')
        transactionObj = models.Transaction.objects.filter(id=order_id)

        if(transactionObj):

                transactionTemp = transactionObj[0]
                #状态为4，已confirm
                #if (transaction_status == "4"):
                if (transactionTemp.transaction_status == 4):
                    with transaction.atomic():
                        #check delay time passed
                        pickup_time=transactionTemp.delay_time + datetime.timedelta(hours=8)
                        pickup_time_cast=pickup_time.replace(tzinfo=None)

                        if datetime.datetime.now() >= pickup_time_cast:
                            return Response({'msg': 'The order pickup time has passed,can\'t cancel'})
                        transactionTemp.cancel_time=datetime.datetime.now()
                        transactionTemp.transaction_status = 3
                        member_id = transactionTemp.member.id
                        wallet = models.Wallet.objects.get(member__id=member_id)
                        total_money=transactionTemp.total_money
                        discount_amount=transactionTemp.discount_amount
                        recharge_money = 0
                        if(total_money>0):
                            if (discount_amount is not None and discount_amount > 0):
                                original_money = total_money + discount_amount
                                real_deduct_money = original_money * 0.5
                                if (real_deduct_money > total_money):
                                    recharge_money = 0
                                    if ((transactionTemp.redeem_invicode) is not None and (
                                            transactionTemp.redeem_invicode != 0)):
                                        invicodeObj = models.Invicode.objects.get(id=transactionTemp.redeem_invicode)
                                        if (invicodeObj):
                                            invicodeObj.status = 1
                                            invicodeObj.save()

                                else:
                                    return_money=total_money-real_deduct_money
                                    wallet.balance += return_money
                                    wallet.save()
                                    if(return_money!=0):
                                        recharge_money=return_money
                                    else:
                                        recharge_money =0
                                    if ((transactionTemp.redeem_invicode) is not None and (
                                            transactionTemp.redeem_invicode != 0)):
                                        invicodeObj = models.Invicode.objects.get(id=transactionTemp.redeem_invicode)
                                        if (invicodeObj):
                                            invicodeObj.status = 1
                                            invicodeObj.save()
                            else:
                                real_deduct_money= total_money * 0.5
                                return_money = total_money - real_deduct_money
                                wallet.balance += return_money
                                wallet.save()
                                recharge_money = return_money


                        else:
                            recharge_money = 0


                        if(recharge_money>0):
                            serializer = RechargeRecordCreateSerializer(
                                data={'money': recharge_money, 'wallet': wallet.id, 'type': 2})
                            if serializer.is_valid():
                                models.RechargeRecord.objects.create(**serializer.validated_data)
                        # if wallet pay campaign activity,dedute return amount
                        if transactionTemp.campaign_return_wallet_cash:
                            wallet.balance -= transactionTemp.campaign_return_wallet_cash
                            wallet.save()
                            serializer = RechargeRecordCreateSerializer(
                                data={'money': transactionTemp.campaign_return_wallet_cash,
                                      'wallet': wallet.id, 'type': 4})
                            if serializer.is_valid():
                                models.RechargeRecord.objects.create(**serializer.validated_data)
                        transactionTemp.save()
                        #send cancel mail
                        # send cancel mail
                        pay_method = ''
                        if transactionTemp.payment_modes == 8:
                            pay_method = 'Wallet'
                        elif transactionTemp.payment_modes == 9:
                            pay_method = 'Wirecard'
                        else:
                            pay_method = 'Grabpay'
                        # print(wallet.id)
                        #countTable = get_cancel_mail_table(transactionTemp, transactionTemp.member, wallet.id,pay_method)
                        #thread_send_mail(countTable, "cancel")

                    return Response({'msg': 'ok'})
                elif (transactionTemp.transaction_status == 3):
                        return Response({'msg': 'The order has been Canceled'})
                elif (transactionTemp.transaction_status == 5):
                        return Response({'msg': 'The order has been Collected'})

                elif (transactionTemp.transaction_status == 2):
                    with transaction.atomic():
                        transactionTemp.cancel_time = datetime.datetime.now()
                        transactionTemp.transaction_status = 3
                        member_id = transactionTemp.member.id
                        wallet = models.Wallet.objects.get(member__id=member_id)
                        wallet.balance += transactionTemp.total_money
                        wallet.save()
                        serializer = RechargeRecordCreateSerializer(
                            data={'money': transactionTemp.total_money, 'wallet': wallet.id, 'type': 2})
                        if serializer.is_valid():
                            models.RechargeRecord.objects.create(**serializer.validated_data)

                        #if wallet pay campaign activity,dedute return amount
                        if transactionTemp.campaign_return_wallet_cash:
                            wallet.balance -= transactionTemp.campaign_return_wallet_cash
                            wallet.save()
                            serializer = RechargeRecordCreateSerializer(
                                data={'money': transactionTemp.campaign_return_wallet_cash, 'wallet': wallet.id, 'type': 4})
                            if serializer.is_valid():
                                models.RechargeRecord.objects.create(**serializer.validated_data)


                        if((transactionTemp.redeem_invicode) is not None and (transactionTemp.redeem_invicode!=0)):
                            invicodeObj = models.Invicode.objects.get(id=transactionTemp.redeem_invicode)
                            if (invicodeObj):
                                invicodeObj.status = 1
                                invicodeObj.save()
                        transactionTemp.save()
                        #send cancel mail
                        pay_method=''
                        if transactionTemp.payment_modes==8:
                            pay_method='Wallet'
                        elif transactionTemp.payment_modes==9:
                            pay_method='Wirecard'
                        else:
                            pay_method='Grabpay'
                        #print(wallet.id)
                        #countTable=get_cancel_mail_table(transactionTemp, transactionTemp.member, wallet.id, pay_method)
                        #thread_send_mail(countTable, "cancel")
                        return Response({'msg': 'ok'})
                elif (transactionTemp.transaction_status == 1):

                    return Response({'msg': 'no permission'})
                # 禁止修改订单状态为已支付
                elif (transactionTemp.transaction_status == 0):
                    with transaction.atomic():
                        transactionTemp=transactionObj[0]
                        transactionTemp.cancel_time = datetime.datetime.now()
                        transactionTemp.transaction_status=1
                        #print(transaction_status)
                        #if(transaction_status=="1"):

                        if((transactionTemp.redeem_invicode) is not None and (transactionTemp.redeem_invicode!=0)):
                                invicodeObj = models.Invicode.objects.get(id=transactionTemp.redeem_invicode)
                                if (invicodeObj):
                                    invicodeObj.status = 1
                                    invicodeObj.save()
                        transactionTemp.save()
                        return Response({'msg':'ok'})
                else:
                    return Response({'msg':'no permission'})
        else:
                return  Response({'msg': 'error'})


@api_view(['GET', 'POST'])
@authentication_classes([])
@permission_classes((AllowAny,))
def wallet_pay(request, *args, **kwargs):
    if request.method == 'GET':
        now = datetime.datetime.now()
        #order_id
        order_id = request.query_params.get('member_class')
        #wallet_id
        wallet_id = request.query_params.get('member_id')
        #money
        amount = request.query_params.get('timenumber')

        wallet = models.Wallet.objects.get(id=wallet_id)
        if float(amount)<0:
            return Response({'msg': 'amount must  not negative value'})
        if wallet:
            #print(float(amount))
            #print(wallet.balance)
            if wallet.balance <float(amount):
                return Response({'msg': 'wallet balance is not enough'})
        transactionObj = models.Transaction.objects.get(id=order_id)
        if (transactionObj.transaction_status != 0):
            return Response({'msg': 'warning:system rejected'})
        #check voucher purchase quantity
        #voucher_can_buy=check_invicode_quantity(transactionObj)
        #if  voucher_can_buy:
        #    return Response(voucher_can_buy)
        if (transactionObj and wallet):
            if (transactionObj.member.id == wallet.member.id):

                with transaction.atomic():
                    wallet.balance -= float(amount)
                    wallet.save()

                    serializer = RechargeRecordCreateSerializer(data={'money':amount, 'wallet': wallet_id,'type':1})
                    if serializer.is_valid():
                        models.RechargeRecord.objects.create(**serializer.validated_data)
                    transactionObj.payment_datetime = time.strftime("%Y-%m-%d %H:%M:%S", time.localtime())
                    #transactionObj.transact_datetime = time.strftime("%Y-%m-%d %H:%M:%S", time.localtime())
                    #delay_time generate
                    #if transactionObj.delay_time:
                     #   delay_time=getDelay_time(transactionObj)
                      #  transactionObj.delay_time=delay_time
                    #else:

                    '''
                    if(transactionObj.pick_up_time==0):
                        transactionObj.delay_time=now + datetime.timedelta(minutes=5)
                        #print(now + datetime.timedelta(minutes=5))
                    elif (transactionObj.pick_up_time==1):
                        transactionObj.delay_time = now + datetime.timedelta(minutes=15)
                    elif (transactionObj.pick_up_time == 2):
                        transactionObj.delay_time = now + datetime.timedelta(minutes=30)
                    elif (transactionObj.pick_up_time == 3):
                        transactionObj.delay_time = now + datetime.timedelta(minutes=45)
                    elif (transactionObj.pick_up_time == 4):
                        transactionObj.delay_time = now + datetime.timedelta(minutes=60)
                        '''
                       # delay_time = getDelay_time(transactionObj)
                        #transactionObj.delay_time = delay_time
                    #coupon set transaction status=5 directly
                    temp_transaction_status = 2
                    has_voucher=False
                    has_other=False
                    invicode_num=0
                    transDetailsList = models.TransactDetails.objects.filter(transaction__id=transactionObj.id)
                    if transDetailsList:
                        for details in transDetailsList:
                            temp_product=details.product
                            quantity=details.quantity
                            invicode_num=invicode_num+quantity
                            if temp_product:
                                voucher=temp_product.voucher
                                if voucher:
                                    temp_transaction_status=5
                                    voucher_expire_date = voucher.expiring_date
                                    has_voucher=True

                                    invicode_register_date=datetime.datetime.now().date()
                                    interval=voucher_expire_date-invicode_register_date
                                    valid_days = interval.days
                                    for i in range(0,quantity):
                                        models.Invicode.objects.create(**{'voucher':voucher, 'code': generate_random_str(), 'status': 1,'member': transactionObj.member, 'register_date': datetime.datetime.now(),'vaild_days': valid_days, 'expire_date': voucher_expire_date})
                                else:
                                    has_other=True
                    if has_other:
                        temp_transaction_status = 2

                    # coupon set transaction status=5 directly
                    if transactionObj.delay_time:
                        delay_time = transactionObj.delay_time
                        delay_time = delay_time + datetime.timedelta(hours=8)
                        if delay_time.replace(tzinfo=None) < now:
                            transactionObj.delay_time = now + datetime.timedelta(minutes=5)
                    else:
                        transactionObj.delay_time = now + datetime.timedelta(minutes=5)
                    transactionObj.payment_modes=8
                    transactionObj.transaction_status = temp_transaction_status
                    transactionObj.save()
                    #modify invicode status
                    if transactionObj.redeem_invicode is not None and transactionObj.redeem_invicode!=0:
                        invicodeObj = models.Invicode.objects.get(id=transactionObj.redeem_invicode)
                        if (invicodeObj):
                            invicodeObj.status = 2
                            invicodeObj.redeem_date = time.strftime("%Y-%m-%d %H:%M:%S", time.localtime())
                            invicodeObj.save()
                    # update member last purchase datetime
                    member_id = transactionObj.member.id
                    member = models.Member.objects.get(id=member_id)
                    member.last_purchase_date = time.strftime("%Y-%m-%d", time.localtime())
                    member.save()
                    #purchase coupon voucher to direct collected,update member points
                    if has_voucher:
                        update_member_points(member, transactionObj.total_money, 1, None, None)
                        if invicode_num>0:
                            if voucher:
                                pass
                                '''
                                invicode_amount = models.Invicode.objects.filter(voucher__id=voucher.id,register_date__date=datetime.datetime.now().date()).aggregate(count=Count('id'))
                                if invicode_amount:
                                    invicodeTable = "<h4 style='text-align:center'  >Mooncake voucher purchase</h4><table border='1' cellspacing='0' style='text-align:center' ><tr><td colspan='5'  style='text-align:left' >order no:" + transactionObj.order_no + "</td></tr><tr><td>member mobile</td><td>register time</td><td>quantity</td><td>today sum</td><td>payment time </td></tr><tr>" + \
                                                 "<td>" + member.mobile_no + "</td><td>" + datetime.datetime.strftime(member.registration_date,"%Y-%m-%d %H:%M:%S") + "</td><td>" + str(invicode_num) + "</td>"+str(invicode_amount['count'])+"<td>" + datetime.datetime.strftime(now,"%Y-%m-%d %H:%M:%S") + "</td></tr></table></br></br>"
                                    thread_send_mail(invicodeTable, "VoucherPurchase")
                                '''
                    #member cashbak
                    #member_payment_cashback(transactionObj, member, wallet, amount,0)
                    #member update membership thread move to confirmed
                    #update_member_points(member,amount,1,None,None)

                    #wallet pay return cash 10% to wallet campaign start
                    '''
                    campaign_Wallet=models.Campaign_Wallet.objects.first()
                    if campaign_Wallet and campaign_Wallet.activity_status:
                        if campaign_Wallet.purchase_return_wallet_percent:
                            campgign_result=float(amount)*campaign_Wallet.purchase_return_wallet_percent
                    '''
                    # wallet pay return cash 10% to wallet campaign end
                    #new cashback from member membership start #
                    if member:
                        member_ship = member.membership
                        if member_ship:
                            cashback_percent = member_ship.cash_back
                            campgign_result = float(amount) * cashback_percent
                    # new cashback from member membership end #


                            campaign_result_str='%.2f' % campgign_result
                            campaign_return=float(campaign_result_str)
                            #campaign_return=round(float(amount)*campaign_Wallet.purchase_return_wallet_percent,2)
                            #outlet cashback
                            outlet=transactionObj.outlet
                            if outlet:
                                if outlet.has_cashback:
                                    if(campaign_return>0):
                                        wallet.balance += campaign_return
                                        wallet.save()
                                        serializer = RechargeRecordCreateSerializer(
                                            data={'money': float(campaign_return),
                                                  'wallet': wallet.id, 'type': 3,

                                                  'status': 1})
                                        if serializer.is_valid():
                                            instance = models.RechargeRecord.objects.create(
                                                **serializer.validated_data)
                                        #add campaign return cash to transaction record
                                        if transactionObj.campaign_return_wallet_cash:
                                            transactionObj.campaign_return_wallet_cash+=campaign_return
                                        else:
                                            transactionObj.campaign_return_wallet_cash=campaign_return
                                        transactionObj.save()
                                #send notification
                            if member:
                                device_token=member.device_token
                                if device_token:
                                    #if campaign_return >0.001:
                                    #    send_message_to_token(device_token, 'Wallet payment successful','$'+str(campaign_return)+' cash back')
                                    #else:
                                        pass
                                        #send_message_to_token(device_token, 'Wallet payment successful','thank you')

                    #send mail
                    #datetime.datetime.strftime('%Y-%m-%d %H:%M:%S',member.registration_date)  time.strftime("%Y-%m-%d %H:%M:%S", time.localtime())
                    '''
                    countTable = "<h4 style='text-align:center'  >Mobile ordering payment</h4><table border='1' cellspacing='0' style='text-align:center' ><tr><td colspan='6'  style='text-align:left' >order no:" + transactionObj.order_no + "</td></tr><tr><td>member mobile</td><td>register time</td><td>outlet</td><td>amount</td><td>payment method</td><td>payment time </td></tr><tr>" + \
                                 "<td>" + member.mobile_no + "</td><td>"+datetime.datetime.strftime(member.registration_date,"%Y-%m-%d %H:%M:%S")+"</td><td>" + transactionObj.outlet.outlet_name + "</td><td>" + str(
                        transactionObj.total_money) + "</td><td>" + \
                                 "wallet pay" + "</td><td>" +datetime.datetime.strftime(now,"%Y-%m-%d %H:%M:%S")  + "</td></tr></table></br></br>"
                    #3 times purchase record
                    third_purchase_table="<table border='1' cellspacing='0' style='text-align:center' ><tr><td colspan='6'  style='text-align:center' >The first three times payment</td></tr><tr><td>times</td><td>voucher</td><td>outlet</td><td>amount</td><td>payment method</td><td>payment time </td></tr>"
                    payment_list=models.Transaction.objects.filter(member__id=member.id,transaction_status__in=(2,4,5)).order_by('payment_datetime')[:3]
                    payment_table_row =""
                    voucher=""
                    if payment_list:
                        index=1

                        for item in payment_list:
                               if item.redeem_invicode is not None and item.redeem_invicode!=0:
                                   invicode=models.Invicode.objects.filter(id=item.redeem_invicode).first()
                                   if invicode:
                                       voucher=invicode.voucher.name
                               payment_table_row=payment_table_row+"<tr><td>"+str(index)+"</td><td>"+voucher+"</td><td>"+item.outlet.outlet_name+"</td><td>"+str(item.total_money)+"</td><td>wallet</td><td>"+datetime.datetime.strftime(item.payment_datetime,"%Y-%m-%d %H:%M:%S")+"</td></tr>"
                               index=index+1
                    third_purchase_table =third_purchase_table+ payment_table_row +"</table></br></br>"

                    #3 times topup record
                    topup_table = "<table border='1' cellspacing='0' style='text-align:center' ><tr><td colspan='4'  style='text-align:center' >The first three times top up</td></tr><tr><td>times</td><td>amount</td><td>payment method</td><td>payment time </td></tr>"
                    topup_list=models.RechargeRecord.objects.filter(wallet__id=wallet_id,type=0,money__gte=10).order_by('created')[0:3]
                    topup_row = ""
                    topup_method=""
                    if topup_list:
                        index_topup=1
                        for item in topup_list:
                            if item.request_id is not None and item.grab_txID is not None:
                                topup_method="GrabPay"
                            elif item.request_id is not None and item.grab_txID is  None:
                                topup_method = "Wirecard"
                            elif item.request_id is  None and item.grab_txID is None:
                                topup_method = "Outlet"

                            topup_row = topup_row + "<tr><td>" + str(index_topup) + "</td><td>" +str( item.money) + "</td>" + topup_method + "</td><td>" + datetime.datetime.strftime(item.created,"%Y-%m-%d %H:%M:%S")+ "</td></tr>"
                            index_topup = index_topup + 1
                    topup_table = topup_table +topup_row + "</table></br></br>"
                    countTable=countTable+third_purchase_table+topup_table
                    '''
                    #countTable=get_payment_mail_table(transactionObj,member,wallet_id,'Wallet')
                    #utils.send_register_email(utils.RECEIVE_MAIL, countTable, send_type="payment", promotion='')
                    #thread_send_mail(countTable, "payment")
                    send_mooncake_payment(transactionObj)
                    return Response({'msg': 'ok'})

            else:
                return Response({'msg': 'memeber has not this wallet'})

@api_view(['GET', 'POST'])
@authentication_classes([])
@permission_classes((AllowAny,))
def wirecard_pay(request, *args, **kwargs):

    if request.method == 'GET':
        now = datetime.datetime.now()
        #order_id
        order_id = request.query_params.get('product_number')
        #member_id
        member_id=request.query_params.get('outlet_id')
        #money
        amount = request.query_params.get('product_price')


        transactionObj = models.Transaction.objects.get(id=order_id)
        if (transactionObj ):

            if (transactionObj.transaction_status == 0):

                with transaction.atomic():

                    # coupon set transaction status=5 directly
                    temp_transaction_status = 2
                    has_voucher = False
                    has_other = False
                    invicode_num = 0
                    transDetailsList = models.TransactDetails.objects.filter(transaction__id=transactionObj.id)
                    if transDetailsList:
                        for details in transDetailsList:
                            temp_product = details.product
                            quantity = details.quantity
                            invicode_num = invicode_num + quantity
                            if temp_product:
                                voucher = temp_product.voucher
                                if voucher:
                                    temp_transaction_status = 5
                                    voucher_expire_date = voucher.expiring_date
                                    has_voucher = True

                                    invicode_register_date = datetime.datetime.now().date()
                                    interval = voucher_expire_date - invicode_register_date
                                    valid_days = interval.days
                                    for i in range(0, quantity):
                                        models.Invicode.objects.create(
                                            **{'voucher': voucher, 'code': generate_random_str(), 'status': 1,
                                               'member': transactionObj.member,
                                               'register_date': datetime.datetime.now(), 'vaild_days': valid_days,
                                               'expire_date': voucher_expire_date})
                                else:
                                    has_other = True
                    if has_other:
                        temp_transaction_status = 2
                    # coupon set transaction status=5 directly

                    transactionObj.payment_datetime = time.strftime("%Y-%m-%d %H:%M:%S", time.localtime())
                    #transactionObj.transact_datetime = time.strftime("%Y-%m-%d %H:%M:%S", time.localtime())
                    transactionObj.payment_modes = 9
                    transactionObj.transaction_status = temp_transaction_status
                    #if transactionObj.delay_time:
                     #   print('ok')
                      #  delay_time = getDelay_time(transactionObj)
                       # transactionObj.delay_time = delay_time
                    #else:
                    '''
                    if (transactionObj.pick_up_time == 0):
                        transactionObj.delay_time = now + datetime.timedelta(minutes=5)
                        # print(now + datetime.timedelta(minutes=5))
                    elif (transactionObj.pick_up_time == 1):
                        transactionObj.delay_time = now + datetime.timedelta(minutes=15)
                    elif (transactionObj.pick_up_time == 2):
                        transactionObj.delay_time = now + datetime.timedelta(minutes=30)
                    elif (transactionObj.pick_up_time == 3):
                        transactionObj.delay_time = now + datetime.timedelta(minutes=45)
                    elif (transactionObj.pick_up_time == 4):
                        transactionObj.delay_time = now + datetime.timedelta(minutes=60)
                        '''
                    if transactionObj.delay_time:
                        delay_time=transactionObj.delay_time
                        delay_time=delay_time+datetime.timedelta(hours=8)
                        if delay_time.replace(tzinfo=None)<now:
                            transactionObj.delay_time = now + datetime.timedelta(minutes=5)
                    else:
                        transactionObj.delay_time = now + datetime.timedelta(minutes=5)
                       # delay_time = getDelay_time(transactionObj)
                        #transactionObj.delay_time = delay_time


                    transactionObj.save()
                    # modify invicode status
                    if transactionObj.redeem_invicode is not None and transactionObj.redeem_invicode != 0:
                        invicodeObj = models.Invicode.objects.get(id=transactionObj.redeem_invicode)
                        if (invicodeObj):
                            invicodeObj.status = 2
                            invicodeObj.redeem_date = time.strftime("%Y-%m-%d %H:%M:%S", time.localtime())
                            invicodeObj.save()
                    #update member last purchase datetime
                    member_id=transactionObj.member.id
                    member=models.Member.objects.get(id=member_id)
                    member.last_purchase_date=time.strftime("%Y-%m-%d", time.localtime())
                    # purchase coupon voucher to direct collected,update member points
                    if has_voucher:
                        update_member_points(member, transactionObj.total_money, 1, None, None)
                        if invicode_num > 0:
                            if voucher:
                                invicode_amount = models.Invicode.objects.filter(voucher__id=voucher.id,register_date__date=datetime.datetime.now().date()).aggregate(count=Count('id'))
                                if invicode_amount:
                                    invicodeTable = "<h4 style='text-align:center'  >Mooncake voucher purchase</h4><table border='1' cellspacing='0' style='text-align:center' ><tr><td colspan='5'  style='text-align:left' >order no:" + transactionObj.order_no + "</td></tr><tr><td>member mobile</td><td>register time</td><td>quantity</td><td>today sum</td><td>payment time </td></tr><tr>" + \
                                                    "<td>" + member.mobile_no + "</td><td>" + datetime.datetime.strftime(
                                        member.registration_date, "%Y-%m-%d %H:%M:%S") + "</td><td>" + str(invicode_num) + "</td>" + str(invicode_amount['count']) + "<td>" + datetime.datetime.strftime(now,"%Y-%m-%d %H:%M:%S") + "</td></tr></table></br></br>"
                                    thread_send_mail(invicodeTable, "VoucherPurchase")


                    wallet = models.Wallet.objects.get(member__id=member_id)
                    #member cash back
                    #member_payment_cashback(transactionObj, member, wallet, amount,5)

                    #return cash 10% to wallet campaign(every payment cash back) start
                    '''
                    campaign_Wallet = models.Campaign_Wallet.objects.first()
                    if campaign_Wallet and campaign_Wallet.activity_status:

                        if campaign_Wallet.purchase_return_wallet_percent:
                            campgign_result = float(amount) * campaign_Wallet.purchase_return_wallet_percent
                    '''
                    # return cash 10% to wallet campaign(every payment cash back) end
                    # new cashback from member membership start #
                    if member:
                        member_ship = member.membership
                        if member_ship:
                            cashback_percent = member_ship.cash_back
                            campgign_result = float(amount) * cashback_percent
                    # new cashback from member membership end #
                            campaign_result_str = '%.2f' % campgign_result
                            campaign_return_money = float(campaign_result_str)
                            # campaign_return=round(float(amount)*campaign_Wallet.purchase_return_wallet_percent,2)
                            if (campaign_return_money > 0):
                                #wallet = models.Wallet.objects.get(member__id=member_id)
                                if wallet:
                                    #purchase record
                                    serializer = RechargeRecordCreateSerializer(
                                        data={'money': amount, 'wallet': wallet.id, 'type': 5})
                                    if serializer.is_valid():
                                        models.RechargeRecord.objects.create(**serializer.validated_data)

                                    outlet = transactionObj.outlet
                                    if outlet:
                                        if outlet.has_cashback:
                                            wallet.balance += campaign_return_money
                                            wallet.save()
                                            serializer = RechargeRecordCreateSerializer(
                                                data={'money': float(campaign_return_money),
                                                      'wallet': wallet.id, 'type': 3,

                                                      'status': 1})
                                            if serializer.is_valid():
                                                instance = models.RechargeRecord.objects.create(
                                                    **serializer.validated_data)
                                            # add campaign return cash to transaction record
                                            if transactionObj.campaign_return_wallet_cash:
                                                transactionObj.campaign_return_wallet_cash += campaign_return_money
                                            else:
                                                transactionObj.campaign_return_wallet_cash = campaign_return_money
                                            transactionObj.save()

                    #purchase campaign return cash to wallet
                    '''
                    purchase_return_wallet_amount=campaign_return(member,amount)
                    if purchase_return_wallet_amount >0:
                        wallet=models.Wallet.objects.get(member__id=member_id)
                        if wallet:

                            wallet.balance +=purchase_return_wallet_amount
                            wallet.save()
                            serializer = RechargeRecordCreateSerializer(
                                data={'money': float(purchase_return_wallet_amount), 'wallet': wallet.id, 'type': 3,

                                      'status': 1})
                            if serializer.is_valid():
                                instance = models.RechargeRecord.objects.create(**serializer.validated_data)
                            # add campaign return cash to transaction record
                            if transactionObj.campaign_return_wallet_cash:
                                transactionObj.campaign_return_wallet_cash += purchase_return_wallet_amount
                            else:
                                transactionObj.campaign_return_wallet_cash = purchase_return_wallet_amount
                            transactionObj.save()
                    if member:

                            if member.non_wallet_pay_times:
                                member.non_wallet_pay_times = member.non_wallet_pay_times + 1
                            else:
                                member.non_wallet_pay_times = 1
                            member.save()
                    '''

                    '''
                    countTable = "<h4 style='text-align:center'  >Mobile ordering payment</h4><table border='1' cellspacing='0' style='text-align:center' ><tr><td colspan='5'  style='text-align:left' >order no:" + transactionObj.order_no + "</td></tr><tr><td>member mobile</td><td>outlet</td><td>amount</td><td>payment method</td><td>payment time </td></tr><tr>" + \
                                 "<td>" + member.mobile_no + "</td><td>" + transactionObj.outlet.outlet_name + "</td><td>" + str(
                        transactionObj.total_money) + "</td><td>" + \
                                 "wirecard pay" + "</td><td>" + time.strftime("%Y-%m-%d %H:%M:%S",time.localtime()) + "</td></tr></table>"
                      '''
                    #countTable = get_payment_mail_table(transactionObj, member, wallet.id, 'Wirecard')
                    #utils.send_register_email(utils.RECEIVE_MAIL, countTable, send_type="payment", promotion='')
                    #thread_send_mail(countTable, "payment")

                    send_mooncake_payment(transactionObj)
                    return Response({'msg': 'ok'})

            else:
                return Response({'msg': 'order status is error'})
@api_view(['GET', 'POST'])
@authentication_classes([])
@permission_classes((AllowAny,))
def topup(request, *args, **kwargs):
    if request.method == 'POST':
        #member_id
        member_id=request.data.get('product_id')
        #money
        amount = request.data.get('product_number')

        request_id=request.data.get('request_id')
        status = request.data.get('status')
        amount=(str(amount)).strip()


        transactionObj = models.Wallet.objects.get(member__id=member_id)
        if (transactionObj ):



                with transaction.atomic():
                    if(status=='1'):

                        #check request id
                        if request_id:
                            request_topup_object=models.RechargeRecord.objects.filter(request_id=request_id)
                            if request_topup_object:
                                return Response({'msg': 'ok'})
                        #recharge campaign
                        campaign_return_cash=0
                        campaignTopup=models.CampaignTopup.objects.first()
                        member = models.Member.objects.get(id=member_id)
                        '''
                        now=datetime.datetime.now()
                        now = now.replace(tzinfo=pytz.timezone('Asia/Singapore'))
                        last_topup_record=models.RechargeRecord.objects.filter(wallet_id=transactionObj.id).order_by('-id').first()
                        if last_topup_record:
                            last_topup_time=last_topup_record.created+ datetime.timedelta(hours=8)
                            now_str=datetime.datetime.strftime(now, "%Y-%m-%d %H:%M:%S")
                            last_topup_time_str=datetime.datetime.strftime(last_topup_time, "%Y-%m-%d %H:%M:%S")

                            now_convert=datetime.datetime.strptime(now_str, "%Y-%m-%d %H:%M:%S")
                            last_topup_time_convert=datetime.datetime.strptime(last_topup_time_str, "%Y-%m-%d %H:%M:%S")

                            #print(now_str)
                            #print(last_topup_time_str)
                            print(now_convert)
                            print(last_topup_time_convert)
                            interval=now_convert-last_topup_time_convert
                            print(interval.total_seconds())
                            if(interval.total_seconds()<10):
                                return  Response({'msg': 'error'})
                                '''
                        if member.device_token:
                            send_message_to_token(member.device_token, 'Top up successfully', 'Amout: $' + str(amount))
                        if member:
                            topup_10_times =0 if member.topup_10_times is None else  member.topup_10_times
                            topup_20_times = 0 if member.topup_20_times is None else member.topup_20_times
                            topup_50_times = 0 if member.topup_50_times is None else member.topup_50_times
                        if campaignTopup:

                            activity_flag=campaignTopup.activity_flag
                            date_limit_flag=campaignTopup.date_limit_flag
                            times_limit_flag=campaignTopup.times_limit_flag
                            if activity_flag:
                                  if times_limit_flag:
                                      if date_limit_flag:
                                            pass

                                      else:
                                          if campaignTopup.topup_10_limit_times>topup_10_times and str(amount)[0:2]=='10':
                                              campaign_return_cash=campaignTopup.topup_10_return_cash
                                          if campaignTopup.topup_20_limit_times>topup_20_times and str(amount)[0:2]=='20':
                                              campaign_return_cash=campaignTopup.topup_20_return_cash
                                          if campaignTopup.topup_50_limit_times>topup_50_times and str(amount)[0:2]=='50':
                                              campaign_return_cash=campaignTopup.topup_50_return_cash

                                  else:
                                      if date_limit_flag:
                                            pass

                                      else:
                                          if  str(amount)[0:2]=='10':
                                              campaign_return_cash=campaignTopup.topup_10_return_cash
                                          if  str(amount)[0:2]=='20':
                                              campaign_return_cash=campaignTopup.topup_20_return_cash
                                          if  str(amount)[0:2]=='50':
                                              campaign_return_cash=campaignTopup.topup_50_return_cash

                        transactionObj.balance+=float(amount)+campaign_return_cash
                        transactionObj.lastest_top_up=time.strftime("%Y-%m-%d", time.localtime())
                        transactionObj.save()
                        serializer = RechargeRecordCreateSerializer(data={'money': amount, 'wallet': transactionObj.id, 'type': 0, 'request_id': request_id,'status': status})
                        if serializer.is_valid():
                            instance = models.RechargeRecord.objects.create(**serializer.validated_data)
                        if  campaign_return_cash:
                            serializer = RechargeRecordCreateSerializer(
                                data={'money': campaign_return_cash, 'wallet': transactionObj.id, 'type': 3, 'request_id': request_id,
                                      'status': status})
                            if serializer.is_valid():
                                instance = models.RechargeRecord.objects.create(**serializer.validated_data)
                            if member.device_token:
                                send_message_to_token(member.device_token, 'Top up reward',
                                                      'Amout: $' + str(campaign_return_cash))
                            #service.recharge(instance)
                        #memeber add topup times

                        if member:
                            if str(amount)[0:2]=='10':
                                if member.topup_10_times:
                                    member.topup_10_times= member.topup_10_times+1
                                else :
                                    member.topup_10_times =1
                            elif  str(amount)[0:2]=='20':
                                if member.topup_20_times:
                                    member.topup_20_times= member.topup_20_times+1
                                else :
                                    member.topup_20_times =1
                            else:
                                if member.topup_50_times:
                                    member.topup_50_times= member.topup_50_times+1
                                else :
                                    member.topup_50_times =1
                            member.save()
                        msg='ok'
                        # send mail
                        '''
                        countTable = "<h4 style='text-align:center'  >Mobile top up payment</h4><table border='1' cellspacing='0' style='text-align:center' ><tr><td colspan='4'  style='text-align:left' >Transaction Id:" + request_id + "</td></tr><tr><td>member mobile</td><td>amount</td><td>payment method</td><td>payment time </td></tr><tr>" + \
                                     "<td>" + member.mobile_no + "</td><td>" + str(
                            amount) + "</td><td>" + \
                                     "wirecard pay" + "</td><td>" + time.strftime("%Y-%m-%d %H:%M:%S",
                                                                                  time.localtime()) + "</td></tr></table>"
                        '''
                        #countTable=get_topup_mail_table(transactionObj, member, transactionObj.id, "Wirecard", amount)
                        #utils.send_register_email(utils.RECEIVE_MAIL, countTable, send_type="topup", promotion='')
                        #thread_send_mail(countTable,"topup")
                        '''
                        mailThread=MailThread()
                        mailThread.mail=countTable
                        mailThread.send_type='topup'
                        mailThread.start()
                        '''
                    else:
                        #serializer = RechargeRecordCreateSerializer(data={'money': amount, 'wallet': transactionObj.id, 'type': 0, 'request_id': request_id,'status': status})
                        #if serializer.is_valid():
                         #    models.RechargeRecord.objects.create(**serializer.validated_data)
                        msg='error'



                    return Response({'msg': msg})

        else:
                return Response({'msg': 'error'})
@api_view(['GET', 'POST'])
@authentication_classes([])
@permission_classes((AllowAny,))
def modPickuptime(request, *args, **kwargs):

    if request.method == 'GET' or request.method == 'POST':
        if request.method == 'GET':
            order_id = request.query_params.get('order_id')
            delay_time=request.query_params.get('delay_time')
        else:
            order_id = request.data.get('order_id')
            delay_time = request.data.get('delay_time')


        transactionTemp = models.Transaction.objects.get(id=order_id)

        if(transactionTemp):

             if(transactionTemp.transaction_status==4):
                 return Response({'msg': 'confirmed'})
             else:
                 transactionTemp.delay_time=delay_time
                 transactionTemp.save()
                 return Response({'msg': 'ok'})
        else:
            return Response({'msg': 'error'})


@api_view(['GET', 'POST'])
@authentication_classes([])
@permission_classes((AllowAny,))
def modDeliverytime(request, *args, **kwargs):

    if request.method == 'GET' or request.method == 'POST':
        if request.method == 'GET':
            order_id = request.query_params.get('order_id')
            delay_time=request.query_params.get('delivery_time')
        else:
            order_id = request.data.get('order_id')
            delay_time = request.data.get('delivery_time')


        transactionTemp = models.Transaction.objects.get(id=order_id)

        if(transactionTemp):

             if(transactionTemp.transaction_status==4):
                 return Response({'msg': 'confirmed'})
             else:
                 transactionTemp.delivery_time=delay_time
                 transactionTemp.save()
                 return Response({'msg': 'ok'})
        else:
            return Response({'msg': 'error'})


@api_view(['GET', 'POST'])
@authentication_classes([])
@permission_classes((AllowAny,))
def modAddress(request, *args, **kwargs):

    if request.method == 'GET' or request.method == 'POST':
        if request.method == 'GET':
            order_id = request.query_params.get('order_id')
            address=request.query_params.get('address')
            remark = request.query_params.get('remark')
        else:
            order_id = request.data.get('order_id')
            address = request.data.get('address')
            remark = request.data.get('remark')


        transactionTemp = models.Transaction.objects.get(id=order_id)

        if(transactionTemp):

             if(transactionTemp.transaction_status==4):
                 return Response({'msg': 'confirmed'})
             else:
                 transactionTemp.delivery_address=address
                 transactionTemp.delivery_remark =remark
                 transactionTemp.save()
                 return Response({'msg': 'ok'})
        else:
            return Response({'msg': 'error'})

#get chart data_hour
@api_view(['GET'])
def getChartData_hour(request, *args, **kwargs):
    outlet_id=request.GET['outlet_id']
    start_date=request.GET['start_date']
    end_date = request.GET['end_date']
    cursor = connection.cursor()
    if(outlet_id=='0'):
            cursor.execute("select ''||(date_part('hour',transact_datetime)+8), sum(total_money) as total_amount from app01_transaction where to_char(transact_datetime,'yyyy-mm-dd')>='%s' and to_char(transact_datetime,'yyyy-mm-dd')<='%s'   group by date_part('hour',transact_datetime) order by date_part('hour',transact_datetime) asc" %(start_date,end_date) )
    else:
            cursor.execute("select ''||(date_part('hour',transact_datetime)+8), sum(total_money) as total_amount from app01_transaction where to_char(transact_datetime,'yyyy-mm-dd')>='%s' and to_char(transact_datetime,'yyyy-mm-dd')<='%s' and outlet_id=%s   group by date_part('hour',transact_datetime) order by date_part('hour',transact_datetime) asc" % (start_date, end_date,outlet_id))
    reg_row = cursor.fetchall()
    reg_obj = []



    if reg_row:



                  h=8
                  for i in range(16):
                      obj={'date':str(h),'total_money':0}
                      h=h+1

                      reg_obj.append(obj)
                  #add  count data
                  num = 0
                  for i in reg_obj:
                      for j in reg_row:
                          print(i['date']+'  '+j[0])
                          if ((i['date'] == j[0])):
                              reg_obj[num]["total_money"] = j[1]
                              break
                      num += 1




    else:

                h=8
                for i in range(16):
                    obj = {'date': str(h), 'total_money': 0}
                    h=h+1
                    reg_obj.append(obj)






    return Response({
            'list': reg_obj,

        }, status=status.HTTP_200_OK)

#get chart data_month
@api_view(['GET'])
def getChartData(request, *args, **kwargs):
    outlet_id=request.GET['outlet_id']
    start_date=request.GET['start_date']
    end_date = request.GET['end_date']
    cursor = connection.cursor()
    if(outlet_id=='0'):
            cursor.execute("select to_char(transact_datetime,'yyyy-mm-dd'), sum(total_money) as total_amount from app01_transaction where to_char(transact_datetime,'yyyy-mm-dd')>='%s' and to_char(transact_datetime,'yyyy-mm-dd')<='%s'   group by to_char(transact_datetime,'yyyy-mm-dd') order by to_char(transact_datetime,'yyyy-mm-dd') asc" %(start_date,end_date) )
    else:
            cursor.execute("select to_char(transact_datetime,'yyyy-mm-dd'), sum(total_money) as total_amount from app01_transaction where to_char(transact_datetime,'yyyy-mm-dd')>='%s' and to_char(transact_datetime,'yyyy-mm-dd')<='%s' and outlet_id=%s   group by to_char(transact_datetime,'yyyy-mm-dd') order by to_char(transact_datetime,'yyyy-mm-dd') asc" % (start_date, end_date,outlet_id))
    reg_row = cursor.fetchall()
    reg_obj = []



    if reg_row:


                  interval_days= (datetime.datetime.strptime(end_date, '%Y-%m-%d')-datetime.datetime.strptime(start_date, '%Y-%m-%d')).days+1
                  for i in range(interval_days):
                      obj={'date':start_date,'total_money':0}
                      start_date=(datetime.datetime.strptime(start_date, '%Y-%m-%d')+datetime.timedelta(days=1)).strftime("%Y-%m-%d")
                      reg_obj.append(obj)
                  #add  count data
                  num = 0
                  for i in reg_obj:
                      for j in reg_row:
                          if ((i['date'] == j[0])):
                              reg_obj[num]["total_money"] = j[1]
                              break
                      num += 1




    else:
            start_date = request.GET['start_date']
            interval_days = (datetime.datetime.strptime(end_date, '%Y-%m-%d') - datetime.datetime.strptime(start_date,
                                                                                              '%Y-%m-%d')).days+1
            for i in range(interval_days):
                obj = {'date': start_date, 'reg_num': 0}
                start_date = (datetime.datetime.strptime(start_date, '%Y-%m-%d') + datetime.timedelta(days=1)).strftime("%Y-%m-%d")
                reg_obj.append(obj)






    return Response({
            'list': reg_obj,

        }, status=status.HTTP_200_OK)

#get chart year
@api_view(['GET'])
def getChartData_year(request, *args, **kwargs):
    outlet_id=request.GET['outlet_id']
    date_year=request.GET['date_year']

    cursor = connection.cursor()
    if(outlet_id=='0'):
            cursor.execute("select to_char(transact_datetime,'yyyy-mm'), sum(total_money) as total_amount from app01_transaction where to_char(transact_datetime,'yyyy')='%s'    group by to_char(transact_datetime,'yyyy-mm') order by to_char(transact_datetime,'yyyy-mm') asc" % date_year )
    else:
            cursor.execute("select to_char(transact_datetime,'yyyy-mm'), sum(total_money) as total_amount from app01_transaction where to_char(transact_datetime,'yyyy')='%s'  and outlet_id=%s   group by to_char(transact_datetime,'yyyy-mm') order by to_char(transact_datetime,'yyyy-mm') asc" % (date_year,outlet_id))
    reg_row = cursor.fetchall()
    reg_obj = []



    if reg_row:



                  for i in range(12):
                      month=str(i+1)
                      if(len(month)<2):
                          month='0'+month
                      obj={'date':date_year+'-'+month,'total_money':0}

                      reg_obj.append(obj)
                  #add  count data
                  num=0
                  for i in reg_obj:
                      for j in reg_row:
                          if ((i['date'] == j[0])):
                              reg_obj[num]["total_money"] = j[1]
                              break
                      num += 1




    else:
                for i in range(12):
                    month = str(i + 1)
                    if (len(month) < 2):
                        month = '0' + month
                    obj = {'date': date_year + '-' + month, 'total_money': 0}

                    reg_obj.append(obj)






    return Response({
            'list': reg_obj,

        }, status=status.HTTP_200_OK)

#get category sell
@api_view(['GET'])
def getChartHot_sell(request, *args, **kwargs):

    date_year=request.GET['date_month']

    cursor = connection.cursor()

    #cursor.execute("select  to_char(app01_transaction.transact_datetime,'yyyy-mm'),app01_product.name, sum(app01_transactdetails.price*app01_transactdetails.quantity) as amount from app01_transactdetails inner join app01_product on (app01_transactdetails.product_id=app01_product.id) inner join app01_transaction on (app01_transaction.id=app01_transactdetails.transaction_id) where to_char(app01_transaction.transact_datetime,'yyyy-mm')='%s' group by to_char(app01_transaction.transact_datetime,'yyyy-mm') ,app01_product.name order by  amount desc limit 10" % date_year )
    cursor.execute("select to_char(app01_transaction.transact_datetime,'yyyy-mm'),app01_category.name, sum(app01_transactdetails.price*app01_transactdetails.quantity) from app01_transactdetails inner join app01_product on (app01_transactdetails.product_id=app01_product.id) inner join app01_transaction on (app01_transaction.id=app01_transactdetails.transaction_id) inner join app01_category on app01_category.id=app01_product.category_id where to_char(app01_transaction.transact_datetime,'yyyy-mm')='%s' group by to_char(app01_transaction.transact_datetime,'yyyy-mm') ,app01_category.name order by to_char(app01_transaction.transact_datetime,'yyyy-mm'), app01_category.name" % date_year)
    reg_row = cursor.fetchall()
    reg_obj = []



    if reg_row:




                  #add  count data

                  for i in reg_row:
                      obj = {'date': date_year ,'product':i[1], 'total_money': i[2]}

                      reg_obj.append(obj)




    else:
                for i in range(10):
                    obj = {'date': date_year, 'product': '', 'total_money':0}

                    reg_obj.append(obj)






    return Response({
            'list': reg_obj,

        }, status=status.HTTP_200_OK)

#get single sell
@api_view(['GET'])
def getChartSingle_sell(request, *args, **kwargs):

    date_year=request.GET['date_month']
    

    cursor = connection.cursor()

    #cursor.execute("select  to_char(app01_transaction.transact_datetime,'yyyy-mm'),app01_product.name, sum(app01_transactdetails.price*app01_transactdetails.quantity) as amount from app01_transactdetails inner join app01_product on (app01_transactdetails.product_id=app01_product.id) inner join app01_transaction on (app01_transaction.id=app01_transactdetails.transaction_id) where to_char(app01_transaction.transact_datetime,'yyyy-mm')='%s' group by to_char(app01_transaction.transact_datetime,'yyyy-mm') ,app01_product.name order by  amount desc limit 10" % date_year )
    cursor.execute("select  to_char(app01_transaction.transact_datetime,'yyyy-mm'),app01_product.name, sum(app01_transactdetails.price*app01_transactdetails.quantity) as amount from app01_transactdetails inner join app01_product on (app01_transactdetails.product_id=app01_product.id) inner join app01_transaction on (app01_transaction.id=app01_transactdetails.transaction_id) where to_char(app01_transaction.transact_datetime,'yyyy-mm')='%s' group by to_char(app01_transaction.transact_datetime,'yyyy-mm') ,app01_product.name order by  amount desc limit 8" % date_year)
    reg_row = cursor.fetchall()
    reg_obj = []
    cursor_sum=connection.cursor()
    cursor_sum.execute("select to_char(app01_transaction.transact_datetime,'yyyy-mm'), sum(total_money) from app01_transaction where to_char(app01_transaction.transact_datetime,'yyyy-mm')='%s'  group by to_char(app01_transaction.transact_datetime,'yyyy-mm')" % date_year )
    sum_row=cursor_sum.fetchall()
    if(sum_row):
        sum_money=sum_row[0][1]

    if reg_row:




                  #add  count data
                  top_money=0
                  for i in reg_row:
                      obj = {'date': date_year ,'product':i[1], 'total_money': i[2]}
                      top_money=top_money+i[2]
                      reg_obj.append(obj)
                  if sum_money:
                      other_money=sum_money-top_money
                      reg_obj.append({'date': date_year ,'product':'Other', 'total_money': round(other_money,1)})



    else:
                for i in range(10):
                    obj = {'date': date_year, 'product': '', 'total_money':0}

                    reg_obj.append(obj)






    return Response({
            'list': reg_obj,

        }, status=status.HTTP_200_OK)
#get all product sale amount count
class ProductCountViewSet(viewsets.ReadOnlyModelViewSet):
    permission_classes = (TransactionAndTransactDetailsViewSetPermission,)
    queryset = models.Transaction.objects.all()
    serializer_class = serializers.SalesCountSerializer
    pagination_class = DefaultPagination
    filter_backends = (
        DjangoFilterBackend,
        #SearchFilter,
        #OrderingFilter,
    )
    #filter_class = InvicodeFilter
    #修改 search_fields  name 为code
    #search_fields = ('code',)
    #search_fields = ('code',)

    #ordering_fields = ('created',)
    #filter_class = MyFilter

    def list(self, request, *args, **kwargs):
        outlet_id=request.GET['outlet_id']
        min_datetime=request.GET["min_datetime"]
        max_datetime = request.GET["max_datetime"]
        if (outlet_id!='0'):
            sql = """select   app01_product.name, sum(app01_transactdetails.quantity) as sum_quantity, sum(app01_transactdetails.price*app01_transactdetails.quantity) as sum_amount from app01_transactdetails inner join app01_product on (app01_transactdetails.product_id=app01_product.id) inner join app01_transaction on (app01_transaction.id=app01_transactdetails.transaction_id) where to_char(app01_transaction.transact_datetime,'yyyy-mm-dd')>='%s' and to_char(app01_transaction.transact_datetime,'yyyy-mm-dd')<='%s' and  app01_transaction.outlet_id= %s group by app01_product.name order by  sum_amount desc """ % ( min_datetime,max_datetime,outlet_id)
            sql_wirecard_pay="select    sum(app01_transaction.total_money) as sum_amount from app01_transaction where app01_transaction.payment_modes=9 and app01_transaction.transaction_status>1 and to_char(app01_transaction.transact_datetime,'yyyy-mm-dd')>='%s' and to_char(app01_transaction.transact_datetime,'yyyy-mm-dd')<='%s' and  app01_transaction.outlet_id= %s  " % ( min_datetime,max_datetime,outlet_id)
            sql_wallet_pay = "select    sum(app01_transaction.total_money) as sum_amount from app01_transaction where app01_transaction.payment_modes=12 and app01_transaction.transaction_status>1 and to_char(app01_transaction.transact_datetime,'yyyy-mm-dd')>='%s' and to_char(app01_transaction.transact_datetime,'yyyy-mm-dd')<='%s' and  app01_transaction.outlet_id= %s  " % (min_datetime, max_datetime, outlet_id)
            sql_pay = "select    sum(app01_transaction.total_money) as sum_amount from app01_transaction where  app01_transaction.transaction_status>1 and to_char(app01_transaction.transact_datetime,'yyyy-mm-dd')>='%s' and to_char(app01_transaction.transact_datetime,'yyyy-mm-dd')<='%s' and  app01_transaction.outlet_id= %s  " % (min_datetime, max_datetime, outlet_id)

        else:
            sql = """select  app01_product.name, sum(app01_transactdetails.quantity) as sum_quantity, sum(app01_transactdetails.price*app01_transactdetails.quantity) as sum_amount from app01_transactdetails inner join app01_product on (app01_transactdetails.product_id=app01_product.id) inner join app01_transaction on (app01_transaction.id=app01_transactdetails.transaction_id) where to_char(app01_transaction.transact_datetime,'yyyy-mm-dd')>='%s' and to_char(app01_transaction.transact_datetime,'yyyy-mm-dd')<='%s'  group by app01_product.name order by  sum_amount desc """ % (min_datetime,max_datetime)
            sql_wirecard_pay = "select    sum(app01_transaction.total_money) as sum_amount from app01_transaction where app01_transaction.payment_modes=9 and app01_transaction.transaction_status>1 and to_char(app01_transaction.transact_datetime,'yyyy-mm-dd')>='%s' and to_char(app01_transaction.transact_datetime,'yyyy-mm-dd')<='%s'  " % (min_datetime, max_datetime)
            sql_wallet_pay = "select    sum(app01_transaction.total_money) as sum_amount from app01_transaction where app01_transaction.payment_modes=12 and app01_transaction.transaction_status>1 and to_char(app01_transaction.transact_datetime,'yyyy-mm-dd')>='%s' and to_char(app01_transaction.transact_datetime,'yyyy-mm-dd')<='%s'  " % (min_datetime, max_datetime)
            sql_pay = "select    sum(app01_transaction.total_money) as sum_amount from app01_transaction where  app01_transaction.transaction_status>1 and to_char(app01_transaction.transact_datetime,'yyyy-mm-dd')>='%s' and to_char(app01_transaction.transact_datetime,'yyyy-mm-dd')<='%s'  " % (min_datetime, max_datetime)

        sql_wirecard_topup="select sum(money) from app01_rechargerecord where type=0 and status=1 and to_char(created,'yyyy-mm-dd')>='%s' and to_char(created,'yyyy-mm-dd')<='%s'"  % (min_datetime,max_datetime)

        cursor = connection.cursor()
        cursor.execute(sql_wirecard_pay)
        row = cursor.fetchall()
        if row:
            wirecard_pay_count = row[0][0]
        else:
            wirecard_pay_count  = 0

        cursor = connection.cursor()
        cursor.execute(sql_wallet_pay )
        row = cursor.fetchall()
        if row:
            wallet_pay_count = row[0][0]
        else:
            wallet_pay_count = 0

        cursor = connection.cursor()
        cursor.execute(sql_wirecard_topup)
        row = cursor.fetchall()
        if row:
            wirecard_topup_count = row[0][0]
        else:
            wirecard_topup_count = 0

        cursor = connection.cursor()
        cursor.execute(sql_pay)
        row = cursor.fetchall()
        if row:
            pay_count = row[0][0]
        else:
            pay_count = 0

        # filter sql


        # search sql

        # get page
        page_size, page = get_page(request, self.paginator.page_size)
        # limit sql
        limit_sql = ' limit %s offset %s ' % (page_size, (page - 1) * page_size)
        # group by sql

        # all sql
        cursor = connection.cursor()
        cursor.execute(sql)
        row = cursor.fetchall()
        if row:
            count=len(row)
        else:
            count=0


        all_sql = sql +  limit_sql

        cursor = connection.cursor()


        cursor.execute(all_sql)
        row = cursor.fetchall()
        queryset1 = []
        if row:
            if page==1:
                id = 1
            else:
                id=(page - 1) * page_size+1
            for item in row:
                obj = {'id':id, 'name': item[0], 'sum_quantity': item[1], 'sum_amount': item[2]
                       }
                queryset1.append(obj)
                id += 1



        #all_queryset = list(all_queryset)
        all_queryset=queryset1

        # for i in all_queryset:
        #     print(i.__dict__)
        serializer = self.get_serializer(all_queryset, many=True)
        # Pagination

        from collections import OrderedDict
        return Response(OrderedDict([
            #('count', len(all_queryset)),
            ('count', count),
            ('wirecard_pay_count',wirecard_pay_count),
            ('wallet_pay_count', wallet_pay_count),
            ('wirecard_topup_count', wirecard_topup_count),
            ('pay_count',pay_count),
            #('next', request.scheme+'://'+request.get_host() +request.path+'?page='+str(page)+'&page_size='+str(page_size)),
             #('previous', request.scheme+'://'+request.get_host() +request.get_full_path()),
            ('results', serializer.data)
        ]))

#Wirecard Log
class WirecardLogViewSet(viewsets.ModelViewSet):
    authentication_classes=()
    permission_classes = (WirecardLogViewSetPermission,)
    queryset = models.WirecardLog.objects.all()
    serializer_class = serializers.WirecardLogSerializer
    pagination_class = DefaultPagination
    filter_backends = (
        DjangoFilterBackend,
        SearchFilter,
        OrderingFilter,
    )


    def create(self, request, *args, **kwargs):

        serializer = self.get_serializer(data=request.data)
        serializer.is_valid(raise_exception=True)


        self.perform_create(serializer)
        headers = self.get_success_headers(serializer.data)

        return Response({'msg':'ok'}, status.HTTP_200_OK, headers=headers)

#grabpay_pos push notification
class GrabPayPosViewSet(viewsets.ModelViewSet):
    authentication_classes=()
    permission_classes = (GrabPayPosViewSetPermission,)
    queryset = models.GrabPayPos.objects.all()
    serializer_class = serializers.GrabPayPosSerializer
    pagination_class = DefaultPagination
    filter_backends = (
        DjangoFilterBackend,
        SearchFilter,
        OrderingFilter,
    )
    filter_class = GrabPayPosFilter
    search_fields = ('txType', 'partnerID', 'partnerTxID', 'txID', 'origTxID')
    ordering_fields = ('id', 'createdAt', 'completedAt')

    def create(self, request, *args, **kwargs):
        #transaction=models.Transaction.objects.get(id=730)
        #transaction.remark=json.dumps(request.data)
        #transaction.save()
        serializer = self.get_serializer(data=request.data)
        serializer.is_valid(raise_exception=True)


        self.perform_create(serializer)
        headers = self.get_success_headers(serializer.data)

        return Response(None, status.HTTP_204_NO_CONTENT, headers=headers)
@api_view(['GET'])
def countPromotion(request, *args, **kwargs):
    data=[]
    total10=0
    total12=0
    total14=0
    total16=0
    total18=0
    total20=0
    total22=0
    totalsum=0
    #countUnit = {'outlet_name': '', 'c10': 0, 'c12': 0, 'c14': 0, 'c16': 0, 'c18': 0, 'c20': 0, 'c22': 0}
    if request.method == 'GET':
        outlet_list=models.Outlet.objects.all()
        if outlet_list:
            for outlet in outlet_list:

               data.append({'outlet_name': outlet.outlet_name, 'c10': 0, 'c12': 0, 'c14': 0, 'c16': 0, 'c18': 0, 'c20': 0, 'c22': 0,'sum':0})
        #8:00-10:00
        sql="select app01_outlet.outlet_name, count(app01_campaignoneredeemtionperday.ic_number) from app01_campaignoneredeemtionperday join  app01_outlet on app01_campaignoneredeemtionperday.redeemtion_outlet_id=app01_outlet.id  where app01_campaignoneredeemtionperday.redeemtion_date=current_date and date_part('hour',app01_campaignoneredeemtionperday.redeemtion_time)>=8 and date_part('hour',app01_campaignoneredeemtionperday.redeemtion_time)<10 group by app01_outlet.outlet_name,app01_campaignoneredeemtionperday.redeemtion_outlet_id order by app01_outlet.outlet_name ,app01_campaignoneredeemtionperday.redeemtion_outlet_id desc"
        cursor = connection.cursor()
        cursor.execute(sql)
        row = cursor.fetchall()
        if row:
            num = 0

            for i in data:
                for j in row:
                    if ((i['outlet_name'] == j[0])):
                        data[num]["c10"] = j[1]
                        total10 =total10+j[1]
                        break
                num += 1
        # 10:00-12:00
        sql = "select app01_outlet.outlet_name, count(app01_campaignoneredeemtionperday.ic_number) from app01_campaignoneredeemtionperday join  app01_outlet on app01_campaignoneredeemtionperday.redeemtion_outlet_id=app01_outlet.id  where app01_campaignoneredeemtionperday.redeemtion_date=current_date and date_part('hour',app01_campaignoneredeemtionperday.redeemtion_time)>=10 and date_part('hour',app01_campaignoneredeemtionperday.redeemtion_time)<12 group by app01_outlet.outlet_name,app01_campaignoneredeemtionperday.redeemtion_outlet_id order by app01_outlet.outlet_name ,app01_campaignoneredeemtionperday.redeemtion_outlet_id desc"
        cursor = connection.cursor()
        cursor.execute(sql)
        row = cursor.fetchall()
        if row:
            num = 0
            for i in data:
                for j in row:
                     if ((i['outlet_name'] == j[0])):
                           data[num]["c12"] = j[1]
                           total12= total12 + j[1]
                           break
                num += 1
        # 12:00-14:00
        sql = "select app01_outlet.outlet_name, count(app01_campaignoneredeemtionperday.ic_number) from app01_campaignoneredeemtionperday join  app01_outlet on app01_campaignoneredeemtionperday.redeemtion_outlet_id=app01_outlet.id  where app01_campaignoneredeemtionperday.redeemtion_date=current_date and date_part('hour',app01_campaignoneredeemtionperday.redeemtion_time)>=12 and date_part('hour',app01_campaignoneredeemtionperday.redeemtion_time)<14 group by app01_outlet.outlet_name,app01_campaignoneredeemtionperday.redeemtion_outlet_id order by app01_outlet.outlet_name ,app01_campaignoneredeemtionperday.redeemtion_outlet_id desc"
        cursor = connection.cursor()
        cursor.execute(sql)
        row = cursor.fetchall()
        if row:
            num = 0
            for i in data:
                for j in row:
                    if ((i['outlet_name'] == j[0])):
                        data[num]["c14"] = j[1]
                        total14 = total14 + j[1]
                        break
                num += 1

        # 14:00-16:00
        sql = "select app01_outlet.outlet_name, count(app01_campaignoneredeemtionperday.ic_number) from app01_campaignoneredeemtionperday join  app01_outlet on app01_campaignoneredeemtionperday.redeemtion_outlet_id=app01_outlet.id  where app01_campaignoneredeemtionperday.redeemtion_date=current_date and date_part('hour',app01_campaignoneredeemtionperday.redeemtion_time)>=14 and date_part('hour',app01_campaignoneredeemtionperday.redeemtion_time)<16 group by app01_outlet.outlet_name,app01_campaignoneredeemtionperday.redeemtion_outlet_id order by app01_outlet.outlet_name ,app01_campaignoneredeemtionperday.redeemtion_outlet_id desc"
        cursor = connection.cursor()
        cursor.execute(sql)
        row = cursor.fetchall()
        if row:
            num = 0
            for i in data:
                for j in row:
                    if ((i['outlet_name'] == j[0])):
                        data[num]["c16"] = j[1]
                        total16 = total16 + j[1]
                        break
                num += 1

        # 16:00-18:00
        sql = "select app01_outlet.outlet_name, count(app01_campaignoneredeemtionperday.ic_number) from app01_campaignoneredeemtionperday join  app01_outlet on app01_campaignoneredeemtionperday.redeemtion_outlet_id=app01_outlet.id  where app01_campaignoneredeemtionperday.redeemtion_date=current_date and date_part('hour',app01_campaignoneredeemtionperday.redeemtion_time)>=16 and date_part('hour',app01_campaignoneredeemtionperday.redeemtion_time)<18 group by app01_outlet.outlet_name,app01_campaignoneredeemtionperday.redeemtion_outlet_id order by app01_outlet.outlet_name ,app01_campaignoneredeemtionperday.redeemtion_outlet_id desc"
        cursor = connection.cursor()
        cursor.execute(sql)
        row = cursor.fetchall()
        if row:
            num = 0
            for i in data:
                for j in row:
                    if ((i['outlet_name'] == j[0])):
                        data[num]["c18"] = j[1]
                        total18 = total18 + j[1]
                        break
                num += 1

        # 18:00-20:00
        sql = "select app01_outlet.outlet_name, count(app01_campaignoneredeemtionperday.ic_number) from app01_campaignoneredeemtionperday join  app01_outlet on app01_campaignoneredeemtionperday.redeemtion_outlet_id=app01_outlet.id  where app01_campaignoneredeemtionperday.redeemtion_date=current_date and date_part('hour',app01_campaignoneredeemtionperday.redeemtion_time)>=18 and date_part('hour',app01_campaignoneredeemtionperday.redeemtion_time)<20 group by app01_outlet.outlet_name,app01_campaignoneredeemtionperday.redeemtion_outlet_id order by app01_outlet.outlet_name ,app01_campaignoneredeemtionperday.redeemtion_outlet_id desc"
        cursor = connection.cursor()
        cursor.execute(sql)
        row = cursor.fetchall()
        if row:
            num = 0
            for i in data:
                for j in row:
                    if ((i['outlet_name'] == j[0])):
                        data[num]["c20"] = j[1]
                        total20 = total20 + j[1]
                        break
                num += 1

        # 20:00-22:00
        sql = "select app01_outlet.outlet_name, count(app01_campaignoneredeemtionperday.ic_number) from app01_campaignoneredeemtionperday join  app01_outlet on app01_campaignoneredeemtionperday.redeemtion_outlet_id=app01_outlet.id  where app01_campaignoneredeemtionperday.redeemtion_date=current_date and date_part('hour',app01_campaignoneredeemtionperday.redeemtion_time)>=20 and date_part('hour',app01_campaignoneredeemtionperday.redeemtion_time)<22 group by app01_outlet.outlet_name,app01_campaignoneredeemtionperday.redeemtion_outlet_id order by app01_outlet.outlet_name ,app01_campaignoneredeemtionperday.redeemtion_outlet_id desc"
        cursor = connection.cursor()
        cursor.execute(sql)
        row = cursor.fetchall()
        if row:
            num = 0
            for i in data:
                for j in row:
                    if ((i['outlet_name'] == j[0])):
                        data[num]["c22"] = j[1]
                        total22= total22 + j[1]
                        break
                num += 1

        #count sum
        num=0
        line=""
        for i in data:
            data[num]["sum"]=data[num]["c10"]+data[num]["c12"]+data[num]["c14"]+data[num]["c16"]+data[num]["c18"]+data[num]["c20"]+data[num]["c22"]
            totalsum=totalsum+data[num]["sum"]
            line=line+"<tr><td>"+data[num]["outlet_name"]+"</td><td>"+str(data[num]["c10"])+"</td><td>"+str(data[num]["c12"])+"</td><td>"+str(data[num]["c14"])+"</td><td>"+str(data[num]["c16"])+"</td><td>"+str(data[num]["c18"])+"</td><td>"+str(data[num]["c20"])+"</td><td>"+str(data[num]["c22"])+"</td><td>"+str(data[num]["sum"])+"</td></tr>"
            num+=1

        #total:
        line=line+"<tr><td>Total</td><td>"+str(total10)+"</td><td>"+str(total12)+"</td><td>"+str(total14)+"</td><td>"+str(total16)+"</td><td>"+str(total18)+"</td><td>"+str(total20)+"</td><td>"+str(total22)+"</td><td>"+str(totalsum)+"</td></tr>"


        #send mail
        countTable = "<table border='1' cellspacing='0' style='text-align:center' ><tr ><td colspan='9'>Promotion Count</td></tr><tr><td>Outlet</td><td>8:00-10:00</td><td>10:00-12:00</td><td>12:00-14:00</td><td>14:00-16:00</td><td>16:00-18:00</td><td>18:00-20:00</td>20:00-22:00</td><td>sum</td></tr>"
        table=countTable+line+"</table>"





        utils.send_register_email(utils.RECEIVE_MAIL, table, send_type="active", promotion='')


    return Response(data)



@api_view(['GET', 'POST'])
@authentication_classes([])
@permission_classes((AllowAny,))
def auto_confirm(request, *args, **kwargs):
    if request.method == 'GET':
        now = datetime.datetime.now()
        #outlet_id
        outlet_id = request.query_params.get('outlet_id')
        if outlet_id:
            with transaction.atomic():
                 outlet=models.Outlet.objects.get(id=outlet_id)
                 if outlet:
                     '''
                     #print(outlet.outlet_count_date==now.date())
                     if  outlet.outlet_count_date:
                         print(outlet.outlet_count_date)
                         print(now.date())
                         print(outlet.outlet_count_date==now.date())
                         if outlet.outlet_count_date==now.date():
                              outlet_count=outlet.outlet_count
                              #print(outlet_count)
                              #outlet_count=outlet_count+1
                              #print(outlet_count)
                              #outlet.outlet_count=outlet_count
                              #print(outlet.outlet_count)
                              #outlet.save()
                         else:
                             outlet.outlet_count_date=now.date()
                             outlet.outlet_count=1
                             outlet.save()
                             outlet_count=1
                     else:
                         outlet.outlet_count_date = now.date()
                         outlet.outlet_count = 1
                         outlet.save()
                         outlet_count = 1
                     '''
                     #recent_list=models.Transaction.objects.filter(outlet__id=outlet_id,transaction_status=2,delay_time__lte=now + datetime.timedelta(minutes=10)).order_by('delay_time')
                     recent_list = models.Transaction.objects.filter(outlet__id=outlet_id, transaction_status=2,delay_time__lte=now + datetime.timedelta( minutes=10)).order_by('delay_time')
                     if recent_list:
                         for item in recent_list:
                             receipt_no=''
                             '''
                             isPot=False
                             #sum = models.Transaction.objects.filter(payment_datetime__date=now.date(),outlet__id=outlet_id,transaction_status__in=(2,3,4,5)).aggregate(count=Count('id',distanct=True))
                             outlet_count_str=str(outlet_count)+''
                             if len(outlet_count_str)==1:
                                 receipt_no='000'+outlet_count_str
                             elif  len(outlet_count_str)==2:
                                 receipt_no = '00' + outlet_count_str
                             elif  len(outlet_count_str)==3:
                                 receipt_no = '0' + outlet_count_str

                             else:
                                 receipt_no=outlet_count_str
                             #item.receipt_no= receipt_no
                             #if item.transaction_status==2:
                             #    item.transaction_status=4
                             #item.save()
                             
                             transDetailsList=models.TransactDetails.objects.filter(transaction__id=item.id)
                             if transDetailsList:
                                 for details in transDetailsList:
                                     if details.transactDetails_type!=0:
                                         isPot=True
                                         break
                             if not isPot:
                                 receipt_no=''
                             '''
                             result=models.Transaction.objects.filter(id=item.id,transaction_status=2).update(receipt_no=receipt_no,transaction_status=4,confirm_time=now)
                             #result = models.Transaction.objects.select_for_update(nowait=True).filter(id=item.id,transaction_status=2).update(transaction_status=4, confirm_time=now)
                             #send notification
                             '''
                             if result:
                                 outlet_count += 1
                                 outlet.outlet_count = outlet_count
                                 outlet.save()
                                 member = item.member
                                 # member update membership thread
                                 #update_member_points(member, item.total_money, 1, None, None)
                                 if (member):
                                     device_token = member.device_token
                                     if (device_token):
                                         transact_datetime = item.transact_datetime
                                         pick_up_time = item.pick_up_time
                                         delay_time = item.delay_time
                                         if (delay_time):
                                             pickup_time = delay_time
                                         else:
                                             interval_time = getIntervalTime(str(pick_up_time))
                                             pickup_time = transact_datetime + datetime.timedelta(minutes=interval_time)
                                         pickup_time = pickup_time + datetime.timedelta(hours=8)
                                         if device_token:
                                             pass
                                             #send_message_to_token(device_token, 'Order Confirmed','Receipt NO.' + receipt_no + '\nOrder NO.' + item.order_no + '\nPick up time ' + pickup_time.strftime("%Y-%m-%d %H:%M"))
                             '''
                     return Response({'msg': 'ok',}, status=status.HTTP_200_OK)


    return Response({'msg': 'None',}, status=status.HTTP_200_OK)

@api_view(['GET', 'POST'])
@authentication_classes([])
@permission_classes((AllowAny,))
def confirmOrder(request, *args, **kwargs):
    if request.method == 'GET':
        now = datetime.datetime.now()
        #order_id
        trans_id = request.query_params.get('product_status')
        trans_status= request.query_params.get('time_inteval')
        outlet_id = request.query_params.get('outlet_id')
        #print(trans_id)
        #print(trans_status)
        with transaction.atomic():
            if (trans_id and trans_status):
                if trans_status=='2':
                    receipt_no=''
                    '''
                    isPot = False
                    outlet = models.Outlet.objects.select_for_update(nowait=True).get(id=outlet_id)
                    if outlet:
                        if outlet.outlet_count_date:
                            if outlet.outlet_count_date == now.date():
                                 outlet_count = outlet.outlet_count

                            else:
                                outlet.outlet_count_date = now.date()
                                outlet.outlet_count = 1
                                outlet.save()
                                outlet_count = 1
                        else:
                            outlet.outlet_count_date = now.date()
                            outlet.outlet_count = 1
                            outlet.save()
                            outlet_count = 1


                    outlet_count_str = str(outlet_count) + ''
                    if len(outlet_count_str) == 1:
                        receipt_no = '000' + outlet_count_str
                    elif len(outlet_count_str) == 2:
                        receipt_no = '00' + outlet_count_str
                    elif len(outlet_count_str) == 3:
                        receipt_no = '0' + outlet_count_str
                    else:
                        receipt_no = outlet_count_str
                    transDetailsList = models.TransactDetails.objects.filter(transaction__id=trans_id)
                    if transDetailsList:
                        for details in transDetailsList:
                            if details.transactDetails_type != 0:
                                isPot = True
                                break
                    if not isPot:
                        receipt_no = ''
                    '''
                    result=models.Transaction.objects.filter(id=trans_id,transaction_status=2).update(transaction_status=4,receipt_no=receipt_no,confirm_time=now)
                    #result = models.Transaction.objects.select_for_update(nowait=True).filter(id=trans_id,transaction_status=2).update(transaction_status=4, receipt_no=receipt_no, confirm_time=now)
                    #result = models.Transaction.objects.select_for_update(nowait=True).filter(id=trans_id,transaction_status=2).update(transaction_status=4, confirm_time=now)
                    #print(result)

                    if result:
                        '''
                        if outlet:
                            outlet.outlet_count = outlet_count+1
                            outlet.save()
                        item=models.Transaction.objects.get(id=trans_id)
                        member = item.member
                        # member update membership thread
                        #update_member_points(member, item.total_money, 1, None, None)
                        if (member):
                            device_token = member.device_token
                            if (device_token):
                                transact_datetime = item.transact_datetime
                                pick_up_time = item.pick_up_time
                                delay_time = item.delay_time
                                if (delay_time):
                                    pickup_time = delay_time
                                else:
                                    interval_time = getIntervalTime(str(pick_up_time))
                                    pickup_time = transact_datetime + datetime.timedelta(minutes=interval_time)
                                pickup_time = pickup_time + datetime.timedelta(hours=8)
                                if device_token:
                                    pass
                                    #send_message_to_token(device_token, 'Order Confirmed','Please collect your order at the counter with recepit number:' + receipt_no )
                        '''
                        return Response({'msg': 'ok', }, status=status.HTTP_200_OK)

                    else:
                        return Response({'msg': 'error', }, status=status.HTTP_200_OK)
                if trans_status=='4':
                    isPot = False
                    transDetailsList = models.TransactDetails.objects.filter(transaction__id=trans_id)
                    if transDetailsList:
                        for details in transDetailsList:
                            if details.transactDetails_type != 0:
                                isPot = True
                                break
                    if isPot:
                        result = models.Transaction.objects.filter(id=trans_id, transaction_status=4).update(transaction_status=5,collected_time=timezone.make_aware(datetime.datetime.now(), timezone=timezone.get_current_timezone()))
                    else:
                        #print_status=True pick_up_type=0
                        result = models.Transaction.objects.filter(id=trans_id).filter(Q(pick_up_type=0, transaction_status__in = (4,), print_status = False) | Q(pick_up_type=1, transaction_status__in = (4,), print_status = False)).update(transaction_status=5,collected_time=timezone.make_aware(datetime.datetime.now(), timezone=timezone.get_current_timezone()))
                        #result = models.Transaction.objects.filter(id=trans_id, transaction_status=4).update(transaction_status=5,collected_time=datetime.datetime.now())
                        #result=models.Transaction.objects.filter(id=trans_id,transaction_status=4,print_status=True).update(transaction_status=5,collected_time=datetime.datetime.now())
                    if result:


                        item = models.Transaction.objects.get(id=trans_id)


                        member = item.member
                        #deal electric sign
                        deal_electric_sign(member,item)
                        if (member):
                            #member update membership thread move to confirmed
                            if item.total_money>0:
                                update_member_points(member,item.total_money,1,None,None)
                            device_token = member.device_token
                            #if (device_token):
                            #    send_message_to_token(device_token, 'Order Collected','Thanks for your coming and we’re looking forward to your next coming again.')
                        # first payment cash back 10%
                        #first_payment_cash_back(trans_id,member.id)
                        return Response({'msg': 'ok', }, status=status.HTTP_200_OK)
                    else:
                        return Response({'msg': 'error', }, status=status.HTTP_200_OK)
        return Response({'msg': 'None', }, status=status.HTTP_200_OK)

@api_view(['GET', 'POST'])
@authentication_classes([])
@permission_classes((AllowAny,))
def dealTopRootId(request, *args, **kwargs):

    if request.method == 'GET' :



        product_list = models.Product.objects.filter(outlet__isnull=True)

        if(product_list):
               for item in product_list:
                   models.Product.objects.filter(outlet__isnull=False,scheme__id=item.scheme.id,name=item.name).update(root_product_id=item.id)

               return Response({'msg': 'ok'})
        else:
            return Response({'msg': 'error'})

@api_view(['GET', 'POST'])
@authentication_classes([])
@permission_classes((AllowAny,))
def sumManualTopup(request, *args, **kwargs):

    if request.method == 'GET' :
        outlet_id=request.GET.get('outlet_id')
        req_date=request.GET.get('created_date')
        print(req_date)
        if (req_date):

            sum = models.TopupRecord.objects.filter(created_date=req_date,outlet__id=outlet_id).aggregate(sum=Sum('money'))
        else:
            sum = models.TopupRecord.objects.filter(outlet__id=outlet_id).aggregate(sum=Sum('money'))


        if(sum):
               print(sum)

               return Response({'sum': sum['sum']})
        else:
            return Response({'sum': 0})

@api_view(['GET', 'POST'])
@authentication_classes([])
@permission_classes((AllowAny,))
def getTopupCount(request, *args, **kwargs):

    if request.method == 'GET' :
        outlet_id=request.GET.get('outlet_id')
        req_date=request.GET.get('created_date')
        payment_type = request.GET.get('payment_type')
        print(req_date)

        if outlet_id:
            today_sum = models.TopupRecord.objects.filter(created_date=time.strftime("%Y-%m-%d",time.localtime(time.time())),outlet__id=outlet_id).aggregate(sum=Sum('money'))
            today_refund_sum = models.TopupRecord.objects.filter(created_date=time.strftime("%Y-%m-%d",time.localtime(time.time())), outlet__id=outlet_id,payment_type=0).aggregate(sum=Sum('money'))
            today_topup_sum = models.TopupRecord.objects.filter(created_date=time.strftime("%Y-%m-%d",time.localtime(time.time())), outlet__id=outlet_id,payment_type=1).aggregate(sum=Sum('money'))

            sum = models.TopupRecord.objects.filter(outlet__id=outlet_id).aggregate(sum=Sum('money'))
            topup_sum = models.TopupRecord.objects.filter( outlet__id=outlet_id,payment_type=1).aggregate(sum=Sum('money'))
            refund_sum = models.TopupRecord.objects.filter(outlet__id=outlet_id, payment_type=0).aggregate(sum=Sum('money'))


        if(sum):
               print(sum)

               return Response({'today_sum': today_sum['sum'],'today_refund_sum': today_refund_sum['sum'],'today_topup_sum': today_topup_sum['sum'],'sum': sum['sum'],'refund_sum': refund_sum['sum'],'topup_sum': topup_sum['sum']})
        else:
            return Response(None)



#manual topup
class TopupRecordViewSet(viewsets.ModelViewSet):
    authentication_classes=()
    permission_classes = (TopupRecordPermission,)
    queryset = models.TopupRecord.objects.all()
    serializer_class = serializers.TopupRecordSerializer
    pagination_class = DefaultPagination
    filter_backends = (
        DjangoFilterBackend,
        SearchFilter,
        OrderingFilter,
    )
    filter_class = TopupRecordFilter
    search_fields = ('created', )
    ordering_fields = ('id', )

    def create(self, request, *args, **kwargs):
        mobile=request.data.get('mobile')
        outlet_id=request.data.get('outlet')
        money=request.data.get('money')
        amount=(str(money)).strip()
        list={}
        if mobile:
            member=models.Member.objects.get(mobile_no=mobile)
            if member:
                if outlet_id:
                    outlet_obj=models.Outlet.objects.get(id=outlet_id)

                    if outlet_obj:
                        with transaction.atomic():
                            if outlet_obj.outlet_name == 'HQ':
                                    if float(money)<5.1:
                                          #check refund times
                                          refund_record=models.TopupRecord.objects.filter(member__id=member.id,payment_type=0)
                                          if refund_record:
                                               if outlet_obj.outlet_name=='HQ':
                                                        pass
                                               else:

                                                   list['error']='Mobile:'+mobile+" has recycled 1 times,can't repeat refund."
                                                   return Response(list, status.HTTP_200_OK)
                                          topup_record={'member': member.id, 'mobile': mobile, 'outlet': outlet_obj.id,'outlet_name':outlet_obj.outlet_name,'money':money,'payment_type':'0'}
                                    else:
                                        topup_record = {'member': member.id, 'mobile': mobile, 'outlet': outlet_obj.id,'outlet_name': outlet_obj.outlet_name, 'money': money,'payment_type':'1'}
                                        #topup campaign


                                    serializer = serializers.TopupRecordSerializer(data=topup_record)
                                    if serializer.is_valid():



                                         record_obj=self.perform_create(serializer)
                                         '''
                                         topup_id = serializer.data['id']
                                         topupObj=models.TopupRecord.objects.get(id=topup_id)
                                         if topupObj:
                                             if float(money) < 5.1:
                                                topupObj.payment_type=0
                                             else:
                                                 topupObj.payment_type = 1
                                             topupObj.save()
                                             '''
                                         #print(record_obj)
                                         headers = self.get_success_headers(serializer.data)
                                         #wallet rechargeRecord
                                         wallet = models.Wallet.objects.get(member__id=member.id)
                                         list = serializer.data
                                         if wallet:
                                             wallet.balance+=float(money)
                                             wallet.save()
                                             serializer_recharge = RechargeRecordCreateSerializer(
                                                 data={'money': money, 'wallet': wallet.id, 'type': 0,'status':0})
                                             if serializer_recharge.is_valid():
                                                 models.RechargeRecord.objects.create(**serializer_recharge.validated_data)

                                             list['balance'] = wallet.balance
                                             if member.device_token:
                                                send_message_to_token(member.device_token, 'Top up successfully','Amout: $'+str(money))

                                             if float(money) > 5:
                                                 # recharge campaign
                                                 campaign_return_cash = 0
                                                 campaignTopup = models.CampaignTopup.objects.first()

                                                 if member:
                                                     topup_10_times = 0 if member.topup_10_times is None else member.topup_10_times
                                                     topup_20_times = 0 if member.topup_20_times is None else member.topup_20_times
                                                     topup_50_times = 0 if member.topup_50_times is None else member.topup_50_times
                                                 if campaignTopup:

                                                     activity_flag = campaignTopup.activity_flag
                                                     date_limit_flag = campaignTopup.date_limit_flag
                                                     times_limit_flag = campaignTopup.times_limit_flag
                                                     if  activity_flag:
                                                         #print('ok')
                                                         if times_limit_flag:
                                                             if date_limit_flag:
                                                                 pass

                                                             else:
                                                                 if campaignTopup.topup_10_limit_times > topup_10_times and str(amount)[0:2] == '10':
                                                                     campaign_return_cash = campaignTopup.topup_10_return_cash
                                                                 if campaignTopup.topup_20_limit_times > topup_20_times and str(amount)[0:2] == '20':
                                                                     campaign_return_cash = campaignTopup.topup_20_return_cash
                                                                 if campaignTopup.topup_50_limit_times > topup_50_times and str(amount)[0:2] == '50':
                                                                     campaign_return_cash = campaignTopup.topup_50_return_cash

                                                         else:
                                                             if date_limit_flag:
                                                                 pass

                                                             else:
                                                                 #print('kkkkkkk'+str(amount)[0:2])
                                                                 if str(amount)[0:2] == '10':
                                                                     campaign_return_cash = campaignTopup.topup_10_return_cash
                                                                 if str(amount)[0:2] == '20':
                                                                     campaign_return_cash = campaignTopup.topup_20_return_cash
                                                                 if str(amount)[0:2] == '50':
                                                                     campaign_return_cash = campaignTopup.topup_50_return_cash
                                                 #print(amount == 10)
                                                 if campaign_return_cash>0:
                                                     wallet.balance += campaign_return_cash
                                                     wallet.lastest_top_up = time.strftime("%Y-%m-%d", time.localtime())
                                                     wallet.save()

                                                     if campaign_return_cash:
                                                         serializer = RechargeRecordCreateSerializer(
                                                             data={'money': campaign_return_cash, 'wallet': wallet.id,
                                                                   'type': 3, 'request_id': member.id,
                                                                   'status': 0})
                                                         if serializer.is_valid():
                                                             instance = models.RechargeRecord.objects.create(
                                                                 **serializer.validated_data)
                                                         if member.device_token:
                                                             send_message_to_token(member.device_token, 'Top up reward',
                                                                                   'Amout: $' + str(campaign_return_cash))
                                                         # service.recharge(instance)
                                                     # memeber add topup times
                                                 if member:
                                                     if str(amount)[0:2] == '10':
                                                         if member.topup_10_times:
                                                             print('ok')
                                                             member.topup_10_times = member.topup_10_times + 1
                                                         else:
                                                             member.topup_10_times = 1
                                                     elif str(amount)[0:2] == '20':
                                                         if member.topup_20_times:
                                                             member.topup_20_times = member.topup_20_times + 1
                                                         else:
                                                             member.topup_20_times = 1
                                                     else:
                                                         if member.topup_50_times:
                                                             member.topup_50_times = member.topup_50_times + 1
                                                         else:
                                                             member.topup_50_times = 1
                                                     member.save()
                                                     #topup_table=get_topup_outlet_mail_table(outlet_obj.outlet_name, member, wallet.id, 'outlet',money)
                                                     #utils.send_register_email(utils.RECEIVE_MAIL, topup_table,send_type="topup", promotion='')
                                                     #thread_send_mail(topup_table, "topup")




                                         return Response(list, status.HTTP_200_OK, headers=headers)
                            else:
                                list['error'] = 'iTEA outlet topup recharging discontinued(门店充值已经停止)'
                                return Response(list, status.HTTP_200_OK)
            return Response(None,status.HTTP_500_INTERNAL_SERVER_ERROR)

#manual RefundRecord
class RefundRecordViewSet(viewsets.ModelViewSet):
    authentication_classes=()
    permission_classes = (TopupRecordPermission,)
    queryset = models.RefundRecord.objects.all()
    serializer_class = serializers.RefundRecordSerializer
    pagination_class = DefaultPagination
    filter_backends = (
        DjangoFilterBackend,
        SearchFilter,
        OrderingFilter,
    )
    filter_class = RefundRecordFilter
    search_fields = ('created', )
    ordering_fields = ('id', )

    def create(self, request, *args, **kwargs):
        mobile=request.data.get('mobile')
        outlet_id=request.data.get('outlet')
        money=request.data.get('money')

        if mobile:
            member=models.Member.objects.get(mobile_no=mobile)
            if member:
                if outlet_id:
                    outlet_obj=models.Outlet.objects.get(id=outlet_id)

                    if outlet_obj:
                        with transaction.atomic():

                            topup_record={'member': member.id, 'mobile': mobile, 'outlet': outlet_obj.id,'outlet_name':outlet_obj.outlet_name,'money':money}

                            serializer = serializers.RefundRecordSerializer(data=topup_record)
                            if serializer.is_valid():



                                 record_obj=self.perform_create(serializer)
                                 #print(record_obj)
                                 headers = self.get_success_headers(serializer.data)
                                 #wallet rechargeRecord
                                 wallet = models.Wallet.objects.get(member__id=member.id)
                                 if wallet:
                                     wallet.balance+=float(money)
                                     wallet.save()
                                     serializer_recharge = RechargeRecordCreateSerializer(
                                         data={'money': money, 'wallet': wallet.id, 'type': 0,'status':0})
                                     if serializer_recharge.is_valid():
                                         models.RechargeRecord.objects.create(**serializer_recharge.validated_data)
                                 if member.device_token:
                                     send_message_to_token(member.device_token, 'Top up successfully','Amout: $'+str(money))
                                 return Response(serializer.data, status.HTTP_200_OK, headers=headers)
            return Response(None,status.HTTP_500_INTERNAL_SERVER_ERROR)

@api_view(['GET'])
def countPayment(request, *args, **kwargs):
    data=[]
    total10=0
    total12=0
    total14=0
    total16=0
    total18=0
    total20=0
    total22=0
    totalsum=0
    #countUnit = {'outlet_name': '', 'c10': 0, 'c12': 0, 'c14': 0, 'c16': 0, 'c18': 0, 'c20': 0, 'c22': 0}
    if request.method == 'GET':
        f=1.236
        g='%.2f' % f
        k=float(g)
        print(k)
        outlet_list=models.Outlet.objects.all()
        if outlet_list:
            for outlet in outlet_list:

               data.append({'outlet_name': outlet.outlet_name, 'c10': 0, 'c12': 0, 'c14': 0, 'c16': 0, 'c18': 0, 'c20': 0, 'c22': 0,'sum':0})
        #8:00-10:00
        sql="select app01_outlet.outlet_name, sum(app01_transaction.total_money) from app01_transaction join  app01_outlet on app01_transaction.outlet_id=app01_outlet.id  where to_char(app01_transaction.payment_datetime,'yyyy-mm-dd')=to_char(current_date,'yyyy-mm-dd') and date_part('hour',app01_transaction.payment_datetime)>=8 and date_part('hour',app01_transaction.payment_datetime)<10 and app01_transaction.transaction_status in (2,4,5) group by app01_outlet.outlet_name,app01_transaction.outlet_id order by app01_outlet.outlet_name ,app01_transaction.outlet_id desc"
        cursor = connection.cursor()
        cursor.execute(sql)
        row = cursor.fetchall()
        if row:
            num = 0

            for i in data:
                for j in row:
                    if ((i['outlet_name'] == j[0])):
                        data[num]["c10"] = j[1]
                        total10 =total10+j[1]
                        break
                num += 1
        # 10:00-12:00
        sql = "select app01_outlet.outlet_name, sum(app01_transaction.total_money) from app01_transaction join  app01_outlet on app01_transaction.outlet_id=app01_outlet.id  where to_char(app01_transaction.payment_datetime,'yyyy-mm-dd')=to_char(current_date,'yyyy-mm-dd') and date_part('hour',app01_transaction.payment_datetime)>=10 and date_part('hour',app01_transaction.payment_datetime)<12 and app01_transaction.transaction_status in (2,4,5) group by app01_outlet.outlet_name,app01_transaction.outlet_id order by app01_outlet.outlet_name ,app01_transaction.outlet_id desc"
        cursor = connection.cursor()
        cursor.execute(sql)
        row = cursor.fetchall()
        print(row)
        if row:
            num = 0
            for i in data:
                for j in row:
                     if ((i['outlet_name'] == j[0])):
                           data[num]["c12"] = j[1]
                           total12= total12 + j[1]
                           break
                num += 1
        # 12:00-14:00
        sql = "select app01_outlet.outlet_name, sum(app01_transaction.total_money) from app01_transaction join  app01_outlet on app01_transaction.outlet_id=app01_outlet.id  where to_char(app01_transaction.payment_datetime,'yyyy-mm-dd')=to_char(current_date,'yyyy-mm-dd') and date_part('hour',app01_transaction.payment_datetime)>=12 and date_part('hour',app01_transaction.payment_datetime)<14 and app01_transaction.transaction_status in (2,4,5) group by app01_outlet.outlet_name,app01_transaction.outlet_id order by app01_outlet.outlet_name ,app01_transaction.outlet_id desc"
        cursor = connection.cursor()
        cursor.execute(sql)
        row = cursor.fetchall()
        if row:
            num = 0
            for i in data:
                for j in row:
                    if ((i['outlet_name'] == j[0])):
                        data[num]["c14"] = j[1]
                        total14 = total14 + j[1]
                        break
                num += 1

        # 14:00-16:00
        sql = "select app01_outlet.outlet_name, sum(app01_transaction.total_money) from app01_transaction join  app01_outlet on app01_transaction.outlet_id=app01_outlet.id  where to_char(app01_transaction.payment_datetime,'yyyy-mm-dd')=to_char(current_date,'yyyy-mm-dd') and date_part('hour',app01_transaction.payment_datetime)>=14 and date_part('hour',app01_transaction.payment_datetime)<16 and app01_transaction.transaction_status in (2,4,5) group by app01_outlet.outlet_name,app01_transaction.outlet_id order by app01_outlet.outlet_name ,app01_transaction.outlet_id desc"
        cursor = connection.cursor()
        cursor.execute(sql)
        row = cursor.fetchall()
        if row:
            num = 0
            for i in data:
                for j in row:
                    if ((i['outlet_name'] == j[0])):
                        data[num]["c16"] = j[1]
                        total16 = total16 + j[1]
                        break
                num += 1

        # 16:00-18:00
        sql = "select app01_outlet.outlet_name, sum(app01_transaction.total_money) from app01_transaction join  app01_outlet on app01_transaction.outlet_id=app01_outlet.id  where to_char(app01_transaction.payment_datetime,'yyyy-mm-dd')=to_char(current_date,'yyyy-mm-dd') and date_part('hour',app01_transaction.payment_datetime)>=16 and date_part('hour',app01_transaction.payment_datetime)<18 and app01_transaction.transaction_status in (2,4,5) group by app01_outlet.outlet_name,app01_transaction.outlet_id order by app01_outlet.outlet_name ,app01_transaction.outlet_id desc"
        cursor = connection.cursor()
        cursor.execute(sql)
        row = cursor.fetchall()
        if row:
            num = 0
            for i in data:
                for j in row:
                    if ((i['outlet_name'] == j[0])):
                        data[num]["c18"] = j[1]
                        total18 = total18 + j[1]
                        break
                num += 1

        # 18:00-20:00
        sql = "select app01_outlet.outlet_name, sum(app01_transaction.total_money) from app01_transaction join  app01_outlet on app01_transaction.outlet_id=app01_outlet.id  where to_char(app01_transaction.payment_datetime,'yyyy-mm-dd')=to_char(current_date,'yyyy-mm-dd') and date_part('hour',app01_transaction.payment_datetime)>=18 and date_part('hour',app01_transaction.payment_datetime)<20 and app01_transaction.transaction_status in (2,4,5) group by app01_outlet.outlet_name,app01_transaction.outlet_id order by app01_outlet.outlet_name ,app01_transaction.outlet_id desc"
        cursor = connection.cursor()
        cursor.execute(sql)
        row = cursor.fetchall()
        if row:
            num = 0
            for i in data:
                for j in row:
                    if ((i['outlet_name'] == j[0])):
                        data[num]["c20"] = j[1]
                        total20 = total20 + j[1]
                        break
                num += 1

        # 20:00-22:00
        sql = "select app01_outlet.outlet_name, sum(app01_transaction.total_money) from app01_transaction join  app01_outlet on app01_transaction.outlet_id=app01_outlet.id  where to_char(app01_transaction.payment_datetime,'yyyy-mm-dd')=to_char(current_date,'yyyy-mm-dd') and date_part('hour',app01_transaction.payment_datetime)>=20 and date_part('hour',app01_transaction.payment_datetime)<22 and app01_transaction.transaction_status in (2,4,5) group by app01_outlet.outlet_name,app01_transaction.outlet_id order by app01_outlet.outlet_name ,app01_transaction.outlet_id desc"
        cursor = connection.cursor()
        cursor.execute(sql)
        row = cursor.fetchall()
        if row:
            num = 0
            for i in data:
                for j in row:
                    if ((i['outlet_name'] == j[0])):
                        data[num]["c22"] = j[1]
                        total22= total22 + j[1]
                        break
                num += 1

        #count sum
        num=0
        line=""
        for i in data:
            data[num]["sum"]=data[num]["c10"]+data[num]["c12"]+data[num]["c14"]+data[num]["c16"]+data[num]["c18"]+data[num]["c20"]+data[num]["c22"]
            totalsum=totalsum+data[num]["sum"]
            line=line+"<tr><td>"+data[num]["outlet_name"]+"</td><td>"+str(data[num]["c10"])+"</td><td>"+str(data[num]["c12"])+"</td><td>"+str(data[num]["c14"])+"</td><td>"+str(data[num]["c16"])+"</td><td>"+str(data[num]["c18"])+"</td><td>"+str(data[num]["c20"])+"</td><td>"+str(data[num]["c22"])+"</td><td>"+str(data[num]["sum"])+"</td></tr>"
            num+=1

        #total:
        line=line+"<tr><td>Total</td><td>"+str(total10)+"</td><td>"+str(total12)+"</td><td>"+str(total14)+"</td><td>"+str(total16)+"</td><td>"+str(total18)+"</td><td>"+str(total20)+"</td><td>"+str(total22)+"</td><td>"+str(totalsum)+"</td></tr>"


        #send mail
        countTable = "<table border='1' cellspacing='0' style='text-align:center' ><tr ><td colspan='9'>Payment Count</td></tr><tr><td>Outlet</td><td>8:00-10:00</td><td>10:00-12:00</td><td>12:00-14:00</td><td>14:00-16:00</td><td>16:00-18:00</td><td>18:00-20:00</td>20:00-22:00</td><td>sum</td></tr>"
        table=countTable+line+"</table>"

        #count topup(mobile)




        utils.send_register_email(utils.RECEIVE_MAIL, table, send_type="active", promotion='')


    return Response(data)


@api_view(['GET'])
def countOutletPayment(request, *args, **kwargs):
    data=[]
    walletTimes=0
    grabPayTimes=0
    creditCardTimes=0
    totalTimes=0
    walletAmount=0
    grabPayAmount=0
    creditCardAmount=0
    totalsum=0
    topup=0
    lemon=0
    #countUnit = {'outlet_name': '', 'c10': 0, 'c12': 0, 'c14': 0, 'c16': 0, 'c18': 0, 'c20': 0, 'c22': 0}
    if request.method == 'GET':


        outlet_list=models.Outlet.objects.all()
        if outlet_list:
            for outlet in outlet_list:

               data.append({'outlet_name': outlet.outlet_name,'outlet_id': outlet.id, 'c10': 0, 'c12': 0, 'c14': 0, 'c16': 0, 'c18': 0, 'c20': 0, 'c22': 0,'sum':0,'topup':0,'lemon':0})
        #wallet times
        sql="select app01_outlet.outlet_name, count(*)  from app01_transaction join  app01_outlet on app01_transaction.outlet_id=app01_outlet.id  where to_char(app01_transaction.payment_datetime,'yyyy-mm-dd')=to_char(current_date,'yyyy-mm-dd')  and app01_transaction.transaction_status in (4,5) and payment_modes=8 group by app01_outlet.outlet_name,app01_transaction.outlet_id order by app01_outlet.outlet_name ,app01_transaction.outlet_id desc"
        cursor = connection.cursor()
        cursor.execute(sql)
        row = cursor.fetchall()
        if row:
            num = 0

            for i in data:
                for j in row:
                    if ((i['outlet_name'] == j[0])):
                        data[num]["c10"] = j[1]
                        walletTimes =walletTimes+j[1]
                        break
                num += 1
        # grabPayTimes
        sql = "select app01_outlet.outlet_name, count(*)  from app01_transaction join  app01_outlet on app01_transaction.outlet_id=app01_outlet.id  where to_char(app01_transaction.payment_datetime,'yyyy-mm-dd')=to_char(current_date,'yyyy-mm-dd')  and app01_transaction.transaction_status in (4,5) and payment_modes=12  group by app01_outlet.outlet_name,app01_transaction.outlet_id order by app01_outlet.outlet_name ,app01_transaction.outlet_id desc"
        cursor = connection.cursor()
        cursor.execute(sql)
        row = cursor.fetchall()
        print(row)
        if row:
            num = 0
            for i in data:
                for j in row:
                     if ((i['outlet_name'] == j[0])):
                           data[num]["c12"] = j[1]
                           grabPayTimes= grabPayTimes + j[1]
                           break
                num += 1
        # creditCardTimes
        sql = "select app01_outlet.outlet_name, count(*)  from app01_transaction join  app01_outlet on app01_transaction.outlet_id=app01_outlet.id  where to_char(app01_transaction.payment_datetime,'yyyy-mm-dd')=to_char(current_date,'yyyy-mm-dd')  and app01_transaction.transaction_status in (4,5) and payment_modes=9  group by app01_outlet.outlet_name,app01_transaction.outlet_id order by app01_outlet.outlet_name ,app01_transaction.outlet_id desc"
        cursor = connection.cursor()
        cursor.execute(sql)
        row = cursor.fetchall()
        if row:
            num = 0
            for i in data:
                for j in row:
                    if ((i['outlet_name'] == j[0])):
                        data[num]["c14"] = j[1]
                        creditCardTimes = creditCardTimes + j[1]
                        break
                num += 1

        # totalTimes
        sql = "select app01_outlet.outlet_name, count(*)  from app01_transaction join  app01_outlet on app01_transaction.outlet_id=app01_outlet.id  where to_char(app01_transaction.payment_datetime,'yyyy-mm-dd')=to_char(current_date,'yyyy-mm-dd')  and app01_transaction.transaction_status in (4,5)   group by app01_outlet.outlet_name,app01_transaction.outlet_id order by app01_outlet.outlet_name ,app01_transaction.outlet_id desc"
        cursor = connection.cursor()
        cursor.execute(sql)
        row = cursor.fetchall()
        if row:
            num = 0
            for i in data:
                for j in row:
                    if ((i['outlet_name'] == j[0])):
                        data[num]["c16"] = j[1]
                        totalTimes = totalTimes + j[1]
                        break
                num += 1

        # walletAmount
        sql = "select app01_outlet.outlet_name, sum(app01_transaction.total_money)  from app01_transaction join  app01_outlet on app01_transaction.outlet_id=app01_outlet.id  where to_char(app01_transaction.payment_datetime,'yyyy-mm-dd')=to_char(current_date,'yyyy-mm-dd')  and app01_transaction.transaction_status in (4,5) and  payment_modes=8  group by app01_outlet.outlet_name,app01_transaction.outlet_id order by app01_outlet.outlet_name ,app01_transaction.outlet_id desc"
        cursor = connection.cursor()
        cursor.execute(sql)
        row = cursor.fetchall()
        if row:
            num = 0
            for i in data:
                for j in row:
                    if ((i['outlet_name'] == j[0])):
                        data[num]["c18"] = j[1]
                        walletAmount = walletAmount + j[1]
                        break
                num += 1

        # grabPayAmount
        sql = "select app01_outlet.outlet_name, sum(app01_transaction.total_money)  from app01_transaction join  app01_outlet on app01_transaction.outlet_id=app01_outlet.id  where to_char(app01_transaction.payment_datetime,'yyyy-mm-dd')=to_char(current_date,'yyyy-mm-dd')  and app01_transaction.transaction_status in (4,5) and  payment_modes=12  group by app01_outlet.outlet_name,app01_transaction.outlet_id order by app01_outlet.outlet_name ,app01_transaction.outlet_id desc"
        cursor = connection.cursor()
        cursor.execute(sql)
        row = cursor.fetchall()
        if row:
            num = 0
            for i in data:
                for j in row:
                    if ((i['outlet_name'] == j[0])):
                        data[num]["c20"] = j[1]
                        grabPayAmount = grabPayAmount + j[1]
                        break
                num += 1

        # creditCardAmount
        sql = "select app01_outlet.outlet_name, sum(app01_transaction.total_money)  from app01_transaction join  app01_outlet on app01_transaction.outlet_id=app01_outlet.id  where to_char(app01_transaction.payment_datetime,'yyyy-mm-dd')=to_char(current_date,'yyyy-mm-dd')  and app01_transaction.transaction_status in (4,5) and  payment_modes=9  group by app01_outlet.outlet_name,app01_transaction.outlet_id order by app01_outlet.outlet_name ,app01_transaction.outlet_id desc"
        cursor = connection.cursor()
        cursor.execute(sql)
        row = cursor.fetchall()
        if row:
            num = 0
            for i in data:
                for j in row:
                    if ((i['outlet_name'] == j[0])):
                        data[num]["c22"] = j[1]
                        creditCardAmount= creditCardAmount + j[1]
                        break
                num += 1
        # sumAmount
        sql = "select app01_outlet.outlet_name, sum(app01_transaction.total_money)  from app01_transaction join  app01_outlet on app01_transaction.outlet_id=app01_outlet.id  where to_char(app01_transaction.payment_datetime,'yyyy-mm-dd')=to_char(current_date,'yyyy-mm-dd')  and app01_transaction.transaction_status in (4,5)   group by app01_outlet.outlet_name,app01_transaction.outlet_id order by app01_outlet.outlet_name ,app01_transaction.outlet_id desc"
        cursor = connection.cursor()
        cursor.execute(sql)
        row = cursor.fetchall()
        if row:
            num = 0
            for i in data:
                for j in row:
                    if ((i['outlet_name'] == j[0])):
                        data[num]["sum"] = j[1]
                        totalsum = totalsum + j[1]
                        break
                num += 1
        # topup
        sql = "select outlet_name, sum(money)  from app01_topuprecord   where created_date=current_date  group by outlet_name order by outlet_name  desc"
        cursor = connection.cursor()
        cursor.execute(sql)
        row = cursor.fetchall()
        if row:
            num = 0
            for i in data:
                for j in row:
                    if ((i['outlet_name'] == j[0])):
                        data[num]["topup"] = j[1]
                        topup = topup + j[1]
                        break
                num += 1
        # lemon
        #sql = "select app01_transaction.outlet_id, sum(app01_transactdetails.quantity) from app01_transactdetails join app01_transaction on app01_transaction.id=app01_transactdetails.transaction_id where to_char(app01_transaction.payment_datetime,'yyyy-mm-dd')=to_char(current_date,'yyyy-mm-dd')  and app01_transaction.transaction_status in (4,5) and app01_transactdetails.product_id in (select id from app01_product where name like '%Honey Lemon%') group by app01_transaction.outlet_id  "
        sql="select app01_transaction.outlet_id, count(app01_transaction.redeem_invicode) from app01_transaction join app01_invicode on app01_transaction.redeem_invicode=app01_invicode.id where to_char(app01_transaction.payment_datetime,'yyyy-mm-dd')=to_char(current_date,'yyyy-mm-dd')  and app01_transaction.transaction_status in (4,5) and app01_transaction.redeem_invicode is not null and  app01_transaction.redeem_invicode in (select id from app01_invicode where voucher_id=101) group by app01_transaction.outlet_id"
        cursor = connection.cursor()
        cursor.execute(sql)
        row = cursor.fetchall()
        if row:
            num = 0

            for i in data:
                for j in row:
                    if ((i['outlet_id'] == j[0])):
                        data[num]["lemon"] = j[1]
                        lemon = lemon + j[1]
                        break
                num += 1
        #count sum
        num=0
        line=""
        for i in data:
            #data[num]["sum"]=data[num]["c10"]+data[num]["c12"]+data[num]["c14"]+data[num]["c16"]+data[num]["c18"]+data[num]["c20"]+data[num]["c22"]
            #totalsum=totalsum+data[num]["sum"]
            line=line+"<tr><td>"+data[num]["outlet_name"]+"</td><td>"+str(data[num]["c10"])+"</td><td>"+str(data[num]["c12"])+"</td><td>"+str(data[num]["c14"])+"</td><td>"+str(data[num]["c16"])+"</td><td>"+str(data[num]["c18"])+"</td><td>"+str(data[num]["c20"])+"</td><td>"+str(data[num]["c22"])+"</td><td>"+str(data[num]["sum"])+"</td><td>"+str(data[num]["topup"])+"</td><td>"+str(data[num]["lemon"])+"</td></tr>"
            num+=1

        #total:
        line=line+"<tr><td>Total</td><td>"+str(walletTimes)+"</td><td>"+str(grabPayTimes)+"</td><td>"+str(creditCardTimes)+"</td><td>"+str(totalTimes)+"</td><td>"+str(getFloat(walletAmount))+"</td><td>"+str(getFloat(grabPayAmount))+"</td><td>"+str(getFloat(creditCardAmount))+"</td><td>"+str(getFloat(totalsum))+"</td><td>"+str(getFloat(topup))+"</td><td>"+str(lemon)+"</td></tr>"


        #send mail
        countTable = "<table border='1' cellspacing='0' style='text-align:center' ><tr ><td colspan='10'>Outlet Payment Count</td></tr><tr><td>Outlet</td><td>iPay(times)</td><td>GrabPay(times)</td><td>CreditCard(times)</td><td>Total(times)</td><td>iPay(amount)</td><td>GrabPay(amount)</td>CreditCard(amount)</td><td>Sum(amount)</td><td>Topup(amount)</td><td>VDAY voucher(count)</td></tr>"
        table=countTable+line+"</table>"

        #count topup(mobile)
        #wirecard
        sql = "select sum(money) from app01_RechargeRecord where type=0 and status=1 and (request_id is not null and \"grab_txID\" is null) and (money=10 or money=20 or money=50) and to_char(created+interval '8' hour,'yyyy-mm-dd')=to_char(current_date,'yyyy-mm-dd')"
        cursor = connection.cursor()
        cursor.execute(sql)
        row = cursor.fetchall()
        if row:
            if row[0][0] is not None:
                wirecard_topup_money=row[0][0]
            else:
                wirecard_topup_money = 0.0
        else:
            wirecard_topup_money = 0.0

        # grabpay
        sql = "select sum(money) from app01_RechargeRecord where type=0 and status=1 and (request_id is not null and \"grab_txID\" is not null) and (money=10 or money=20 or money=50) and to_char(created+interval '8' hour,'yyyy-mm-dd')=to_char(current_date,'yyyy-mm-dd')"
        cursor = connection.cursor()
        cursor.execute(sql)
        row = cursor.fetchall()
        if row:
            if row[0][0] is not None:
                grabpay_topup_money = row[0][0]
            else:
                grabpay_topup_money = 0.0
        else:
            grabpay_topup_money = 0.0


        # iPay wallet balance
        sql = "select sum(balance) from app01_wallet where member_id not in (95,383,822,27,881,529,2749,102)  "
        cursor = connection.cursor()
        cursor.execute(sql)
        row = cursor.fetchall()
        if row:
            if row[0][0] is not None:
                wallet_balance = row[0][0]
            else:
                wallet_balance = 0.0
        else:
            wallet_balance = 0.0
        # invite code
        sql = "select count(*) from app01_invite_code where activate_status=False "
        cursor = connection.cursor()
        cursor.execute(sql)
        row = cursor.fetchall()
        if row:
            if row[0][0] is not None:
                remain_invite_code = row[0][0]
            else:
                remain_invite_code = 0
        else:
            remain_invite_code = 0
        # $1 for login
        sql = "select count(*) from app01_invicode where status=0 and voucher_id=95 "
        cursor = connection.cursor()
        cursor.execute(sql)
        row = cursor.fetchall()
        if row:
            if row[0][0] is not None:
                remain_1_login = row[0][0]
            else:
                remain_1_login = 0
        else:
            remain_1_login = 0
        # $2 for regiser
        sql = "select count(*) from app01_invicode where status=0 and voucher_id=96 "
        cursor = connection.cursor()
        cursor.execute(sql)
        row = cursor.fetchall()
        if row:
            if row[0][0] is not None:
                remain_2_regiser = row[0][0]
            else:
                remain_2_regiser = 0
        else:
            remain_2_regiser = 0



        topup_mobile_table="<p>Remain Invitation Code: "+str(remain_invite_code)+"</p><p>Remain $1 for login(voucher): "+str(remain_1_login)+"</p><p>Remain $2 for register(voucher): "+str(remain_2_regiser)+"</p><p>WireCard top up: $"+str(wirecard_topup_money)+"</p><p>GrabPay top up: $"+str(grabpay_topup_money)+"</p><p>iPay wallet balance(sum): $"+str(wallet_balance)+"</p></br></br>"
        table=topup_mobile_table+table
        utils.send_register_email(utils.RECEIVE_MAIL, table, send_type="paymentCount", promotion='')


    return Response(data)
def getFloat(f):

    g = '%.2f' % f
    return float(g)

def getDelay_time(transactionObj):
    #last pickup time
    outlet = transactionObj.outlet
    outlet_closetime = outlet.outlet_closetime
    now = datetime.datetime.now()

    now_date = now.date()
    now_date_str = datetime.datetime.strftime(now_date, "%Y-%m-%d")

    closetime_datetime_str = now_date_str + ' ' + outlet_closetime
    closetime_datetime = datetime.datetime.strptime(closetime_datetime_str, "%Y-%m-%d %H:%M")
    last_pickup_time = closetime_datetime - datetime.timedelta(minutes=15)
    #delay time
    delay_time=transactionObj.delay_time
    delay_time_str = datetime.datetime.strftime(delay_time, "%H:%M")
    delay_datetime_str=now_date_str + ' ' +delay_time_str
    delay_time_datetime = datetime.datetime.strptime(delay_datetime_str, "%Y-%m-%d %H:%M")
    delay_time_datetime = delay_time_datetime + datetime.timedelta(hours=8)
    print(delay_time_datetime)
    print(now)
    print(last_pickup_time)
    if delay_time_datetime<now:
        delay_time_datetime=now+datetime.timedelta(minutes=10)
    elif delay_time_datetime>last_pickup_time:
        delay_time_datetime=last_pickup_time
    return delay_time_datetime
@api_view(['GET', 'POST'])
@authentication_classes([])
@permission_classes((AllowAny,))
def clone_order(request, *args, **kwargs):





    if request.method == 'GET':
        id=request.query_params.get('entityBeanId')
        order_no = request.query_params.get('order_no')

        transaction1=models.Transaction.objects.get(id=id)

        if(transaction1):
                list = models.TransactDetails.objects.filter(transaction__id=id)
                transaction1.pk=None
                now = datetime.datetime.now()
                tomorrow_day = now + datetime.timedelta(hours=24)
                transaction1.transact_datetime=now
                transaction1.transaction_status=0
                transaction1.order_no=order_no


                transaction1.save()
                transaction_id=transaction1.pk
                if(list):
                    for item in list:
                        item.transaction=transaction1
                        item.pk=None
                        item.save()
                    return Response({'msg': 'ok'})
                #print(str(transaction_id))
                '''
                with transaction.atomic():


                    transaction1.transaction_status=int(status)
                    transaction1.reject_reason=reject_reason
                    transaction1.save()
                    return Response({'msg': 'ok'})

                '''
    return Response({'msg': 'error'})


