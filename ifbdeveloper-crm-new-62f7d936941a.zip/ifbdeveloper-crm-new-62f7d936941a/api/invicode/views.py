from rest_framework import viewsets
from utils.pagination import DefaultPagination
from app01 import models
from rest_framework.response import Response
from rest_framework import status
from rest_framework.decorators import api_view
from . import serializers,utils,lib
from django_filters.rest_framework import DjangoFilterBackend
from rest_framework.filters import SearchFilter, OrderingFilter
from .permissions import InvicodeViewSetPermission
from django_filters import rest_framework as filters
from django_filters import Filter,FilterSet
from django_filters.fields import Lookup
from django.db import connection
from utils.query_filter import get_page
from django.db.models import Q,Sum,Count
from rest_framework import pagination
import json
import random
import string
import time
import datetime
from django.db.models import Aggregate, CharField, Count
from member.utils import dispatch_invicode


class IntegerListFilter(Filter):
    def filter(self,qs,value):
     if value not in (None,''):
      integers = [int(v) for v in value.split(',')]
      return qs.filter(**{'%s__%s'%(self.field_name, self.lookup_expr):integers})
     return qs
class MyFilter(FilterSet):
    status = IntegerListFilter(field_name='status',lookup_expr='in')
    voucher = IntegerListFilter(field_name='voucher_id', lookup_expr='in')
    member = filters.NumberFilter(field_name="member", lookup_expr='exact')
    #status = filters.NumberFilter(field_name="status", lookup_expr='exact')
    state = filters.NumberFilter(field_name="voucher__state", lookup_expr='exact')
    effective_date = filters.DateFilter(field_name="voucher__effective_date", lookup_expr='lte')
    expiring_date = filters.DateFilter(field_name="voucher__expiring_date", lookup_expr='gte')
    invicode_expire_date=filters.DateFilter(field_name="expire_date", lookup_expr='gte')
    expired_date = filters.DateFilter(field_name="expire_date", lookup_expr='lt')
    by_new_user=filters.CharFilter(field_name="voucher__by_new_user", lookup_expr='exact')
    class Meta:
     model = models.Invicode
     fields = ('status',"voucher","member","status","state","effective_date","expiring_date")

class ListFilter(Filter):
    def filter(self, qs, value):
        if value not in (None,''):
            value_list = value.split(u',')
            return super(ListFilter, self).filter(qs, Lookup(value_list, 'in'))
        else:
            return qs

class InvicodeFilter(filters.FilterSet):

    #修改，django2.0以上版本用field_name代替name 注意：服务器上是name
    #min_effective_date = filters.DateTimeFilter(field_name="effective_date", lookup_expr='gte')
    #max_effective_date = filters.DateTimeFilter(field_name="effective_date", lookup_expr='lte')
    #min_expiring_date = filters.DateTimeFilter(field_name="expiring_date", lookup_expr='gte')
    #max_expiring_date = filters.DateTimeFilter(field_name="expiring_date", lookup_expr='lte')
    status = ListFilter(field_name="status", lookup_expr='iexact')
    voucher = ListFilter(field_name="voucher_id", lookup_expr='iexact')

    class Meta:
        model = models.Invicode
        # fields = ('state', 'type', 'min_effective_date', 'max_effective_date', 'max_expiring_date',
        #           'max_expiring_date', 'status')
        fields = ('status', 'voucher')


class InvicodeViewSet(viewsets.ModelViewSet):
    permission_classes = (InvicodeViewSetPermission,)
    queryset = models.Invicode.objects.all()
    serializer_class = serializers.InvicodeSerializer
    pagination_class = DefaultPagination
    filter_backends = (
        DjangoFilterBackend,
        SearchFilter,
        OrderingFilter,
    )
    #filter_class = InvicodeFilter
    #修改 search_fields  name 为code
    search_fields = ('code',)
    #search_fields = ('code',)

    ordering_fields = ('created',)
    filter_class = MyFilter


    def get_queryset(self):
        self.queryset = self.queryset.prefetch_related(
            #'created',
            #'invicode_number', 'code',
            # 'description', 'status'
            # 'redemption_products',
            # 'size_upgrade_unparticipated_products',
            # 'discount_per_unparticipated_products',
            # 'discount_price_unparticipated_products',
            # 'unparticipated_outlets', 'limit_memberships'
        )
        return super(InvicodeViewSet, self).get_queryset()


class InvicodeMobileViewSet(viewsets.ModelViewSet):
    permission_classes = (InvicodeViewSetPermission,)
    queryset = models.Invicode.objects.all()
    serializer_class = serializers.InvicodeMobileSerializer
    pagination_class = DefaultPagination
    filter_backends = (
        DjangoFilterBackend,
        SearchFilter,
        OrderingFilter,
    )
    # filter_class = InvicodeFilter
    # 修改 search_fields  name 为code
    search_fields = ('code','member')
    # search_fields = ('code',)

    ordering_fields = ('created',)
    filter_class = MyFilter

    def get_queryset(self):


        #ipot voucher campaign
        member_id=self.request.query_params.get('member')
        if member_id:
            member=models.Member.objects.filter(id=member_id).first()
            if member:
                #pass
                if member.last_login_date!=datetime.datetime.now().date():
                    member.last_login_date=datetime.datetime.now().date()
                    member.save()
                #dispatch_invicode(member)


        # ipot voucher campaign
        return super(InvicodeMobileViewSet, self).get_queryset()


class GroupConcat(Aggregate):
    function = 'GROUP_CONCAT'
    template = '%(function)s(%(distinct)s%(expressions)s%(ordering)s%(separator)s)'

    def __init__(self, expression, distinct=False, ordering=None, separator=',', **extra):
        super(GroupConcat, self).__init__(
            expression,
            distinct='DISTINCT ' if distinct else '',
            ordering=' ORDER BY %s' % ordering if ordering is not None else '',
            separator=' SEPARATOR "%s"' % separator,
            output_field=CharField(),
            **extra)

class InvicodeCountViewSet(viewsets.ReadOnlyModelViewSet):
    permission_classes = (InvicodeViewSetPermission,)
    queryset = models.Invicode.objects.all()
    serializer_class = serializers.SalesCountSerializer
    pagination_class = DefaultPagination
    filter_backends = (
        DjangoFilterBackend,
        #SearchFilter,
        #OrderingFilter,
    )
    #filter_class = InvicodeFilter
    #修改 search_fields  name 为code
    #search_fields = ('code',)
    #search_fields = ('code',)

    #ordering_fields = ('created',)
    #filter_class = MyFilter

    def list(self, request, *args, **kwargs):
        sql = """SELECT  app01_voucher.name as voucher,  app01_invicode.voucher_id,  app01_invicode.abbreviation,count(*) as count_sum
	FROM public.app01_invicode inner join app01_voucher on app01_voucher.id=app01_invicode.voucher_id group by   app01_invicode.voucher_id,app01_voucher.name , app01_invicode.abbreviation order by app01_invicode.voucher_id  desc"""

        sqlReg = """SELECT  app01_voucher.name as voucher,  app01_invicode.voucher_id,  app01_invicode.abbreviation,count(*) as count_reg
	FROM public.app01_invicode inner join app01_voucher on app01_voucher.id=app01_invicode.voucher_id   where ( app01_invicode.status=1 or app01_invicode.status=2 ) group by   app01_invicode.voucher_id,app01_voucher.name , app01_invicode.abbreviation order by app01_invicode.voucher_id  desc"""

        sqlRed = """SELECT  app01_voucher.name as voucher,  app01_invicode.voucher_id,  app01_invicode.abbreviation,count(*) as count_red
	FROM public.app01_invicode inner join app01_voucher on app01_voucher.id=app01_invicode.voucher_id   where app01_invicode.status=2 group by   app01_invicode.voucher_id,app01_voucher.name , app01_invicode.abbreviation order by app01_invicode.voucher_id  desc"""
        # filter sql


        # search sql

        # get page
        page_size, page = get_page(request, self.paginator.page_size)
        # limit sql
        limit_sql = ' limit %s offset %s ' % (page_size, (page - 1) * page_size)
        # group by sql

        # all sql
        cursor = connection.cursor()
        cursor.execute(sql)
        row = cursor.fetchall()
        if row:
            count=len(row)
        else:
            count=0


        all_sql = sql +  limit_sql
        all_sql_Reg = sqlReg
        all_sql_Red = sqlRed 
        cursor = connection.cursor()

        cursor.execute(all_sql)
        row = cursor.fetchall()
        queryset1 = []
        if row:
            id = 1
            for item in row:
                obj = {'id': id,'voucher':item[0], 'voucher_id': item[1], 'abbreviation': item[2], 'count_sum': item[3],
                       'count_reg': 0, 'count_red': 0}
                queryset1.append(obj)
                id += 1
        cursor = connection.cursor()
        cursor.execute(all_sql_Reg)
        row = cursor.fetchall()
        if row:
            num = 0
            for i in queryset1:
                for j in row:
                    if ((i["voucher_id"] == j[1]) and (i["abbreviation"] == j[2])):
                        queryset1[num]["count_reg"] = j[3]
                num += 1
        cursor = connection.cursor()
        cursor.execute(all_sql_Red)
        row = cursor.fetchall()
        if row:
            num = 0
            for i in queryset1:
                for j in row:
                    if ((i["voucher_id"] == j[1]) and (i["abbreviation"] == j[2])):
                        queryset1[num]["count_red"] = j[3]
                num += 1

        #all_queryset = list(all_queryset)
        all_queryset=queryset1

        # for i in all_queryset:
        #     print(i.__dict__)
        serializer = self.get_serializer(all_queryset, many=True)
        # Pagination

        from collections import OrderedDict
        return Response(OrderedDict([
            #('count', len(all_queryset)),
            ('count', count),
            #('next', request.scheme+'://'+request.get_host() +request.path+'?page='+str(page)+'&page_size='+str(page_size)),
             #('previous', request.scheme+'://'+request.get_host() +request.get_full_path()),
            ('results', serializer.data)
        ]))















@api_view(['GET', 'POST', ])
def redeemInvicode(request, *args, **kwargs):


    '''
    from_addr = input('wangziyi20192019@gmail.com')
    password = input('ruge0722')
    to_addr = input('ziyiw2019@gmail.com')
    smtp_server = input('smtp.gmail.com')

    msg = MIMEText('hello, send by Python...', 'plain', 'utf-8')
    msg['From'] = _format_addr('Voucher Redeem track <%s>' % from_addr)
    msg['To'] = _format_addr('ITEA <%s>' % to_addr)
    msg['Subject'] = Header('Hi……', 'utf-8').encode()
  
    server = smtplib.SMTP(smtp_server, 25)
    server.set_debuglevel(1)
    server.login(from_addr, password)
    server.sendmail(from_addr, [to_addr], msg.as_string())
    server.quit()
    '''
    if 'code' in request.GET:
        cursor = connection.cursor()
        cursor.execute("select * from app01_invicode where code = '%s'" % (request.GET['code']))
        row = cursor.fetchall()
        if row and (row[0][1] == 0 or row[0][1] == 3 or row[0][1] ==1):

            cursor.execute("select * from app01_invicode where code = '%s'" % (request.GET['code']))
            row_member = cursor.fetchall()
            if row_member:
                invicode_user = row_member[0][7]
                abbreviation=row_member[0][8]
            cursor.execute("select * from app01_voucher where id = '%s'" % (row_member[0][3]))
            row_voucher = cursor.fetchall()
            if  row_voucher:
                voucherName=row_voucher[0][1]
                effective_date = row_voucher[0][5]
                expiring_date = row_voucher[0][6]
            if 'redeem_outlet' in request.GET:
                cursor.execute("update app01_invicode set status = 2,redeem_date=CURRENT_DATE+CURRENT_TIME,redeem_outlet='%s' where code = '%s'" % (request.GET['redeem_outlet'],request.GET['code']))
                promotionCount = getPromotionCount(abbreviation)
                countTable = "<table border='1' cellspacing='0' style='text-align:center' ><tr ><td colspan='7'>" + voucherName + "&nbsp;[" + abbreviation + "]</td></tr><tr><td>Number</td><td>Today Registered</td><td>Today Redeemed</td><td>Registered</td><td>Redeemed</td><td>start_date</td><td>expiring_date</td></tr><tr><td>" + promotionCount['sum_count'] + "</td><td>" + promotionCount[
                                 'reg_today_count'] + "</td><td>" + promotionCount['red_today_count'] + "</td><td>" + \
                             promotionCount['reg_count'] + "</td><td>" + promotionCount[
                                 'red_count'] + "</td><td>"+   effective_date.strftime("%Y-%m-%d") +"</td><td>"+  expiring_date.strftime("%Y-%m-%d")  +"</td></tr></table>"
                content = '<p>voucher:' + voucherName + '<br /> Promotion Code:' + abbreviation + '<br /> QR code:' + request.GET['code'] + '<br /> member:' + invicode_user + '<br /> redeem time:' + str(
                    time.strftime("%Y-%m-%d %H:%M:%S", time.localtime())) + '<br /> outlet:'+request.GET['redeem_outlet']+"</p>" +countTable
                #utils.send_register_email(utils.RECEIVE_MAIL, content, send_type="redeem",promotion=abbreviation)
                print(content)
            else:
                cursor.execute("update app01_invicode set status = 2,redeem_date=CURRENT_DATE+CURRENT_TIME where code = '%s'" % ( request.GET['code']))
                promotionCount = getPromotionCount(abbreviation)
                countTable = "<table border='1' cellspacing='0' style='text-align:center' ><tr ><td colspan='7'>" + voucherName + "&nbsp;[" + abbreviation + "]</td></tr><tr><td>Number</td><td>Today Registered</td><td>Today Redeemed</td><td>Registered</td><td>Redeemed</td><td>start_date</td><td>expiring_date</td></tr><tr><td>" + promotionCount['sum_count'] + "</td><td>" + promotionCount[
                                 'reg_today_count'] + "</td><td>" + promotionCount['red_today_count'] + "</td><td>" + \
                             promotionCount['reg_count'] + "</td><td>" + promotionCount[
                                 'red_count'] + "</td><td>"+   effective_date.strftime("%Y-%m-%d") +"</td><td>"+  expiring_date.strftime("%Y-%m-%d")  +"</td></tr></table>"
                content = '<p>voucher:' + voucherName + '<br /> Promotion Code:' + abbreviation + '<br /> QR code:' + request.GET[
                    'code'] + '<br /> member:' + invicode_user + '<br /> redeem time:' + str(
                    time.strftime("%Y-%m-%d %H:%M:%S", time.localtime())) + '<br /> outlet:</p>'+countTable
                print(content)
                #utils.send_register_email(utils.RECEIVE_MAIL, content, send_type="redeem",promotion=abbreviation)
            cursor.execute("select * from app01_voucher_unparticipated_outlets where voucher_id = '%s'" % (row_member[0][3]))
            row_outlet = cursor.fetchall()
            outlet = []
            #outlet dynamic load
            outlet_list=[]
            for i in row_outlet:
                outlet_list.append(i[2])
            if outlet_list:
                outlet_array=models.Outlet.objects.filter(id__in=outlet_list)
                if outlet_array:
                    for i in outlet_array:
                        outlet.append(i.outlet_name)
                '''
            for i in row_outlet:
                if i[2] == 7:
                    outlet.append('201')
                elif i[2] == 8:
                    outlet.append('828')
                elif i[2] == 9:
                    outlet.append('OTH')
                elif i[2] == 10:
                    outlet.append('EM')
                elif i[2] == 11:
                    outlet.append('BK')
                elif i[2] == 12:
                    outlet.append('Nex')
                elif i[2] == 13:
                    outlet.append('PLS')
                elif i[2] == 14:
                    outlet.append('TP')
                elif i[2] == 15:
                    outlet.append('CL')
                elif i[2] == 16:
                    outlet.append('504')
                elif i[2] == 17:
                    outlet.append('372')
                elif i[2] == 18:
                    outlet.append('YS')
                elif i[2] == 19:
                    outlet.append('888')
                    '''
            return Response({
                'status': 'valid',
                'user': 'root',
                'voucher': row_voucher[0][1],
                'outlet': row_outlet if row_outlet else '',
                'outlet_limit': outlet
            }, status=status.HTTP_201_CREATED)
        else:
            return Response({
                'status': 'invalid',
            }, status=status.HTTP_400_BAD_REQUEST)

@api_view(['GET', 'POST', ])
def checkInvicode(request, *args, **kwargs):
    if 'code' in request.GET:
        cursor = connection.cursor()
        cursor.execute("select * from app01_invicode where code = '%s'" % (request.GET['code']))
        row = cursor.fetchall()
        if row and (row[0][1] == 0 or row[0][1] == 3):




            cursor.execute("select * from app01_invicode where code = '%s'" % (request.GET['code']))
            row_member = cursor.fetchall()
            if row_member:
                invicode_id=row_member[0][0]
            cursor.execute("select * from app01_voucher where id = '%s'" % (row_member[0][3]))
            row_voucher = cursor.fetchall()
            cursor.execute("select * from app01_voucher_unparticipated_outlets where voucher_id = '%s'" % (row_member[0][3]))
            row_outlet = cursor.fetchall()
            outlet = []
            outlet_list = []
            for i in row_outlet:
                outlet_list.append(i[2])
            if outlet_list:
                outlet_array = models.Outlet.objects.filter(id__in=outlet_list)
                if outlet_array:
                    for i in outlet_array:
                        outlet.append(i.outlet_name)
            '''
            for i in row_outlet:
                print(i)
                if i[2] == 7:
                    outlet.append('201')
                elif i[2] == 8:
                    outlet.append('828')
                elif i[2] == 9:
                    outlet.append('OTH')
                elif i[2] == 10:
                    outlet.append('EM')
                elif i[2] == 11:
                    outlet.append('BK')
                elif i[2] == 12:
                    outlet.append('Nex')
                elif i[2] == 13:
                    outlet.append('PLS')
                elif i[2] == 14:
                    outlet.append('TP')
                elif i[2] == 15:
                    outlet.append('CL')
                elif i[2] == 16:
                    outlet.append('504')
                elif i[2] == 17:
                    outlet.append('372')
                elif i[2] == 18:
                    outlet.append('YS')
                elif i[2] == 19:
                    outlet.append('888')
                    '''
            return Response({
                'status': 'valid',
                'user': 'root',
                'voucher': row_voucher[0][1],
                'voucher_id':row_voucher[0][0],
                'outlet': row_outlet if row_outlet else '',
                'outlet_limit':outlet,
                'invicode_id':invicode_id

            }, status=status.HTTP_201_CREATED)
        elif row and row[0][1] == 1:
            voucher_id = row[0][3]
            voucherObj = models.Voucher.objects.get(id=voucher_id)
            if voucherObj:

                effective_date = voucherObj.effective_date
                expiring_date = voucherObj.expiring_date
                print(str(datetime.date.today()),effective_date.strftime("%Y-%m-%d"))
                #print(str(datetime.date.today()) < effective_date.strftime("%Y-%m-%d"))
                #print(str(datetime.date.today()) ,expiring_date.strftime("%Y-%m-%d"))
                #print(str(datetime.date.today()) > expiring_date.strftime("%Y-%m-%d") )
                if (str(datetime.date.today()) < effective_date.strftime("%Y-%m-%d")):
                    return Response({
                        'status': 'invalid',
                        'msg': 'Promtion has not started .'
                    }, status=status.HTTP_200_OK)
                if (str(datetime.date.today()) > expiring_date.strftime("%Y-%m-%d") ):
                    return Response({
                        'status': 'invalid',
                        'msg': 'Promtion Ended .'
                    }, status=status.HTTP_200_OK)


            cursor.execute("select * from app01_invicode where code = '%s'" % (request.GET['code']))
            row_member = cursor.fetchall()
            if row_member:
                invicode_id=row_member[0][0]
            cursor.execute("select * from app01_voucher where id = '%s'" % (row_member[0][3]))
            row_voucher = cursor.fetchall()
            cursor.execute("select * from app01_voucher_unparticipated_outlets where voucher_id = '%s'" % (row_member[0][3]))
            row_outlet = cursor.fetchall()
            outlet = []
            outlet_list = []
            for i in row_outlet:
                outlet_list.append(i[2])
            if outlet_list:
                outlet_array = models.Outlet.objects.filter(id__in=outlet_list)
                if outlet_array:
                    for i in outlet_array:
                        outlet.append(i.outlet_name)
            '''
            for i in row_outlet:
                if i[2] == 7:
                    outlet.append('201')
                elif i[2] == 8:
                    outlet.append('828')
                elif i[2] == 9:
                    outlet.append('OTH')
                elif i[2] == 10:
                    outlet.append('EM')
                elif i[2] == 11:
                    outlet.append('BK')
                elif i[2] == 12:
                    outlet.append('Nex')
                elif i[2] == 13:
                    outlet.append('PLS')
                elif i[2] == 14:
                    outlet.append('TP')
                elif i[2] == 15:
                    outlet.append('CL')
                elif i[2] == 16:
                    outlet.append('504')
                elif i[2] == 17:
                    outlet.append('372')
                elif i[2] == 18:
                    outlet.append('YS')
                elif i[2] == 19:
                    outlet.append('888')
                    '''
            return Response({
                'status': 'valid',
                'user': row_member[0][7],
                'voucher': row_voucher[0][1],
                'voucher_id': row_voucher[0][0],
                'outlet': row_outlet if row_outlet else '',
                'outlet_limit':outlet,
                'invicode_id': invicode_id
            }, status=status.HTTP_201_CREATED)
        else:
            cursor.execute("select * from app01_invicode where code = '%s'" % (request.GET['code']))
            row_member = cursor.fetchall()
            GMT_FORMAT = '%a, %d %b %Y %H:%M:%S GMT'
            datetime.datetime.utcnow().strftime(GMT_FORMAT)
            if row_member:
                print(row_member[0][11])
                redeemDate=str(row_member[0][11])

                if redeemDate not in (None,''):
                    arr=redeemDate.split('+')
                    if arr and isinstance(arr,(tuple,list)):
                         rdDate=arr[0]
                         if rdDate:
                             arr1 = rdDate.split('.')
                             if arr1 and isinstance(arr1, (tuple, list)):
                                 nDate=arr1[0]
                                 dt=datetime.datetime.strptime(nDate, "%Y-%m-%d %H:%M:%S")
                                 rdDate=(dt+datetime.timedelta(hours=8)).strftime("%Y-%m-%d %H:%M:%S")


                else:
                    rdDate=''

                #ttuple = time.strptime(str(rdDate), '%d/%m/%Y %H:%M')
                #timestamp = time.mktime(ttuple)
                #print(timestamp)
                return Response({
                    'status': 'invalid',
                    #'redeem_date':row_member[0][9],
                    #'redeem_date': datetime.datetime.strptime(rdDate,GMT_FORMAT)+datetime.timedelta(hours=8),
                    'redeem_date':rdDate,
                    #strTime = time.strftime("%Y/%m/%d %H:%M:%S", timeStruct)
                    'redeem_outlet':row_member[0][9],
                }, status=status.HTTP_200_OK)
            else:
                return Response({
                    'status': 'invalid',
                }, status=status.HTTP_200_OK)

@api_view(['GET', 'POST', ])
def checkMobileInvicode(request, *args, **kwargs):
    if 'user' in request.GET:
        cursor = connection.cursor()
        cursor.execute("select app01_voucher.id ,app01_voucher.name,app01_voucher.effective_date,app01_voucher.expiring_date,app01_voucher.state,app01_invicode.redeem_date,app01_invicode.status,app01_invicode.code  from app01_voucher INNER JOIN app01_invicode  ON app01_voucher.id = app01_invicode.voucher_id where app01_invicode.invicode_user = '%s' Order by app01_voucher.id" % (request.GET['user']))
        row = cursor.fetchall()
        if row:
            arr = []
            for item in row:
                if not arr:
                    arr.append(item[0])
                else:
                    if item[0] in arr:
                        pass
                    else:
                        arr.append(item[0])
            voucher_arr = []
            voucher_list = ''
            if arr:
                for voucher_id in arr:
                    voucher_list += str(voucher_id) + ','
            voucher_list = voucher_list[:-1];
            if voucher_list:
                #modify add outlet name
                #cursor.execute("select * from app01_voucher_unparticipated_outlets where voucher_id in (%s)" % voucher_list)
                cursor.execute("SELECT app01_voucher_unparticipated_outlets.id, app01_voucher_unparticipated_outlets.voucher_id, app01_voucher_unparticipated_outlets.outlet_id,app01_outlet.outlet_name FROM app01_voucher_unparticipated_outlets inner join app01_outlet on app01_voucher_unparticipated_outlets.outlet_id=app01_outlet.id where app01_voucher_unparticipated_outlets.voucher_id in (%s)" % voucher_list)
                row_outlet = cursor.fetchall()
        return Response({
            'vouchers': row,
            'outlet': row_outlet
        }, status=status.HTTP_200_OK)
    else:
        return Response({'ping': 'PONG'}, status=status.HTTP_200_OK)

@api_view(['GET', 'POST', ])
def registeMobileInvicode(request, *args, **kwargs):
    #time check
    invicode_sended=request.data.get('invicode_send')
    if invicode_sended:
        invicodeObj=models.Invicode.objects.filter(Q(abbreviation =invicode_sended) | Q(code=invicode_sended)).first()
        if (invicodeObj):

            if invicodeObj.description and '10:00' in invicodeObj.description:
                now_time=time.strftime('%H:%M',time.localtime(time.time()))
                #print(now_time)
                if now_time<'10:00':
                    return Response({
                        'msg': 'Campaign will start at '+'10:00am.'
                    }, status=status.HTTP_200_OK)

    if len(request.data.get('invicode_send')) >0:
        #unlimit invicode check start
        cursor = connection.cursor()
        invicode_valid_obj = models.Invicode.objects.filter(Q(abbreviation=invicode_sended) | Q(code=invicode_sended)).first()
        if invicode_valid_obj is None:
            return Response({
                'msg': 'Invalid Promotion Code.'
            }, status=status.HTTP_200_OK)
        invicode_obj=models.Invicode.objects.filter(Q(abbreviation=invicode_sended) | Q(code=invicode_sended)).filter(Q(status=0) | Q(status=3)).first()
        if invicode_obj:
            voucher_obj=invicode_obj.voucher
            if voucher_obj:
                effective_date = voucher_obj.effective_date
                expiring_date = voucher_obj.expiring_date
                if (str(datetime.date.today()) > expiring_date.strftime("%Y-%m-%d")):
                    return Response({
                        'msg': 'Promtion Ended .'
                    }, status=status.HTTP_200_OK)
                unlimit_flag=voucher_obj.unlimit_flag
                if unlimit_flag is not None and unlimit_flag==True:
                    id = models.Member.objects.get(username=request.data.get('username')).id
                    # print(id)
                    now_date=datetime.datetime.now()
                    invicode_expire_date = expiring_date
                    if invicode_obj.vaild_days and invicode_obj.vaild_days>0:
                        v_days=invicode_obj.vaild_days-1
                        now_expire_date=now_date+datetime.timedelta(days=v_days)
                        if now_expire_date.date() >= expiring_date:

                            invicode_expire_date = expiring_date
                        else:
                            invicode_expire_date = now_expire_date

                    else:
                        invicode_expire_date=expiring_date

                    row_effect = cursor.execute(
                        "update app01_invicode set invicode_user = '%s',status = 1,member_id=%d,register_date=CURRENT_DATE+CURRENT_TIME,expire_date='%s' where (abbreviation ='%s' or code ='%s') and id = %d" % (
                            request.data.get('username'), id,datetime.datetime.strftime(invicode_expire_date, "%Y-%m-%d"),
                            request.data.get('invicode_send'),
                            request.data.get('invicode_send'), invicode_obj.id))
                    # voucher_id=row[0][3]

                    promotionCount = getPromotionCount(invicode_sended)
                    countTable = "<table border='1' cellspacing='0' style='text-align:center' ><tr ><td colspan='7'>" + voucher_obj.name + "&nbsp;[" + invicode_sended + "]</td></tr><tr><td>Number</td><td>Today Registered</td><td>Today Redeemed</td><td>Registered</td><td>Redeemed</td><td>start_date</td><td>expiring_date</td></tr><tr><td>" + \
                                 promotionCount['sum_count'] + "</td><td>" + promotionCount[
                                     'reg_today_count'] + "</td><td>" + promotionCount[
                                     'red_today_count'] + "</td><td>" + promotionCount['reg_count'] + "</td><td>" + \
                                 promotionCount['red_count'] + "</td><td>" + effective_date.strftime(
                        "%Y-%m-%d") + "</td><td>" + expiring_date.strftime("%Y-%m-%d") + "</td></tr></table>"
                    content = '<p>Voucher:' + voucher_obj.name + '<br /> Promotion Code:' + invicode_sended + '<br /> QR Code:' + invicode_obj.code + '<br /> member:' + request.data.get(
                        'username') + '<br /> register time:' + str(
                        time.strftime("%Y-%m-%d %H:%M:%S", time.localtime())) + '<br />' + countTable + "</p>"
                    # utils.send_register_email(utils.RECEIVE_MAIL, content, send_type="registered",promotion=promotionCode)
                    # cursor.execute("update app01_invicode set status = 1 where code ='%s'" % (request.data.get('invicode_send')))
                    if (row_effect != 0):
                        #utils.send_register_email(utils.RECEIVE_MAIL, content, send_type="registered",promotion=invicode_sended)
                        #lib.thread_send_mail(content,"registered",invicode_sended)
                        remain_count = 0
                        sum_count = 0
                        invicodeCount = models.Invicode.objects.filter(
                            Q(abbreviation=invicode_sended) | Q(code=invicode_sended)).filter(status=0).count()
                        invicodeSumCount = models.Invicode.objects.filter(
                            Q(abbreviation=invicode_sended) | Q(code=invicode_sended)).count()
                        if invicodeCount:
                            remain_count = invicodeCount
                        if invicodeSumCount:
                            sum_count = invicodeSumCount
                        return Response({
                            'msg': 'Exchanged Successfully;' + str(remain_count) + '/' + str(
                                sum_count) + '(remain/total)'
                        }, status=status.HTTP_200_OK)
                    else:
                        return Response({
                            'msg': 'System busy,please retry!'
                        }, status=status.HTTP_200_OK)

        else:
            invicodeCount = models.Invicode.objects.filter(
                Q(abbreviation=invicode_sended) | Q(code=invicode_sended)).filter(status=0).count()
            invicodeSumCount = models.Invicode.objects.filter(
                Q(abbreviation=invicode_sended) | Q(code=invicode_sended)).count()
            if invicodeCount:
                remain_count = invicodeCount
            else:
                remain_count=0
            if invicodeSumCount:
                sum_count = invicodeSumCount
            return Response({
                'msg': 'Already Exchanged;' + str(remain_count) + '/' + str(sum_count) + '(remain/total)'
            }, status=status.HTTP_200_OK)
        # unlimit invicode check end
        #print('kkkkkkkkk')
        cursor.execute("select * from app01_invicode where (code = '%s'   or  abbreviation = '%s') and status in(0,3)" % ( request.data.get('invicode_send'),  request.data.get('invicode_send')))
        row = cursor.fetchall()
        if row:
            cursor.execute("select * from app01_invicode where (code = '%s'  or  abbreviation = '%s') and invicode_user ='%s'" % (request.data.get('invicode_send'), request.data.get('invicode_send'),request.data.get('username')))
            row_user = cursor.fetchall()

            if  row_user:
                invicodeCount = models.Invicode.objects.filter(
                    Q(abbreviation=invicode_sended) | Q(code=invicode_sended)).filter(status=0).count()
                invicodeSumCount = models.Invicode.objects.filter(
                    Q(abbreviation=invicode_sended) | Q(code=invicode_sended)).count()
                if invicodeCount:
                    remain_count = invicodeCount
                if invicodeSumCount:
                    sum_count = invicodeSumCount
                return Response({
                    'msg': 'Already Exchanged;'+str(remain_count)+'/'+str(sum_count)+'(remain/total)'
                }, status=status.HTTP_200_OK)
            else:
                if row[0][1] == 0 or row[0][1] == 3:
                    #add voucher expiring date check
                    voucher_id = row[0][3]
                    code = row[0][6]
                    promotionCode = row[0][8]
                    voucherObj = models.Voucher.objects.get(id=voucher_id)
                    if voucherObj:
                        voucher = voucherObj.name
                        effective_date = voucherObj.effective_date
                        expiring_date = voucherObj.expiring_date
                        if(str(datetime.date.today())>expiring_date.strftime("%Y-%m-%d")):
                            return Response({
                                'msg': 'Promtion Ended .'
                            }, status=status.HTTP_200_OK)
                        now_date = datetime.datetime.now()
                        invicode_expire_date = expiring_date
                        if invicode_obj.vaild_days and invicode_obj.vaild_days > 0:
                            v_days = invicode_obj.vaild_days - 1
                            now_expire_date = now_date + datetime.timedelta(days=v_days)
                            if now_expire_date.date() >= expiring_date:

                                invicode_expire_date = expiring_date
                            else:
                                invicode_expire_date = now_expire_date

                        else:
                            invicode_expire_date = expiring_date


                    id=models.Member.objects.get(username=request.data.get('username')).id
                    #print(id)
                    row_effect = cursor.execute(
                        "update app01_invicode set invicode_user = '%s',status = 1,member_id=%d,register_date=CURRENT_DATE+CURRENT_TIME,expire_date='%s' where (abbreviation ='%s' or code ='%s') and id = %d" % (
                            request.data.get('username'),id,datetime.datetime.strftime(invicode_expire_date, "%Y-%m-%d"), request.data.get('invicode_send'),request.data.get('invicode_send'), row[0][0]))
                    #voucher_id=row[0][3]

                    promotionCount=getPromotionCount(promotionCode)
                    #countTable="<table border='1' cellspacing='0' style='text-align:center' ><tr ><td colspan='7'>"+voucher+"&nbsp;["+promotionCode+"]</td></tr><tr><td>Number</td><td>Today Registered</td><td>Today Redeemed</td><td>Registered</td><td>Redeemed</td><td>start_date</td><td>expiring_date</td></tr><tr><td>"+promotionCount['sum_count']+"</td><td>"+promotionCount['reg_today_count']+"</td><td>"+promotionCount['red_today_count']+"</td><td>"+promotionCount['reg_count']+"</td><td>"+promotionCount['red_count']+"</td><td>"+   effective_date.strftime("%Y-%m-%d") +"</td><td>"+  expiring_date.strftime("%Y-%m-%d")  +"</td></tr></table>"
                    #content =  '<p>Voucher:' +voucher+'<br /> Promotion Code:' + promotionCode +'<br /> QR Code:' +code  + '<br /> member:' + request.data.get('username') + '<br /> register time:' + str(time.strftime("%Y-%m-%d %H:%M:%S", time.localtime()))+'<br />'+countTable+"</p>"
                    #utils.send_register_email(utils.RECEIVE_MAIL, content, send_type="registered",promotion=promotionCode)
                    # cursor.execute("update app01_invicode set status = 1 where code ='%s'" % (request.data.get('invicode_send')))
                    if (row_effect != 0):
                        #utils.send_register_email(utils.RECEIVE_MAIL, content, send_type="registered",promotion=promotionCode)
                        #lib.thread_send_mail(content, "registered", invicode_sended)
                        remain_count=0
                        sum_count=0
                        invicodeCount = models.Invicode.objects.filter(Q(abbreviation=invicode_sended) | Q(code=invicode_sended)).filter(status=0).count()
                        invicodeSumCount = models.Invicode.objects.filter(
                            Q(abbreviation=invicode_sended) | Q(code=invicode_sended)).count()
                        if invicodeCount:
                            remain_count=invicodeCount
                        if invicodeSumCount:
                            sum_count=invicodeSumCount
                        return Response({
                            'msg': 'Exchanged Successfully;'+str(remain_count)+'/'+str(sum_count)+'(remain/total)'
                        }, status=status.HTTP_200_OK)
                    else:
                        return Response({
                            'msg': 'System busy,please retry!'
                        }, status=status.HTTP_200_OK)
        else:
            cursor.execute("select * from app01_invicode where abbreviation = '%s' and invicode_user <>'%s'"% (request.data.get('invicode_send'),request.data.get('username')))
            row = cursor.fetchall()
            if row:
                return Response({
                    'msg': 'Promotion Ended /Fully Exchange.'
                }, status=status.HTTP_200_OK)
            else:# The Promation code Alray Redeemed
                return Response({
                    'msg': 'Invalid Promotion Code.'
                }, status=status.HTTP_200_OK)
    #elif len(request.data.get('invicode_send')) <= 10:
            '''
    #else:
        #cursor = connection.cursor()
        #cursor.execute("select * from app01_invicode where abbreviation = '%s' and status = 0" % request.data.get('invicode_send'))
        #row = cursor.fetchone()
        #if row:
                cursor.execute("update app01_invicode set invicode_user = '%s' where code ='%s'" % (request.data.get('username'), row[6]))
                cursor.execute("update app01_invicode set status = 1 where code ='%s'" % (row[6]))
                return Response({
                    'status': 'success'
                }, status=status.HTTP_200_OK)
        else:           
            return Response({
                'status': 'there are no avalible code.'
            }, status=status.HTTP_200_OK)       
'''


@api_view(['POST'])
def setInvicodeSend(request, *args, **kwargs):
    cursor = connection.cursor()
    cursor.execute("select * from app01_invicode where code = '%s'" % request.data.get('code'))
    row = cursor.fetchall()
    if row[0][1] == 0:
        cursor.execute("update app01_invicode set status = 3 where code ='%s'" % (request.data.get('code')))
        return Response({
            'status': 'success'
        }, status=status.HTTP_200_OK)
    else:
        return Response({
            'status': 'false invicode has been used'
        }, status=status.HTTP_200_OK)
#get chart data
@api_view(['GET'])
def getChartData(request, *args, **kwargs):
    voucher=request.GET['voucher']
    abbreviation = request.GET['abbreviation']
    cursor = connection.cursor()
    cursor.execute("select id,to_char(effective_date,'yyyy-mm-dd'),to_char(expiring_date,'yyyy-mm-dd') from app01_voucher where name = '%s'" % voucher)
    row = cursor.fetchall()
    reg_obj = []
    red_obj = []
    if row:
        voucher_id=row[0][0]
        effective_date=row[0][1]
        expiring_date=row[0][2]

        #register data
        reg_sql="SELECT to_char(register_date,'yyyy-mm-dd'),count(*) 	FROM  app01_invicode where voucher_id=%s and  abbreviation='%s' and ( status=1 or status=2 )  group by to_char(register_date,'yyyy-mm-dd') order by to_char(register_date,'yyyy-mm-dd') asc" %(voucher_id,abbreviation)
        cursor = connection.cursor()
        cursor.execute(reg_sql)
        reg_row=cursor.fetchall()

        if reg_row:

              if reg_row[0][0]<effective_date:
                  reg_start_date =reg_row[0][0]
                  interval_days= (datetime.datetime.strptime(expiring_date, '%Y-%m-%d')-datetime.datetime.strptime(reg_start_date, '%Y-%m-%d')).days+1
                  for i in range(interval_days):
                      obj={'date':reg_start_date,'reg_num':0}
                      reg_start_date=(datetime.datetime.strptime(reg_start_date, '%Y-%m-%d')+datetime.timedelta(days=1)).strftime("%Y-%m-%d")
                      reg_obj.append(obj)
                  #add  count data
                  num = 0
                  for i in reg_obj:
                      for j in reg_row:
                          if ((i['date'] == j[0])):
                              reg_obj[num]["reg_num"] = j[1]
                      num += 1

              else:
                  reg_start_date=effective_date
                  interval_days = (datetime.datetime.strptime(expiring_date, '%Y-%m-%d') - datetime.datetime.strptime(reg_start_date,'%Y-%m-%d')).days+1
                  for i in range(interval_days):
                      obj = {'date': reg_start_date, 'reg_num': 0}
                      reg_start_date = (datetime.datetime.strptime(reg_start_date, '%Y-%m-%d') + datetime.timedelta(days=1)).strftime("%Y-%m-%d")
                      reg_obj.append(obj)
                  # add  count data
                  num = 0
                  for i in reg_obj:
                      for j in reg_row:
                          if ((i['date'] == j[0])):
                              reg_obj[num]["reg_num"] = j[1]
                      num += 1


        else:
            reg_start_date = effective_date
            interval_days = (datetime.datetime.strptime(expiring_date, '%Y-%m-%d') - datetime.datetime.strptime(reg_start_date,
                                                                                              '%Y-%m-%d')).days+1
            for i in range(interval_days):
                obj = {'date': reg_start_date, 'reg_num': 0}
                reg_start_date = (datetime.datetime.strptime(reg_start_date, '%Y-%m-%d') + datetime.timedelta(days=1)).strftime("%Y-%m-%d")
                reg_obj.append(obj)





        #redeem data
        red_sql = "SELECT to_char(redeem_date,'yyyy-mm-dd'),count(*) 	FROM  app01_invicode where voucher_id=%s and  abbreviation='%s' and status=2  group by to_char(redeem_date,'yyyy-mm-dd') order by to_char(redeem_date,'yyyy-mm-dd') asc" % ( voucher_id, abbreviation)
        cursor = connection.cursor()
        cursor.execute(red_sql)
        red_row = cursor.fetchall()

        if red_row:

            if red_row[0][0] < effective_date:
                red_start_date = red_row[0][0]
                interval_days = (datetime.datetime.strptime(expiring_date, '%Y-%m-%d') - datetime.datetime.strptime(red_start_date,'%Y-%m-%d')).days+1
                for i in range(interval_days):
                    obj = {'date': red_start_date, 'red_num': 0}
                    red_start_date = (
                            datetime.datetime.strptime(red_start_date, '%Y-%m-%d') + datetime.timedelta(days=1)).strftime("%Y-%m-%d")
                    red_obj.append(obj)
                # add  count data
                num = 0
                for i in red_obj:
                    for j in red_row:
                        if ((i['date'] == j[0])):
                            red_obj[num]["red_num"] = j[1]
                    num += 1

            else:
                red_start_date = effective_date
                interval_days = (datetime.datetime.strptime(expiring_date, '%Y-%m-%d') - datetime.datetime.strptime(red_start_date,'%Y-%m-%d')).days+1
                for i in range(interval_days):
                    obj = {'date': red_start_date, 'red_num': 0}
                    red_start_date = (datetime.datetime.strptime(red_start_date, '%Y-%m-%d') + datetime.timedelta(days=1)).strftime("%Y-%m-%d")
                    red_obj.append(obj)
                # add  count data
                num = 0
                for i in red_obj:
                    for j in red_row:
                        if ((i['date'] == j[0])):
                            red_obj[num]["red_num"] = j[1]
                    num += 1


        else:
            red_start_date = effective_date
            interval_days = (datetime.datetime.strptime(expiring_date, '%Y-%m-%d') - datetime.datetime.strptime(red_start_date,'%Y-%m-%d')).days+1
            for i in range(interval_days):
                obj = {'date': red_start_date, 'red_num': 0}
                red_start_date = (datetime.datetime.strptime(red_start_date, '%Y-%m-%d') + datetime.timedelta(days=1)).strftime("%Y-%m-%d")
                red_obj.append(obj)
    return Response({
            'reg_obj': reg_obj,
            'red_obj': red_obj,
        }, status=status.HTTP_200_OK)

def getPromotionCount(promotion=''):
    code=promotion
    reg_count=0
    red_count=0
    reg_today_count=0
    red_today_count=0
    if code:
        sum_count=models.Invicode.objects.filter(abbreviation=code).count()
        print(sum_count)
        reg_count_only=models.Invicode.objects.filter(abbreviation=code,status=1).count()
        print(reg_count_only)
        red_count = models.Invicode.objects.filter(abbreviation=code, status=2).count()
        print(red_count)
        reg_count=reg_count_only+red_count
        print(reg_count)
        reg_sql="select count(*) from app01_invicode where app01_invicode.abbreviation='%s' and ( status=1 or status=2) and to_char(register_date,'yyyy-mm-dd')=to_char(current_date,'yyyy-mm-dd')" % code
        red_sql="select count(*) from app01_invicode where app01_invicode.abbreviation='%s' and  status=2 and to_char(redeem_date,'yyyy-mm-dd')=to_char(current_date,'yyyy-mm-dd')" % code
        cursor = connection.cursor()
        cursor.execute(reg_sql)
        reg_today_count = cursor.fetchall()[0][0]
        print(reg_today_count)
        cursor.execute(red_sql)
        red_today_count = cursor.fetchall()[0][0]
        print(red_today_count)
        return {'sum_count':str(sum_count),'reg_count':str(reg_count),'red_count':str(red_count),'reg_today_count':str(reg_today_count),'red_today_count':str(red_today_count)}
    else:
        return {}

@api_view(['GET'])
def bindVoucher(request, *args, **kwargs):
    mobile_no = request.GET['mobile_no']
    voucher_id = request.GET['voucher_id']
    if mobile_no:
        member=models.Member.objects.filter(mobile_no=mobile_no).first()
        if member:
            invicode=models.Invicode.objects.filter(voucher__id=voucher_id,status=0).first()
            if invicode:
                invicode.member_id=member.id
                invicode.invicode_user=mobile_no
                invicode.expire_date=datetime.datetime.now().date()+datetime.timedelta(days=invicode.vaild_days)
                invicode.status=1
                invicode.save()
                return Response({'msg': 'ok',}, status=status.HTTP_200_OK)
    return Response({'msg': 'error', }, status=status.HTTP_200_OK)
@api_view(['GET'])
def getRewardVoucher(request, *args, **kwargs):
    invicode_id = request.GET['invicode_id']
    member_id = request.GET['member_id']
    if invicode_id:
        invicode_list=invicode_id.split(',')
        invicode_touple=[]
        for i in invicode_list:
            invicode_touple.append(int(i))

        invicode_list = models.Invicode.objects.filter(id__in=tuple(invicode_touple))
        if invicode_list:
            for invicode in invicode_list:
                if invicode:
                        now_date = datetime.datetime.now()
                        invicode.member_id=member_id

                        invicode.status=1
                        invicode.register_date=now_date

                        voucher=invicode.voucher
                        expiring_date=voucher.expiring_date
                        if invicode.vaild_days and invicode.vaild_days > 0:
                            v_days = invicode.vaild_days - 1
                            now_expire_date = now_date + datetime.timedelta(days=v_days)
                            if now_expire_date.date() >= expiring_date:

                                invicode_expire_date = expiring_date
                            else:
                                invicode_expire_date = now_expire_date

                        else:
                            invicode_expire_date = expiring_date
                        invicode.expire_date= invicode_expire_date
                        invicode.save()
            return Response({'msg': 'ok',}, status=status.HTTP_200_OK)
    return Response({'msg': 'error', }, status=status.HTTP_200_OK)

@api_view(['GET'])
def getInvicode(request, *args, **kwargs):
    quantity = request.GET['quantity']
    voucher_id = request.GET['voucher_id']
    list = models.Invicode.objects.filter(voucher__id=voucher_id, status=0)[:int(quantity)]
    print_code = ''
    if list:
        for item in list:
            models.Invicode.objects.filter(id=item.id, status=0).update(status=3)
            print_code = print_code + item.code + ','

    return Response({'code': print_code})




