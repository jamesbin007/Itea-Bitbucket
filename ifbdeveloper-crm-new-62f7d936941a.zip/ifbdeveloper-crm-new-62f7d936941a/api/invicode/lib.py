import threading
from . import utils
class MailThread(threading.Thread):
    mail=''
    send_type=''
    promotion=''

    def run(self):
        utils.send_register_email(utils.RECEIVE_MAIL, self.mail, send_type=self.send_type, promotion=self.promotion)

def thread_send_mail(mail,send_type,promotion):
    mailThread = MailThread()
    mailThread.mail = mail
    mailThread.send_type = send_type
    mailThread.promotion=promotion
    mailThread.start()