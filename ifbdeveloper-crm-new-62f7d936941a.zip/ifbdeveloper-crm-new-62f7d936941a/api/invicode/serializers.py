from rest_framework import serializers
from app01 import models
from outlet.serializers import OutletSerializer
import string
import random
from rest_framework.response import Response
from rest_framework import status
from rest_framework.renderers import JSONRenderer


def generate_random_str(randomlength=16):
    str_list = [random.choice(string.digits + string.ascii_uppercase) for i in range(randomlength)]
    random_str = ''.join(str_list)
    return random_str

class InvicodeMobileSerializer(serializers.ModelSerializer):
    voucher_obj=serializers.SerializerMethodField()

    unparticipated_outlets= serializers.SerializerMethodField()
    unparticipated_products = serializers.SerializerMethodField()
    #redemption_products = serializers.SerializerMethodField()
    #redemption_products_category = serializers.SerializerMethodField()
    class Meta:
        model = models.Invicode
        fields = '__all__'

    def get_voucher_obj(self, obj):
        ret = models.Voucher.objects.get(id=obj.voucher.id)
        if (ret is not None):
            return {"remark":ret.remark,"description":ret.description,"number_purchase":ret.number_purchase,"number_complimentary_drinks":ret.number_complimentary_drinks,"number_discount_drinks":ret.number_discount_drinks,"voucher_name":ret.name,"effective_date":ret.effective_date,"expiring_date":ret.expiring_date,"state":ret.state,"type":ret.type,"discount_percent":ret.discount_percent,"discount_price":ret.discount_price,"product_size":ret.product_size,"product_number":ret.product_number,"full_money":ret.full_money,'merchant':ret.merchant}
        else:
            return {}





    def get_unparticipated_outlets(self, obj):
        outlet_list=obj.voucher.unparticipated_outlets.all()

        outlet_id_list=[]
        if(outlet_list):
            for outlet in outlet_list:
                outlet_id_list.append(outlet.id)

        ret = models.Outlet.objects.filter(id__in=outlet_id_list)
        if (ret is not None):
            return [OutletSerializer(i).data for i in ret]
        else:
            return []
    def get_unparticipated_products(self, obj):
        product_list=obj.voucher.unparticipated_products.all()

        product_id_list=[]
        if(product_list):
            for product in product_list:
                product_id_list.append(product.id)
        return product_id_list
        '''
        ret = models.Outlet.objects.filter(id__in=outlet_id_list)
        if (ret is not None):
            return [OutletSerializer(i).data for i in ret]
        else:
            return []
        '''

    def get_redemption_products(self, obj):
        product_list=obj.voucher.redemption_products.all()

        product_id_list=[]
        if(product_list):
            for product in product_list:
                product_id_list.append(product.id)
        return  product_id_list
    def get_redemption_products_category(self, obj):
        category_list=obj.voucher.redemption_products_category.all()

        category_id_list=[]
        if(category_list):
            for category in category_list:
                category_id_list.append(category.id)
        return  category_id_list
class InvicodeSerializer(serializers.ModelSerializer):
    class Meta:
        model = models.Invicode
        fields = '__all__'

    def create(self, validated_data):
        validated_data['invicode_number'] = int(self.validated_data.get('invicode_number'))
        #validated_data['voucher'] = int(self.validated_data.get('voucher'))
        #voucher = models.Voucher.objects.get(id=int())
        validated_data['voucher'] = self.validated_data.get('voucher')


        for i in range(0, validated_data['invicode_number']):
            validated_data['code'] = generate_random_str()
            instance = super(InvicodeSerializer, self).create(validated_data)
            instance.save()
        return instance
class SalesCountSerializer(serializers.ModelSerializer):
    id = serializers.IntegerField(required=False, allow_null=True)
    count_sum = serializers.IntegerField(required=False, allow_null=True)
    voucher = serializers.CharField(required=False, allow_null=True)
    count_reg = serializers.IntegerField(required=False, allow_null=True)
    count_red = serializers.IntegerField(required=False, allow_null=True)

    class Meta:
        model = models.Invicode
        #fields = ("voucher_id","abbreviation")
        fields = "__all__"