from django.urls import path, include, re_path
from rest_framework.routers import DefaultRouter
from . import views
from django.conf.urls import url






invicode_router = DefaultRouter()
invicode_router.register('', views.InvicodeViewSet)
#invicode_router.register('count', views.InvicodeCountViewSet)
urlpatterns = [
    path('get_invicode/', views.InvicodeMobileViewSet.as_view({'get': 'list'}), name="get_invicode"),
    path('getRewardVoucher/', views.getRewardVoucher, name="getRewardVoucher"),
    path('check/', views.checkInvicode, name="check"),
    path('redeem/', views.redeemInvicode, name="redeem"),
    path('set/', views.setInvicodeSend, name="set"),
    path('count/', views.InvicodeCountViewSet.as_view({'get': 'list'}), name="count"),
    path('mobile/', views.checkMobileInvicode, name="mobile"),
    path('chart/', views.getChartData, name="chart"),
    path('mobile/register/', views.registeMobileInvicode, name="reginvicode"),
    path('bindVoucher/', views.bindVoucher, name="bindVoucher"),
    path('getInvicode/', views.getInvicode, name="getInvicode"),
    path('', include(invicode_router.urls))
]
