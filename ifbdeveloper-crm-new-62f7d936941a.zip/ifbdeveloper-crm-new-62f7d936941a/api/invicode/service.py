from app01 import models
from utils.utils import transaction_wrapper
from .serializers import generate_random_str
import datetime
from utils.message_manage import send_message_to_token
@transaction_wrapper
def record_reward_member_invicode(member, reward_voucher,default=''):
    """ Record the invicode obtained by this member"""
    objs = []
    if reward_voucher:
        voucher=None
        for i in reward_voucher:
            #status 4 waiting for get
            voucher=i
            obj = models.Invicode(**{'voucher': i, 'code': generate_random_str(), 'status': 4,'member':member,'register_date':datetime.datetime.now(),'vaild_days':30, 'expire_date': datetime.datetime.now().date()+datetime.timedelta(days=30)})
            objs.append(obj)
        models.Invicode.objects.bulk_create(objs)
        if default=='birthday':
            if voucher:
                if member.device_token:
                    send_message_to_token(member.device_token, 'Happy birthday',"Voucher for happy birthday waiting you to pick up in iTEA apps" )



@transaction_wrapper
def record_redeemed_member_invicode(voucher, redeemed_invicodes):
    """ Record the invicode redeemed by this member"""
    for invicode in redeemed_invicodes:
        obj = models.Invicode.objects.filter(voucher=voucher, invicode=invicode, status=0).order_by('created').first()
        if obj:
            obj.status = 2
            obj.save()
