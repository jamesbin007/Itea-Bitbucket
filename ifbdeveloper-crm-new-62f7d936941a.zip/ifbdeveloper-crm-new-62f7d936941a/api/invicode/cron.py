from app01 import models
from datetime import datetime

from django.db.models import Count
from django.db import transaction
from . import views
from enum import Enum,unique
from transaction.service import get_payment_mail_table
from django.db import connection
from transaction.utils import thread_send_mail
import time
from django.db.models import Q,Sum,Count
def invicodeDayReport():
    Month=Enum('Month',('Jan','Feb','Mar','Apr','May','Jun'))

@unique
class EnumDemo(Enum):
    Sun=0
    Mon=1
    Tue=2

class MyDictMetaclass(type):
    def __new__(cls,name,bases,attrs):
        attrs['get']=lambda self,key:self.get(key)
        return type.__new__(cls,name,bases,attrs)



class MyDice(dict,metaclass=MyDictMetaclass):
    pass
def send_payment():
    list=models.Transaction.objects.filter(transaction_status=2,send_mail_flag=0)
    if list:
        for transactionObj in list:

            wallet_id = 0
            member = None
            pay_mode = 'Wallet'
            if transactionObj:
                transactionObj.send_mail_flag=1
                transactionObj.save()

                member = transactionObj.member
                if transactionObj.payment_modes == 8:
                    pay_mode = 'Wallet'
                elif transactionObj.payment_modes == 9:
                    pay_mode = 'Wirecard'
                elif transactionObj.payment_modes == 12:
                    pay_mode = 'Grabpay'
            if member:
                wallet = models.Wallet.objects.filter(member__id=member.id).first()
                if wallet:
                    wallet_id = wallet.id

            countTable = get_payment_mail_table(transactionObj, member, wallet_id, pay_mode)

            thread_send_mail(countTable, "payment")
            time.sleep(0.5)


def countPrize():
    #prize_class_set_count=models.PrizeClassSet.objects.filter(id__gte=0).count()
    prize_class_set_count = models.PrizeClassSet.objects.filter(id__gt=4).count()

    if prize_class_set_count:
        #prize probability
        table = "<table border='1' cellspacing='0' style='text-align:center' ><tr><td colspan='"+str(prize_class_set_count+1)+"'  style='text-align:center' >Prize Probability</td></tr>"



        #prize_class_set_list=models.PrizeClassSet.objects.all().order_by('id')
        prize_class_set_list = models.PrizeClassSet.objects.filter(id__gt=4).order_by('id')

        if prize_class_set_list:
            prize_class_name_line=""
            prize_class_probability_line=""
            sum_prize_probability=0
            for item in prize_class_set_list:
                prize_class_name_line = prize_class_name_line+ "<td>" + item.prize_name + "</td>"
                prize_class_probability_line=prize_class_probability_line+"<td>" +str(('{:.1f}%'.format(item.probability*100) ))+ "</td>"
                sum_prize_probability=sum_prize_probability+item.probability

            prize_class_name_line = "<tr>" + prize_class_name_line + "<td>total probability</td></tr>"
            prize_class_probability_line = "<tr>" +  prize_class_probability_line +"<td>"+str(('{:.1f}%'.format(sum_prize_probability*100) )) + "</td></tr>"
            table=table+prize_class_name_line+prize_class_probability_line+"</table>"

        #count prize times
        count_table = "<table border='1' cellspacing='0' style='text-align:center' ><tr><td colspan='" + str(
            (prize_class_set_count+2)*2 + 1) + "'  style='text-align:center' >Prize Count</td></tr>"
        member_login_count_dict = models.Member.objects.filter(last_login_date=datetime.now().date()).aggregate(
            count=Count('id'))

        if member_login_count_dict:
            member_login_count = member_login_count_dict['count']
        else:
            member_login_count = 0
        count_table=count_table+"<tr><td colspan='" + str(
            (prize_class_set_count+2)*2 + 1) + "'  style='text-align:left' >Today login apps persons:"+str(member_login_count)+"</td></tr>"

        today_lucky_draw_times=0
        all_lucky_draw_times = 0
        today_prize_times=0
        all_prize_times=0
        # today lucky draw times
        today_lucky_draw_times_aggre_count=models.PrizeMemberLog.objects.filter(prize_date=datetime.now().date()).aggregate(today_times_count=Sum('used_prize_times'))
        if today_lucky_draw_times_aggre_count:
            today_lucky_draw_times=today_lucky_draw_times_aggre_count['today_times_count']

        # all lucky draw times

        all_lucky_draw_times_aggre_count = models.PrizeMemberLog.objects.filter(id__gte=1).aggregate(all_times_count=Sum('all_used_prize_times'))
        if all_lucky_draw_times_aggre_count:
            all_lucky_draw_times = all_lucky_draw_times_aggre_count['all_times_count']
        # today prize times
        today_prize_times_aggre_count = models.PrizeLog.objects.filter(
            created__date=datetime.now().date()).aggregate(today_prize_times_count=Count('id'))
        if today_prize_times_aggre_count:
            today_prize_times = today_prize_times_aggre_count['today_prize_times_count']

        # all prize times **

        all_prize_times_aggre_count = models.PrizeLog.objects.filter(id__gte=1).aggregate(
            all_prize_times_count=Count('id'))
        if all_prize_times_aggre_count:
            all_prize_times = all_prize_times_aggre_count['all_prize_times_count']

        #today thank you
        today_thank_times=today_lucky_draw_times-today_prize_times
        all_thank_times=all_lucky_draw_times-all_prize_times

        today_thank_times_precent='0.0%'
        if today_lucky_draw_times>0:
            today_thank_times_precent ='{:.1f}%'.format((today_thank_times/today_lucky_draw_times)*100)
        all_thank_times_precent = '0.0%'
        if all_lucky_draw_times > 0:
            all_thank_times_precent = '{:.1f}%'.format((all_thank_times / all_lucky_draw_times)*100)


        #class set prize_count
        today_class_prize_dict={}
        today_class_prize_dict['today_thank_times']=today_thank_times
        today_class_prize_dict['today_thank_times_precent'] = today_thank_times_precent
        all_class_prize_dict = {}
        all_class_prize_dict['all_thank_times'] = all_thank_times
        all_class_prize_dict['all_thank_times_precent'] = all_thank_times_precent
        redeem_dict={}
        redeem_dict['thank_times'] = ''
        redeem_dict['thank_times_precent'] = ''
        total_redeems=0
        #prize_class_set_list = models.PrizeClassSet.objects.all().order_by('id')
        prize_class_set_list = models.PrizeClassSet.objects.filter(id__gt=4).order_by('id')
        if prize_class_set_list:
            count_table_line_1 = '<tr><td rowspan=2 >Prize&Redeem</td>'
            count_table_line_2 = '<tr>'
            for item in prize_class_set_list:
                prize_list=item.prize.all()
                today_prize_class_times=0
                all_prize_class_times = 0
                all_redeem_times=0
                all_prize_vouchers=0
                prize_class_name=item.prize_name
                count_table_line_1=count_table_line_1+'<td colspan=2 >'+item.prize_title+'</td>'
                count_table_line_2=count_table_line_2+'<td >times</td><td>percent</td>'
                if prize_list:
                    prize_id_list=[]
                    voucher_id_list=[]
                    for prize in prize_list:
                        prize_id_list.append(prize.id)
                        if prize.voucher:
                            voucher_id_list.append(prize.voucher.id)
                    prize_id_tuple=tuple(prize_id_list)
                    voucher_id_tuple=tuple(voucher_id_list)
                    if prize_id_tuple:
                        sql = 'select count(*) from app01_PrizeLog   where to_char(created+interval \'8\' hour,\'yyyy-mm-dd\')=\''+time.strftime("%Y-%m-%d", time.localtime())+'\' and prize_id in ('+','.join([str(i) for i in prize_id_list])+')'
                        cursor = connection.cursor()
                        cursor.execute(sql)
                        row = cursor.fetchall()
                        if row:
                            if row[0][0] is not None:
                                today_prize_class_times = row[0][0]
                            else:
                                today_prize_class_times = 0
                        else:
                            today_prize_class_times = 0

                        sql = 'select count(*) from app01_PrizeLog   where  prize_id in ('+','.join([str(i) for i in prize_id_list])+')'
                        cursor = connection.cursor()
                        cursor.execute(sql)
                        row = cursor.fetchall()
                        if row:
                            if row[0][0] is not None:
                                all_prize_class_times = row[0][0]
                            else:
                                all_prize_class_times = 0
                        else:
                            all_prize_class_times = 0

                        today_prize_class_precent = '0.0%'
                        if today_lucky_draw_times > 0:
                            today_prize_class_precent = '{:.1f}%'.format((today_prize_class_times / today_lucky_draw_times)*100)
                        all_prize_class_precent = '0.0%'
                        if all_lucky_draw_times > 0:
                            all_prize_class_precent = '{:.1f}%'.format((all_prize_class_times / all_lucky_draw_times)*100)
                    if voucher_id_tuple:
                        'select count(*) from app01_invicode   where  voucher_id in ('+','.join([str(i) for i in voucher_id_list])+')'
                        cursor = connection.cursor()
                        cursor.execute(sql)
                        row = cursor.fetchall()
                        if row:
                            if row[0][0] is not None:
                                all_prize_vouchers = row[0][0]
                            else:
                                all_prize_vouchers = 0
                        else:
                            all_prize_vouchers = 0

                        sql = 'select count(*) from app01_invicode   where status=2 and voucher_id in ('+','.join([str(i) for i in voucher_id_list])+')'
                        cursor = connection.cursor()
                        cursor.execute(sql)
                        row = cursor.fetchall()
                        if row:
                            if row[0][0] is not None:
                                #init value 8
                                if prize.voucher.id==380:
                                    all_redeem_times = row[0][0] +8
                                else:
                                    all_redeem_times = row[0][0]
                            else:
                                all_redeem_times = 0
                        else:
                            all_redeem_times = 0
                        total_redeems=total_redeems+all_redeem_times
                        redeem_precent = '0.0%'
                        if all_prize_vouchers > 0:
                            redeem_precent = '{:.1f}%'.format((all_redeem_times / all_prize_vouchers)*100)

                today_class_prize_dict[prize_class_name]=today_prize_class_times
                today_class_prize_dict[prize_class_name+'_percent'] = today_prize_class_precent
                all_class_prize_dict[prize_class_name]=all_prize_class_times
                all_class_prize_dict[prize_class_name + '_percent'] = all_prize_class_precent
                redeem_dict[prize_class_name] = all_redeem_times
                redeem_dict[prize_class_name + '_percent'] = redeem_precent


            count_table_line_1=count_table_line_1+'<td colspan=2>thank you</td><td rowspan=2>total times</td></tr>'
            count_table_line_2 = count_table_line_2 + '<td>times</td><td>percent</td></tr>'
            count_table=count_table+count_table_line_1+count_table_line_2

            line_1='<tr><td>today</td>'
            line_2='<tr><td>all</td>'
            line_3='<tr><td>redeem</td>'
            for i in range(3):
                for item in prize_class_set_list:
                    if i==0:
                        line_1=line_1+'<td>'+str(today_class_prize_dict[item.prize_name])+'</td>'+'<td>'+today_class_prize_dict[item.prize_name+'_percent']+'</td>'
                    elif i==1:
                        line_2 = line_2 + '<td>' + str(all_class_prize_dict[item.prize_name]) + '</td>' + '<td>' + all_class_prize_dict[item.prize_name + '_percent'] + '</td>'
                    elif i==2:
                        line_3 = line_3 + '<td>' + str(redeem_dict[item.prize_name]) + '</td>' + '<td>' + redeem_dict[item.prize_name + '_percent'] + '</td>'
            line_1=line_1+'<td>'+str(today_thank_times)+'</td>'+'<td>'+today_thank_times_precent+'</td><td>'+str(today_lucky_draw_times)+'</td></tr>'
            line_2 = line_2 + '<td>' + str(all_thank_times) + '</td>' + '<td>' + all_thank_times_precent + '</td><td>' + str(all_lucky_draw_times )+ '</td></tr>'
            line_3 = line_3 + '<td></td>' + '<td></td><td>' + str(total_redeems) + '</td></tr>'
            count_table=count_table+line_1+line_2+line_3
        count_table=count_table+"</table>"
        table=table+count_table
        #thread_send_mail(count_table, "prize")