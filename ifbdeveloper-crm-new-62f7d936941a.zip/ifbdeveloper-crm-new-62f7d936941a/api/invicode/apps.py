from django.apps import AppConfig


class InvicodeConfig(AppConfig):
    name = 'invicode'
