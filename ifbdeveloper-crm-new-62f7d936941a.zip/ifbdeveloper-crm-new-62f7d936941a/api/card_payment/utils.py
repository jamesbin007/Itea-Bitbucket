from django.conf import settings # new
from django.views.generic.base import TemplateView
from django.shortcuts import render # new
from rest_framework.permissions import AllowAny
from rest_framework.decorators import api_view,authentication_classes,permission_classes
from rest_framework import viewsets, request
from rest_framework.response import Response
from django.http import HttpResponse
import json
import time
from app01 import models
from wallet import serializers,service
from django.http import HttpResponse,HttpResponseRedirect
from django.db import connection
import datetime
import base64
import hashlib
import binascii
import os
import urllib.parse
import requests
import hmac
import json
import random
import string
from wsgiref.handlers import format_date_time
from datetime import datetime
from time import mktime
import sys
import base64
from django.http import QueryDict
class MasterCard():
    countryCode = 'SG'
    currency = 'SGD'
    session_url='/session/'
    def __init__(self, merchantId, password,region,apiVersion):
        self.merchantId = merchantId
        self.password = password
        self.region = region
        self.apiVersion = apiVersion

    def is_test(self):
        if len(self.merchantId)>4:
            if self.merchantId[0,4].strip().lower() == 'test':
                return True
        return False
    def get_region_prefix(self):
        prefix = ''
        if self.region.strip().upper() == 'ASIA_PACIFIC':
            prefix = 'ap.'
        elif self.region.strip().upper() == 'EUROPE':
            prefix = 'eu.'
        elif self.region.strip().upper() == 'NORTH_AMERICA':
            prefix = 'na.'
        elif self.region.strip().upper() == 'INDIA':
            prefix = 'in.'
        elif self.region.strip().upper() == 'CHINA':
            prefix = 'CHINA.'
        elif self.region.strip().upper() == 'MTF':
            prefix = 'mtf.'
        elif self.region.strip().upper() == 'QA01':
            prefix = 'qa01.'
        return prefix
    def getApiUrl(self):
        prefix=self.get_region_prefix()
        gatewayUrl = "https://"+prefix+"gateway.mastercard.com/api/rest/version/"+self.apiVersion+"/merchant/"+self.merchantId
        #gatewayUrl = "https://test-gateway.mastercard.com/api/rest/version/" + self.apiVersion + "/merchant/" + self.merchantId
        return gatewayUrl
    def DecodingJson(self,json_file):
        dic = {}
        decode_file = json.loads(json_file)
        for key, value in decode_file.items():
                dic[key] = value
        return dic
    def buildHeader(self):
        header={'Content-Type':'application/json', 'Authorization': 'Basic ' +str( base64.b64encode(("merchant."+self.merchantId+":"+self.password).encode('utf-8')),encoding="utf-8"), }
        return header
    def buildPageUrl(self,request):
        return "https://"+request.META['HTTP_HOST']+request.META['PATH_INFO']
    def getJsonPayload(self, request):
        post_data={}
        if request.method=='POST':
            post_item = {}
            #for key, value in request.POST.items():
            #    post_item[key]=value
            post_data = json.dumps(request.data)
            #post_data={"apiOperation":"AUTHORIZE","sourceOfFunds":{"type":"CARD","provided":{"card":{"number":"5123450000000008","expiry":{"month":"05","year":"21"},"securityCode":"100"}}},"order":{"amount":"1","currency":"GSD"}}
            #post_data = "{ \"apiOperation\":\"AUTHORIZE\" }"
            print(post_data)
            #post_data={}
            '''
            post_data={
            "apiUsername":"merchant.TEST168900001330",
            "apiPassword":"3c4032add00b8a15105091a45d982ee7",
        }
        '''
            #post_data = dict(request.POST.lists())
            #post_data = QueryDict(request.body)
        if request.method=='PUT':
            #post_data = dict(request.POST.lists())
            #post_data = QueryDict(request.body)
            post_data = json.dumps(request.data)

        return post_data
    #temprory function
    def doRedirect(self,url):
        return HttpResponseRedirect(url)
        #requests.head(url)
    def requestTransaction(self,orderId,txnId,request):
        header=self.buildHeader()
        body=self.getJsonPayload(request)
        print(body)
        path = '/order/'+orderId+'/transaction/'+txnId
        result= self.callApi('PUT',path,header,body)
        return result
    def requestSession(self,request):
        header=self.buildHeader()
        body=self.getJsonPayload(request)
        path = MasterCard.session_url
        result= self.callApi('POST',path,header,body)
        return result
    def requestToken(self,request):
        header=self.buildHeader()
        body=self.getJsonPayload(request)
        path = "/token"
        result= self.callApi('POST',path,header,body)
        return result
    def callApi(self, method, path, headers, body = ''):

        try:
            base_uri=self.getApiUrl()

            if(method=='GET'):
                response = requests.get(base_uri + path, headers=headers)
            if(method=='POST'):
                response = requests.post(base_uri+path, headers=headers, data=body)
            if (method == 'PUT'):
                response = requests.put(base_uri + path, headers=headers, data=body)
            gateWayResponse=json.loads(response.text)
            #print(json.loads(response.text))
            return_response= {
                'apiVersion':self.apiVersion,
                'gatewayResponse':gateWayResponse
            }
            return return_response
        except Exception as e:
            print(repr(e))

            return {'msg':e}

    def callApi_3d(self, method, path, headers, body = ''):

        try:
            base_uri=self.getApiUrl()

            if(method=='GET'):
                response = requests.get(base_uri + path, headers=headers)
            if(method=='POST'):
                response = requests.post(base_uri+path, headers=headers, data=body)
            if (method == 'PUT'):
                response = requests.put(base_uri + path, headers=headers, data=body)
            print(response.text)
            r_text=response.text
            r_text=r_text.replace("/","\\/")
            print(r_text)
            gateWayResponse=json.loads(r_text)
            print(gateWayResponse)
            return_response= {
                'apiVersion':self.apiVersion,
                'gatewayResponse':gateWayResponse
            }
            return return_response
        except Exception as e:
            print(repr(e))

            return {'msg':e}



