from django.urls import path, include
from rest_framework.routers import DefaultRouter
from . import views






card_router = DefaultRouter()
card_router.register('', views.CardViewSet)

urlpatterns = [
    path('check/', views.check, name='check'),
    path('wirecard_status/', views.wirecard_status, name='wirecard_status'),
    path('session/', views.session, name='session'),
    path('token/', views.token, name='token'),
    path('transaction/', views.transaction, name='transaction'),
    path('three_d_secure/', views.three_d_secure, name='three_d_secure'),
    path('three_d_secure_result/', views.three_d_secure_result, name='three_d_secure_result'),
    path('', include(card_router.urls)),

]
