from django.contrib.auth.base_user import BaseUserManager
from django.contrib.auth.hashers import make_password
from django.db import models
from django.contrib.auth.models import AbstractBaseUser
from rest_framework.authtoken.models import Token as authToken
from django.utils import timezone
from django.contrib.postgres.fields import ArrayField
from datetime import datetime, timedelta
from django.conf import settings
from django.utils.translation import ugettext_lazy as _
#from django.contrib.auth.models import UserManager

def one_year_later():
    now = datetime.now()
    return now + timedelta(days=365)


class InterestGroup(models.Model):
    name = models.CharField('Interest Group name', max_length=32, unique=True)


class Role(models.Model):
    ADMIN, POS, MEMBER, ANONYMOUS, APP = range(5)
    NAME_CHOICES = (
        (ADMIN, 'ADMIN'),
        (POS, 'POS'),
        (MEMBER, 'MEMBER'),
        (ANONYMOUS, 'ANONYMOUS'),
        (APP, 'APP'),
    )
    name = models.PositiveSmallIntegerField(
        "Role name",
        choices=NAME_CHOICES,
        help_text="0:admin,1:pos,2:member,3:anonymous,4:app",
        unique=True
    )


class Membership(models.Model):
    # W, C, P = range(3)
    # LEVEL_CHOICES = (
    #     (W, 'Welcome membership'),
    #     (C, 'Classic membership'),
    #     (P, 'Premium membership'),
    # )
    # level = models.PositiveSmallIntegerField(
    #     "level",
    #     choices=LEVEL_CHOICES,
    #     help_text="0:Welcome membership,1:Classic membership,2:Premium membership",
    # )
    name = models.CharField('name', max_length=64)
    description = models.CharField('description', max_length=128, null=True, blank=True)
    complimentary_vouchers = models.ManyToManyField(to='Voucher', related_name='membership_compliment', null=True,
                                                    blank=True)
    reward_vouchers = models.ManyToManyField(to='Voucher', related_name='membership_reward', null=True,
                                                    blank=True)
    invitation_vouchers = models.ManyToManyField(to='Voucher', related_name='membership_invitation', null=True,
                                                    blank=True)
    birthday_vouchers = models.ManyToManyField(to='Voucher', related_name='membership_birthday', null=True, blank=True)
    start_points = models.IntegerField('start_points')
    # end_points = models.IntegerField('end_points')
    renewal_points = models.IntegerField('renewal_points')
    complimentary_m_drink_points = models.IntegerField('start_points', null=True, blank=True)
    cash_back= models.FloatField('cash_back', null=True, blank=True)
    processing, launched, archived = range(3)
    STATE_CHOICES = (
        (processing, 'processing'),
        (launched, 'launched'),
        (archived, 'archived'),
    )
    state = models.PositiveSmallIntegerField(
        "state",
        choices=STATE_CHOICES,
        help_text="0:processing,1:launched,2:archived",
    )


class Member_CampaignType(models.Model):
    member = models.ForeignKey(to='Member', related_name='member_campaigntypes', on_delete=models.CASCADE)
    campaign_type = models.ForeignKey(to='CampaignType', related_name='member_campaigntypes', on_delete=models.CASCADE)
    created = models.DateTimeField('created', default=timezone.now)

class UserManager(BaseUserManager):
    def create_user(self,  username, password,alias=None):
        user = self.model(
        mobile_no=username,
                username = username,)
        user.set_password(make_password(password))

        user.save()
        return user
    def create_superuser(self,  username, password):
       user=self.create_user( username, password)
       user.is_staff=True
       user.is_superuser = True
       user.save()
       return user

class Member(AbstractBaseUser):
    TYPE = (
        (0, "male"),
        (1, "female")
    )
    #modify USERNAME_FIELD from email to username
    #USERNAME_FIELD = 'email'
    USERNAME_FIELD = 'username'
    REQUIRED_FIELDS = [ ]
    is_staff = models.NullBooleanField('is_staff', null=True, blank=True)
    #is_superuser = models.NullBooleanField('is_superuser', null=True, blank=True)
    # invicode  = models.ForeignKey(to='Invicode', related_name='invicode', on_delete=models.CASCADE, null=True, blank=True)
    mobile_no = models.CharField('mobile_no', max_length=64,  null=True, blank=True)
    invicode = models.CharField('invicode', max_length=16,  null=True, blank=True)
    registration_date = models.DateTimeField('registration_date', default=timezone.now)
    username = models.CharField('username', max_length=64, unique=True)
    password = models.CharField('password', max_length=128)
    last_login = models.DateTimeField('last login', blank=True, null=True)
    role = models.ForeignKey(to='Role', related_name='members', on_delete=models.CASCADE)
    interestGroups = models.ManyToManyField(to='InterestGroup', related_name='members', blank=True)
    membership = models.ForeignKey(to='Membership', related_name='members', on_delete=models.CASCADE)
    last_purchase_date = models.DateField('last_purchase_date', null=True, blank=True)
    vouchers = models.ManyToManyField(to='Voucher', through='Voucher_Member', through_fields=('member', 'voucher'))
    name = models.CharField('Member name', max_length=64, null=True, blank=True)
    points_bal = models.IntegerField('points_bal', default=0)
    total_points = models.IntegerField('total_points', default=0)
    # points_bal = models.FloatField('points_bal', default=0)
    # total_points = models.FloatField('total_points', default=0)
    dob = models.DateField('Member birthday', null=True, blank=True)
    telephone = models.CharField('telephone', max_length=64, null=True, blank=True)
    race = models.CharField('race', max_length=64, null=True, blank=True)
    email = models.EmailField('Member email', null=True, blank=True, unique=True)
    campaigntypes = models.ManyToManyField(to='CampaignType', through='Member_CampaignType',
                                           through_fields=('member', 'campaign_type'), related_name='members',
                                           blank=True)

    is_active = models.IntegerField(choices=TYPE, verbose_name="gender", default=0)
    nick_name = models.CharField(verbose_name="NickName", max_length=64, null=True, blank=True)
    device_token=models.CharField(verbose_name="device_token", max_length=300, null=True, blank=True)
    topup_10_times = models.IntegerField(verbose_name='topup_10_times', default=0)

    topup_20_times = models.IntegerField(verbose_name='topup_20_times', default=0)

    topup_50_times = models.IntegerField(verbose_name='topup_50_times', default=0)
    topup_100_times = models.IntegerField(verbose_name='topup_100_times', default=0)
    non_wallet_pay_times=models.IntegerField(verbose_name='non_wallet_pay_times', default=0)

    invite_code=models.CharField(verbose_name="invite_code", max_length=20, null=True, blank=True)
    register_code = models.CharField(verbose_name="ShareCode", max_length=20, null=True, blank=True)
    invite_count = models.IntegerField(verbose_name='invite_count', default=0)

    ANDROID,IOS=range(2)
    COUNTED_CHOICE=(
        (ANDROID,'ANDROID'),
        (IOS,'IOS')
    )
    terminal= models.PositiveSmallIntegerField('terminal',choices= COUNTED_CHOICE,help_text='0:ANDROID,1:IOS',default=ANDROID)
    delivery_address=models.CharField(verbose_name="delivery_address", max_length=200, null=True, blank=True)
    post_code = models.CharField(verbose_name="post_code", max_length=30, null=True, blank=True)
    last_login_date = models.DateField('last_login_date', null=True, blank=True)
    reward_birthday_voucher_date=models.DateField('reward_birthday_voucher_date', null=True, blank=True)
    last_phone_number = models.CharField('last_phone_number', max_length=64, null=True, blank=True)
    NORMAL,DELETION = range(2)
    STATUS_CHOICE = (
        (NORMAL, 'NORMAL'),
        (DELETION, 'DELETION')
    )
    status = models.PositiveSmallIntegerField('status', choices=STATUS_CHOICE, help_text='0:NORMAL,1:DELETION',
                                                default=NORMAL)
    #is_new_user = models.PositiveSmallIntegerField('is_new_user', choices=STATUS_CHOICE, help_text='0:new user,1:old user', default=NORMAL)
    delete_time=models.DateTimeField('delete account time', blank=True, null=True)
    #member_delivery_address=models.OneToOneField(to='Member_delivery_Address', related_name='members', on_delete=models.CASCADE)
    #invitation_count=models.PositiveSmallIntegerField('CountStatus',choices= COUNTED_CHOICE,help_text='0:NotCounted,1:Counted',default=NOTCOUNTED)
    GUEST, MEMBER = range(2)
    GUEST_CHOICE = (
        (GUEST, 'GUEST'),
        (MEMBER, 'MEMBER')
    )
    is_guest = models.PositiveSmallIntegerField('is_guest', choices=GUEST_CHOICE, help_text='0:GUEST,1:MEMBER',
                                              default=GUEST)
    NOT_SECURE_PAYMENT, SECURE_PAYMENT = range(2)
    PAYMENT_CHOICE = (
        (NOT_SECURE_PAYMENT, 'NOT_SECURE_PAYMENT'),
        (SECURE_PAYMENT, 'SECURE_PAYMENT')
    )
    is_secure_payment = models.PositiveSmallIntegerField('is_secure_payment', choices=PAYMENT_CHOICE, help_text='0:NOT_SECURE_PAYMENT,1:SECURE_PAYMENT',
                                              default=NOT_SECURE_PAYMENT)
    objects = UserManager()

    class Meta:
        indexes = [
            models.Index(fields=['mobile_no'], name='mobile_no_idx'),
            models.Index(fields=['username'], name='username_idx'),
        ]
        # individual_position = models.CharField('Individual position', max_length=64, null=True, blank=True)
        # salutation = models.CharField('Member salutation', max_length=64, null=True, blank=True)
        # NRIC = models.CharField('Member NRIC', max_length=64, null=True, blank=True)
        # passport = models.CharField('Member passport', max_length=64, null=True, blank=True)
        # gender = models.CharField('Member gender', max_length=64, null=True, blank=True)
        # nationality = models.CharField('Member nationality', max_length=64, null=True, blank=True)
        # block = models.CharField('Member block', max_length=64, null=True, blank=True)
        # level = models.CharField('Member level', max_length=64, null=True, blank=True)
        # unit = models.CharField('Member unit', max_length=64, null=True, blank=True)
        # street = models.CharField('Member street', max_length=64, null=True, blank=True)
        # building = models.CharField('Member building', max_length=64, null=True, blank=True)
        # postal_code = models.CharField('Member postal_code', max_length=64, null=True, blank=True)
        # country = models.CharField('Member country', max_length=64, null=True, blank=True)
        # address1 = models.CharField('Member address1', max_length=64, null=True, blank=True)
        # address2 = models.CharField('Member address2', max_length=64, null=True, blank=True)
        # address3 = models.CharField('Member address3', max_length=64, null=True, blank=True)
        # contact_no = models.CharField('contact_no', max_length=64, null=True, blank=True)
        # fax_no = models.CharField('fax_no', max_length=64, null=True, blank=True)
        # referrer_code = models.CharField('referrer_code', max_length=64, null=True, blank=True)
        # facebook_id = models.CharField('salutation', max_length=64, null=True, blank=True)
        # facebook_name = models.CharField('facebook_name', max_length=64, null=True, blank=True)
        # facebook_photo_link = models.CharField('facebook_photo_link', max_length=128, null=True, blank=True)
        # facebook_token = models.CharField('facebook_token', max_length=128, null=True, blank=True)
        # facebook_token_expiry = models.CharField('facebook_token_expiry', max_length=64, null=True, blank=True)
        # full_photo_name = models.CharField('full_photo_name', max_length=64, null=True, blank=True)
        # base64_photo_string = models.CharField('base64_photo_string', max_length=256, null=True, blank=True)
        # photo_link = models.CharField('photo_link', max_length=128, null=True, blank=True)
        # race_code = models.CharField('race_code', max_length=64, null=True, blank=True)
        # notify_post = models.NullBooleanField('notify_post', max_length=64, null=True, blank=True)
        # notify_sms = models.NullBooleanField('notify_sms', max_length=64, null=True, blank=True)
        # first_name = models.CharField('first_name', max_length=64, null=True, blank=True)
        # last_name = models.CharField('last_name', max_length=64, null=True, blank=True)

class Membership_Record(models.Model):
    member = models.ForeignKey(to='Member', related_name='membership_record',
                               on_delete=models.CASCADE,null=True,blank=True)
    membership = models.ForeignKey(to='Membership', related_name='membership_record',
                                   on_delete=models.CASCADE,null=True,blank=True)
    create_date = models.DateTimeField('create_date', default=timezone.now)
class Membership_Member(models.Model):
    member = models.ForeignKey(to='Member', related_name='membership_members',
                               on_delete=models.CASCADE)
    membership = models.ForeignKey(to='Membership', related_name='membership_members',
                                   on_delete=models.CASCADE)
    effective_date = models.DateTimeField('effective_date', default=timezone.now)
    expiring_date = models.DateTimeField('expiring_date', default=one_year_later)
    ACTIVE, EXPIRED = range(2)
    STATUS_CHOICES = (
        (ACTIVE, 'active'),
        (EXPIRED, 'expired'),
    )
    status = models.PositiveSmallIntegerField(
        "status",
        choices=STATUS_CHOICES,
        help_text="0:active,1:expired",
    )
class Member_Life_Circle(models.Model):
    member = models.ForeignKey(to='Member', related_name='member_life',
                               on_delete=models.CASCADE)

    effective_date = models.DateTimeField('effective_date', default=timezone.now)
    expiring_date = models.DateTimeField('expiring_date', default=one_year_later)


class Card(models.Model):
    card_no = models.CharField(' Member card number Member', max_length=64, unique=True)
    member = models.ForeignKey(to='Member', related_name='cards', on_delete=models.CASCADE, null=True, blank=True)
    printed_name = models.CharField('The name of the member card', max_length=64, null=True, blank=True)
    membership_type_code = models.CharField('Member type code', max_length=64, null=True, blank=True)
    membership_status_code = models.CharField('Member status code', max_length=64, null=True, blank=True)
    membership_photo = models.CharField('Member photo', max_length=64, null=True, blank=True)
    issue_date = models.DateTimeField('Issue date', null=True, blank=True)
    effective_date = models.DateTimeField('Effective Date', null=True, blank=True)
    expiry_date = models.DateTimeField('Expiry Date ', null=True, blank=True)
    printed = models.NullBooleanField('printed', null=True, blank=True)
    printed_date = models.DateTimeField('Printed Date', null=True, blank=True)
    renewed_date = models.DateTimeField('Renewed Date', null=True, blank=True)
    tmp_effective_date = models.DateTimeField('Tmp Effective Date', null=True, blank=True)
    tmp_expiry_date = models.DateTimeField('Tmp Expiry Date', null=True, blank=True)
    tmp_membership_status_code = models.CharField('Tmp Membership Status Code', max_length=64, null=True, blank=True)
    points_bal = models.FloatField('Points Bal', max_length=32, null=True, blank=True, default=0)
    total_points_bal = models.FloatField('Total_Points Bal', max_length=32, null=True, blank=True, default=0)
    holding_points = models.FloatField('Holding Points', max_length=32, null=True, blank=True, default=0)
    remarks = models.CharField('Remarks', max_length=64, null=True, blank=True)
    membership_discount = models.FloatField('Membership Discount', max_length=32, null=True, blank=True, default=0)
    tier_code = models.CharField('Tier Code', max_length=64, null=True, blank=True)
    tier_anniversary_start_date = models.DateTimeField('Tier Anniversary Start Date', null=True, blank=True)
    tier_anniversary_end_date = models.DateTimeField('Tier Anniversary End Date', null=True, blank=True)
    loyalty_message = models.CharField('Loyalty Message', max_length=64, null=True, blank=True)
    dollar_to_points_ratio = models.FloatField('Dollar to Point Ratio', max_length=32, null=True, blank=True, default=0)
    is_supplementary = models.NullBooleanField('Is Supplementary', null=True, blank=True)
    is_burn_supplementary = models.NullBooleanField('Is Burn Supplementary', null=True, blank=True)
    relation_id = models.CharField('Relation Id', max_length=64, null=True, blank=True)
    primary_card_no = models.CharField('Primary Card No', max_length=64, null=True, blank=True)
    primary_relation_id = models.CharField('Primary Relation Id', max_length=64, null=True, blank=True)
    primary_card_expiry_date = models.DateTimeField('Primary Card Expiry Date ', null=True, blank=True)
    primary_card_effective_date = models.DateTimeField('Primary Card Effective Date', null=True, blank=True)
    pts_holding_days = models.IntegerField('Pts Holding Days', null=True, blank=True)
    current_net_spent = models.FloatField('Current Net Spent', max_length=32, null=True, blank=True, default=0)
    pass_code = models.CharField('Pass Code', max_length=64, null=True, blank=True)
    stored_value_balance = models.FloatField('Stored Value Balance', max_length=32, null=True, blank=True, default=0)
    currency = models.CharField('Currency', max_length=64, null=True, blank=True)
    last_visited_date = models.DateTimeField('Last Visited Date', null=True, blank=True)
    last_visited_outlet = models.CharField('Last Visited Outlet', max_length=64, null=True, blank=True)
    points_to_next_tier = models.FloatField('Points To Next Tier', max_length=32, null=True, blank=True, default=0)
    nett_to_next_tier = models.FloatField('Nett To Next Tier', max_length=32, null=True, blank=True, default=0)
    lucky_draw_conversion_pts_usage_type = models.CharField(max_length=64, null=True, blank=True)
    lucky_draw_conversion_rate = models.CharField('Lucky Draw Conversion Rate', max_length=64, null=True, blank=True)
    spent_quota_increasement = models.FloatField(max_length=32, null=True, blank=True, default=0)
    spent_quota_increasement_expired_on = models.CharField(max_length=64, null=True, blank=True)
    pickup_date = models.DateTimeField('pickup_date', null=True, blank=True)
    pickup_by = models.CharField('pickup_by', max_length=64, null=True, blank=True)
    current_rcnett_spent = models.IntegerField('current_rcnett_spent', null=True, blank=True)
    cmc_earned_points = models.FloatField('cmc_earned_points', max_length=32, null=True, blank=True, default=0)
    crc_earned_points = models.IntegerField('crc_earned_points', null=True, blank=True)
    current_tier_nett = models.FloatField('current_tier_nett', max_length=32, null=True, blank=True, default=0)
    current_tier_amt = models.FloatField('current_tier_amt', max_length=32, null=True, blank=True, default=0)
    bring_fwd_tier_nett = models.FloatField('bring_fwd_tier_nett', max_length=32, null=True, blank=True, default=0)
    bring_fwd_tier_amt = models.FloatField('bring_fwd_tier_amt', max_length=32, null=True, blank=True, default=0)
    bring_fwd_tier_expiry = models.CharField('bring_fwd_tier_expiry', max_length=64, null=True, blank=True)
    bring_fwd_tier_start_date = models.DateTimeField('bring_fwd_tier_start_date', null=True, blank=True)
    extended_tier_anniversary_end_date = models.DateTimeField(null=True, blank=True)



class Occupation(models.Model):
    name = models.CharField('Occupation name', max_length=32, unique=True)


class CampaignCondition(models.Model):
    campaign = models.ForeignKey(to='Campaign', related_name='campaignconditions',
                                 on_delete=models.CASCADE)
    purchase_products_number = models.IntegerField(null=True, blank=True)
    every_spent = models.FloatField('every_spent', null=True, blank=True)
    every_top_up = models.FloatField('every_top_up', null=True, blank=True)
    every_use_points = models.IntegerField('every_use_points', null=True, blank=True)
    every_purchase_points = models.IntegerField('every_purchase_points', null=True, blank=True)
    every_purchase_m_drinks_flavors = models.ManyToManyField(to='Product', related_name='m_drinks_condition', null=True,
                                                             blank=True)
    every_purchase_l_drinks_flavors = models.ManyToManyField(to='Product', related_name='l_drinks_condition', null=True,
                                                             blank=True)
    every_purchase_products = models.ManyToManyField(to='Product',
                                                     related_name='products_condition', null=True, blank=True)
    A, B, C, D, E, F,G = range(7)
    ACTIONS_CHOICES = (
        (A, 'Like our facebook page itea.sg'),
        (B, 'Like our facebook post'),
        (C, 'Rate us on facebook'),
        (D, 'Post on our facebook page'),
        (E, 'Share our facebook page/post'),
        (F, 'Like our instagram'),
        (G, 'Share invitation code in facebook'),
    )
    online_actions = ArrayField(models.PositiveSmallIntegerField(
        choices=ACTIONS_CHOICES,
    ), verbose_name='online_actions', null=True, blank=True)
    every_customers = models.IntegerField('every_customers', null=True, blank=True)
    A, B, C, D, E, F, G, H, I, J, K,L= range(12)
    ORDERING_MODE_CHOICES = (
        (A, 'cash'),
        (B, 'apple pay'),
        (C, 'andriod pay'),
        (D, 'visa'),
        (E, 'mastercard'),
        (F, 'ezylink'),
        (G, 'QR code'),
        (H, 'favepay'),
        (I, 'grabpay'),
        (J, 'Alipay'),
        (K, 'Internet Banking'),
        (L, 'NETS')
    )
    ordering_modes = ArrayField(models.PositiveSmallIntegerField(
        choices=ORDERING_MODE_CHOICES,
    ), verbose_name='ordering_modes', null=True, blank=True)
    WALKIN, MOBILE = range(2)
    PAYMENT_MODE_CHOICES = (
        (WALKIN, 'Walk-in'),
        (MOBILE, 'Mobile ordering'),
    )
    payment_modes = ArrayField(models.PositiveSmallIntegerField(
        choices=PAYMENT_MODE_CHOICES,
    ), verbose_name='payment_modes', null=True, blank=True)
    other_actions = models.TextField('other_actions', null=True, blank=True)
    limit_redemption = models.IntegerField('limit_redemption', null=True, blank=True)


class Campaign(models.Model):
    name = models.CharField('Campaign name', max_length=128)
    description = models.CharField('Campaign description', max_length=128, null=True, blank=True)
    occupations = models.ManyToManyField(to='Occupation', related_name='campaigns',
                                         null=True, blank=True)
    memberships = models.ManyToManyField(to='Membership', related_name='campaigns',
                                         null=True, blank=True)
    M, F = range(2)
    GENDER_CHOICES = (
        (M, 'Male'),
        (F, 'Female'),
    )
    gender = ArrayField(models.PositiveSmallIntegerField(choices=GENDER_CHOICES), verbose_name='gender',
                        help_text="0:Male,1:Female", null=True, blank=True)
    # min_age = models.IntegerField('min_age', null=True, blank=True)
    # max_age = models.IntegerField('max_age', null=True, blank=True)
    age = ArrayField(models.CharField(max_length=128), verbose_name='age', null=True, blank=True)
    A, B, C, D, E, F, G, H, I = range(9)
    Repetition_periods_CHOICES = (
        (A, 'daily'),
        (B, 'every mon'),
        (C, 'every tue'),
        (D, 'every wed'),
        (E, 'every thur'),
        (F, 'every fri'),
        (G, 'every sat'),
        (H, 'every sun'),
        (I, 'monthly'),
    )
    repetition_periods = ArrayField(models.PositiveSmallIntegerField(
        choices=Repetition_periods_CHOICES,
    ), verbose_name='repetition_periods', null=True, blank=True)
    DAYS_CHOICES = []
    for i in range(31):
        DAYS_CHOICES.append((i + 1, i + 1))
    days_of_month = ArrayField(models.PositiveSmallIntegerField(
        choices=DAYS_CHOICES,
    ), verbose_name='days_of_month', null=True, blank=True)
    effective_date = models.DateField('Campaign effective Date')
    expiring_date = models.DateField('Campaign Expiring Date')
    every_1_dollar_bouns_points = models.IntegerField('every_1_dollar_bouns_points', null=True, blank=True)
    outlets = models.ManyToManyField(to='Outlet', related_name='campaigns', null=True, blank=True)
    event_venue = models.CharField('event_venue', max_length=64, null=True, blank=True)
    processing, waiting, launched, completed, archived = range(5)
    STATE_CHOICES = (
        (processing, 'processing'),
        (waiting, 'waiting'),
        (launched, 'launched'),
        (completed, 'completed'),
        (archived, 'archived'),
    )
    state = models.PositiveSmallIntegerField(
        "Campaign state",
        choices=STATE_CHOICES,
        help_text="0:processing,1:waiting,2:launched,3:completed,4:archived",
    )

    class Meta:
        ordering = ['-id']


class CampaignType(models.Model):
    campaign = models.ForeignKey(to='Campaign', related_name='campaigntypes',
                                 on_delete=models.CASCADE)
    first_discount_per = models.FloatField('first_discount_per', null=True, blank=True)
    last_discount_per = models.FloatField('last_discount_per', null=True, blank=True)
    first_discount_price = models.FloatField('first_discount_price', null=True, blank=True)
    last_discount_price = models.FloatField('last_discount_price', null=True, blank=True)
    bouns_points = models.IntegerField('Reward points', null=True, blank=True)
    top_up_money = models.FloatField('top_up_money', null=True, blank=True)
    upgrade_membership = models.ForeignKey(to='Membership',
                                           on_delete=models.CASCADE, null=True, blank=True)
    free_vouchers = models.ManyToManyField(to='Voucher', related_name='campaigns',
                                           null=True, blank=True)
    campaign_condition = models.OneToOneField(to='CampaignCondition', related_name='campaigntype',
                                              on_delete=models.CASCADE)


class Outlet(models.Model):
    outlet_name = models.CharField('Outlet name', max_length=64, unique=True)
    outlet_code = models.CharField('Outlet code', max_length=64, unique=True)
    outlet_manager = models.CharField('outlet_manager', max_length=64)
    outlet_district = models.CharField('outlet_district', max_length=64)
    outlet_floor_area = models.FloatField('outlet_floor_area')
    outlet_address = models.CharField('outlet_address', max_length=64)
    outlet_longitude=models.FloatField('outlet_longitude',default=0)
    outlet_latitude = models.FloatField('outlet_latitude',default=0)
    outlet_tel=models.IntegerField("tel", default=0)
    outlet_opentime=models.CharField("opentime",max_length=255,null=True,blank=True,default='')
    outlet_closetime = models.CharField('closetime', max_length=255,null=True,blank=True,default='')
    outlet_scheme = models.ForeignKey(to="ProductScheme", related_name='outletscheme', on_delete=models.CASCADE, null=True)
    outlet_has_spicy_pot = models.IntegerField("outlet_has_spicy_pot", default=0)
    outlet_pass = models.CharField("outlet_pass", max_length=255, null=True, blank=True, default='')
    outlet_count_date=models.DateField('outlet_count_date', null=True, blank=True)
    outlet_count=models.IntegerField("outlet_count", default=0)
    category=models.ManyToManyField(to='Category', related_name='outlet', null=True, blank=True)
    visiable = models.BooleanField('visiable', default=True)
    closed = models.BooleanField('closed', default=False)
    SELF_PICKUP,DELIVERY,SELF_PICKUP_DELIVERY = range(3)
    PICKUP_CHOICES = (
        (SELF_PICKUP, 'SELF_PICKUP'),

        (DELIVERY, 'DELIVERY'),
        (SELF_PICKUP_DELIVERY, 'SELF_PICKUP_DELIVERY'),

    )
    pickup_choice = models.PositiveSmallIntegerField(
        "pickup_choice",
        choices=PICKUP_CHOICES,
        help_text="0:SELF_PICKUP,1:DELIVERY,2:SELF_PICKUP_DELIVERY",
    )
    delivery_min_amount=models.FloatField('delivery_min_amount',default=0)
    pickup_min_amount = models.FloatField('pickup_min_amount', default=0)
    can_transfer= models.NullBooleanField('can_transfer', default=False)
    device_token = models.CharField('device_token', max_length=255, null=True, blank=True)
    pos_intergration_platform_code= models.CharField('pos_intergration_platform_code', max_length=255, null=True, blank=True)
    top_show=models.NullBooleanField('top_show', default=False)
    has_cashback = models.NullBooleanField('has_cashback', default=True)
    class Meta:
        ordering = ['id']


class Category(models.Model):
    name = models.CharField('Product category name', max_length=32)
    category_code = models.CharField('category_code', max_length=64, unique=True)
    description = models.CharField('description', max_length=128, null=True, blank=True)
    TEA, SPICY = range(2)
    TYPE_CHOICES = (
        (TEA, 'tea'),
        (SPICY, 'spicy'),

    )
    category_type = models.IntegerField("category_type", choices=TYPE_CHOICES,
                                               help_text="0:tea,1:spicy", null=True,
                                               blank=True)
    product=models.ManyToManyField(to='Product', related_name='category1', null=True, blank=True)
    order_key=models.IntegerField("order_key", null=True,blank=True)
    title_img_url=models.CharField('title_img_url', max_length=250, null=True, blank=True)
    class Meta:
        ordering = ['order_key']

class ProductScheme(models.Model):
    name = models.CharField('Scheme name', max_length=32)
    description = models.CharField('description', max_length=128, null=True, blank=True)

class Group(models.Model):
    group_name = models.CharField('group_name', max_length=128)
    c_name=models.CharField('chinese_name', max_length=128)
    priority=models.IntegerField('priority', null=True, blank=True)
    attribute = models.ManyToManyField(to='Attribute', related_name='group', null=True, blank=True)
    an_enable=models.NullBooleanField('android enable', default=False)

class Attribute(models.Model):
    name = models.CharField('group_name', max_length=128)
    c_name = models.CharField('chinese_name', max_length=128)
    price = models.FloatField('Attribute price', default=0)
    priority = models.IntegerField('priority', null=True, blank=True)
    enum_value= models.IntegerField('enum_value', null=True, blank=True)
    default = models.BooleanField('Attribute status', default=False)
    default_selected= models.BooleanField('Attribute status', default=False)
    relation_name=models.CharField('relation_name', max_length=128, null=True, blank=True)

class Product(models.Model):
    name = models.CharField('Product name', max_length=128)
    description = models.CharField('description', max_length=128, null=True, blank=True)
    price = models.FloatField('Product price',default=0)
    original_price = models.FloatField('original_price', default=0)
    tea_base = models.CharField('Product tea_base', max_length=32, null=True, blank=True)
    item_code = models.CharField('Product item_code', max_length=64, null=True, blank=True)
    category = models.ForeignKey(to='Category', related_name='products',on_delete=models.CASCADE,null=True,blank=True)
    outlet=models.ForeignKey(to="Outlet",related_name='products',on_delete=models.CASCADE,null=True)
    uom=models.CharField('Product uom',max_length=15,null=True,blank=True)
    chinese_name=models.CharField('Product chinese name',max_length=30,null=True,blank=True)
    image_path=models.CharField('Product image path',max_length=300,null=True,blank=True)
    thumb_image_path=models.CharField('Product image path',max_length=300,null=True,blank=True)
    group_name=models.CharField('Product image path',max_length=20,null=True,blank=True)
    group=models.ManyToManyField(to='Group', related_name='product', null=True, blank=True)
    # add product_status --ff(19-6-7)
    product_status = models.BooleanField('product_status', default=True)
    SUGAR_HIDE,SUGAR_SHOW=range(2)
    SUGAR_CHOICES=(
        (SUGAR_HIDE,'SUGAR HIDE'),
        (SUGAR_SHOW,'SUGAR SHOW'),
    )
    show_sugar_level=models.IntegerField('sugar show',choices=SUGAR_CHOICES,help_text='0:hide,1:show',default=SUGAR_SHOW)
    HONEY_HIDE, HONEY_SHOW = range(2)
    HONEY_CHOICES = (
        (HONEY_HIDE, 'HONEY HIDE'),
        (HONEY_SHOW, 'HONEY SHOW'),
    )
    show_honey_level = models.IntegerField('honey show', choices=HONEY_CHOICES, help_text='0:hide,1:show',default=HONEY_SHOW)
    SIZE_HIDE, SIZE_SHOW = range(2)
    SIZE_CHOICES = (
        (SIZE_HIDE, 'SIZE HIDE'),
        (SIZE_SHOW, 'SIZE SHOW'),
    )
    show_size_level = models.IntegerField('size show', choices=SIZE_CHOICES, help_text='0:hide,1:show',
                                           default=SIZE_SHOW)

    ICE_HIDE, ICE_SHOW = range(2)
    ICE_CHOICES = (
        (ICE_HIDE, 'ICE HIDE'),
        (ICE_SHOW, 'ICE SHOW'),
    )
    show_ice_level = models.IntegerField('ice show', choices=ICE_CHOICES, help_text='0:hide,1:show',
                                          default=ICE_SHOW)
    TOPPINGS_HIDE, TOPPINGS_SHOW = range(2)
    TOPPINGS_CHOICES = (
        (TOPPINGS_HIDE, 'TOPPINGS HIDE'),
        (TOPPINGS_SHOW, 'TOPPINGS SHOW'),
    )
    show_toppings_level = models.IntegerField('toppings show', choices=TOPPINGS_CHOICES, help_text='0:hide,1:show',
                                         default=TOPPINGS_SHOW)

    QBALL_HIDE, QBALL_SHOW = range(2)
    QBALL_CHOICES = (
        (QBALL_HIDE, 'QBALL HIDE'),
        (QBALL_SHOW, 'QBALL SHOW'),
    )
    show_qball_selection = models.IntegerField('qball show', choices=QBALL_CHOICES, help_text='0:hide,1:show',
                                              default=QBALL_HIDE)

    WATER_HIDE, WATER_SHOW = range(2)
    WATER_CHOICES = (
        (WATER_HIDE, 'WATER HIDE'),
        (WATER_SHOW, 'WATER SHOW'),
    )
    show_water_level = models.IntegerField('water show', choices=WATER_CHOICES, help_text='0:hide,1:show',
                                                   default=WATER_SHOW)

    created = models.DateTimeField('Product created time', default=one_year_later)
    MEDIUM, LARGE,TALL = range(3)
    SIZE_CHOICES = (
        (MEDIUM, 'Meduim'),
        (LARGE, 'Large'),
        (TALL,'Tall')
    )
    size = models.IntegerField("size", choices=SIZE_CHOICES, help_text="0:Meduim,1:Large,2:Tall",default=MEDIUM)
    MEDIUM_SIZE_HIDE, MEDIUM_SIZE_SHOW = range(2)
    MEDIUM_SIZE_CHOICES = (
        (MEDIUM_SIZE_HIDE, 'MEDIUM_SIZE_HIDE'),
        (MEDIUM_SIZE_SHOW, 'MEDIUM_SIZE_SHOW'),
    )
    show_medium_size_level = models.IntegerField('size medium show', choices=MEDIUM_SIZE_CHOICES, help_text='0:hide,1:show',
                                           default=MEDIUM_SIZE_SHOW)
    LARGE_SIZE_HIDE, LARGE_SIZE_SHOW = range(2)
    LARGE_SIZE_CHOICES = (
        (LARGE_SIZE_HIDE, 'LARGE_SIZE_HIDE'),
        (LARGE_SIZE_SHOW, 'LARGE_SIZE_SHOW'),
    )
    show_large_size_level = models.IntegerField('size large show', choices=LARGE_SIZE_CHOICES,
                                                 help_text='0:hide,1:show',
                                                 default=LARGE_SIZE_SHOW)
    TALL_SIZE_HIDE, TALL_SIZE_SHOW = range(2)
    TALL_SIZE_CHOICES = (
        (TALL_SIZE_HIDE, 'TALL_SIZE_HIDE'),
        (TALL_SIZE_SHOW, 'TALL_SIZE_SHOW'),
    )
    show_tall_size_level = models.IntegerField('size tall show', choices=TALL_SIZE_CHOICES,
                                                 help_text='0:hide,1:show',
                                                 default=TALL_SIZE_SHOW)
    scheme = models.ForeignKey(to="ProductScheme",related_name='productscheme',on_delete=models.CASCADE,null=True)

    template = models.CharField('Template PLU_code', max_length=64, null=True, blank=True)
    show_title= models.CharField('show_title', max_length=64, null=True, blank=True)
    root_product_id=models.IntegerField('root_product_id', null=True, blank=True)

    defaultSelected=models.BooleanField('defaultSelected', default=True)
    TEA, SPICY, DISH = range(3)
    TYPE_CHOICES = (
        (TEA, 'tea'),
        (SPICY, 'spicy'),
        (DISH, 'dish')
    )
    type = models.IntegerField("type", choices=TYPE_CHOICES, help_text="0:tea,1:spicy,2:dish", default=TEA)
    show_pot_topping = models.NullBooleanField('show_pot_topping', default=True)
    show_description = models.NullBooleanField('show_description', default=False)
    min_single_price=models.FloatField('min_single_price', default=0)
    long_sold_out = models.NullBooleanField('long_sold_out', default=False)
    exclude_low_amount = models.NullBooleanField('exclude_low_amount', default=False)
    max_limit_num=models.IntegerField('max_limit_num', default=0)
    voucher=models.ForeignKey(to="Voucher",related_name='product_voucher',on_delete=models.CASCADE,null=True)
    preorder_days=models.IntegerField('preorder_days', default=0)
    class Meta:
        ordering = ['item_code']
class Template(models.Model):
    plu_code = models.CharField('Template PLU_code', max_length=64, null=True, blank=True)
    name = models.CharField('Product name', max_length=128, unique=True)
    group_name = models.CharField('Product group name', max_length=20, null=True, blank=True)
    price = models.FloatField('Product price', default=0)
    source_plu = models.CharField('source plu', max_length=128, unique=True)
    dest_plu = models.CharField('dest plu', max_length=128, unique=True)




class Toppings(models.Model):
    name = models.CharField('Toppings name', max_length=32)
    description = models.CharField('description', max_length=128, null=True, blank=True)
    price = models.FloatField('Toppings price')
    item_code = models.CharField('item_code', max_length=50, null=True, blank=True)
    relation_name = models.CharField('relation_name', max_length=50, null=True, blank=True)
    key_word= models.CharField('key_word', max_length=50, null=True, blank=True)
    TEA, SPICY = range(2)
    TOPPINGS_CHOICES = (
        (TEA, 'tea'),
        (SPICY, 'spicy'),

    )
    toppings_type = models.IntegerField("toppings_type", choices=TOPPINGS_CHOICES,
                                               help_text="0:tea,1:spicy", null=True,
                                               blank=True)
    outlet = models.ForeignKey(to='Outlet', related_name='spicy_topping', on_delete=models.CASCADE)
    topping_status = models.NullBooleanField('topping_status', default=True)
    class Meta:
        ordering = ['id']
    topping_status=models.NullBooleanField('topping_status', default=True)
    class Meta:
        ordering = ['key_word']
class Voucher(models.Model):
    #
    name = models.CharField('Voucher name', max_length=128)
    Product, Upgrade, Cash, Discount, BuyOneGetOne, Toppings ,MoneyOff,MoneyOffPersent,FreeDrink,FreeOFF50,Free2ND50,Buy3GetOne= range(12)
    TYPE_CHOICES = (
        (Product, 'Product'),
        (Upgrade, 'Size upgrade'),
        (Cash, 'Discount'),
        (Discount, 'Cash'),
        (BuyOneGetOne, 'Buy one get one free'),
        (Toppings, 'Toppings'),
        (MoneyOff, 'Full reduction'),
        (MoneyOffPersent, 'Full reduction percent'),
        (FreeDrink, 'Free Drink'),
        (FreeOFF50, '50% OFF 1 DRINK'),
        (Free2ND50, '50% OFF 2ND Cup'),
        (Buy3GetOne, 'Buy 3 Get 1'),
    )
    type = models.PositiveSmallIntegerField('type', choices=TYPE_CHOICES,
                                            help_text='0:Product,1:Size upgrade,2:Discount,3:Cash,4:Buy one get one free,5:Toppings,6:MoneyOff,7:MoneyOffPersent,8:FreeDrink,9:50% OFF 1 DRINK,10:50% OFF 2ND Cup,11:Buy 3 Get 1')
    description = models.CharField('Voucher description', max_length=128, null=True, blank=True)
    remark = models.CharField('remark', max_length=500, null=True, blank=True)
    voucher_code = models.CharField('voucher_code', max_length=500, unique=True)
    effective_date = models.DateField('effective Date')
    expiring_date = models.DateField('expiring_date')
    redemption_points = models.IntegerField('redemption_points')
    redemption_toppings = models.ManyToManyField(to='Toppings', related_name='vouchers', null=True, blank=True)
    toppings_number = models.IntegerField('toppings_number', null=True, blank=True)
    redemption_products = models.ManyToManyField(to='Product', related_name='vouchers_redemption', null=True,
                                                 blank=True)
    redemption_products_category=models.ManyToManyField(to='Category', related_name='vouchers_redemption', null=True,
                                                 blank=True)
    M, L,T = range(3)
    SIZE_CHOICES = (
        (M, 'medium'),
        (L, 'large'),
        (T,'Tall')
    )
    product_size = ArrayField(models.PositiveSmallIntegerField(
        choices=SIZE_CHOICES,
    ), verbose_name='product_size', help_text="0:medium,1:large,2:Tall", null=True, blank=True)
    product_number = models.IntegerField('product_number', null=True, blank=True)
    # size_upgrade_unparticipated_products = models.ManyToManyField(to='Product', related_name='vouchers_upgrade',
    #                                                               null=True, blank=True)
    size_upgrade = models.BooleanField('size_upgrade', default=False)
    # discount_per_unparticipated_products = models.ManyToManyField(to='Product', related_name='vouchers_discount_per',
    #                                                               null=True, blank=True)
    discount_percent = models.FloatField('discount_percent', null=True, blank=True)
    # discount_price_unparticipated_products = models.ManyToManyField(to='Product',
    #                                                                 related_name='vouchers_discount_price', null=True,
    #                                                                 blank=True)
    discount_price = models.FloatField('discount_price', null=True, blank=True)
    number_purchase = models.IntegerField('number_purchase', null=True, blank=True)
    number_complimentary_drinks = models.IntegerField('number_complimentary_drinks', null=True, blank=True)
    number_discount_drinks = models.IntegerField('number_discount_drinks', null=True, blank=True)
    processing, waiting, launched, completed, archived = range(5)
    STATE_CHOICES = (
        (processing, 'processing'),
        (waiting, 'waiting'),
        (launched, 'launched'),
        (completed, 'completed'),
        (archived, 'archived'),
    )
    state = models.PositiveSmallIntegerField(
        "state",
        choices=STATE_CHOICES,
        help_text="0:processing,1:waiting,2:launched,3:completed,4:archived",
    )
    unparticipated_outlets = models.ManyToManyField(to='Outlet', related_name='vouchers', null=True, blank=True)
    unparticipated_products = models.ManyToManyField(to='Product', related_name='vouchers', null=True, blank=True)
    limit_memberships = models.ManyToManyField(to='Membership',
                                               related_name='vouchers', null=True, blank=True)
    exclusive_new_members = models.BooleanField('exclusive_new_members', default=False)
    exclusive_non_members = models.BooleanField('exclusive_non_members', default=False)
    redemption_per = models.IntegerField('redemption_per', null=True, blank=True)
    merchant = models.IntegerField('product category:0 tea,1 pot,2 all', null=True, blank=True)
    limit_first_redemption = models.IntegerField('limit_first_redemption', null=True, blank=True)
    full_money = models.FloatField('full_money', null=True, blank=True)
    unlimit_flag=models.NullBooleanField('limit_flag', null=True, blank=True,default=False)
    by_new_user = models.NullBooleanField('by_new_user', null=True, blank=True, default=False)
    A, B, C, D, E, F, G, H = range(8)
    OTHER_LIMITS_CHOICES = (
        (A, 'Not valid with other promo'),
        (B, 'Non- refundable, non-transferable, non-reusable and non-exchangable for cash/points/credit in kind'),
        (C, 'Voucher(s) must be used upon payment'),
        (D, 'Voucher(s) must be utilized fully to the amount stated. Any unused amount will not be refunded'),
        (E, 'Purchase exxceeding redemption value shall be topped up with cash or other payment option'),
        (F, 'itea reserves the right to amend the terms and conditions without prior notice'),
        (G, 'Redemption must be shown upon ordering for counter ordering'),
        (H, 'itea will not be responsible for replacing expired vouchers'),
    )
    other_limits = ArrayField(models.PositiveSmallIntegerField(
        choices=OTHER_LIMITS_CHOICES,
    ), verbose_name='other_limits', null=True, blank=True)


    class Meta:
        ordering = ['-id']


class Voucher_Member(models.Model):
    voucher = models.ForeignKey(to='Voucher', related_name='voucher_members',
                                on_delete=models.CASCADE)
    member = models.ForeignKey(to='Member', related_name='voucher_members',
                               on_delete=models.CASCADE)
    A, B, C = range(3)
    STATUS_CHOICES = (
        (A, 'active'),
        (B, 'used'),
        (C, 'expired'),
    )
    status = models.PositiveSmallIntegerField(
        "Voucher status",
        choices=STATUS_CHOICES,
        help_text="0:active,1:used,2:expired",
        default=A
    )
    created = models.DateTimeField('created', default=timezone.now)


class Invicode(models.Model):
    voucher = models.ForeignKey(to='Voucher', related_name='voucher',
                                on_delete=models.CASCADE)
    member = models.ForeignKey(to='Member', related_name='member', on_delete=models.CASCADE, null=True,
                               blank=True)
    A, B, C, D,E = range(5)
    STATUS_CHOICES = (
        (A, 'active'),
        (B, 'exchanged'),
        (C, 'redeemed'),
        (D, 'in use'),
        (E, 'reward wait for get'),
    )
    status = models.PositiveSmallIntegerField(
        "Invicoder status",
        choices=STATUS_CHOICES,
        help_text="0:active,1:exchanged,2:redeemed,3:in use,4:reward wait for get",
        default=A
    )
    created = models.DateTimeField('created', default=timezone.now)
    invicode_number = models.IntegerField('number of invicode', default=1)
    description = models.CharField('Invicode description', max_length=128, null=True, blank=True)
    code = models.CharField('code', max_length=16, null=True, blank=True)
    abbreviation = models.CharField('Abbreviation', max_length=20, null=True, blank=True)
    redeem_date=models.DateTimeField('redeem_date', null=True)
    redeem_outlet=models.CharField('redeem_outlet', max_length=20, null=True, blank=True)
    register_date = models.DateTimeField('register_date', null=False,default=datetime.strptime('2099-09-09', '%Y-%m-%d'))
    vaild_days= models.IntegerField('valid days of invicode', default=7)
    expire_date=models.DateField('expire_date', default=datetime.strptime('2021-12-30', '%Y-%m-%d').date())

class Invicode_Voucher(models.Model):
    voucher = models.ForeignKey(to='Voucher', related_name='invicode_voucher',
                                on_delete=models.CASCADE)
    A, B, C = range(3)
    STATUS_CHOICES = (
        (A, 'active'),
        (B, 'used'),
        (C, 'expired'),
    )
    status = models.PositiveSmallIntegerField(
        "Invicoder status",
        choices=STATUS_CHOICES,
        help_text="0:active,1:used,2:expired",
        default=A
    )
    created = models.DateTimeField('created', default=timezone.now)
    code = models.CharField('code', max_length=16, null=True, blank=True)


class Points_Member(models.Model):
    member = models.ForeignKey(to='Member', related_name='points', on_delete=models.CASCADE)
    points_number = models.IntegerField('points_number')
    A, B, C, D = range(4)
    METHOD_CHOICES = (
        (A, 'Complete information'),
        (B, 'Payment in apps'),
        (C, 'Campaign reward points'),
        (D, 'Redeem'),
    )
    method = models.PositiveSmallIntegerField(
        "method",
        choices=METHOD_CHOICES,
        help_text="0:Complete information,1:Payment in apps,2:Campaign reward points,3:Redeem",
    )
    campaigntype = models.ForeignKey(to='CampaignType', on_delete=models.CASCADE, null=True, blank=True)
    rewards= models.ForeignKey(to='Rewards', on_delete=models.CASCADE, null=True, blank=True)
    created = models.DateTimeField('created', default=timezone.now)

class Transaction(models.Model):
    member = models.ForeignKey(to='Member', related_name='transaction', on_delete=models.CASCADE, null=True, blank=True)
    outlet = models.ForeignKey(to='Outlet', related_name='transaction', on_delete=models.CASCADE)
    campaigns = models.ManyToManyField(to='Campaign', related_name='transactions', null=True, blank=True)
    campaigntypes = models.ManyToManyField(to='CampaignType', related_name='transactions', null=True, blank=True)
    reward_vouchers = models.ManyToManyField(to='Voucher', related_name='transaction_reward', null=True, blank=True)
    redeemed_vouchers = models.ManyToManyField(to='Voucher', related_name='transaction_redeemed', null=True, blank=True)
    reward_points = models.FloatField('reward_points', null=True, blank=True)
    redeemed_points = models.FloatField('redeemed_points', null=True, blank=True)
    WALKIN, MOBILE = range(2)
    ORDERING_MODE_CHOICES = (
        (WALKIN, 'Walk-in'),
        (MOBILE, 'Mobile ordering'),

    )
    ordering_modes = models.PositiveSmallIntegerField('ordering_modes', choices=ORDERING_MODE_CHOICES)

    A, B, C, D, E, F, G, H, I, J, K, L,M,N = range(14)
    PAYMENT_MODE_CHOICES = (
        (A, 'cash'),
        (B, 'Grab Pay'),
        (C, 'Fave pay'),
        (D, 'visa'),
        (E, 'mastercard'),
        (F, 'ezylink'),
        (G, 'QR code'),
        (H, 'favepay'),
        (I, 'eWallet'),
        (J, 'WIRECARD'),
        (K, 'Internet Banking'),
        (L, 'NETS'),
        (M, 'grabpay'),
        (N, 'Alipay')


    )
    payment_modes = models.PositiveSmallIntegerField('payment_modes', choices=PAYMENT_MODE_CHOICES)
    pos_no = models.CharField('pos_no', max_length=32, null=True, blank=True)
    cashier_no = models.CharField('cashier_no', max_length=32, null=True, blank=True)
    receipt_no = models.CharField('receipt_no', max_length=32)
    transact_datetime = models.DateTimeField('transact_datetime', default=timezone.now)
    total_money = models.FloatField('total_money')
    remark = models.CharField('remark', max_length=64, null=True, blank=True)
    NON_PAYMENT,CANCEL, PAID,PAID_CANCEL,CONFIRM_ORDER,FINISHED = range(6)
    ORDERING_STATUS_CHOICES = (
        (NON_PAYMENT, 'None-payment'),
        (CANCEL, 'Cancel order'),
        (PAID, 'Order paid'),
        (PAID_CANCEL, 'Cancel order after paid'),
        (CONFIRM_ORDER,"CONFIRM_ORDER"),
        (FINISHED,"FINISHED"),



    )
    transaction_status=models.PositiveSmallIntegerField('payment_status', choices=ORDERING_STATUS_CHOICES,default=NON_PAYMENT)
    order_no=models.CharField('order_no', max_length=32, null=True, blank=True)
    NOW,FIFTEEN,THIRTY,FORTYFIVE,ONEHOUR=range(5)
    PICK_UP_CHOICES=(
        (NOW,'NOW'),
        (FIFTEEN,'FIFTEEN'),
        (THIRTY,'THIRTY'),
        (FORTYFIVE,'FORTYFIVE'),
        (ONEHOUR,'ONEHOUR'),

    )
    pick_up_time=models.PositiveSmallIntegerField('pick_up_time', choices=PICK_UP_CHOICES,default=NOW)
    payment_datetime=models.DateTimeField('payment_datetime', null=True, blank=True)
    redeem_invicode=models.BigIntegerField("redeem_invicode",null=True,blank=True)
    discount_amount= models.FloatField('discount_amount',default=0)
    # add delay single time
    delay_time = models.DateTimeField('delay_time', null=True, blank=True)
    grab_txID = models.CharField('grab_txID', max_length=128, null=True, blank=True)
    campaign_return_wallet_cash=models.FloatField('campaign_return_wallet_cash',default=0)
    print_status=models.BooleanField('print_status', default=False)
    cancel_time=models.DateTimeField('cancel_time', null=True, blank=True)
    collected_time = models.DateTimeField('collected_time', null=True, blank=True)
    confirm_time = models.DateTimeField('collected_time', null=True, blank=True)
    PICKUP, DELIVERY = range(2)
    PICKUP_TYPE_CHOICES = (
        (PICKUP, 'PICKUP'),
        (DELIVERY, 'DELIVERY'),


    )
    pick_up_type = models.PositiveSmallIntegerField('pick_up_type', choices=PICKUP_TYPE_CHOICES, default=PICKUP)
    delivery_address= models.CharField('delivery_address', max_length=500, null=True, blank=True)
    delivery_time= models.CharField('delivery_time', max_length=100, null=True, blank=True)
    delivery_remark= models.CharField('delivery_remark', max_length=500, null=True, blank=True)
    delivery_fee=models.FloatField('delivery_fee',default=0)
    transfer_outlet = models.ForeignKey(to='Outlet', related_name='transfer_transaction', null=True, blank=True, on_delete=models.CASCADE)
    origin_outlet_name = models.CharField('origin_outlet_name', max_length=50, null=True, blank=True)
    UNSEND, SENDED = range(2)
    SEND_TYPE_CHOICES = (
        (UNSEND, 'UNSEND'),
        (SENDED, 'SENDED'),

    )
    send_mail_flag=models.PositiveSmallIntegerField('send_mail_type', choices=SEND_TYPE_CHOICES , default=UNSEND)
    signed=models.NullBooleanField('signed', null=True, blank=True,default=False)
    inserted_signed_record=models.NullBooleanField('insert_signed_record', null=True, blank=True,default=False)
    member_updated= models.NullBooleanField('member_updated', null=True, blank=True, default=False)
    class Meta:
        ordering = ['-transact_datetime']
    # transact_type = models.CharField('transact_type', max_length=32, null=True, blank=True)
    # is_rebate_system = models.NullBooleanField('is_rebate_system', null=True, blank=True)
    # rebate_usage = models.IntegerField('rebate_usage', default=2)
    # A, B = range(1, 3)
    # TYPE_CHOICES = (
    #     (A, 'Earn points for shopping'),
    #     (B, 'Use points to redeem voucher')
    # )
    # points_calculation_type = models.PositiveSmallIntegerField(
    #     "points_calculation_type",
    #     choices=TYPE_CHOICES,
    #     help_text="1:Earn points for shopping,2:Use points to redeem voucher",
    #     default=A
    # )
    # points_usage = models.CharField('points_usage', max_length=32, default='COMBINE')
    # redeemed_item_code = models.CharField('redeemed_item_code', max_length=32, null=True, blank=True)
    # rebate_to_be_reducted = models.FloatField('rebate_to_be_reducted', null=True, blank=True)


class TransactDetails(models.Model):
    transaction = models.ForeignKey(to='Transaction', related_name='transact_details', on_delete=models.CASCADE)
    product = models.ForeignKey(to='Product', related_name='transact_details', on_delete=models.CASCADE)
    productName= models.CharField('productName', max_length=128, null=True, blank=True,default='')
    chineseName = models.CharField('chineseName', max_length=128, null=True, blank=True, default='')
    #修改models.ForeignKey为ManyToMany
    toppings = models.ManyToManyField(to='Toppings', related_name='transact_details',  null=True,
                                 blank=True)
    remark = models.CharField('remark', max_length=128, null=True, blank=True)
    quantity = models.IntegerField('quantity')
    price = models.FloatField('price')
    eat_in, take_out = range(2)
    METHOD_CHOICES = (
        (eat_in, 'eat in'),
        (take_out, 'take out'),
    )
    method = models.IntegerField("method", choices=METHOD_CHOICES, help_text="0:eat in,1:take out", null=True, blank=True)
    ZERO_SUGAR, NORMAL_SUGAR = range(2)
    SUGAR_TYPE_CHOICES = (
        (ZERO_SUGAR, 'ZERO_SUGAR'),
        (NORMAL_SUGAR, 'NORMAL_SUGAR'),
    )
    sugar_type = models.IntegerField("sugar_type", choices=SUGAR_TYPE_CHOICES, help_text="0:zero sugar,1:normal sugar")
    LESS, MORE ,TALL= range(3)
    SWEETNAEE_CHOICES = (
        (LESS, 'less'),
        (MORE, 'more'),
        (TALL, 'tall'),
    )
    sweetness = models.IntegerField("sweetness", choices=SWEETNAEE_CHOICES, help_text="0:less,1:more,2:tall", null=True,
                                    blank=True)

    MEDIUM, LARGE, TALL = range(3)
    SIZE_CHOICES = (
        ( MEDIUM, 'medium'),
        (LARGE, 'large'),
        (TALL, 'tall'),
    )
    size = models.IntegerField("size", choices=SIZE_CHOICES, help_text="0:medium,1:large,2:tall", null=True,
                                    blank=True)

    NORMAL, LESS_ICE, FILTER_ICE ,MORE_ICE,FILTER_PRICE_ICE,WATER_ROOM_TEMPERATURE,WATER_WARM= range(7)
    ICE_LEVEL_CHOICES = (
        (NORMAL, 'Normal'),
        (LESS_ICE, 'Less Ice'),
        (FILTER_ICE, 'Filter Ice'),
        (MORE_ICE,'More Ice'),
        (FILTER_PRICE_ICE,'Filter Price Ice'),
        (WATER_ROOM_TEMPERATURE,'Water Room Temperature'),
        (WATER_WARM,'Water Warm'),
    )
    ice_level = models.IntegerField("ice_level", choices=ICE_LEVEL_CHOICES, help_text="0:normal,1:less ice,2:Filter Ice,3:More Ice,4:Filter Price Ice,5:Water Room Temperature,6:Water Warm",
                                    null=True, blank=True)
    ZERO, TWRNTY_FIVE, FIFTY, SEVENTY_FIVE, ONE_HUNDRED,ONE_TWRNTY_FIVE ,NONE_SUGAR= range(7)
    SUGAR_LEVEL_CHOICES = (
        (ZERO, "0%"),
        (TWRNTY_FIVE, "25%"),
        (FIFTY, "50%"),
        (SEVENTY_FIVE, "75%"),
        (ONE_HUNDRED, "100%"),
        (ONE_TWRNTY_FIVE,"125%"),
        (NONE_SUGAR,"NONE_SUGAR")
    )
    sugar_level = models.IntegerField("sugar_level", choices=SUGAR_LEVEL_CHOICES,
                                      help_text="0:0%,1:25%,2:50%,3:75%,4:100%,5:125%,6:none", null=True, blank=True)

    ZERO, TWRNTY_FIVE, FIFTY, SEVENTY_FIVE, ONE_HUNDRED, ONE_TWRNTY_FIVE ,NONE_HONEY= range(7)
    HONEY_LEVEL_CHOICES = (
        (ZERO, "0%"),
        (TWRNTY_FIVE, "25%"),
        (FIFTY, "50%"),
        (SEVENTY_FIVE, "75%"),
        (ONE_HUNDRED, "100%"),
        (ONE_TWRNTY_FIVE, "125%"),
        (NONE_HONEY,"NONE_HONEY")
    )
    honey_level = models.IntegerField("honey_level", choices=HONEY_LEVEL_CHOICES,
                                      help_text="0:0%,1:25%,2:50%,3:75%,4:100%,5:125%,6:none", null=True, blank=True)

    #HoneyLevel
    ZERO, TWRNTY_FIVE, FIFTY, SEVENTY_FIVE, ONE_HUNDRED,ONE_TWRNTY_FIVE = range(6)
    CONCENTRATION_CHOICES = (
        (ZERO, "0%"),
        (TWRNTY_FIVE, "25%"),
        (FIFTY, "50%"),
        (SEVENTY_FIVE, "75%"),
        (ONE_HUNDRED, "100%"),
        (ONE_TWRNTY_FIVE, "125%"),
    )
    concentration = models.IntegerField("concentration", choices=CONCENTRATION_CHOICES,
                                        help_text="0:0%,1:25%,2:50%,3:75%,4:100%,5:125", null=True, blank=True)
    qball_selection = models.CharField('qball_selection', max_length=128, null=True, blank=True,default='')
    SMALL,MEDIUM,LARGE,TALL=range(4)
    SPICY_CHOICES = (
        (SMALL, 'Mild Spicy'),
        (MEDIUM, 'Less Spicy'),
        (LARGE, 'Medum Spicy'),
        (TALL, 'Extra Spicy'),
    )
    spicy_level = models.IntegerField("spicy_level", choices=SPICY_CHOICES, help_text="0:Mild Spicy,1:Less Spicy,2:Medum Spicy,3:Extra Spicy", null=True,
                               blank=True)
    TEA, SPICY,DISH = range(3)
    TRANSACTDETAILS_CHOICES = (
        (TEA, 'tea'),
        (SPICY, 'spicy'),
        (DISH, 'dish'),
    )
    transactDetails_type=models.IntegerField("transactDetails_type", choices=TRANSACTDETAILS_CHOICES, help_text="0:tea,1:spicy,2:dish", null=True,
                               blank=True)
    CORIANDER_YES, CORIANDER_NO = range(2)
    CORIANDER_CHOICES = (
        (CORIANDER_NO, 'no'),
        (CORIANDER_YES, 'yes'),

    )
    coriander_choice=models.IntegerField("coriander_choice", choices=CORIANDER_CHOICES, help_text="0:no,1:yes", null=True,
                               blank=True)

    PEANUT_YES, PEANUT_NO = range(2)
    PEANUT_CHOICES = (
        (PEANUT_NO, 'no'),
        (PEANUT_YES, 'yes'),

    )
    peanut_choice = models.IntegerField("peanut_choice", choices=PEANUT_CHOICES, help_text="0:no,1:yes",
                                           null=True,
                                           blank=True)

    single_price = models.FloatField('single_price', null=True, blank=True)
    image_path = models.CharField('image_path', max_length=128, null=True, blank=True, default='')
    group = models.CharField('group', max_length=128, null=True, blank=True, default='')
    item_code=models.CharField('item_code', max_length=128, null=True, blank=True, default='')
class SignedPrize(models.Model):
    index= models.IntegerField('index', null=True, blank=True)
    name=models.CharField('name', max_length=250, null=True, blank=True)
    img_url = models.CharField('img_url', max_length=250, null=True, blank=True)
    signed_img_url = models.CharField('signed_img_url', max_length=250, null=True, blank=True)
    voucher=models.ForeignKey(to='Voucher', related_name='signedPrize', null=True,blank=True,on_delete=models.CASCADE)

class PuzzleImage(models.Model):

    img_url = models.CharField('img_url', max_length=250, null=True, blank=True)
    probability = models.FloatField(verbose_name='probability', default=1)
    max_quantity=models.IntegerField(verbose_name='max_quantity', default=0)
    status=models.NullBooleanField('enable status', null=True, blank=True,default=False)
    sort_index=models.IntegerField(verbose_name='sort_index', default=0)
class PuzzleImageLog(models.Model):
    signed_order_record = models.ForeignKey(to='SignedOrderRecord', related_name='puzzleItem', null=True, blank=True,on_delete=models.CASCADE)
    member=models.ForeignKey(to='Member', related_name='puzzleLog', null=True,blank=True,on_delete=models.CASCADE)
    puzzle_image=models.ForeignKey(to='PuzzleImage', related_name='puzzleLog', null=True,blank=True,on_delete=models.CASCADE)
    puzzle_image_url = models.CharField('puzzle_image_url', max_length=250, null=True, blank=True)
    created=models.DateTimeField('created', auto_now_add=True)
    status = models.NullBooleanField('temp status', null=True, blank=True, default=False)
class PuzzleProbability(models.Model):
    puzzle_image=models.ForeignKey(to='PuzzleImage', related_name='puzzleImage', null=True, blank=True, on_delete=models.CASCADE)
    rand_number=models.IntegerField(verbose_name='rand_number', default=0)
class PuzzleTimesCache(models.Model):
    puzzle_times=models.IntegerField(verbose_name='puzzle_times', default=0)
    now_date = models.DateField('now_date', auto_now_add=True)
class SignedGlobalIndex(models.Model):
    member = models.ForeignKey(to='Member', related_name='globalIndex', null=True, blank=True,on_delete=models.CASCADE)
    circle_status = models.NullBooleanField('life cycle status', null=True, blank=True, default=False)
    all_signed = models.NullBooleanField('all signed', null=True, blank=True, default=False)
class SignedOrderRecord(models.Model):
    signed_global_index=models.ForeignKey(to='SignedGlobalIndex', related_name='global_index', null=True,blank=True,on_delete=models.CASCADE)
    member=models.ForeignKey(to='Member', related_name='signedRecord', null=True,blank=True,on_delete=models.CASCADE)
    transaction=models.ForeignKey(to='Transaction', related_name='signedRecord', null=True,blank=True,on_delete=models.CASCADE)
    electronic_signed = models.NullBooleanField('electronic_signed', null=True, blank=True, default=False)
    NULL, PUZZLE, PRIZE = range(3)
    SIGNED_CHOICES = (
        (NULL, 'NULL'),
        (PUZZLE, 'PUZZLE'),
        (PRIZE, 'PRIZE'),

    )
    signed_type = models.IntegerField("signed_type", choices=SIGNED_CHOICES, help_text="0:null,1:puzzle,2:prize",
                                      null=True,
                                      blank=True, default=NULL)
    puzzle_image = models.ForeignKey(to='PuzzleImage', related_name='transDetails', null=True, blank=True,
                                     on_delete=models.CASCADE)


    signed_prize = models.ForeignKey(to='SignedPrize', related_name='transDetails', null=True, blank=True,on_delete=models.CASCADE)
    null_image_url = models.CharField('null_image_url', max_length=250, null=True, blank=True, default='https://crm.itea.sg/tea_imgs2/signed/null.gif')
    signed_null_image_url = models.CharField('signed_null_image_url', max_length=250, null=True, blank=True,default='https://crm.itea.sg/tea_imgs2/signed/signed_null.png')
    puzzle_image_url = models.CharField('puzzle_image_url', max_length=250, null=True, blank=True)
    prize_image_url = models.CharField('prize_img_url', max_length=250, null=True, blank=True)
    signed_prize_image_url = models.CharField('signed_prize_image_url', max_length=250, null=True, blank=True)
    circle_status = models.NullBooleanField('life cycle status', null=True, blank=True, default=False)
    circle_index = models.IntegerField('circle_index', null=True, blank=True)
    fake_image_url = models.CharField('fake_image_url', max_length=250, null=True, blank=True)
    fake = models.NullBooleanField('fake', null=True, blank=True, default=False)
    created = models.DateTimeField('created', auto_now_add=True)
class Wallet(models.Model):
    balance = models.FloatField('balance', default=0)
    created = models.DateTimeField('created', auto_now_add=True)
    lastest_top_up = models.DateField('lastest_top_up', null=True, blank=True)
    member = models.OneToOneField(to='Member', related_name='wallet', on_delete=models.CASCADE)
    grab_token=models.CharField('grab_token', max_length=2500, null=True, blank=True)
    grab_expire = models.BigIntegerField("grab_expire", null=True, blank=True)

class RechargeRecord(models.Model):
    money = models.FloatField('money')
    created = models.DateTimeField('created', auto_now_add=True)
    wallet = models.ForeignKey(to='Wallet', related_name='rechargerecord',
                               on_delete=models.CASCADE)
    TYPE_CHOICES = (
        (0, "recharge"),
        (1, "order deduction"),
        (2, "order cancel"),
        (3,"coupon cashback"),
        (4, "coupon deduction"),
        (5, "credit card payment"),
        (6, "Grabpay payment"),
        (7, "ipay scan payment"),
        (8, "Google payment"),
        (9, "Apple payment"),

    )
    type = models.IntegerField(default="0", null=False, choices=TYPE_CHOICES)
    TOPUP_TYPE_CHOICES = (
        (0, "credit card"),
        (1, "grab pay"),
        (2, "google pay"),
        (3, "apple pay"),


    )
    topup_type = models.IntegerField(default="0", null=True, choices=TOPUP_TYPE_CHOICES)
    request_id=models.CharField('request_id', max_length=128, null=True, blank=True)
    SUCCESS,FAILURE=range(2)
    TOPUP_CHOICES = (
        (SUCCESS, 'success'),
        (FAILURE, 'failure'),
    )
    status = models.IntegerField(
        "status",
        choices=TOPUP_CHOICES,
        help_text="0:failure,1:success",
        null=True,
        blank=True
    )

    grab_txID=models.CharField('grab_txID', max_length=128, null=True, blank=True)
    outlet_id=models.IntegerField("outlet_id", null=True, blank=True)
    class Meta:
        ordering = ['-id']

class Evaluation(models.Model):
    service_content = models.CharField('service_content', max_length=128, null=True, blank=True)
    A, B, C, D, E, F, G, H, I, J = range(10)
    SCORE_CHOICES = (
        (A, 1),
        (B, 2),
        (C, 3),
        (D, 4),
        (E, 5),
        (F, 6),
        (G, 7),
        (H, 8),
        (I, 9),
        (J, 10),
    )
    service_satisfaction = models.PositiveSmallIntegerField('service_satisfaction', choices=SCORE_CHOICES)
    product_quality_content = models.CharField('product_quality_content', max_length=128, null=True, blank=True)
    product_quality_satisfaction = models.PositiveSmallIntegerField('product_quality_satisfaction',
                                                                    choices=SCORE_CHOICES)
    created = models.DateTimeField('created', auto_now_add=True)
    transaction = models.ForeignKey(to='Transaction', related_name='evaluation',
                                    on_delete=models.CASCADE)


class Cart(models.Model):
    product = models.ForeignKey(to='Product', related_name='cart', on_delete=models.CASCADE)
    member = models.ForeignKey(to='Member', related_name='cart', on_delete=models.CASCADE)
    quantity = models.IntegerField('quantity')
    price = models.FloatField('price')
    created = models.DateTimeField('created', auto_now_add=True)
    updated = models.DateTimeField('updated', auto_now=True)
    A, B, C, D = range(4)
    STATUS_CHOICES = (
        (A, 'active'),
        (B, 'bought'),
        (C, 'deleted'),
        (D, 'invalid'),
    )
    status = models.IntegerField(
        "status",
        choices=STATUS_CHOICES,
        help_text="0:active,1:bought,2:deleted,3:invalid",
        default=A
    )
    flavours = models.CharField('flavours', max_length=32, null=True, blank=True)
    FRUIT_TEA, PREMUM_TEA, MILK_TEA = range(3)
    TEA_BASE_CHOICES = (
        (FRUIT_TEA, 'FRUIT TEA'),
        (PREMUM_TEA, 'PREMUM TEA'),
        (MILK_TEA, 'MILK TEA'),
    )
    tea_base = models.IntegerField(
        "tea_base",
        choices=TEA_BASE_CHOICES,
        help_text="0:FRUIT TEA,1:PREMUM TEA,2:MILK TEA",
        null=True,
        blank=True
    )
    LESS, MORE = range(2)
    SWEETNAEE_CHOICES = (
        (LESS, 'less'),
        (MORE, 'more'),
    )
    sweetness = models.IntegerField(
        "sweetness",
        choices=SWEETNAEE_CHOICES,
        help_text="0:less,1:more",
        null=True, blank=True)
    MEDIUM, LARGE = range(2)
    SIZE_CHOICES = (
        (MEDIUM, 'Meduim'),
        (LARGE, 'Large'),
    )
    size = models.IntegerField(
        "size",
        choices=SIZE_CHOICES,
        help_text="0:Meduim,1:Large",
        null=True, blank=True)
    No_Pearls, AiYu_Jelly, Golden_Bubbles, Oreo, White_Jelly, Whipped_Cream = range(6)
    toppings_choices = (
        (No_Pearls, "No Pearls"),
        (AiYu_Jelly, "AiYu Jelly"),
        (Golden_Bubbles, "Golden Bubbles"),
        (Oreo, "Oreo"),
        (White_Jelly, "White Jelly"),
        (Whipped_Cream, "Whipped Cream"),
    )
    toppings = models.IntegerField(
        "toppings",
        choices=toppings_choices,
        help_text="0:No Pearls,1:AiYu Jelly,2:Golden Bubbles,3:Oreo,4:White Jelly,5:Whipped Cream",
        null=True, blank=True)
    NORMAL, LESS_ICE, NO_ICE = range(3)
    ICE_LEVEL_CHOICES = (
        (NORMAL, 'Normal'),
        (LESS_ICE, 'Less Ice'),
        (NO_ICE, 'No Ice'),
    )
    ice_level = models.IntegerField(
        "ice_level",
        choices=ICE_LEVEL_CHOICES,
        help_text="0:normal,1:less ice,2:no ice",
        default=1,
        null=True,
        blank=True
    )
    ZERO, TWRNTY_FIVE, FIFTY, SEVENTY_FIVE, ONE_HUNDRED = range(5)
    SUGAR_LEVEL_CHOICES = (
        (ZERO, "0%"),
        (TWRNTY_FIVE, "25%"),
        (FIFTY, "50%"),
        (SEVENTY_FIVE, "75%"),
        (ONE_HUNDRED, "100%"),
    )
    sugar_level = models.IntegerField(
        "sugar_level",
        choices=SUGAR_LEVEL_CHOICES,
        help_text="0:0%,1:25%,2:50%,3:75%,4:100%",
        default=1,
        null=True, blank=True)
    ZERO, TWRNTY_FIVE, FIFTY, SEVENTY_FIVE, ONE_HUNDRED = range(5)
    CONCENTRATION_CHOICES = (
        (ZERO, "0%"),
        (TWRNTY_FIVE, "25%"),
        (FIFTY, "50%"),
        (SEVENTY_FIVE, "75%"),
        (ONE_HUNDRED, "100%"),
    )
    concentration = models.IntegerField(
        "concentration",
        choices=CONCENTRATION_CHOICES,
        help_text="0:0%,1:25%,2:50%,3:75%,4:100%",
        default=1,
        null=True,
        blank=True
    )
    is_new = models.BooleanField('is_new', default=False)


class Token(authToken):
    user=models.ForeignKey(to='Member', related_name='m_token', on_delete=models.CASCADE)
    key=models.CharField(verbose_name='key', max_length=500)
    created=models.DateTimeField('created', auto_now_add=True)

# 访问网站的ip地址和次数
class Userip(models.Model):
    ip = models.CharField(verbose_name='IP', max_length=15000)  # ip地址
    request = models.CharField(verbose_name='request', max_length=15000)
    count = models.IntegerField(verbose_name='visitCount', default=0)  # 该ip访问次数

    class Meta:
        verbose_name = 'visitor info'
        verbose_name_plural = verbose_name

    def __str__(self):
        return self.ip


# 网站总访问次数
class VisitNumber(models.Model):
    count = models.IntegerField(verbose_name='visit sum times', default=0)  # 网站访问总次数

    class Meta:
        verbose_name = 'visit sum times'
        verbose_name_plural = verbose_name

    def __str__(self):
        return str(self.count)


# 单日访问量统计
class DayNumber(models.Model):
    day = models.DateField(verbose_name='day', default=timezone.now)
    count = models.IntegerField(verbose_name='visit count', default=0)  # 网站访问总次数

    class Meta:
        verbose_name = 'visit times per day'
        verbose_name_plural = verbose_name

    def __str__(self):
        return str(self.day)
class Modify:
    pass

class GrabPayPos(models.Model):


    txType = models.CharField('txType', max_length=50, null=False, default='')
    partnerID = models.CharField('partnerID', max_length=50, null=False, default='')
    partnerTxID = models.CharField('partnerTxID', max_length=50, null=False, default='')
    txID = models.CharField('txID', max_length=50, null=False, default='')
    origTxID = models.CharField('origTxID', max_length=50, null=False, default='')


    amount = models.BigIntegerField('amount',null=False, default=0)
    currency = models.CharField('currency', max_length=50, null=False, default='')
    status = models.CharField('status', max_length=50, null=False, default='')
    createdAt = models.BigIntegerField('createdAt', null=False, default=0)
    completedAt = models.BigIntegerField('completedAt', null=False, default=0)
    payload = models.TextField('payload', null=False, default='')

class CampaignOneRedeemtionPerDay(models.Model):


    ic_number = models.CharField('ic number', max_length=50, null=True, default='')
    mask_code=models.CharField('ic number', max_length=50, null=True, default='')
    redeemtion_date = models.DateField('redeemtion date',  null=True,blank=True)
    redeemtion_time = models.TimeField('redeemtion time ', null=True,blank=True)
    redeemtion_outlet = models.ForeignKey(to='Outlet', related_name='m_campaign', on_delete=models.CASCADE)

class CampaignTopup(models.Model):
    topup_10_return_cash=models.FloatField('topup_10_return_cash', default=0)
    topup_10_limit_times=models.IntegerField(verbose_name='topup_10_limit_times', default=0)
    topup_20_return_cash = models.FloatField('topup_20_return_cash', default=0)
    topup_20_limit_times = models.IntegerField(verbose_name='topup_20_limit_times', default=0)
    topup_50_return_cash = models.FloatField('topup_50_return_cash', default=0)
    topup_50_limit_times = models.IntegerField(verbose_name='topup_50_limit_times', default=0)
    topup_100_return_cash = models.FloatField('topup_100_return_cash', default=0)
    topup_100_limit_times = models.IntegerField(verbose_name='topup_100_limit_times', default=0)
    start_date=models.DateField('start_date',  null=True,blank=True)
    end_date = models.DateField('end_date', null=True, blank=True)
    times_limit_flag= models.BooleanField('times_limit_flag', default=False)
    date_limit_flag= models.BooleanField('date_limit_flag', default=False)
    activity_flag= models.BooleanField('activity_flag', default=False)


class CampaignPurchase(models.Model):
    purchase_return_wallet_percent=models.FloatField('purchase_return_wallet_percent', default=0)
    max_return_wallet_amount=models.IntegerField(verbose_name='max_return_wallet_amount', default=0)
    limit_times=models.IntegerField(verbose_name='limit_times', default=0)
    times_limit_flag = models.BooleanField('times_limit_flag', default=False)
    activity_flag = models.BooleanField('activity_flag', default=False)


class Campaign_Wallet(models.Model):
    purchase_return_wallet_percent=models.FloatField('purchase_return_wallet_percent', default=0)
    activity_status= models.BooleanField('activity_flag', default=False)

class Campaign_Invitation_Code(models.Model):
    invitation_times=models.IntegerField(verbose_name='invitation_times', default=0)
    register_cash_back=models.FloatField('register_cash_back', default=0)
    inviter_cash_back = models.FloatField('inviter_cash_back', default=0)
    voucher =models.ForeignKey(to='Voucher', related_name='intite_code',
                               on_delete=models.CASCADE)
    activity_status = models.BooleanField('activity_flag', default=False)

class Campaign_Register(models.Model):

    register_cash_back=models.FloatField('register_cash_back', default=0)
    voucher = models.ForeignKey(to='Voucher', related_name='register',
                                on_delete=models.CASCADE)
    activity_status = models.BooleanField('activity_flag', default=False)

class Invite_Code(models.Model):
    invite_code=models.CharField('invite_code', max_length=20, null=True, default='')
    activate_status= models.BooleanField('activate_status', default=False)

class Advertising(models.Model):
    title=models.CharField('title', max_length=50, null=True, default='')
    url= models.CharField('title', max_length=250, null=True, default='')
    outlet=models.ForeignKey(to='Outlet', related_name='adv', null=True, on_delete=models.CASCADE)
    class Meta:
        ordering = ['-id']

class TransactDetails_Spicy(models.Model):
    transactdetails= models.ForeignKey(to='TransactDetails', related_name='transactDetails_spicy', on_delete=models.CASCADE)
    toppings = models.ForeignKey(to='Toppings', related_name='toppings', on_delete=models.CASCADE)
    t_number = models.IntegerField(verbose_name='number', default=0)
    topping_name = models.CharField('topping_name', max_length=250, null=True, default='')
    topping_chinese_name = models.CharField('topping_chinese_name', max_length=250, null=True, default='')
class TransactDetails_Group_Attribute(models.Model):
    transactdetails = models.ForeignKey(to='TransactDetails', related_name='transactDetails_group_attribute',on_delete=models.CASCADE)
    group= models.ForeignKey(to='Group', related_name='transactDetails_group', on_delete=models.CASCADE)
    attribute = models.ForeignKey(to='Attribute', related_name='transactDetails_attribute', on_delete=models.CASCADE)

    group_name = models.CharField('group_name', max_length=250, null=True, default='')
    attribute_name = models.CharField('attribute_name', max_length=250, null=True, default='')
    price = models.FloatField('price')
class WirecardLog(models.Model):
    request_id = models.CharField('request_id', max_length=50, null=True, default='')
    amount = models.FloatField('amount', default=0)
    PURCHASE, TOPUP = range(2)
    PAYMENT_TYPE = (
        (PURCHASE, "PURCHASE"),
        (TOPUP, "TOPUP"),

    )
    payment_type= models.IntegerField(
        "payment_type",
        choices=PAYMENT_TYPE,
        help_text="0:PURCHASE,1:TOPUP",
        default=0,
        null=True,
        blank=True
    )
    created = models.DateTimeField('created', auto_now_add=True)
    member = models.ForeignKey(to='Member', related_name='wirecard', on_delete=models.CASCADE)
    SUCCESS, FAIL = range(2)
    STATUS_TYPE = (
        (SUCCESS, "SUCCESS"),
        (FAIL, "FAIL"),

    )
    status = models.IntegerField(
        "status_type",
        choices=STATUS_TYPE,
        help_text="0:PURCHASE,1:TOPUP",
        default=0,
        null=True,
        blank=True
    )

#manual topup
class TopupRecord(models.Model):
    member=models.ForeignKey(to='Member', related_name='topup',
                               on_delete=models.CASCADE)
    mobile=models.CharField('mobile', max_length=30, null=True, blank=True)
    outlet=models.ForeignKey(to='Outlet', related_name='topup',
                               on_delete=models.CASCADE)
    outlet_name=models.CharField('outlet_name', max_length=100, null=True, blank=True)
    money = models.FloatField('money')
    created = models.DateTimeField('created', auto_now_add=True)
    created_date=models.DateField('created_date', auto_now_add=True)
    REFUND, TOPUP = range(2)
    PAYMENT_TYPE = (
        (REFUND, "REFUND"),
        (TOPUP, "TOPUP"),

    )
    payment_type = models.IntegerField(
        "payment_type",
        choices=PAYMENT_TYPE,
        help_text="0:REFUND,1:TOPUP",
        default=1,
        null=True,
        blank=True
    )

    class Meta:
        ordering = ['-id']

class OpenAdvertising(models.Model):
    title=models.CharField('title', max_length=50, null=True, default='')
    url= models.CharField('title', max_length=250, null=True, default='')
    status= models.NullBooleanField('status',  null=True, blank=True,default=True)
    class Meta:
        ordering = ['-id']

#manual refund
class RefundRecord(models.Model):
    member=models.ForeignKey(to='Member', related_name='refund',
                               on_delete=models.CASCADE)
    mobile=models.CharField('mobile', max_length=30, null=True, blank=True)
    outlet=models.ForeignKey(to='Outlet', related_name='refund',
                               on_delete=models.CASCADE)
    outlet_name=models.CharField('outlet_name', max_length=100, null=True, blank=True)
    money = models.FloatField('money')
    created = models.DateTimeField('created', auto_now_add=True)
    created_date=models.DateField('created_date', auto_now_add=True)
    class Meta:
        ordering = ['id']

class TopupImgs(models.Model):
    title=models.CharField('title', max_length=50, null=True, default='')
    url= models.CharField('url', max_length=250, null=True, default='')

    class Meta:
        ordering = ['-id']

class Holiday(models.Model):
    holiday = models.CharField('title', max_length=50, null=True, default='')


    class Meta:
        ordering = ['-id']

class Outlet_Opening(models.Model):
    outlet=models.ForeignKey(to='Outlet', related_name='opening',on_delete=models.CASCADE)
    open_time=models.CharField('open_time', max_length=50, null=True, default='')
    close_time=models.CharField('close_time', max_length=50, null=True, default='')
    week_num=models.IntegerField(verbose_name='week_num', default=0)
    class Meta:
        ordering = ['week_num']
class WalletBalance(models.Model):
    balance = models.FloatField('balance')
    test_balance=models.FloatField('balance')
    record_date=models.DateField('record_date', auto_now_add=True)

class Bind_Voucher(models.Model):
    voucher = models.ForeignKey(to='Voucher', related_name='bind_second',on_delete=models.CASCADE)
    activity_flag=models.NullBooleanField('activity_flag', null=True, blank=True,default=False)
class Bind_Second_Voucher(models.Model):
    voucher = models.ForeignKey(to='Voucher', related_name='bind',on_delete=models.CASCADE)
    activity_flag=models.NullBooleanField('activity_flag', null=True, blank=True,default=False)
class Bind_Third_Voucher(models.Model):
    voucher = models.ForeignKey(to='Voucher', related_name='bind_third',on_delete=models.CASCADE)
    activity_flag=models.NullBooleanField('activity_flag', null=True, blank=True,default=False)
class PrizeActivity(models.Model):
    url=models.CharField('url', max_length=50, null=True, default='')
    backgroud_color=models.CharField('app_banner_color', max_length=50, null=True, default='')
    activity_status=models.NullBooleanField('activity_status', null=True, blank=True,default=False)
    img_url = models.CharField('img_url', max_length=250, null=True, default='')
class ActivityTimes(models.Model):
    start_time=models.CharField('start_time', max_length=50, null=True, default='')
    end_time = models.CharField('end_time', max_length=50, null=True, default='')
class Prize(models.Model):
    name=models.CharField('name', max_length=50, null=True, default='')
    VOUCHER, CASH,OTHER,THANK = range(4)
    PRIZE_TYPE = (
        (VOUCHER, "VOUCHER"),
        (CASH, "CASH"),
        (OTHER, "OTHER"),
        (THANK, "THANK"),
    )
    prize_type = models.IntegerField(
        "prize_type",
        choices=PRIZE_TYPE,
        help_text="0:VOUCHER,1:CASH,2:OTHER,3:THANK",
        default=0,
        null=True,
        blank=True
    )
    voucher = models.ForeignKey(to='Voucher', related_name='prize', null=True,blank=True,on_delete=models.CASCADE)
    img_url=models.CharField('img_url', max_length=500, null=True, default='')
    amount=models.FloatField('amount')
    prize_quantity=models.IntegerField(verbose_name='prize_quantity', default=0)
    max_quantity_per_day = models.IntegerField(verbose_name='max_quantity_per_day', default=0)
    generate_per_prizes=models.IntegerField(verbose_name='generate_per_prizes', default=0)
    status=models.NullBooleanField('prize_flag', null=True, blank=True,default=False)
    index=models.IntegerField(verbose_name='html_index', default=0)
    activity_prize_flag=models.NullBooleanField('prize_flag', null=True, blank=True,default=False)
    none_purchase_enable=models.NullBooleanField('none_purchase_enable', null=True, blank=True,default=False)

class PrizeLog(models.Model):
    member=models.ForeignKey(to='Member', related_name='prizeLog', null=True,blank=True,on_delete=models.CASCADE)
    prize=models.ForeignKey(to='Prize', related_name='prizeLog', null=True,blank=True,on_delete=models.CASCADE)

    created=models.DateTimeField('created', auto_now_add=True)
class PrizeCacheLog(models.Model):
    member=models.ForeignKey(to='Member', related_name='prizeCacheLog', null=True,blank=True,on_delete=models.CASCADE)
    prize_status=models.NullBooleanField('prize_status', null=True, blank=True,default=False)
    prize_selected_list=models.CharField('prize_selected_list', max_length=500, null=True, default='')
    created=models.DateTimeField('created', auto_now_add=True)
class PrizeMemberLog(models.Model):
    member = models.ForeignKey(to='Member', related_name='prizeMemberLog', null=True, blank=True, on_delete=models.CASCADE)
    used_prize_times = models.IntegerField(verbose_name='used_prize_times', default=0)
    prize_times=models.IntegerField(verbose_name='prize_times', default=1)
    prize_status=models.NullBooleanField('prize_status', null=True, blank=True,default=False)
    prize_date = models.DateField('prize_date', auto_now_add=True)
    all_used_prize_times = models.IntegerField(verbose_name='all_used_prize_times', default=0)
class PrizeTimesSet(models.Model):
    none_purchase_prize_times=models.IntegerField(verbose_name='none_purchase_prize_times', default=1)
    purchase_prize_times = models.IntegerField(verbose_name='purchase_prize_times', default=1)
    amount_prize_times=models.FloatField('amount_prize_times', default=0)
    activity_prize_times = models.IntegerField(verbose_name='activity_prize_times', default=1)
    activity_circles= models.IntegerField(verbose_name='activity_circles', default=1)
class PrizeClassSet(models.Model):
    prize=models.ManyToManyField(to='Prize', related_name='prize_class',  null=True,
                                 blank=True)
    prize_title=models.CharField('prize_title', max_length=50, null=True, default='')
    prize_name = models.CharField('prize_name', max_length=50, null=True, default='')
    prize_generate_interval_times= models.IntegerField(verbose_name='prize_generate_interval_times', default=0)
    prize_generate_excursion_times = models.IntegerField(verbose_name='prize_generate_excursion_times', default=0)
    today_generate_interval_times= models.IntegerField(verbose_name='prize_generate_interval_times', default=0)
    today_generate_status = models.NullBooleanField('today_generate_status', null=True, blank=True,default=False)
    now_date=models.DateField('now_date', auto_now_add=True)
    max_number_per_day=models.IntegerField(verbose_name='max_number_per_day', default=0)

    probability= models.FloatField(verbose_name='probability', default=1)
    activity_flag = models.NullBooleanField('activity_flag', null=True, blank=True, default=False)
    activity_probability = models.FloatField(verbose_name='activity_probability', default=1)
class PrizeProbability(models.Model):
    prize_class_set=models.ForeignKey(to='PrizeClassSet', related_name='prizeClassSet', null=True, blank=True, on_delete=models.CASCADE)
    rand_number=models.IntegerField(verbose_name='rand_number', default=0)


class PrizeProbabilityActivity(models.Model):
    prize_class_set=models.ForeignKey(to='PrizeClassSet', related_name='prizeClassSetActivity', null=True, blank=True, on_delete=models.CASCADE)
    rand_number=models.IntegerField(verbose_name='rand_number', default=0)

class PrizeTimesCache(models.Model):
    prize_times=models.IntegerField(verbose_name='prize_times', default=0)
    now_date = models.DateField('now_date', auto_now_add=True)

class Activity(models.Model):
    activity_url= models.CharField('activity_url', max_length=500, null=True, default='')
    img_url = models.CharField('img_url', max_length=500, null=True, default='')
    activity_flag = models.NullBooleanField('activity_flag', null=True, blank=True, default=False)
    activity_name = models.CharField('activity_name', max_length=500, null=True, default='')
class DeliverySet(models.Model):
    outlet=models.ForeignKey(to='Outlet', related_name='delivery_outlet', null=True, blank=True, on_delete=models.CASCADE)
    start_date=models.DateField('start_date', null=True, blank=True)
    end_date = models.DateField('end_date', null=True, blank=True)
    max_show_days = models.IntegerField('max_show_days', null=True, default=1)
    today_enable=models.NullBooleanField('today_enable', null=True, blank=True,default=False)
    min_delivery_fee=models.FloatField('min_delivery_fee', default=0)
    max_delivery_fee = models.FloatField('max_delivery_fee', default=0)
    min_limit_minute = models.IntegerField(verbose_name='min_limit_minute', default=0)
    max_limit_minute = models.IntegerField(verbose_name='max_limit_minute', default=0)
    min_start_time=models.CharField('min_start_time', max_length=50, null=True, default='')
    max_end_time = models.CharField('max_end_time', max_length=50, null=True, default='')
    interval_minute= models.IntegerField('interval_minute',  null=True, default=0)
    tomorrow_pickup_end_order_time = models.CharField('pickup_order_end_time', max_length=50, null=True, default='')
    tomorrow_pickup_end_order_time_enable = models.NullBooleanField('tomorrow_pickup_end_order_time_enable', null=True, blank=True, default=False)
    tomorrow_delivery_end_order_time = models.CharField('tomorrow_delivery_end_order_time', max_length=50, null=True, default='')
    tomorrow_delivery_end_order_time_enable = models.NullBooleanField('tomorrow_delivery_end_order_time_enable', null=True,blank=True, default=False)
    deliveryweektimes = models.ManyToManyField(to='DeliveryWeekTimes', related_name='delivery_week_times', null=True,
                                                 blank=True)

class DeliveryWeekTimes(models.Model):
    outlet_id=models.IntegerField('outlet_id',  null=True, default=0)
    week=models.IntegerField(verbose_name='week_num 0-6:monday-sunday', default=0)
    deliverytimes=models.ManyToManyField(to='DeliveryTimes', related_name='delivery_week_times',  null=True,blank=True)
class DeliveryTimes(models.Model):

    delivery_times =  models.CharField('delivery_times', max_length=50, null=True, default='')
    enable=models.NullBooleanField('enable', null=True, blank=True,default=False)
'''
class Member_delivery_Address(models.Model):
    member=models.ForeignKey(to='Member', related_name='address_member', null=True,blank=True,on_delete=models.CASCADE)
    house_number=models.CharField('house_number', max_length=500, null=True, default='')
    company = models.CharField('company', max_length=50, null=True, default='')
    address=models.CharField('address', max_length=50, null=True, default='')
'''
###############################################################################################
#delivery app

class Driver(models.Model):

    mobile_no = models.CharField('mobile_no', max_length=64, unique=True)

    name = models.CharField('name', max_length=64, null=True,blank=True)
    password = models.CharField('password', max_length=128)
    location_latitude = models.FloatField('location_latitude', default=0)
    location_longitude = models.FloatField('location_longitude', default=0)
    location_update_time = models.DateTimeField('location_update_time', null=True, blank=True)
    DIMISSION, ONJOB = range(2)
    JOB_TYPE = (
        (DIMISSION, "DIMISSION"),
        (ONJOB, "ONJOB"),

    )
    status=models.IntegerField(
        "JOB_TYPE",
        choices=JOB_TYPE,
        help_text="0:DIMISSION, 1:ONJOB",
        default=1,
        null=True,
        blank=True
    )

class DeliveryOrder(models.Model):
    transaction = models.ForeignKey(to='Transaction', related_name='delivery_order', on_delete=models.CASCADE)
    driver= models.ForeignKey(to='Driver', related_name='delivery_order', on_delete=models.CASCADE)
    driver_mobile= models.CharField('member_mobile', max_length=50, null=True, blank=True,default='')
    member_mobile = models.CharField('member_mobile', max_length=50, null=True, blank=True,default='')
    post_code = models.CharField('post_code', max_length=50, null=True, blank=True, default='')
    receipt_no = models.CharField('receipt_no', max_length=50, null=True, blank=True, default='')
    delivery_address = models.CharField('delivery_address', max_length=250, null=True, blank=True, default='')
    delivery_remark = models.CharField('delivery_remark', max_length=250, null=True, blank=True, default='')
    delivery_time = models.CharField('delivery_time', max_length=150, null=True, blank=True, default='')
    NON_PAYMENT, CANCEL, PAID, PAID_CANCEL, CONFIRM_ORDER, FINISHED = range(6)
    ORDERING_STATUS_CHOICES = (
        (NON_PAYMENT, 'None-payment'),
        (CANCEL, 'Cancel order'),
        (PAID, 'Order paid'),
        (PAID_CANCEL, 'Cancel order after paid'),
        (CONFIRM_ORDER, "CONFIRM_ORDER"),
        (FINISHED, "FINISHED"),

    )
    transaction_status = models.PositiveSmallIntegerField('transaction_status', choices=ORDERING_STATUS_CHOICES,
                                                          default=CONFIRM_ORDER)
    finish_time= models.DateTimeField('finish_time', null=True, blank=True)
    NON_DELIVERY, DELIVERING, DELIVERY_FINISHED = range(3)
    DELIVERY_STATUS_CHOICES = (
        (NON_DELIVERY, 'Non_Delivery'),
        (DELIVERING, 'Delivering'),
        (DELIVERY_FINISHED, 'Delivery_Finished'),


    )
    delivery_status=models.PositiveSmallIntegerField('delivery_status', choices=DELIVERY_STATUS_CHOICES,
                                                          default=NON_DELIVERY)


class PayMerchant(models.Model):
    logo = models.CharField('logo', max_length=500, null=True,blank=True)

    brand = models.CharField('brand', max_length=64, null=True, blank=True)
    branch = models.CharField('branch', max_length=128, null=True, blank=True)
    promotion_code = models.CharField('promotionCode', max_length=128, null=True, blank=True)
    outlet = models.ForeignKey(to='Outlet', related_name='ipay', on_delete=models.CASCADE)
    discount = models.FloatField('discount', default=0)
    discount_percent = models.FloatField('ddiscount_percent', default=0)

    DISCOUNT, DISCOUNT_PERCENT = range(2)
    DISCOUNT_TYPE = (
        (DISCOUNT, "DISCOUNT"),
        (DISCOUNT_PERCENT, "DISCOUNT_PERCENT"),

    )
    discount_type = models.IntegerField(
        "discount_type",
        choices=DISCOUNT_TYPE,
        help_text="0:DISCOUNT, 1:DISCOUNT_PERCENT",
        default=1,
        null=True,
        blank=True
    )

    cash_back = models.FloatField('cashBack', default=0)
    promotion_start_time= models.DateTimeField('promotion_start_time', null=True, blank=True)
    promotion_end_time = models.DateTimeField('promotion_end_time', null=True, blank=True)
    token = models.CharField('token', max_length=255, null=True, blank=True)

#ipay payment record
class IpayRecord(models.Model):
    member=models.ForeignKey(to='Member', related_name='ipay',
                               on_delete=models.CASCADE)
    mobile=models.CharField('mobile', max_length=30, null=True, blank=True)
    outlet=models.ForeignKey(to='Outlet', related_name='ipay_record',
                               on_delete=models.CASCADE)
    paymerchant=models.ForeignKey(to='PayMerchant', related_name='ipay',
                               on_delete=models.CASCADE)
    outlet_name=models.CharField('outlet_name', max_length=100, null=True, blank=True)
    amount=money = models.FloatField('amount')
    money = models.FloatField('money')
    created = models.DateTimeField('created', auto_now_add=True)
    created_date=models.DateField('created_date', auto_now_add=True)


    class Meta:
        ordering = ['-id']

class ShareImg(models.Model):
    url = models.CharField('url', max_length=500, null=True, blank=True)

class  Pos_Intergration_Order(models.Model):

    platformRestaurant_id=models.CharField('platformRestaurant_id', max_length=300, null=True, blank=True)
    code=models.CharField('platformOrderCode', max_length=300, null=True, blank=True)
    price_grandTotal=models.FloatField('grandTotal')
    price_subTotal = models.FloatField('subTotal')
    shortCode=models.CharField('shortCode', max_length=300, null=True, blank=True)
    createdAt=models.DateTimeField('timestamp', auto_now_add=True)
    token=models.CharField('orderToken', max_length=300, null=True, blank=True)
    customer_phoneNumber=models.CharField('customer_phoneNumber', max_length=300, null=True, blank=True)
    customer_firstName=models.CharField('customer_firstName', max_length=300, null=True, blank=True)
    customer_lastName=models.CharField('customer_lastName', max_length=300, null=True, blank=True)
    outlet=models.ForeignKey(to='Outlet', related_name='details', null=True, blank=True,on_delete=models.CASCADE)
    pos_response = models.NullBooleanField('enable', null=True, blank=True, default=False)
    cancel_status= models.NullBooleanField('cancel_status', null=True, blank=True, default=False)
class Pos_Intergration_Order_Details(models.Model):
    name = models.CharField('name', max_length=300, null=True, blank=True)
    comment= models.CharField('comment', max_length=300, null=True, blank=True,default='')
    paidPrice = models.FloatField('paidPrice')
    size = models.CharField('size', max_length=300, null=True, blank=True)
    remoteCode = models.CharField('remoteCode', max_length=300, null=True, blank=True,default='')
    order = models.ForeignKey(to='Pos_Intergration_Order', related_name='details',on_delete=models.CASCADE)
    unitPrice = models.FloatField('unit_price')
    quantity =  models.IntegerField('quantity')
class Pos_Intergration_Order_Toppings(models.Model):

    price = models.FloatField('price')
    name = models.CharField('name', max_length=300, null=True, blank=True)
    remoteCode = models.CharField('remoteCode', max_length=300, null=True, blank=True,default='')
    order_details = models.ForeignKey(to='Pos_Intergration_Order_Details', related_name='details',on_delete=models.CASCADE)

    quantity =  models.IntegerField('qty')

class Grab_Hook(models.Model):
    txType = models.CharField('txType', max_length=300, null=True, blank=True)
    partnerTxID = models.CharField('partnerTxID', max_length=300, null=True, blank=True)
    txID = models.CharField('txID', max_length=300, null=True, blank=True)
    currency = models.CharField('currency', max_length=300, null=True, blank=True)
    status = models.CharField('status', max_length=300, null=True, blank=True)

    amount=models.IntegerField('amount')
    createdAt = models.IntegerField('createdAt')
    completedAt = models.IntegerField('completedAt')

class Grab_Logs(models.Model):
    json_from_grabpay = models.CharField('json_from_grabpay', max_length=2000, null=True, blank=True)
    created = models.DateTimeField('created', auto_now_add=True)

class Member_Reward (models.Model):
    title = models.CharField('title', max_length=50, null=True, blank=True)
    comment = models.CharField('comment', max_length=100, null=True, blank=True)
    points = models.IntegerField('points')
    url = models.CharField('url', max_length=300, null=True, blank=True)
    status= models.NullBooleanField('status', null=True, blank=True, default=False)

class Voucher_Set (models.Model):
    voucher = models.ForeignKey(to='Voucher', related_name='set', null=True,blank=True,on_delete=models.CASCADE)

    max_quantity = models.IntegerField('max_quantity')
    all_limit = models.NullBooleanField('all_limit', null=True, blank=True, default=False)
    today_limit= models.NullBooleanField('today_limit', null=True, blank=True, default=False)
class Product_Limit_Quantity(models.Model):
    max_quantity = models.IntegerField('max_quantity')

class Outlet_Count_Sales(models.Model):
    outlet=models.ForeignKey(to="Outlet",related_name='outlet_mail',on_delete=models.CASCADE,null=True)
    status=models.NullBooleanField('status', null=True, blank=True, default=False)

class Wirecard_Status(models.Model):
    w_status=models.NullBooleanField('status', null=True, blank=True, default=False)
class Member_Campaign(models.Model):
    member_ship=models.ForeignKey(to="MemberShip",related_name='member_campaign',on_delete=models.CASCADE,null=True)
    voucher=models.ManyToManyField(to='Voucher', related_name='member_campaign_voucher',  null=True,blank=True)
    content=models.CharField('content', max_length=150, null=True, blank=True)
    status=models.NullBooleanField('status', null=True, blank=True, default=False)
class TabletMachineCode(models.Model):
    outlet_name = models.CharField(verbose_name='outlet_name', max_length=50)
    machine_code = models.CharField(verbose_name='machine_code', max_length=100)
    created=models.DateTimeField('created', auto_now_add=True)
class TabletLoginStatus(models.Model):

    status =models.BooleanField('status', default=True)
class LoginOtp(models.Model):
    mobile_no = models.CharField(verbose_name='mobile_no', max_length=50, null=True, blank=True)
    send_date = models.DateField('send_date', auto_now_add=True)
    send_time = models.DateTimeField('send_date', auto_now_add=True)
    expire_time=models.DateTimeField('expire_time', null=True, blank=True)
    verify_code=models.CharField(verbose_name='verify_code', max_length=50, null=True, blank=True)
class OtpSet(models.Model):
    expire_minute = models.IntegerField('expire_minute')
    max_times_per_minute = models.IntegerField('max_times_per_minute')
    max_times_per_day = models.IntegerField('max_times_per_day')
class Promotion_Code(models.Model):
    code = models.CharField('code', max_length=100, null=True, blank=True, unique=True)
    order_no = models.CharField('order_no', max_length=100, null=True, blank=True)
    outlet_name = models.CharField('outlet_name', max_length=100, null=True, blank=True)
    status = models.NullBooleanField('status', null=True, blank=True,default=False)
class Voucher_Terms_Conditions(models.Model):

    content=models.CharField('content', max_length=128, null=True, blank=True)
    index=models.IntegerField('index')
    class Meta:
        ordering = ['index']
class Terms_Conditions(models.Model):
    rewards=models.ForeignKey(to="Rewards",related_name='reward_terms',on_delete=models.CASCADE,null=True)
    content=models.CharField('content', max_length=128, null=True, blank=True)
    index=models.IntegerField('index')
    class Meta:
        ordering = ['index']
class Rewards(models.Model):
    name=models.CharField('name', max_length=50, null=True, default='')
    description = models.CharField('description', max_length=128, null=True, blank=True)
    VOUCHER, LUCKY_DRAW_TIMES,PRESENT,OTHER = range(4)
    REWARDS_TYPE = (
        (VOUCHER, "VOUCHER"),
        (LUCKY_DRAW_TIMES, "LUCKY_DRAW_TIMES"),
        (PRESENT, "PRESENT"),
        (OTHER, "OTHER"),

    )
    reward_type= models.IntegerField(
        "reward_type",
        choices=REWARDS_TYPE,
        help_text="0:VOUCHER, 1:LUCKY_DRAW_TIMES,2:PRESENT,3:OTHER",
        default=0,
        null=True,
        blank=True
    )
    exchange_points=models.IntegerField('exchange_points')
    exchange_points_before_discount = models.IntegerField('exchange_points_before_discount')
    voucher = models.ForeignKey(to='Voucher', related_name='rewards', null=True,blank=True,on_delete=models.CASCADE)
    lucky_draw_times = models.IntegerField('lucky_draw_times')
    img_url=models.CharField('img_url', max_length=500, null=True, default='')
    effective_date = models.DateField('effective Date')
    expiring_date = models.DateField('expiring_date')
    status = models.NullBooleanField('enable status', null=True, blank=True, default=False)
    class Meta:
        ordering=['exchange_points']
class Rewards_Log(models.Model):
    member=models.ForeignKey(to='Member', related_name='rewards', null=True,blank=True,on_delete=models.CASCADE)
    rewards = models.ForeignKey(to="Rewards", related_name='reward_log', on_delete=models.CASCADE, null=True)
    invicode= models.ForeignKey(to="Invicode", related_name='reward_invicode', on_delete=models.CASCADE, null=True)
    lucky_draw_times = models.IntegerField('lucky_draw_times')
    created=models.DateTimeField('created', auto_now_add=True)
    class Meta:
        ordering = ['-created']

class Payment_Code(models.Model):
    member=models.ForeignKey(to='Member', related_name='payment_code', null=True,blank=True,on_delete=models.CASCADE)
    payment_code = models.CharField('Payment Code', max_length=100, null=True,blank=True, default='')
    created=models.DateTimeField('created', auto_now_add=True)

class New_User_Rewards(models.Model):
    name=models.CharField('name', max_length=50, null=True, default='')
    description = models.CharField('description', max_length=128, null=True, blank=True)
    voucher = models.ForeignKey(to='Voucher', related_name='new_user_rewards', null=True,blank=True,on_delete=models.CASCADE)
    quantity = models.IntegerField('quantity')
    status = models.NullBooleanField('enable status', null=True, blank=True, default=False)
    class Meta:
        ordering=['id']