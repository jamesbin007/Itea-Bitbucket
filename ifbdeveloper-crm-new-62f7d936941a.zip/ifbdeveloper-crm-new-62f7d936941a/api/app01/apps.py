from django.apps import AppConfig


class App01Config(AppConfig):
    name = 'app01'

class TestConfig(AppConfig):
    name = 'test'
    verbose_name = 'Test'

    def ready(self):
       from utils.message_handler import MessageHandler

