from django.contrib import admin
from django.urls import path, re_path, include
from django.conf.urls import include, url
from django.conf import settings
from django.conf.urls import include, url
from rest_framework import routers
from django.contrib.staticfiles.urls import staticfiles_urlpatterns
from django.views import static ##新增
from django.conf import settings ##新增


#from rest_framework.schemas import get_schema_view
#from rest_framework_swagger.renderers import SwaggerUIRenderer, OpenAPIRenderer
#from rest_framework.documentation import include_docs_urls
#from rest_framework_swagger.views import get_swagger_view



#schema_view = get_schema_view(title='Users API', renderer_classes=[OpenAPIRenderer, SwaggerUIRenderer])
#schema_view = get_swagger_view(title="api-doc")
urlpatterns = [
    # path('admin/', admin.site.urls),
    #url(r'^docs/', schema_view, name="docs"),




    re_path('api/(?P<version>\w+)/campaign/', include(('campaign.urls', 'campaign'), namespace='campaign')),
    re_path('api/(?P<version>\w+)/membership/', include(('membership.urls', 'membership'), namespace='membership')),
    re_path('api/(?P<version>\w+)/product/', include(('product.urls', 'product'), namespace='product')),
    re_path('api/(?P<version>\w+)/member/', include(('member.urls', 'member'), namespace='member')),
    re_path('api/(?P<version>\w+)/card/', include(('card.urls', 'card'), namespace='card')),
    re_path('api/(?P<version>\w+)/outlet/', include(('outlet.urls', 'outlet'), namespace='outlet')),
    re_path('api/(?P<version>\w+)/wallet/', include(('wallet.urls', 'wallet'), namespace='wallet')),
    re_path('api/(?P<version>\w+)/voucher/', include(('voucher.urls', 'voucher'), namespace='voucher')),
    re_path('api/(?P<version>\w+)/invicode/', include(('invicode.urls', 'invicode'), namespace='invicode')),
    re_path('api/(?P<version>\w+)/payments/', include(('payments.urls', 'payments'), namespace='payments')),
    re_path('api/(?P<version>\w+)/transaction/', include(('transaction.urls', 'transaction'), namespace='transaction')),
    re_path('api/(?P<version>\w+)/delivery/', include(('delivery.urls', 'delivery'), namespace='delivery')),
    re_path('api/(?P<version>\w+)/ipay/', include(('ipay.urls', 'delivery'), namespace='ipay')),
    re_path('api/(?P<version>\w+)/pos_intergration/', include(('pos_intergration.urls', 'pos_intergration'), namespace='pos_intergration')),
    re_path('api/(?P<version>\w+)/card_payment/', include(('card_payment.urls', 'card_payment'), namespace='card_payment')),
    re_path('api/(?P<version>\w+)/card_payment_3ds/', include(('card_payment_3ds.urls', 'card_payment_3ds'), namespace='card_payment_3ds')),
    re_path('api/(?P<version>\w+)/card_payment_3ds2/', include(('card_payment_3ds2.urls', 'card_payment_3ds2'), namespace='card_payment_3ds2')),
##　以下是新增
  url(r'^static/(?P<path>.*)$', static.serve,
      {'document_root': settings.STATIC_ROOT}, name='static'),

    #url(r'^api-auth/', include('rest_framework.urls', namespace='rest_framework'))
]
urlpatterns += staticfiles_urlpatterns()

# if settings.DEBUG:
#     import debug_toolbar
#     urlpatterns = [
#                       url(r'^__debug__/', include(debug_toolbar.urls)),
#                   ] + urlpatterns
