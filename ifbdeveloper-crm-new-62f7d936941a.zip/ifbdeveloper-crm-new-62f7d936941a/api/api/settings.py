

import os
from datetime import timedelta
# Build paths inside the project like this: os.path.join(BASE_DIR, ...)
BASE_DIR = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))


# Quick-start development settings - unsuitable for production
# See https://docs.djangoproject.com/en/dev/howto/deployment/checklist/

# SECURITY WARNING: keep the secret key used in production secret! * *
SECRET_KEY = '(yz$4vzbf=smc__)c@5rz*r78zql2!-a=xt3m+9w_4app)6beb'

# SECURITY WARNING: don't run with debug turned on in production! * ***
DEBUG =True

ALLOWED_HOSTS = ['*']




# Application definition * *

INSTALLED_APPS = [
    # 'django.contrib.admin',
    'django.contrib.auth',
    'django.contrib.contenttypes',
    'django.contrib.sessions',
    # 'django.contrib.messages',
    'django.contrib.staticfiles',
    'corsheaders',
    'django_filters',
    'rest_framework',
    'django_crontab',
    #'rest_framework_firebase',
    'app01',  # database
    'wallet',  # signals


    #'rest_framework_swagger',
    'payments',
    # 'debug_toolbar',
    # 'pympler',
]
STRIPE_SECRET_KEY = "sk_345453454645645657567sHj"
STRIPE_PUBLISHABLE_KEY = "pk_t574557567567567567L7P"
#STRIPE_SECRET_KEY = "sk_l5675675675675675675671Pt"
#STRIPE_PUBLISHABLE_KEY = "pk_l5675675675675675677ndlQeX"
# CACHES = {
#     "default": {
#         "BACKEND": "django_redis.cache.RedisCache",
#         "LOCATION": "redis://127.0.0.1:6379/1",
#         "OPTIONS": {
#             "CLIENT_CLASS": "django_redis.client.DefaultClient",
#             # "PASSWORD": "mysecret"
#         }
#     }
# }
# SESSION_ENGINE = "django.contrib.sessions.backends.cache"
# SESSION_CACHE_ALIAS = "default"
# CACHE_MIDDLEWARE_SECONDS = 100

# CACHES = {
#     'default': {
#         'BACKEND': 'django.core.cache.backends.locmem.LocMemCache',
#         'LOCATION': 'unique-snowflake',
#         'TIMEOUT': 300,  # Cache timeout (default 300, None means never expires, 0 means expires immediately)
#         'OPTIONS': {
#             'MAX_ENTRIES': 300,  # Maximum number of caches (default 300)
#             'CULL_FREQUENCY': 3,
#             # After the maximum number of caches reaches, the ratio of the number of caches is removed, namely: 1/CULL_FREQUENCY (default 3)
#         }
#     }
# }






MIDDLEWARE = [

    # 'django.middleware.cache.UpdateCacheMiddleware',
    'utils.middleware.BlockedIpMiddleware',
    'corsheaders.middleware.CorsMiddleware',
    # 'django.middleware.security.SecurityMiddleware',
    'django.contrib.sessions.middleware.SessionMiddleware',
    'django.middleware.common.CommonMiddleware',
    'django.middleware.csrf.CsrfViewMiddleware',
    'django.contrib.auth.middleware.AuthenticationMiddleware',
    # 'django.contrib.messages.middleware.MessageMiddleware',
    # 'django.middleware.clickjacking.XFrameOptionsMiddleware',
    # 'django.middleware.cache.FetchFromCacheMiddleware',
    # 'debug_toolbar.middleware.DebugToolbarMiddleware',

]

# INTERNAL_IPS = ['127.0.0.1']
# DEBUG_TOOLBAR_CONFIG = {
#     'JQUERY_URL': "http://code.jquery.com/jquery-2.1.1.min.js",
# }
# DEBUG_TOOLBAR_PANELS = (
#     'debug_toolbar.panels.versions.VersionsPanel',
#     'debug_toolbar.panels.timer.TimerPanel',
#     'debug_toolbar.panels.settings.SettingsPanel',
#     'debug_toolbar.panels.headers.HeadersPanel',
#     'debug_toolbar.panels.request.RequestPanel',
#     'debug_toolbar.panels.sql.SQLPanel',
#     'debug_toolbar.panels.staticfiles.StaticFilesPanel',
#     'debug_toolbar.panels.templates.TemplatesPanel',
#     'debug_toolbar.panels.cache.CachePanel',
#     'debug_toolbar.panels.signals.SignalsPanel',
#     'debug_toolbar.panels.logging.LoggingPanel',
#     'debug_toolbar.panels.redirects.RedirectsPanel',
#     'pympler.panels.MemoryPanel',
# )

# CRON_CLASSES = [
#     "member.cron.MyCronJob",
# ]
# ]

CRONJOBS = [
    #('*/20 10-21,22 * * *', 'transaction.cron.daily'),
    #('35 23 * * *', 'invicode.cron.countPrize'),
    ('08 22 * * *', 'card.cron.countDuozouluItemQuantity'),
    ('11 22 * * *', 'card.cron.countVivaiaItemQuantity'),
    ('13 22 * * *', 'card.cron.countBeneunderItemQuantity'),
    ('15 22 * * *', 'card.cron.DuozouluChinaOrder'),
    ('17 22 * * *', 'card.cron.VivaiaChinaOrder'),
    ('19 22 * * *', 'card.cron.BeneunderChinaOrder'),
    ('25 22 * * *', 'card.cron.DuozouluOutletDispatch'),
    ('27 22 * * *', 'card.cron.DuozouluBackupStock'),
    ('32 22 * * *', 'card.cron.VivaiaBackupStock'),
    ('32 23 * * *', 'card.cron.IndonisiaVivaiaBackupStock'),
    ('34 22 * * *', 'card.cron.BeneunderBackupStock'),
    ('35 22 * * *', 'invicode.cron.countPrize'),
    ('*/2 9-23 * * *', 'outlet.cron.auto_confirm'),
    ('*/5 6-23 * * *', 'card.cron.timing_modify_category_time'),
    #('*/5 9-23 * * *', 'invicode.cron.send_payment'),
    ('*/20 6-23 * * *', 'card.cron.erpSalesComp'),
    ('*/20 11-21 * * *', 'card.cron.shoesSalesComp'),
    ('40 10 * * *', 'card.cron.shoesSalesComp'),
    ('*/20 11-22 * * *', 'card.cron.shoesSalesComp_indonisia'),
    ('40 10 * * *', 'card.cron.shoesSalesComp_indonisia'),
    ('0 22 * * *', 'card.cron.shoesSalesComp'),
    ('*/60 11-23 * * *', 'card.cron.shoesSalesComp_1'),
    ('*/60 6-23 * * *', 'card.cron.breadFreshSalesComp'),
    ('*/60 8-11 * * *', 'card.cron.erpOutletClockin'),
    ('0 12 1 * *', 'card.cron.erpGoodsCount'),
    ('15 12 1 * *', 'card.cron.getOutletWorkHours'),
    ('13 12 1 * *', 'card.cron.getDurableGoods'),
    ('20 0 1 * *', 'card.cron.getOutletEmployeeWorkHours'),
    ('03 13 1 * *', 'card.cron.getOutletEmployeeWorkHoursAndByEmployee'),

    #('55 23 * * *', 'card.cron.erpOrderCount'),
    #('35 22 * * *', 'card.cron.count_purchase'),
    ('45 23 * * *', 'card.cron.getPosCompare_month_count'),
    ('45 9 * * *', 'card.cron.AllOutletSalesMail'),
    ('58 23 * * *', 'card.cron.record_wallet_balance'),
    ('30 22 * * *', 'card.cron.all_count'),
    ('05 23 * * *', 'card.cron.getMonitorClockIn'),
    ('0 0 * * *', 'outlet.cron.prize_random'),
    ('10 0 * * *', 'outlet.cron.modify_opening_time'),
    ('45 0 * * *', 'card.cron.erp_modify_opening_time'),
    #('45 22 * * *', 'card.cron.erpStockAlert'),
    ('50 23 * * *', 'card.cron.productStockLog'),
    ('08 23 * * *', 'card.cron.posTransactionBackup'),
    ('10 11 * * *', 'card.cron.getStockDetails'),
    ('*/60 10-23 * * *', 'card.cron.schedule_count'),
    ('*/60 10-23 * * *', 'card.cron.duozoulu_prize_count'),
    ('30 23 * * *', 'card.cron.AveragePricePerCupMail'),
    ('12 23 * * *', 'card.cron.china_duozoulu_email'),
    ('25 23 * * *', 'card.cron.MonthBonusMail'),
    ('15 23 * * *', 'card.cron.getSalesAndWorkHours'),
    ('05 9 * * *', 'card.cron.getYesterdaySalesAndWorkHours'),
    ('30 9 * * *', 'card.cron.getBreadFreshAlert'),
    ('45 9 * * *', 'card.cron.getVivaiaEmployeeSalesData'),
    ('48 9 * * *', 'card.cron.getDuozouluEmployeeSalesData'),
    #('5 10-22/1 * * *', 'transaction.cron.get_member_count'),
    #('*/30 10-22 * * *', 'transaction.cron.countOutletPayment'),
    ('5 9 * * 1', 'card.cron.getTastyChinaWeeklySales'),
    ('0 11 * * *', 'card.cron.check_long_sold_product'),
    ('20 8 * * *', 'member.cron.member_birthday'),
    ('30 0 * * *', 'member.cron.auto_collect'),
    ('40 0 * * *', 'card.cron.deal_promotion_price'),
    ('10 6 * * *', 'card.cron.update_restaunant_status'),
    #('2 0 * * *', 'member.cron.daily', '>>/home/pyprojects/cobra/api/member_cron.log'),
    #('2 0 1 * *', 'member.cron.monthly', '>>/home/pyprojects/cobra/api/member_cron.log'),
    #('0 12 * * *', 'product.cron.update_goods', '>>/home/pyprojects/cobra/api/product_cron.log'),
]

# 跨域忽略
# CORS_ALLOW_CREDENTIALS = False
CORS_ORIGIN_ALLOW_ALL = True

ROOT_URLCONF = 'api.urls'

TEMPLATES = [
     {
         'BACKEND': 'django.template.backends.django.DjangoTemplates',
         'DIRS': [os.path.join(BASE_DIR, 'templates')],
         #'DIRS':[],
         'APP_DIRS': True,
         'OPTIONS': {
             'context_processors': [
                 'django.template.context_processors.debug',
                 'django.template.context_processors.request',
                 'django.contrib.auth.context_processors.auth',
                 'django.contrib.messages.context_processors.messages',
             ],
         },
     },
]

WSGI_APPLICATION = 'api.wsgi.application'
'''
DATABASES = {
    'default': {
        'ENGINE': 'django.db.backends.postgresql',
        'NAME': 'crm_test',
        'USER': 'postgres',
        'PASSWORD': 'root1234',
        'HOST': '192.168.2.131',
        'PORT': '5432',
    }
}
'''

DATABASES = {
    'default': {
        'ENGINE': 'django.db.backends.postgresql',
        'NAME': 'crm',
        #'NAME': 'test_crm',
        'USER': 'itea_database',
        'PASSWORD': 'itea_ifb_1234',
        #'HOST': 'rm-gs5u98x4ral194628.pgsql.singapore.rds.aliyuncs.com',
        'HOST': 'rm-gs5u98x4ral194628.pgsql.singapore.rds.aliyuncs.com',
        'PORT': '1921',
    }
}

'''
DATABASES = {
    'default': {
        'ENGINE': 'django.db.backends.postgresql',
        'NAME': 'cobra_db',
        'USER': 'cobra_user',
        'PASSWORD': 'Cobra_iTEA!!!0217*11pm?_',
        'HOST': 'crm.itea.sg',
        'PORT': '5432',
    }
}
'''
'''
DATABASES = {
    'default': {
        'ENGINE': 'django.db.backends.postgresql',
        'NAME': 'delivery_db',
        'USER': 'postgres',
        'PASSWORD': 'erp1234',
        'HOST': '47.74.156.85',
        'PORT': '5432',
    }
}
'''
# qsazxsx111112222
# Password validation
# https://docs.djangoproject.com/en/dev/ref/settings/#auth-password-validators

AUTH_PASSWORD_VALIDATORS = [
    # {
    #     'NAME': 'django.contrib.auth.password_validation.UserAttributeSimilarityValidator',
    # },
    # {
    #     'NAME': 'django.contrib.auth.password_validation.MinimumLengthValidator',
    # },
    # {
    #     'NAME': 'django.contrib.auth.password_validation.CommonPasswordValidator',
    # },
    # {
    #     'NAME': 'django.contrib.auth.password_validation.NumericPasswordValidator',
    # },
]

LOGGING = {
    'version': 1,
    'disable_existing_loggers': False,
    'handlers': {
        'console': {
            'class': 'logging.StreamHandler',
        },
    },
    'loggers': {
        'django.db.backends': {
            'handlers': ['console'],
            'level': 'DEBUG' if DEBUG else 'INFO',
        },
    },
}

# LOGGING = {
#     'version': 1,
#     'disable_existing_loggers': True,
#     'formatters': {
#         'verbose': {
#             'format': '[%(asctime)s] %(levelname)s [%(name)s.%(funcName)s:%(lineno)d] %(message)s',
#             'datefmt': '%Y-%m-%d %H:%M:%S'
#         },
#     },
#     'handlers': {
#         'console': {
#             'level': 'DEBUG',
#             'class': 'logging.StreamHandler',
#             'formatter': 'verbose'
#         },
#         'logfile': {
#             'level': 'DEBUG',
#             'class': 'logging.handlers.RotatingFileHandler',
#             'filename': 'cobra.log',
#             'maxBytes': 1024 * 1024 * 5,  # 5 MB
#             'backupCount': 7,
#             'formatter': 'verbose'
#         },
#     },
#     'loggers': {
#         'django.db.backends': {
#             'level': 'ERROR',
#             'handlers': ['console', 'logfile'],
#             'propagate': False,
#         },
#         'django': {
#             'handlers': ['console', 'logfile'],
#             'propagate': False,
#             'level': 'DEBUG',
#         },
#     }
# }


# Internationalization
# https://docs.djangoproject.com/en/dev/topics/i18n/

LANGUAGE_CODE = 'en-us'

# TIME_ZONE = 'Asia/Shanghai'
TIME_ZONE = 'Asia/Singapore'

USE_I18N = True

USE_L10N = True

USE_TZ = True


# Static files (CSS, JavaScript, Images)
# https://docs.djangoproject.com/en/dev/howto/static-files/

STATIC_URL = '/static/'
STATIC_ROOT = os.path.join(BASE_DIR, 'static')
#STATIC_URL = '/static/'
STATICFILES_DIRS=(

    ('images', os.path.join(STATIC_ROOT, 'images').replace('\\', '/')),
    ('js', os.path.join(STATIC_ROOT, 'js').replace('\\', '/')),
    ('css', os.path.join(STATIC_ROOT, 'css').replace('\\', '/')),
    ('img', os.path.join(STATIC_ROOT, 'img').replace('\\', '/')),

)

#MEDIA_URL = '/static/uploads/'
#MEDIA_ROOT = os.path.join(STATIC_ROOT, "uploads")

AUTH_USER_MODEL = "app01.Member"  # for rest_framework.authtoken.models.Token


# ##################### Global configuration rest_framework ########################
REST_FRAMEWORK = {
    "DEFAULT_VERSIONING_CLASS": "rest_framework.versioning.URLPathVersioning",
    "VERSION_PARAM": "version",
    "DEFAULT_VERSION": "v1",
    "ALLOWED_VERSIONS": ["v1", "v2"],
    "UNAUTHENTICATED_USER": None,
    "UNAUTHENTICATED_TOKEN": None,
    'DEFAULT_PAGINATION_CLASS': 'utils.pagination.DefaultPagination',
    'DEFAULT_AUTHENTICATION_CLASSES': (
        #jwt token
        #'rest_framework_simplejwt.authentication.JWTAuthentication',
        'utils.auth.CustomAuthentication',
    ),
    'DEFAULT_FILTER_BACKENDS': (
        'django_filters.rest_framework.DjangoFilterBackend',
    ),
    "DEFAULT_PERMISSION_CLASSES": (
        "rest_framework.permissions.IsAuthenticated",
    ),
    # "DEFAULT_THROTTLE_RATES": {
    #     "anon": "5/m",
    #     "user": "10/m",
    # },
    'DEFAULT_PARSER_CLASSES': (
        'rest_framework.parsers.JSONParser',
        'rest_framework.parsers.FormParser',
        'rest_framework.parsers.MultiPartParser',
    ),
    'DEFAULT_RENDERER_CLASSES': (
        'rest_framework.renderers.JSONRenderer',
    ),
    #'DEFAULT_AUTHENTICATION_CLASSES': (
    #    'rest_framework_firebase.authentication.FirebaseAuthentication',
    #)
}
SIMPLE_JWT = {
    'ACCESS_TOKEN_LIFETIME': timedelta(minutes=360),
    'REFRESH_TOKEN_LIFETIME': timedelta(days=1),

    #'SECRET_KEY': SECRET_KEY,  # Defaults to django project secret key

    'AUTH_HEADER_TYPES': 'Token',
    'AUTH_HEADER_NAME': 'HTTP_AUTHORIZATION',
    'USER_ID_FIELD': 'id',
    'USER_ID_CLAIM': 'member_id',
    'USER_AUTHENTICATION_RULE': 'rest_framework_simplejwt.authentication.default_user_authentication_rule',

    'AUTH_TOKEN_CLASSES': ('rest_framework_simplejwt.tokens.AccessToken',),
    'TOKEN_TYPE_CLAIM': 'token_type',

    'SLIDING_TOKEN_LIFETIME': timedelta(minutes=5),
    'SLIDING_TOKEN_REFRESH_LIFETIME': timedelta(days=1),
    'SLIDING_TOKEN_REFRESH_EXP_CLAIM': 'refresh_exp',
}

FIREBASE_AUTH = {
    'FIREBASE_ACCOUNT_KEY_FILE': BASE_DIR+'/utils/qualified-cacao-245606-firebase-adminsdk-qxuqv-4372964079.json',
}

'''
TEMPLATE_LOADERS = (

'django.template.loaders.eggs.Loader',

)
'''

# from rest_framework.parsers
# ##################### Business logic configuration ########################
# Member can get bonus points by binding emails
BINDING_EMAIL = {
    'reward_points': 3
}

# Supplementary Information Bonus Points
SUPPLEMENT_INFO = {
    'reward_points': 3
}

# # ########## Initialization data
# # Initialize points reward rules data
# INIT_POINTS_INFO_LIST = [
#     {
#         "name": "Default member's supplementary information points reward",
#         "description": "Default member's supplementary information points reward",
#         "obtain_type": 3,
#         "effective_date": "2000-01-01T00:00:00",
#         "expiring_date": "2099-01-01T00:00:00",
#         "bonus_points": BONUS_POINTS,
#     }
# ]
#Authorization='Token fa3c5db850ada70422a02e4638984dc08822f010'
SWAGGER_SETTINGS = {

    'USE_SESSION_AUTH': False,
    'DOC_EXPANSION': 'list',
    'APIS_SORTER': 'alpha',
    'SECURITY_DEFINITIONS': {
        'apiKey': {
            'type': 'apiKey',
            'in': 'header',
            'name': 'Authorization',
            'description': 'Json Web Token'
        },
    },
    'Default': ['get', 'post', 'put', 'delete', 'patch'],
    'LOGIN_URL': 'rest_framework:login',
    'LOGOUT_URL': 'rest_framework:logout',
    'SHOW_REQUEST_HEADERS': True,
    'JSON_EDITOR': True,
    'CUSTOM_HEADERS': {'Authorization': 'Token fa3c5db850ada70422a02e4638984dc08822f010'},
    'SHOW_REQUEST_HEADERS': True



   


}

# ################# IP Black LIST ###############
BLOCKED_IPS = ('111.231.105.60', '111.231.215.222', '198.23.206.98',)
# 添加邮箱相关配置(the setting of email service)
EMAIL_HOST = "smtp.gmail.com"   # 服务器
EMAIL_PORT = 465              # 一般情况下都为25
EMAIL_HOST_USER = "admin@ifbsg.com"   # 账号
EMAIL_HOST_PASSWORD = "lynvfmhzaaobrouz"  # 密码
EMAIL_USE_TLS = False             # 一般都为False
EMAIL_FROM = "admin@ifbsg.com"        # 邮箱来自
#RECEIVE_MAIL="support@itea.sg"
RECEIVE_MAIL="admin@itea.sg"
#RECEIVE_MAIL="ziyiw2019@gmail.com"
TOKEN_EXPIRE_TIME=21600