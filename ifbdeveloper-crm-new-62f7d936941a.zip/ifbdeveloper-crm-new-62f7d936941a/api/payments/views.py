from django.conf import settings  # new
from django.views.generic.base import TemplateView
import stripe  # new
from django.shortcuts import render  # new
from rest_framework.permissions import AllowAny
from rest_framework.decorators import api_view, authentication_classes, permission_classes, renderer_classes
from rest_framework.response import Response
from wallet.serializers import RechargeRecordCreateSerializer
from django.http import HttpResponse
from django.template import Context, loader
import json
import time
from app01 import models
from wallet import serializers, service
from rest_framework import status
from django.db import connection
import datetime
import sys
from django.db import transaction
from rest_framework.renderers import StaticHTMLRenderer, TemplateHTMLRenderer
from . import OneTimeCharge, tokenization
from django.http import HttpResponseRedirect
from utils.campaign_function import campaign_return
from invicode import utils
from utils.message_manage import send_message_to_token
from transaction.service import get_payment_mail_table, get_topup_mail_table
from transaction.utils import thread_send_mail, send_mooncake_payment
from decimal import *
from .service import member_payment_cashback
from invicode.serializers import generate_random_str
from member.services import update_member_points
from django.db.models import Q, Sum, Count


@api_view(['GET', 'POST'])
@authentication_classes([])
@permission_classes((AllowAny,))
@renderer_classes((TemplateHTMLRenderer, StaticHTMLRenderer,))
def one_time_charge(request, *args, **kwargs):
    oneTimeCharge = OneTimeCharge.OneTimeCharge('6962c659-7b30-48a7-9495-2cb6c7b34b32', 'RsEeUPTC6sq5bDnM',
                                                'bb6318fe450b4729adb831a2a87c5c7b', '3ybZRTq8hrd07tnl',
                                                '8be3a726-2c75-4750-af22-a1df55c2ba7f')
    amount = 168
    description = 'TestOne-TimeChargePayment'

    partnerGroupTxId = 'OrderID' + oneTimeCharge.generateNonce(4)
    request.session['partnerTxId'] = 'IdempotencyKey' + oneTimeCharge.generateNonce(4)
    request.session['codeVerifier'] = oneTimeCharge.generateNonce(64)
    request.session['redirectUrl'] = 'https://crm.itea.sg/api/v1/payments/one_time_charge_complete/'

    context = {}
    context['hello'] = 'oauthAuthorizeUrl is empty'

    initCharge = oneTimeCharge.initCharge(request.session['partnerTxId'], partnerGroupTxId, amount, description)

    oauthAuthorizeUrl = oneTimeCharge.getOauthAuthorizeUrl(request.session['codeVerifier'], initCharge['request'],
                                                           request.session['redirectUrl'], 'payment.one_time_charge')
    if oauthAuthorizeUrl:
        return HttpResponseRedirect(oauthAuthorizeUrl)
    else:
        return render(request, 'index.html', context)


@api_view(['GET', 'POST'])
@authentication_classes([])
@permission_classes((AllowAny,))
@renderer_classes((TemplateHTMLRenderer, StaticHTMLRenderer,))
def one_time_charge_complete(request, *args, **kwargs):
    template = loader.get_template('index.html')
    context = {}
    oneTimeCharge = OneTimeCharge.OneTimeCharge('6962c659-7b30-48a7-9495-2cb6c7b34b32', 'RsEeUPTC6sq5bDnM',
                                                'bb6318fe450b4729adb831a2a87c5c7b', '3ybZRTq8hrd07tnl',
                                                '8be3a726-2c75-4750-af22-a1df55c2ba7f')

    if request and request.GET.get('code'):
        accessToken = oneTimeCharge.getAccessToken(request.GET.get('code'), request.session['redirectUrl'],
                                                   request.session['codeVerifier'])

    else:
        context = {}
        context['hello'] = 'OAuth2 code is missing'
        return HttpResponse(content=template.render(context), content_type='text/html; charset=utf-8', status=200)

    if accessToken:
        if 'access_token' in accessToken.keys():

            completeCharge = oneTimeCharge.completeCharge(accessToken['access_token'], request.session['partnerTxId'])
            context['hello'] = json.dumps(accessToken) + json.dumps(completeCharge)

        else:
            if 'errors' in accessToken.keys():
                context['hello'] = accessToken['errors']

            else:
                # transaction = models.Transaction.objects.get(id=730)
                # transaction.remark = json.dumps(accessToken)
                # transaction.save()
                context['hello'] = json.dumps(accessToken)
        return HttpResponse(content=template.render(context), content_type='text/html; charset=utf-8', status=200)


    else:

        context['hello'] = 'Access token is error'
        return HttpResponse(content=template.render(context), content_type='text/html; charset=utf-8', status=200)


@api_view(['GET', 'POST'])
@authentication_classes([])
@permission_classes((AllowAny,))
@renderer_classes((TemplateHTMLRenderer, StaticHTMLRenderer,))
def grab_token_charge(request, *args, **kwargs):
    member_id = request.GET.get('member_id')
    topup_no = request.GET.get('topup_no')
    amount = int(request.GET.get('amount'))
    tockenization = tokenization.Tokenization('6962c659-7b30-48a7-9495-2cb6c7b34b32', 'RsEeUPTC6sq5bDnM',
                                              'bb6318fe450b4729adb831a2a87c5c7b', '3ybZRTq8hrd07tnl',
                                              '8be3a726-2c75-4750-af22-a1df55c2ba7f')

    description = 'TokenChargePayment'

    partnerGroupTxId = 'OrderID' + tockenization.generateNonce(4)

    # request.session['partnerTxId'] = 'IdempotencyKey' +tockenization.generateNonce(4)
    request.session['partnerTxId'] = topup_no
    request.session['member_id'] = member_id
    request.session['amount'] = amount
    request.session['codeVerifier'] = tockenization.generateNonce(64)
    request.session['redirectUrl'] = 'https://crm.itea.sg/api/v1/payments/grab_token_charge_complete/'

    context = {}
    context['hello'] = 'oauthAuthorizeUrl is empty'

    initCharge = tockenization.bind(request.session['partnerTxId'])
    if initCharge:
        if not 'request' in initCharge.keys():
            context['hello'] = json.dumps(initCharge)
            return render(request, 'index.html', context)
        else:
            oauthAuthorizeUrl = tockenization.getOauthAuthorizeUrl(request.session['codeVerifier'],
                                                                   initCharge['request'],
                                                                   request.session['redirectUrl'],
                                                                   'payment.recurring_charge')
    if oauthAuthorizeUrl:
        return HttpResponseRedirect(oauthAuthorizeUrl)
    else:
        return render(request, 'index.html', context)


@api_view(['GET', 'POST'])
@authentication_classes([])
@permission_classes((AllowAny,))
@renderer_classes((TemplateHTMLRenderer, StaticHTMLRenderer,))
def grab_token_charge_complete(request, *args, **kwargs):
    template = loader.get_template('index.html')
    context = {}
    tockenization = tokenization.Tokenization('6962c659-7b30-48a7-9495-2cb6c7b34b32', 'RsEeUPTC6sq5bDnM',
                                              'bb6318fe450b4729adb831a2a87c5c7b', '3ybZRTq8hrd07tnl',
                                              '8be3a726-2c75-4750-af22-a1df55c2ba7f')
    amount = request.session['amount']
    description = 'Test Tokenization Payment'
    partnerGroupTxId = 'OrderID' + tockenization.generateNonce(4)

    if (request.GET.get('code')):

        accessToken = tockenization.getAccessToken(request.GET.get('code'), request.session['redirectUrl'],
                                                   request.session['codeVerifier'])

    else:
        context = {}
        context['hello'] = 'OAuth2 code is missing'
        return HttpResponse(content=template.render(context), content_type='text/html; charset=utf-8', status=200)

    if accessToken:
        if 'access_token' in accessToken.keys():
            if request.session['member_id']:
                wallet = models.Wallet.objects.get(member__id=request.session['member_id'])
                if wallet:
                    wallet.grab_token = accessToken['access_token']
                    wallet.grab_expire = accessToken['expires_in'] * 1000 + int(round(time.time() * 1000))
                    wallet.save()
                else:
                    models.Wallet.objects.create(balance=0, member=request.session['member_id'],
                                                 grab_token=accessToken['access_token'],
                                                 grab_expire=accessToken['expires_in'])

            completeCharge = tockenization.charge(accessToken['access_token'], request.session['partnerTxId'],
                                                  partnerGroupTxId, amount, description)
            if completeCharge:
                # context['hello'] = json.dumps(accessToken) + json.dumps(completeCharge)
                # return HttpResponse(content=template.render(context), content_type='text/html; charset=utf-8',status=200)
                # transactions = models.Transaction.objects.get(id=730)
                # transactions.remark = json.dumps(completeCharge)
                # transactions.save()
                if 'txID' in completeCharge.keys():
                    txID = completeCharge['txID']
                    status = completeCharge['status']
                    txStatus = completeCharge['txStatus']
                    reason = completeCharge['reason']
                    if (txStatus == 'success'):
                        wallet = models.Wallet.objects.get(member__id=request.session['member_id'])
                        if wallet:
                            # recharge campaign
                            campaign_return_cash = 0
                            campaignTopup = models.CampaignTopup.objects.first()
                            member = models.Member.objects.get(id=request.session['member_id'])
                            if member:
                                topup_10_times = 0 if member.topup_10_times is None else member.topup_10_times
                                topup_20_times = 0 if member.topup_20_times is None else member.topup_20_times
                                topup_50_times = 0 if member.topup_50_times is None else member.topup_50_times
                            if campaignTopup:

                                activity_flag = campaignTopup.activity_flag
                                date_limit_flag = campaignTopup.date_limit_flag
                                times_limit_flag = campaignTopup.times_limit_flag
                                if activity_flag:
                                    if times_limit_flag:
                                        if date_limit_flag:
                                            pass

                                        else:
                                            if campaignTopup.topup_10_limit_times > topup_10_times and amount == 1000:
                                                campaign_return_cash = campaignTopup.topup_10_return_cash
                                            if campaignTopup.topup_20_limit_times > topup_20_times and amount == 2000:
                                                campaign_return_cash = campaignTopup.topup_20_return_cash
                                            if campaignTopup.topup_50_limit_times > topup_50_times and amount == 5000:
                                                campaign_return_cash = campaignTopup.topup_50_return_cash

                                    else:
                                        if date_limit_flag:
                                            pass

                                        else:
                                            if amount == 1000:
                                                campaign_return_cash = campaignTopup.topup_10_return_cash
                                            if amount == 2000:
                                                campaign_return_cash = campaignTopup.topup_20_return_cash
                                            if amount == 5000:
                                                campaign_return_cash = campaignTopup.topup_50_return_cash
                            if member.terminal == 1:
                                pass
                            else:

                                wallet.balance += float(amount / 100) + campaign_return_cash
                                wallet.lastest_top_up = time.strftime("%Y-%m-%d", time.localtime())
                                wallet.save()
                                serializer = RechargeRecordCreateSerializer(
                                    data={'money': float(amount / 100), 'wallet': wallet.id, 'type': 0,
                                          'request_id': request.session['partnerTxId'],
                                          'status': 1, 'grab_txID': txID, 'topup_type': 1})
                                if serializer.is_valid():
                                    models.RechargeRecord.objects.create(**serializer.validated_data)
                                if campaign_return_cash:
                                    serializer = RechargeRecordCreateSerializer(
                                        data={'money': campaign_return_cash, 'wallet': wallet.id, 'type': 3,
                                              'grab_txID': txID,
                                              'status': 1})
                                    if serializer.is_valid():
                                        instance = models.RechargeRecord.objects.create(**serializer.validated_data)

                                    if member.device_token:
                                        send_message_to_token(member.device_token, 'Top up reward',
                                                              'Amout: $' + str(campaign_return_cash))

                                if member:
                                    if amount == 1000:
                                        if member.topup_10_times:
                                            member.topup_10_times = member.topup_10_times + 1
                                        else:
                                            member.topup_10_times = 1
                                    elif amount == 2000:
                                        if member.topup_20_times:
                                            member.topup_20_times = member.topup_20_times + 1
                                        else:
                                            member.topup_20_times = 1
                                    else:
                                        if member.topup_50_times:
                                            member.topup_50_times = member.topup_50_times + 1
                                        else:
                                            member.topup_50_times = 1
                                    member.save()
                            # send mail
                            '''
                            countTable = "<h4 style='text-align:center'  >Mobile top up payment</h4><table border='1' cellspacing='0' style='text-align:center' ><tr><td colspan='4'  style='text-align:left' >Grab TxId:" + txID + "</td></tr><tr><td>member mobile</td><td>amount</td><td>payment method</td><td>payment time </td></tr><tr>" + \
                                         "<td>" + member.mobile_no + "</td><td>" + str(
                                amount/100) + "</td><td>" + \
                                         "grab pay" + "</td><td>" + time.strftime("%Y-%m-%d %H:%M:%S",time.localtime()) + "</td></tr></table>"
                                         '''
                            amount_val = float(amount / 100)
                            # countTable = get_topup_mail_table(wallet, member, wallet.id, "Grabpay", amount_val)
                            # if member.terminal == 0:
                            # utils.send_register_email(utils.RECEIVE_MAIL, countTable, send_type="topup",promotion='')
                            # thread_send_mail(countTable, "topup")
                        # success jump
                        context['hello'] = 'success,' + accessToken['access_token'] + ',' + str(
                            accessToken['expires_in'])

                    else:
                        context['hello'] = json.dumps(completeCharge['txStatus'] + ',' + completeCharge['reason'])
                elif 'reason' in completeCharge.keys():
                    context['hello'] = json.dumps(completeCharge['reason'])
                else:
                    context['hello'] = 'errors'
            else:
                context['hello'] = 'errors'

            # context['hello'] =json.dumps(accessToken)+json.dumps(completeCharge)
            # transStatus=tockenization.checkTransactionStatus(accessToken['access_token'],completeCharge['txID'])
            # context['hello'] =context['hello']+json.dumps(transStatus)

        else:
            if 'errors' in accessToken.keys():
                context['hello'] = accessToken['errors']

            else:
                # transaction = models.Transaction.objects.get(id=730)
                # transaction.remark = json.dumps(accessToken)
                # transaction.save()
                context['hello'] = json.dumps(accessToken)
        return HttpResponse(content=template.render(context), content_type='text/html; charset=utf-8', status=200)


    else:

        context['hello'] = 'Access token is error'
        return HttpResponse(content=template.render(context), content_type='text/html; charset=utf-8', status=200)


@api_view(['GET', 'POST'])
@authentication_classes([])
@permission_classes((AllowAny,))
@renderer_classes((TemplateHTMLRenderer, StaticHTMLRenderer,))
def grab_token_charge_pay(request, *args, **kwargs):
    member_id = request.GET.get('member_id')
    order_no = request.GET.get('order_no')
    amount = int(request.GET.get('amount'))
    type = request.GET.get('type')
    tockenization = tokenization.Tokenization('6962c659-7b30-48a7-9495-2cb6c7b34b32', 'RsEeUPTC6sq5bDnM',
                                              'bb6318fe450b4729adb831a2a87c5c7b', '3ybZRTq8hrd07tnl',
                                              '8be3a726-2c75-4750-af22-a1df55c2ba7f')

    description = 'TokenChargePayment'

    partnerGroupTxId = 'OrderID' + tockenization.generateNonce(4)
    current_ts_ms = int(time.time() * 1000)
    # request.session['partnerTxId'] = 'IdempotencyKey' +tockenization.generateNonce(4)
    request.session['partnerTxId'] = order_no + '_' + str(current_ts_ms)
    request.session['member_id'] = member_id
    request.session['amount'] = amount
    request.session['codeVerifier'] = tockenization.generateNonce(64)
    # request.session['redirectUrl'] = 'https://crm.itea.sg/api/v1/payments/grab_token_charge_complete_pay/'
    if type:
        if type == '1':
            request.session['redirectUrl'] = 'https://crm.itea.sg/api/v1/payments/grab_token_charge_complete_pay/'
        else:
            request.session[
                'redirectUrl'] = 'https://crm.itea.sg/api/v1/payments/grab_token_charge_complete_pay_for_web/'
    else:
        request.session['redirectUrl'] = 'https://crm.itea.sg/api/v1/payments/grab_token_charge_complete_pay/'
    context = {}
    context['hello'] = 'oauthAuthorizeUrl is empty'

    initCharge = tockenization.bind(request.session['partnerTxId'])
    if initCharge:
        if not 'request' in initCharge.keys():
            context['hello'] = json.dumps(initCharge)
            return render(request, 'index.html', context)
        else:
            oauthAuthorizeUrl = tockenization.getOauthAuthorizeUrl(request.session['codeVerifier'],
                                                                   initCharge['request'],
                                                                   request.session['redirectUrl'],
                                                                   'payment.recurring_charge')
    if oauthAuthorizeUrl:
        return HttpResponseRedirect(oauthAuthorizeUrl)
    else:
        return render(request, 'index.html', context)


@api_view(['GET', 'POST'])
@authentication_classes([])
@permission_classes((AllowAny,))
@renderer_classes((TemplateHTMLRenderer, StaticHTMLRenderer,))
def grab_token_charge_complete_pay(request, *args, **kwargs):
    now = datetime.datetime.now()
    template = loader.get_template('index.html')
    context = {}
    tockenization = tokenization.Tokenization('6962c659-7b30-48a7-9495-2cb6c7b34b32', 'RsEeUPTC6sq5bDnM',
                                              'bb6318fe450b4729adb831a2a87c5c7b', '3ybZRTq8hrd07tnl',
                                              '8be3a726-2c75-4750-af22-a1df55c2ba7f')
    amount = request.session['amount']
    description = 'Test Tokenization Payment'
    partnerGroupTxId = 'OrderID' + tockenization.generateNonce(4)

    if (request.GET.get('code')):

        accessToken = tockenization.getAccessToken(request.GET.get('code'), request.session['redirectUrl'],
                                                   request.session['codeVerifier'])

    else:
        context = {}
        context['hello'] = 'OAuth2 code is missing'
        return HttpResponse(content=template.render(context), content_type='text/html; charset=utf-8', status=200)

    if accessToken:
        if 'access_token' in accessToken.keys():
            if request.session['member_id']:
                wallet = models.Wallet.objects.get(member__id=request.session['member_id'])
                if wallet:
                    wallet.grab_token = accessToken['access_token']
                    wallet.grab_expire = accessToken['expires_in'] * 1000 + int(round(time.time() * 1000))
                    wallet.save()
                else:
                    models.Wallet.objects.create(balance=0, member=request.session['member_id'],
                                                 grab_token=accessToken['access_token'],
                                                 grab_expire=accessToken['expires_in'])

            completeCharge = tockenization.charge(accessToken['access_token'], request.session['partnerTxId'],
                                                  partnerGroupTxId, amount, description)
            if completeCharge:
                # context['hello'] = json.dumps(accessToken) + json.dumps(completeCharge)
                # return HttpResponse(content=template.render(context), content_type='text/html; charset=utf-8',status=200)
                # transactions = models.Transaction.objects.get(id=1114)
                # transactions.remark = str(accessToken['expires_in'])+'  '+str(int(round(time.time() * 1000)))
                # transactions.save()
                if 'txID' in completeCharge.keys():
                    txID = completeCharge['txID']
                    status = completeCharge['status']
                    txStatus = completeCharge['txStatus']
                    reason = completeCharge['reason']
                    if (txStatus == 'success'):
                        grab_transaction_id = request.session['partnerTxId']

                        trans_arr = request.session['partnerTxId'].split('_')
                        if trans_arr and len(trans_arr) > 0:
                            grab_transaction_id = trans_arr[0]
                        # transactionObj = models.Transaction.objects.filter(order_no=request.session['partnerTxId']).first()
                        transactionObj = models.Transaction.objects.filter(order_no=grab_transaction_id).first()
                        # transactions = models.Transaction.objects.get(id=730)
                        # transactions.remark = json.dumps(completeCharge)
                        # transactions.save()
                        if (transactionObj):

                            if (transactionObj.transaction_status == 0):
                                with transaction.atomic():
                                    # coupon set transaction status=5 directly
                                    temp_transaction_status = 2
                                    has_voucher = False
                                    has_other = False
                                    invicode_num = 0
                                    transDetailsList = models.TransactDetails.objects.filter(
                                        transaction__id=transactionObj.id)
                                    if transDetailsList:
                                        for details in transDetailsList:
                                            temp_product = details.product
                                            quantity = details.quantity
                                            invicode_num = invicode_num + quantity
                                            if temp_product:
                                                voucher = temp_product.voucher
                                                if voucher:
                                                    temp_transaction_status = 5
                                                    voucher_expire_date = voucher.expiring_date
                                                    has_voucher = True

                                                    invicode_register_date = datetime.datetime.now().date()
                                                    interval = voucher_expire_date - invicode_register_date
                                                    valid_days = interval.days
                                                    for i in range(0, quantity):
                                                        models.Invicode.objects.create(
                                                            **{'voucher': voucher, 'code': generate_random_str(),
                                                               'status': 1,
                                                               'member': transactionObj.member,
                                                               'register_date': datetime.datetime.now(),
                                                               'vaild_days': valid_days,
                                                               'expire_date': voucher_expire_date})
                                                else:
                                                    has_other = True
                                    if has_other:
                                        temp_transaction_status = 2
                                    # coupon set transaction status=5 directly
                                    transactionObj.payment_datetime = time.strftime("%Y-%m-%d %H:%M:%S",
                                                                                    time.localtime())
                                    # transactionObj.transact_datetime = time.strftime("%Y-%m-%d %H:%M:%S",time.localtime())
                                    transactionObj.payment_modes = 12
                                    transactionObj.transaction_status = temp_transaction_status
                                    '''
                                    if (transactionObj.pick_up_time == 0):
                                        transactionObj.delay_time = now + datetime.timedelta(minutes=5)
                                    elif (transactionObj.pick_up_time == 1):
                                        transactionObj.delay_time = now + datetime.timedelta(minutes=15)
                                    elif (transactionObj.pick_up_time == 2):
                                        transactionObj.delay_time = now + datetime.timedelta(minutes=30)
                                    elif (transactionObj.pick_up_time == 3):
                                        transactionObj.delay_time = now + datetime.timedelta(minutes=45)
                                    elif (transactionObj.pick_up_time == 4):
                                        transactionObj.delay_time = now + datetime.timedelta(minutes=60)
                                    '''
                                    if transactionObj.delay_time:
                                        delay_time = transactionObj.delay_time
                                        delay_time = delay_time + datetime.timedelta(hours=8)
                                        if delay_time.replace(tzinfo=None) < now:
                                            transactionObj.delay_time = now + datetime.timedelta(minutes=5)
                                    else:
                                        transactionObj.delay_time = now + datetime.timedelta(minutes=5)

                                    transactionObj.grab_txID = txID
                                    transactionObj.save()
                                    # modify invicode status
                                    if transactionObj.redeem_invicode is not None and transactionObj.redeem_invicode != 0:
                                        invicodeObj = models.Invicode.objects.get(
                                            id=transactionObj.redeem_invicode)
                                        if (invicodeObj):
                                            invicodeObj.status = 2
                                            invicodeObj.redeem_date = time.strftime("%Y-%m-%d %H:%M:%S",
                                                                                    time.localtime())
                                            invicodeObj.save()
                                    # update member last purchase datetime
                                    member_id = transactionObj.member.id
                                    member = models.Member.objects.get(id=member_id)
                                    member.last_purchase_date = time.strftime("%Y-%m-%d", time.localtime())
                                    member.save()
                                    # purchase coupon voucher to direct collected,update member points
                                    if has_voucher:
                                        update_member_points(member, transactionObj.total_money, 1, None, None)
                                        if invicode_num > 0:
                                            if voucher:
                                                pass
                                                '''
                                                invicode_amount = models.Invicode.objects.filter(voucher__id=voucher.id,register_date__date=datetime.datetime.now().date()).aggregate(count=Count('id'))
                                                if invicode_amount:
                                                    invicodeTable = "<h4 style='text-align:center'  >Mooncake voucher purchase</h4><table border='1' cellspacing='0' style='text-align:center' ><tr><td colspan='5'  style='text-align:left' >order no:" + transactionObj.order_no + "</td></tr><tr><td>member mobile</td><td>register time</td><td>quantity</td><td>today sum</td><td>payment time </td></tr><tr>" + \
                                                                    "<td>" + member.mobile_no + "</td><td>" + datetime.datetime.strftime(member.registration_date,"%Y-%m-%d %H:%M:%S") + "</td><td>" + str(invicode_num) + "</td>" + str(invicode_amount['count']) + "<td>" + datetime.datetime.strftime( now,"%Y-%m-%d %H:%M:%S") + "</td></tr></table></br></br>"
                                                    thread_send_mail(invicodeTable, "VoucherPurchase")
                                                '''
                                    wallet = models.Wallet.objects.get(member__id=member_id)
                                    # member cashbak
                                    # member_payment_cashback(transactionObj, member, wallet, amount/100, 6)
                                    # return cash to wallet campaign(every payment cash back) start
                                    '''
                                    campaign_Wallet = models.Campaign_Wallet.objects.first()
                                    if campaign_Wallet and campaign_Wallet.activity_status:

                                        if campaign_Wallet.purchase_return_wallet_percent:

                                            campgign_result = float(amount / 100) * campaign_Wallet.purchase_return_wallet_percent
                                    '''
                                    # return cash to wallet campaign(every payment cash back) end
                                    # new cashback from member membership start #
                                    if member:
                                        member_ship = member.membership
                                        if member_ship:
                                            cashback_percent = member_ship.cash_back
                                            campgign_result = float(amount / 100) * cashback_percent
                                            # new cashback from member membership end #
                                            # origin_num = Decimal(campgign_result)
                                            # campaign_return_money=origin_num.quantize(Decimal('0.00'), rounding=ROUND_HALF_UP)
                                            # transactionObj.discount_amount = 1
                                            # transactionObj.save()
                                            campaign_result_str = '%.2f' % campgign_result
                                            campaign_return_money = float(campaign_result_str)
                                            # campaign_return=round(float(amount)*campaign_Wallet.purchase_return_wallet_percent,2)
                                            if (campaign_return_money >= 0.01):
                                                # wallet = models.Wallet.objects.get(member__id=member_id)
                                                if wallet:
                                                    # purchase record
                                                    serializer = RechargeRecordCreateSerializer(
                                                        data={'money': amount / 100, 'wallet': wallet.id, 'type': 6})
                                                    if serializer.is_valid():
                                                        models.RechargeRecord.objects.create(
                                                            **serializer.validated_data)
                                                    outlet = transactionObj.outlet
                                                    if outlet:
                                                        if outlet.has_cashback:
                                                            wallet.balance += campaign_return_money
                                                            wallet.save()
                                                            serializer = RechargeRecordCreateSerializer(
                                                                data={'money': float(campaign_return_money),
                                                                      'wallet': wallet.id, 'type': 3,

                                                                      'status': 1})
                                                            if serializer.is_valid():
                                                                instance = models.RechargeRecord.objects.create(
                                                                    **serializer.validated_data)
                                                            # add campaign return cash to transaction record
                                                            if transactionObj.campaign_return_wallet_cash:
                                                                transactionObj.campaign_return_wallet_cash += campaign_return_money
                                                            else:
                                                                transactionObj.campaign_return_wallet_cash = campaign_return_money
                                                            transactionObj.save()
                                                    # send message
                                                    device_token = member.device_token
                                                    if device_token:
                                                        send_message_to_token(device_token,
                                                                              'GrabPay payment successful', 'thank you')

                                    # purchase campaign return cash to wallet
                                    '''
                                    purchase_return_wallet_amount = campaign_return(member, float(amount / 100))
                                    if purchase_return_wallet_amount>0:
                                        wallet = models.Wallet.objects.get(member__id=member_id)
                                        if wallet:

                                            wallet.balance += purchase_return_wallet_amount
                                            wallet.save()
                                            serializer = RechargeRecordCreateSerializer(
                                                data={'money': float(purchase_return_wallet_amount),
                                                      'wallet': wallet.id, 'type': 3,

                                                      'status': 1})
                                            if serializer.is_valid():
                                                instance = models.RechargeRecord.objects.create(
                                                    **serializer.validated_data)
                                            # add campaign return cash to transaction record
                                            if transactionObj.campaign_return_wallet_cash:
                                                transactionObj.campaign_return_wallet_cash += purchase_return_wallet_amount
                                            else:
                                                transactionObj.campaign_return_wallet_cash = purchase_return_wallet_amount
                                            transactionObj.save()
                                    if member:

                                        if member.non_wallet_pay_times:
                                            member.non_wallet_pay_times = member.non_wallet_pay_times + 1
                                        else:
                                            member.non_wallet_pay_times = 1







                                    member.save()
                                     '''

                                    # send mail
                                    '''
                                    countTable = "<h4 style='text-align:center'  >Mobile ordering payment</h4><table border='1' cellspacing='0' style='text-align:center' ><tr><td colspan='5'  style='text-align:left' >order no:" + transactionObj.order_no + "</td></tr><tr><td>member mobile</td><td>outlet</td><td>amount</td><td>payment method</td><td>payment time </td></tr><tr>" + \
                                                 "<td>" + member.mobile_no + "</td><td>" + transactionObj.outlet.outlet_name + "</td><td>" + str(transactionObj.total_money) + "</td><td>" + \
                                                 "grab pay" + "</td><td>" + time.strftime("%Y-%m-%d %H:%M:%S",time.localtime()) + "</td></tr></table>"
                                                 '''
                                    # countTable=get_payment_mail_table(transactionObj, member, wallet.id, "GrabPay")
                                    # utils.send_register_email(utils.RECEIVE_MAIL, countTable,send_type="payment", promotion='')
                                    # thread_send_mail(countTable, "payment")
                                    # send_mooncake_payment(transactionObj)
                        # success jump
                        context['hello'] = 'success,' + accessToken['access_token'] + ',' + str(
                            accessToken['expires_in'])

                    else:
                        context['hello'] = json.dumps(completeCharge['txStatus'] + ',' + completeCharge['reason'])
                elif 'reason' in completeCharge.keys():
                    context['hello'] = json.dumps(completeCharge['reason'])
                else:
                    context['hello'] = 'errors'
            else:
                context['hello'] = 'errors'

            # context['hello'] =json.dumps(accessToken)+json.dumps(completeCharge)
            # transStatus=tockenization.checkTransactionStatus(accessToken['access_token'],completeCharge['txID'])
            # context['hello'] =context['hello']+json.dumps(transStatus)

        else:
            if 'errors' in accessToken.keys():
                context['hello'] = accessToken['errors']

            else:
                # transaction = models.Transaction.objects.get(id=730)
                # transaction.remark = json.dumps(accessToken)
                # transaction.save()
                context['hello'] = json.dumps(accessToken)
        return HttpResponse(content=template.render(context), content_type='text/html; charset=utf-8', status=200)


    else:

        context['hello'] = 'Access token is error'
        return HttpResponse(content=template.render(context), content_type='text/html; charset=utf-8', status=200)


@api_view(['GET', 'POST'])
@authentication_classes([])
@permission_classes((AllowAny,))
def grab_token_direct_charge(request, *args, **kwargs):
    member_id = request.GET.get('member_id')
    topup_no = request.GET.get('topup_no')
    amount = int(request.GET.get('amount'))
    tockenization = tokenization.Tokenization('6962c659-7b30-48a7-9495-2cb6c7b34b32', 'RsEeUPTC6sq5bDnM',
                                              'bb6318fe450b4729adb831a2a87c5c7b', '3ybZRTq8hrd07tnl',
                                              '8be3a726-2c75-4750-af22-a1df55c2ba7f')

    description = 'TokenChargePayment'

    partnerGroupTxId = 'OrderID' + tockenization.generateNonce(4)

    # request.session['partnerTxId'] = 'IdempotencyKey' +tockenization.generateNonce(4)
    request.session['partnerTxId'] = topup_no
    request.session['member_id'] = member_id
    request.session['amount'] = amount
    request.session['codeVerifier'] = tockenization.generateNonce(64)

    context = {}
    context['hello'] = 'oauthAuthorizeUrl is empty'
    if member_id:
        wallet = models.Wallet.objects.get(member__id=member_id)
        if wallet:
            accessToken = wallet.grab_token
            completeCharge = tockenization.charge(accessToken, request.session['partnerTxId'],
                                                  partnerGroupTxId, amount, description)
            if completeCharge:
                # context['hello'] = json.dumps(accessToken) + json.dumps(completeCharge)
                # return HttpResponse(content=template.render(context), content_type='text/html; charset=utf-8',status=200)
                if 'txID' in completeCharge.keys():
                    txID = completeCharge['txID']
                    retStatus = completeCharge['status']
                    txStatus = completeCharge['txStatus']
                    reason = completeCharge['reason']
                    if (txStatus == 'success'):
                        with transaction.atomic():
                            wallet = models.Wallet.objects.get(member__id=request.session['member_id'])
                            if wallet:
                                # recharge campaign
                                campaign_return_cash = 0
                                campaignTopup = models.CampaignTopup.objects.first()
                                member = models.Member.objects.get(id=request.session['member_id'])
                                if member:
                                    topup_10_times = 0 if member.topup_10_times is None else member.topup_10_times
                                    topup_20_times = 0 if member.topup_20_times is None else member.topup_20_times
                                    topup_50_times = 0 if member.topup_50_times is None else member.topup_50_times
                                if campaignTopup:

                                    activity_flag = campaignTopup.activity_flag
                                    date_limit_flag = campaignTopup.date_limit_flag
                                    times_limit_flag = campaignTopup.times_limit_flag
                                    if activity_flag:
                                        if times_limit_flag:
                                            if date_limit_flag:
                                                pass

                                            else:
                                                if campaignTopup.topup_10_limit_times > topup_10_times and amount == 1000:
                                                    campaign_return_cash = campaignTopup.topup_10_return_cash
                                                if campaignTopup.topup_20_limit_times > topup_20_times and amount == 2000:
                                                    campaign_return_cash = campaignTopup.topup_20_return_cash
                                                if campaignTopup.topup_50_limit_times > topup_50_times and amount == 5000:
                                                    campaign_return_cash = campaignTopup.topup_50_return_cash

                                        else:
                                            if date_limit_flag:
                                                pass

                                            else:
                                                if amount == 1000:
                                                    campaign_return_cash = campaignTopup.topup_10_return_cash
                                                if amount == 2000:
                                                    campaign_return_cash = campaignTopup.topup_20_return_cash
                                                if amount == 5000:
                                                    campaign_return_cash = campaignTopup.topup_50_return_cash
                                if member.terminal == 1:
                                    pass
                                else:
                                    wallet.balance += float(amount / 100) + campaign_return_cash
                                    wallet.lastest_top_up = time.strftime("%Y-%m-%d", time.localtime())
                                    wallet.save()
                                    serializer = RechargeRecordCreateSerializer(
                                        data={'money': float(amount / 100), 'wallet': wallet.id, 'type': 0,
                                              'request_id': request.session['partnerTxId'],
                                              'status': 1, 'grab_txID': txID, 'topup_type': 1})
                                    if serializer.is_valid():
                                        instance = models.RechargeRecord.objects.create(**serializer.validated_data)
                                        # service.recharge(instance)

                                    if campaign_return_cash:
                                        serializer = RechargeRecordCreateSerializer(
                                            data={'money': campaign_return_cash, 'wallet': wallet.id, 'type': 3,
                                                  'grab_txID': txID,
                                                  'status': 1})
                                        if serializer.is_valid():
                                            instance = models.RechargeRecord.objects.create(**serializer.validated_data)
                                    if member.device_token:
                                        send_message_to_token(member.device_token, 'Top up reward',
                                                              'Amout: $' + str(campaign_return_cash))
                                    # service.recharge(instance)
                                    # memeber add topup times

                                    if member:
                                        if amount == 1000:
                                            if member.topup_10_times:
                                                member.topup_10_times = member.topup_10_times + 1
                                            else:
                                                member.topup_10_times = 1
                                        elif amount == 2000:
                                            if member.topup_20_times:
                                                member.topup_20_times = member.topup_20_times + 1
                                            else:
                                                member.topup_20_times = 1
                                        else:
                                            if member.topup_50_times:
                                                member.topup_50_times = member.topup_50_times + 1
                                            else:
                                                member.topup_50_times = 1
                                        member.save()
                                # send mail
                                '''
                                countTable = "<h4 style='text-align:center'  >Mobile top up payment</h4><table border='1' cellspacing='0' style='text-align:center' ><tr><td colspan='4'  style='text-align:left' >Grab TxId:" + txID + "</td></tr><tr><td>member mobile</td><td>amount</td><td>payment method</td><td>payment time </td></tr><tr>" + \
                                             "<td>" + member.mobile_no + "</td><td>" + str(
                                    amount/100) + "</td><td>" + \
                                             "grab pay" + "</td><td>" + time.strftime("%Y-%m-%d %H:%M:%S",
                                                                                          time.localtime()) + "</td></tr></table>"
                                '''
                                amount_val = float(amount / 100)
                                # countTable = get_topup_mail_table(wallet, member, wallet.id, "Grabpay", amount_val)
                                # if member.terminal == 0:
                                # utils.send_register_email(utils.RECEIVE_MAIL, countTable, send_type="topup", promotion='')
                                # thread_send_mail(countTable, "topup")
                            # success jump
                            return Response({'msg': 'success'}, status=status.HTTP_200_OK)


                    else:

                        return Response({'msg': txStatus}, status=status.HTTP_200_OK)
                elif 'reason' in completeCharge.keys():
                    context['hello'] = json.dumps(completeCharge['reason'])
                else:
                    context['hello'] = 'errors'

    return Response({'msg': 'errors'}, status.HTTP_200_OK)


@api_view(['GET', 'POST'])
@authentication_classes([])
@permission_classes((AllowAny,))
def grab_token_direct_charge_pay(request, *args, **kwargs):
    now = datetime.datetime.now()
    member_id = request.GET.get('member_id')
    order_no = request.GET.get('order_no')
    amount = int(request.GET.get('amount'))
    tockenization = tokenization.Tokenization('6962c659-7b30-48a7-9495-2cb6c7b34b32', 'RsEeUPTC6sq5bDnM',
                                              'bb6318fe450b4729adb831a2a87c5c7b', '3ybZRTq8hrd07tnl',
                                              '8be3a726-2c75-4750-af22-a1df55c2ba7f')

    description = 'TokenChargePayment'

    # transactions = models.Transaction.objects.get(id=730)
    # transactions.remark = str(member_id)+'  '+order_no+'  '+str(amount)
    # transactions.save()

    partnerGroupTxId = 'OrderID' + tockenization.generateNonce(4)

    # request.session['partnerTxId'] = 'IdempotencyKey' +tockenization.generateNonce(4)
    request.session['partnerTxId'] = order_no
    request.session['member_id'] = member_id
    request.session['amount'] = amount
    request.session['codeVerifier'] = tockenization.generateNonce(64)

    context = {}
    context['hello'] = 'oauthAuthorizeUrl is empty'
    if member_id:
        wallet = models.Wallet.objects.get(member__id=member_id)
        if wallet:
            accessToken = wallet.grab_token
            completeCharge = tockenization.charge(accessToken, request.session['partnerTxId'],
                                                  partnerGroupTxId, amount, description)
            if completeCharge:
                # context['hello'] = json.dumps(accessToken) + json.dumps(completeCharge)
                # return HttpResponse(content=template.render(context), content_type='text/html; charset=utf-8',status=200)
                if 'txID' in completeCharge.keys():
                    txID = completeCharge['txID']
                    retStatus = completeCharge['status']
                    txStatus = completeCharge['txStatus']
                    reason = completeCharge['reason']
                    if (txStatus == 'success'):

                        transactionObj = models.Transaction.objects.get(order_no=request.session['partnerTxId'])
                        # transactions = models.Transaction.objects.get(id=730)
                        # transactions.remark = json.dumps(completeCharge)
                        # transactions.save()
                        if (transactionObj):

                            if (transactionObj.transaction_status == 0):
                                with transaction.atomic():
                                    # coupon set transaction status=5 directly
                                    temp_transaction_status = 2
                                    has_voucher = False
                                    has_other = False
                                    invicode_num = 0
                                    transDetailsList = models.TransactDetails.objects.filter(
                                        transaction__id=transactionObj.id)
                                    if transDetailsList:
                                        for details in transDetailsList:
                                            temp_product = details.product
                                            quantity = details.quantity
                                            invicode_num = invicode_num + quantity
                                            if temp_product:
                                                voucher = temp_product.voucher
                                                if voucher:
                                                    temp_transaction_status = 5
                                                    voucher_expire_date = voucher.expiring_date
                                                    has_voucher = True

                                                    invicode_register_date = datetime.datetime.now().date()
                                                    interval = voucher_expire_date - invicode_register_date
                                                    valid_days = interval.days
                                                    for i in range(0, quantity):
                                                        models.Invicode.objects.create(
                                                            **{'voucher': voucher, 'code': generate_random_str(),
                                                               'status': 1,
                                                               'member': transactionObj.member,
                                                               'register_date': datetime.datetime.now(),
                                                               'vaild_days': valid_days,
                                                               'expire_date': voucher_expire_date})
                                                else:
                                                    has_other = True
                                    if has_other:
                                        temp_transaction_status = 2
                                    # coupon set transaction status=5 directly
                                    transactionObj.payment_datetime = time.strftime("%Y-%m-%d %H:%M:%S",
                                                                                    time.localtime())
                                    # transactionObj.transact_datetime = time.strftime("%Y-%m-%d %H:%M:%S",time.localtime())
                                    transactionObj.payment_modes = 12
                                    transactionObj.transaction_status = temp_transaction_status
                                    transactionObj.grab_txID = txID
                                    '''
                                    if (transactionObj.pick_up_time == 0):
                                        transactionObj.delay_time = now + datetime.timedelta(minutes=5)
                                    elif (transactionObj.pick_up_time == 1):
                                        transactionObj.delay_time = now + datetime.timedelta(minutes=15)
                                    elif (transactionObj.pick_up_time == 2):
                                        transactionObj.delay_time = now + datetime.timedelta(minutes=30)
                                    elif (transactionObj.pick_up_time == 3):
                                        transactionObj.delay_time = now + datetime.timedelta(minutes=45)
                                    elif (transactionObj.pick_up_time == 4):
                                        transactionObj.delay_time = now + datetime.timedelta(minutes=60)
                                    '''
                                    if transactionObj.delay_time:
                                        delay_time = transactionObj.delay_time
                                        delay_time = delay_time + datetime.timedelta(hours=8)
                                        if delay_time.replace(tzinfo=None) < now:
                                            transactionObj.delay_time = now + datetime.timedelta(minutes=5)
                                    else:
                                        transactionObj.delay_time = now + datetime.timedelta(minutes=5)

                                    transactionObj.save()
                                    # modify invicode status
                                    if transactionObj.redeem_invicode is not None and transactionObj.redeem_invicode != 0:
                                        invicodeObj = models.Invicode.objects.get(id=transactionObj.redeem_invicode)
                                        if (invicodeObj):
                                            invicodeObj.status = 2
                                            invicodeObj.redeem_date = time.strftime("%Y-%m-%d %H:%M:%S",
                                                                                    time.localtime())
                                            invicodeObj.save()
                                    # update member last purchase datetime
                                    member_id = transactionObj.member.id
                                    member = models.Member.objects.get(id=member_id)
                                    member.last_purchase_date = time.strftime("%Y-%m-%d", time.localtime())
                                    member.save()
                                    # purchase coupon voucher to direct collected,update member points
                                    if has_voucher:
                                        update_member_points(member, transactionObj.total_money, 1, None, None)
                                        if invicode_num > 0:
                                            if voucher:
                                                invicode_amount = models.Invicode.objects.filter(voucher__id=voucher.id,
                                                                                                 register_date__date=datetime.datetime.now().date()).aggregate(
                                                    count=Count('id'))
                                                if invicode_amount:
                                                    invicodeTable = "<h4 style='text-align:center'  >Mooncake voucher purchase</h4><table border='1' cellspacing='0' style='text-align:center' ><tr><td colspan='5'  style='text-align:left' >order no:" + transactionObj.order_no + "</td></tr><tr><td>member mobile</td><td>register time</td><td>quantity</td><td>today sum</td><td>payment time </td></tr><tr>" + \
                                                                    "<td>" + member.mobile_no + "</td><td>" + datetime.datetime.strftime(
                                                        member.registration_date,
                                                        "%Y-%m-%d %H:%M:%S") + "</td><td>" + str(
                                                        invicode_num) + "</td>" + str(
                                                        invicode_amount['count']) + "<td>" + datetime.datetime.strftime(
                                                        now, "%Y-%m-%d %H:%M:%S") + "</td></tr></table></br></br>"
                                                    thread_send_mail(invicodeTable, "VoucherPurchase")
                                    wallet = models.Wallet.objects.get(member__id=member_id)
                                    # member cashbak
                                    # member_payment_cashback(transactionObj, member, wallet, amount / 100, 6)
                                    # return cash to wallet campaign(every payment cash back) start
                                    '''
                                    campaign_Wallet = models.Campaign_Wallet.objects.first()
                                    if campaign_Wallet and campaign_Wallet.activity_status:

                                        if campaign_Wallet.purchase_return_wallet_percent:

                                            campgign_result = float(amount / 100) * campaign_Wallet.purchase_return_wallet_percent
                                    '''
                                    # return cash to wallet campaign(every payment cash back) end
                                    # new cashback from member membership start #
                                    if member:
                                        member_ship = member.membership
                                        if member_ship:
                                            cashback_percent = member_ship.cash_back
                                            campgign_result = float(amount / 100) * cashback_percent
                                            # new cashback from member membership end #
                                            # origin_num = Decimal(campgign_result)
                                            # campaign_return_money = origin_num.quantize(Decimal('0.00'),rounding=ROUND_HALF_UP)

                                            campaign_result_str = '%.2f' % campgign_result
                                            campaign_return_money = float(campaign_result_str)
                                            # transactionObj.discount_amount = 1
                                            # transactionObj.save()
                                            # campaign_return=round(float(amount)*campaign_Wallet.purchase_return_wallet_percent,2)
                                            if (campaign_return_money >= 0.01):
                                                # wallet = models.Wallet.objects.get(member__id=member_id)
                                                if wallet:
                                                    # purchase record
                                                    serializer = RechargeRecordCreateSerializer(
                                                        data={'money': amount / 100, 'wallet': wallet.id, 'type': 6})
                                                    if serializer.is_valid():
                                                        models.RechargeRecord.objects.create(
                                                            **serializer.validated_data)
                                                    outlet = transactionObj.outlet
                                                    if outlet:
                                                        if outlet.has_cashback:
                                                            wallet.balance += campaign_return_money
                                                            wallet.save()
                                                            serializer = RechargeRecordCreateSerializer(
                                                                data={'money': float(campaign_return_money),
                                                                      'wallet': wallet.id, 'type': 3,

                                                                      'status': 1})
                                                            if serializer.is_valid():
                                                                instance = models.RechargeRecord.objects.create(
                                                                    **serializer.validated_data)
                                                            # add campaign return cash to transaction record
                                                            if transactionObj.campaign_return_wallet_cash:
                                                                transactionObj.campaign_return_wallet_cash += campaign_return_money
                                                            else:
                                                                transactionObj.campaign_return_wallet_cash = campaign_return_money
                                                            transactionObj.save()
                                                    # send message
                                                    device_token = member.device_token
                                                    if device_token:
                                                        send_message_to_token(device_token,
                                                                              'GrabPay payment successful', 'thank you')
                                    # purchase campaign return cash to wallet
                                    '''
                                    purchase_return_wallet_amount = campaign_return(member, float(amount/100))
                                    if purchase_return_wallet_amount>0:
                                        wallet = models.Wallet.objects.get(member__id=member_id)
                                        if wallet:

                                            wallet.balance += purchase_return_wallet_amount
                                            wallet.save()
                                            serializer = RechargeRecordCreateSerializer(
                                                data={'money': float(purchase_return_wallet_amount),
                                                      'wallet': wallet.id, 'type': 3,

                                                      'status': 1})
                                            if serializer.is_valid():
                                                instance = models.RechargeRecord.objects.create(
                                                    **serializer.validated_data)
                                            # add campaign return cash to transaction record
                                            if transactionObj.campaign_return_wallet_cash:
                                                transactionObj.campaign_return_wallet_cash += purchase_return_wallet_amount
                                            else:
                                                transactionObj.campaign_return_wallet_cash = purchase_return_wallet_amount
                                            transactionObj.save()
                                    if member:

                                        if member.non_wallet_pay_times:
                                            member.non_wallet_pay_times = member.non_wallet_pay_times + 1
                                        else:
                                            member.non_wallet_pay_times = 1





                                    member.save()
                                    '''
                                    # send mail
                                    '''
                                    countTable = "<h4 style='text-align:center'  >Mobile ordering payment</h4><table border='1' cellspacing='0' style='text-align:center' ><tr><td colspan='5'  style='text-align:left' >order no:" + transactionObj.order_no + "</td></tr><tr><td>member mobile</td><td>outlet</td><td>amount</td><td>payment method</td><td>payment time </td></tr><tr>" + \
                                                 "<td>" + member.mobile_no + "</td><td>" + transactionObj.outlet.outlet_name + "</td><td>" + str(
                                        transactionObj.total_money) + "</td><td>" + \
                                                 "grab pay" + "</td><td>" + time.strftime("%Y-%m-%d %H:%M:%S",
                                                                                          time.localtime()) + "</td></tr></table>"
                                    '''
                                    # countTable = get_payment_mail_table(transactionObj, member, wallet.id,'GrabPay')
                                    # utils.send_register_email(utils.RECEIVE_MAIL, countTable,send_type="payment", promotion='')
                                    # thread_send_mail(countTable, "payment")
                                    send_mooncake_payment(transactionObj)
                        # success jump
                        return Response({'msg': 'success'}, status=status.HTTP_200_OK)


                    else:
                        return Response({'msg': txStatus}, status=status.HTTP_200_OK)
                elif 'reason' in completeCharge.keys():
                    context['hello'] = json.dumps(completeCharge['reason'])
                else:
                    context['hello'] = 'errors'

    return Response({'msg': 'errors'}, status.HTTP_200_OK)


@api_view(['GET', 'POST'])
@authentication_classes([])
@permission_classes((AllowAny,))
def grab_get_walletInfo(request, *args, **kwargs):
    tockenization = tokenization.Tokenization('6962c659-7b30-48a7-9495-2cb6c7b34b32', 'RsEeUPTC6sq5bDnM',
                                              'bb6318fe450b4729adb831a2a87c5c7b', '3ybZRTq8hrd07tnl',
                                              '8be3a726-2c75-4750-af22-a1df55c2ba7f')
    accessToken = request.data.get('token')
    context = {}

    if accessToken is not None and accessToken != '':
        walletInfo = tockenization.getWalletInfo(accessToken)
        if walletInfo:
            # transaction = models.Transaction.objects.get(id=730)
            # transaction.remark = json.dumps(walletInfo)
            # transaction.save()
            # if not 'request' in initCharge.keys():
            # context['hello']=json.dumps(walletInfo)
            # return render(request, 'index.html', context)
            if 'isPaymentAllowed' in walletInfo.keys() and 'balance' in walletInfo.keys():
                return Response({'amount': str(walletInfo['balance']), 'status': str(walletInfo['isPaymentAllowed'])},
                                status=status.HTTP_200_OK)
            else:
                return Response({'amount': '-1', 'status': 'error'}, status=status.HTTP_200_OK)

        else:
            # context['hello']='Empty wallet info'
            # return render(request, 'index.html', context)
            return Response({'amount': '-1', 'status': 'error'}, status=status.HTTP_200_OK)
    return Response({'amount': '-1', 'status': 'error'}, status=status.HTTP_200_OK)
    # else:
    #   oauthAuthorizeUrl = tockenization.getOauthAuthorizeUrl(request.session['codeVerifier'], initCharge['request'], request.session['redirectUrl'], 'payment.recurring_charge')
    # if oauthAuthorizeUrl:
    #   return  HttpResponseRedirect(oauthAuthorizeUrl)
    # else:
    #   return render(request, 'index.html', context)


@api_view(['GET', 'POST'])
@authentication_classes([])
@permission_classes((AllowAny,))
@renderer_classes((TemplateHTMLRenderer, StaticHTMLRenderer,))
def grab_check_transaction_status(request, *args, **kwargs):
    tockenization = tokenization.Tokenization('6962c659-7b30-48a7-9495-2cb6c7b34b32', 'RsEeUPTC6sq5bDnM',
                                              'bb6318fe450b4729adb831a2a87c5c7b', '3ybZRTq8hrd07tnl',
                                              '8be3a726-2c75-4750-af22-a1df55c2ba7f')
    accessToken = 'eyJhbGciOiJSUzI1NiIsImtpZCI6Il9kZWZhdWx0IiwidHlwIjoiSldUIn0.eyJhdWQiOiJkNDE5Zjk1MWRkNTU0OGU4ODM2ODM5OTZkMDg4ZDBmZCIsImV4cCI6MTg4MzYyMjg0NywiaWF0IjoxNTY4MjYyODQ3LCJpbnRfc3ZjX2F1dGh6X2N0eCI6ImZlODc0MDI5M2ViNDQzOGQ5OGY3MDZjMDNlMWMxOGJmIiwiaXNzIjoiaHR0cHM6Ly9pZHAuZ3JhYi5jb20iLCJqdGkiOiI3MjVvX09YMVFyZTJVQTNRbFdaTHdnIiwibmJmIjoxNTY4MjYyNjY3LCJwaWQiOiJlODJjYTZmZi0zOTU2LTQzZmQtYmYzZi0wNzA3MTQwOGFkNDkiLCJzY3AiOiJbXCJmM2JkNDVkNzFlOWY0NDgyOTgzOTZmNTI5ZmY5YzYxM1wiXSIsInN1YiI6IjkyMjM4MDU5LWZiZmEtNGZhMC05NGJkLWU2ZGRiMTY4ZTgxOCIsInN2YyI6IlBBU1NFTkdFUiIsInRrX3R5cGUiOiJhY2Nlc3MifQ.QSdVt0HK30RM_zr3ClwQoSgDiBgp0_kXd5WJ8TS36ViExCg2QVKy4TDHeNLQ8Kb09Q_POdUscdP2uaP6zdPp6uIBs0zft1xptRviU-E1EqdVkbyPxGWHYXmQyXKNklSJVlQbvQvhYg8xRXp51Ti8iZyn-fUx94EmsujhrvzrceODtKkjEmA-X2EekhS9PXRBK5Eul7j1hP6I-o4kIGzPBwHHXzHy210d3D8goHwLJtu1JuVxBkc7SYc6bYjyKymkinUOgc-M_ftKeHzmWIXF7hCNxTpBC6euNwnlrN9nwxQFtpo8Os9ketaobSMjHoJr-dpgQiRRqw5ynXmYVA64Lg'
    context = {}
    transactionID = '8ed28ef979f24447930244903c16dcb2'
    transStatus = tockenization.checkTransactionStatus(accessToken, transactionID)

    if transStatus:
        # if not 'request' in initCharge.keys():
        context['hello'] = json.dumps(transStatus)
        return render(request, 'index.html', context)
    else:
        context['hello'] = 'Empty wallet info'
        return render(request, 'index.html', context)


@api_view(['GET', 'POST'])
@authentication_classes([])
@permission_classes((AllowAny,))
def unbind_grab_pay(request, *args, **kwargs):
    member_id = request.GET.get('member_id')
    order_no = request.GET.get('order_no')

    tockenization = tokenization.Tokenization('6962c659-7b30-48a7-9495-2cb6c7b34b32', 'RsEeUPTC6sq5bDnM',
                                              'bb6318fe450b4729adb831a2a87c5c7b', '3ybZRTq8hrd07tnl',
                                              '8be3a726-2c75-4750-af22-a1df55c2ba7f')

    description = 'TokenChargePayment'
    if member_id:
        wallet = models.Wallet.objects.get(member__id=member_id)
        if wallet:
            accessToken = wallet.grab_token
            tockenization.unbind(accessToken, order_no)
            wallet.grab_token = None
            wallet.grab_expire = None
            wallet.save()

    return Response({'msg': 'unbind_ok'}, status=status.HTTP_200_OK)


'''
stripe.api_key = settings.STRIPE_SECRET_KEY # new

@api_view(['POST'])
@authentication_classes([])
@permission_classes((AllowAny,))

def charge(request, *args, **kwargs):

    try:
        amount =request.data.get('amount')
        charge = stripe.Charge.create(
            amount=request.data.get('amount'),
            currency=request.data.get('currency'),
            source=request.data.get('source'),
            description=request.data.get('description'),
            statement_descriptor="22 Characters max",
            metadata={'order_id': 12345}
        )

        # Only confirm an order after you have status: succeeded
        print("______STATUS_____", charge['status'])  # should be succeeded
        if charge['status'] == 'succeeded':

            mobile_no=request.data.get('user')
            money = int(int(request.data.get('money'))/100)
            wallet = request.data.get('wallet')
            serializer = serializers.RechargeRecordCreateSerializer(data={'money': money , 'wallet': wallet})
            if serializer.is_valid():
                instance=models.RechargeRecord.objects.create(**serializer.validated_data)
                service.recharge(instance)
                #return instance
                print(request.POST.get('user', ''))
                return HttpResponse(json.dumps(
                    {'message': 'Your charge has been successful.'})
                )
            else:
                return HttpResponse(json.dumps(
                    {'message': 'Charge parameter error.'})
                )

        else:
            raise stripe.error.CardError
    except stripe.error.CardError as e:
        body = e.json_body
        err = body.get('error', {})
        print('Status is: %s' % e.http_status)
        print('Type is: %s' % err.get('type'))
        print('Code is: %s' % err.get('code'))
        print('Message is %s' % err.get('message'))
        return HttpResponse(
            json.dumps({"message": err.get('message')}),
            status=e.http_status
        )
    except stripe.error.RateLimitError as e:
        # Too many requests made to the API too quickly
        return HttpResponse(json.dumps({
            'message': "The API was not able to respond, try again."
        }))
    except stripe.error.InvalidRequestError as e:
        # invalid parameters were supplied to Stripe's API
        return HttpResponse(json.dumps({
            'message': "Invalid parameters, unable to process payment."
        }))
    except stripe.error.AuthenticationError as e:
        # Authentication with Stripe's API failed
        # (maybe you changed API keys recently)
        pass
    except stripe.error.APIConnectionError as e:
        # Network communication with Stripe failed
        return HttpResponse(json.dumps({
            'message': 'Network communication failed, try again.'
        }))
    except stripe.error.StripeError as e:
        # Display a very generic error to the user, and maybe
        # send yourself an email
        return HttpResponse(json.dumps({
            'message': 'Internal Error, contact support.'
        }))

    # Something else happened, completely unrelated to Stripe
    except Exception as e:
        return HttpResponse(json.dumps({
            'message': 'Unable to process payment, try again.'
        }))'''


@api_view(['GET', 'POST'])
@authentication_classes([])
@permission_classes((AllowAny,))
def grab_token_direct_charge_new(request, *args, **kwargs):
    member_id = request.GET.get('member_id')
    topup_no = request.GET.get('topup_no')
    amount = int(request.GET.get('amount'))
    tockenization = tokenization.Tokenization('6962c659-7b30-48a7-9495-2cb6c7b34b32', 'RsEeUPTC6sq5bDnM',
                                              'bb6318fe450b4729adb831a2a87c5c7b', '3ybZRTq8hrd07tnl',
                                              '8be3a726-2c75-4750-af22-a1df55c2ba7f')

    description = 'TokenChargePayment'

    partnerGroupTxId = 'OrderID' + tockenization.generateNonce(4)

    # request.session['partnerTxId'] = 'IdempotencyKey' +tockenization.generateNonce(4)
    request.session['partnerTxId'] = topup_no
    request.session['member_id'] = member_id
    request.session['amount'] = amount
    request.session['codeVerifier'] = tockenization.generateNonce(64)

    context = {}
    context['hello'] = 'oauthAuthorizeUrl is empty'
    if member_id:
        wallet = models.Wallet.objects.get(member__id=member_id)
        if wallet:
            accessToken = wallet.grab_token
            completeCharge = tockenization.charge(accessToken, request.session['partnerTxId'],
                                                  partnerGroupTxId, amount, description)
            if completeCharge:
                # context['hello'] = json.dumps(accessToken) + json.dumps(completeCharge)
                # return HttpResponse(content=template.render(context), content_type='text/html; charset=utf-8',status=200)
                if 'txID' in completeCharge.keys():
                    txID = completeCharge['txID']
                    retStatus = completeCharge['status']
                    txStatus = completeCharge['txStatus']
                    reason = completeCharge['reason']
                    if (txStatus == 'success'):
                        with transaction.atomic():
                            wallet = models.Wallet.objects.get(member__id=request.session['member_id'])
                            if wallet:
                                # recharge campaign
                                campaign_return_cash = 0
                                campaignTopup = models.CampaignTopup.objects.first()
                                member = models.Member.objects.get(id=request.session['member_id'])
                                if member:
                                    topup_10_times = 0 if member.topup_10_times is None else member.topup_10_times
                                    topup_20_times = 0 if member.topup_20_times is None else member.topup_20_times
                                    topup_50_times = 0 if member.topup_50_times is None else member.topup_50_times
                                if campaignTopup:

                                    activity_flag = campaignTopup.activity_flag
                                    date_limit_flag = campaignTopup.date_limit_flag
                                    times_limit_flag = campaignTopup.times_limit_flag
                                    if activity_flag:
                                        if times_limit_flag:
                                            if date_limit_flag:
                                                pass

                                            else:
                                                if campaignTopup.topup_10_limit_times > topup_10_times and amount == 1000:
                                                    campaign_return_cash = campaignTopup.topup_10_return_cash
                                                if campaignTopup.topup_20_limit_times > topup_20_times and amount == 2000:
                                                    campaign_return_cash = campaignTopup.topup_20_return_cash
                                                if campaignTopup.topup_50_limit_times > topup_50_times and amount == 5000:
                                                    campaign_return_cash = campaignTopup.topup_50_return_cash

                                        else:
                                            if date_limit_flag:
                                                pass

                                            else:
                                                if amount == 1000:
                                                    campaign_return_cash = campaignTopup.topup_10_return_cash
                                                if amount == 2000:
                                                    campaign_return_cash = campaignTopup.topup_20_return_cash
                                                if amount == 5000:
                                                    campaign_return_cash = campaignTopup.topup_50_return_cash
                                # if member and (member.mobile_no=='84848166' or member.mobile_no=='98524980' or  member.mobile_no=='91489401'):
                                wallet.balance += float(amount / 100) + campaign_return_cash
                                wallet.lastest_top_up = time.strftime("%Y-%m-%d", time.localtime())
                                wallet.save()
                                serializer = RechargeRecordCreateSerializer(
                                    data={'money': float(amount / 100), 'wallet': wallet.id, 'type': 0,
                                          'request_id': request.session['partnerTxId'],
                                          'status': 1, 'grab_txID': txID, 'topup_type': 1})
                                if serializer.is_valid():
                                    instance = models.RechargeRecord.objects.create(**serializer.validated_data)
                                    # service.recharge(instance)

                                if campaign_return_cash:
                                    serializer = RechargeRecordCreateSerializer(
                                        data={'money': campaign_return_cash, 'wallet': wallet.id, 'type': 3,
                                              'grab_txID': txID,
                                              'status': 1})
                                    if serializer.is_valid():
                                        instance = models.RechargeRecord.objects.create(**serializer.validated_data)
                                    if member.device_token:
                                        send_message_to_token(member.device_token, 'Top up reward',
                                                              'Amout: $' + str(campaign_return_cash))
                                    # service.recharge(instance)
                                # memeber add topup times

                                if member:
                                    if amount == 1000:
                                        if member.topup_10_times:
                                            member.topup_10_times = member.topup_10_times + 1
                                        else:
                                            member.topup_10_times = 1
                                    elif amount == 2000:
                                        if member.topup_20_times:
                                            member.topup_20_times = member.topup_20_times + 1
                                        else:
                                            member.topup_20_times = 1
                                    else:
                                        if member.topup_50_times:
                                            member.topup_50_times = member.topup_50_times + 1
                                        else:
                                            member.topup_50_times = 1
                                    member.save()
                                # send mail
                                '''
                                countTable = "<h4 style='text-align:center'  >Mobile top up payment</h4><table border='1' cellspacing='0' style='text-align:center' ><tr><td colspan='4'  style='text-align:left' >Grab TxId:" + txID + "</td></tr><tr><td>member mobile</td><td>amount</td><td>payment method</td><td>payment time </td></tr><tr>" + \
                                             "<td>" + member.mobile_no + "</td><td>" + str(
                                    amount/100) + "</td><td>" + \
                                             "grab pay" + "</td><td>" + time.strftime("%Y-%m-%d %H:%M:%S",
                                                                                          time.localtime()) + "</td></tr></table>"
                                 '''
                                amount_val = float(amount / 100)
                                # countTable = get_topup_mail_table(wallet, member, wallet.id,"Grabpay", amount_val)
                                # utils.send_register_email(utils.RECEIVE_MAIL, countTable, send_type="topup",promotion='')
                                # thread_send_mail(countTable, "topup")
                            # success jump
                            return Response({'msg': 'success'}, status=status.HTTP_200_OK)


                    else:

                        return Response({'msg': txStatus}, status=status.HTTP_200_OK)
                elif 'reason' in completeCharge.keys():
                    context['hello'] = json.dumps(completeCharge['reason'])
                else:
                    context['hello'] = 'errors'

    return Response({'msg': 'errors'}, status.HTTP_200_OK)


@api_view(['GET', 'POST'])
@authentication_classes([])
@permission_classes((AllowAny,))
@renderer_classes((TemplateHTMLRenderer, StaticHTMLRenderer,))
def grab_token_charge_new(request, *args, **kwargs):
    member_id = request.GET.get('member_id')
    topup_no = request.GET.get('topup_no')
    amount = int(request.GET.get('amount'))
    type = request.GET.get('type')
    tockenization = tokenization.Tokenization('6962c659-7b30-48a7-9495-2cb6c7b34b32', 'RsEeUPTC6sq5bDnM',
                                              'bb6318fe450b4729adb831a2a87c5c7b', '3ybZRTq8hrd07tnl',
                                              '8be3a726-2c75-4750-af22-a1df55c2ba7f')

    description = 'TokenChargePayment'

    partnerGroupTxId = 'OrderID' + tockenization.generateNonce(4)
    current_ts_ms = int(time.time() * 1000)
    # request.session['partnerTxId'] = 'IdempotencyKey' +tockenization.generateNonce(4)
    request.session['partnerTxId'] = topup_no
    request.session['member_id'] = member_id
    request.session['amount'] = amount
    request.session['codeVerifier'] = tockenization.generateNonce(64)
    # request.session['redirectUrl'] = 'https://crm.itea.sg/api/v1/payments/grab_token_charge_complete_new/'
    if type:
        if type == '1':
            request.session['redirectUrl'] = 'https://crm.itea.sg/api/v1/payments/grab_token_charge_complete_new/'
        else:
            request.session[
                'redirectUrl'] = 'https://crm.itea.sg/api/v1/payments/grab_token_charge_complete_new_for_web/'
            # request.session['redirectUrl'] = 'http://127.0.0.1:8000/api/v1/payments/grab_token_charge_complete_new_for_web/'
    else:
        request.session['redirectUrl'] = 'https://crm.itea.sg/api/v1/payments/grab_token_charge_complete_new/'
    context = {}
    context['hello'] = 'oauthAuthorizeUrl is empty'

    initCharge = tockenization.bind(request.session['partnerTxId'])
    if initCharge:
        if not 'request' in initCharge.keys():
            context['hello'] = json.dumps(initCharge)
            return render(request, 'index.html', context)
        else:
            oauthAuthorizeUrl = tockenization.getOauthAuthorizeUrl(request.session['codeVerifier'],
                                                                   initCharge['request'],
                                                                   request.session['redirectUrl'],
                                                                   'payment.recurring_charge')
    if oauthAuthorizeUrl:
        return HttpResponseRedirect(oauthAuthorizeUrl)
    else:
        return render(request, 'index.html', context)


@api_view(['GET', 'POST'])
@authentication_classes([])
@permission_classes((AllowAny,))
@renderer_classes((TemplateHTMLRenderer, StaticHTMLRenderer,))
def grab_token_charge_complete_new(request, *args, **kwargs):
    template = loader.get_template('index.html')
    context = {}
    try:
        tockenization = tokenization.Tokenization('6962c659-7b30-48a7-9495-2cb6c7b34b32', 'RsEeUPTC6sq5bDnM',
                                                  'bb6318fe450b4729adb831a2a87c5c7b', '3ybZRTq8hrd07tnl',
                                                  '8be3a726-2c75-4750-af22-a1df55c2ba7f')
        amount = request.session['amount']
        description = 'Test Tokenization Payment'
        partnerGroupTxId = 'OrderID' + tockenization.generateNonce(4)

        if (request.GET.get('code')):

            accessToken = tockenization.getAccessToken(request.GET.get('code'), request.session['redirectUrl'],
                                                       request.session['codeVerifier'])

        else:
            context = {}
            context['hello'] = 'OAuth2 code is missing'
            return HttpResponse(content=template.render(context), content_type='text/html; charset=utf-8', status=200)

    except Exception as e:
        context['hello'] = str(e)
        return HttpResponse(content=template.render(context), content_type='text/html; charset=utf-8', status=200)

    if accessToken:
        try:
            if 'access_token' in accessToken.keys():
                if request.session['member_id']:
                    wallet = models.Wallet.objects.get(member__id=request.session['member_id'])
                    if wallet:
                        wallet.grab_token = accessToken['access_token']
                        wallet.grab_expire = accessToken['expires_in'] * 1000 + int(round(time.time() * 1000))
                        wallet.save()
                    else:
                        models.Wallet.objects.create(balance=0, member=request.session['member_id'],
                                                     grab_token=accessToken['access_token'],
                                                     grab_expire=accessToken['expires_in'])

                completeCharge = tockenization.charge(accessToken['access_token'], request.session['partnerTxId'],
                                                      partnerGroupTxId, amount, description)
                if completeCharge:
                    # context['hello'] = json.dumps(accessToken) + json.dumps(completeCharge)
                    # return HttpResponse(content=template.render(context), content_type='text/html; charset=utf-8',status=200)
                    # transactions = models.Transaction.objects.get(id=730)
                    # transactions.remark = json.dumps(completeCharge)
                    # transactions.save()
                    if 'txID' in completeCharge.keys():
                        txID = completeCharge['txID']
                        status = completeCharge['status']
                        txStatus = completeCharge['txStatus']
                        reason = completeCharge['reason']
                        if (txStatus == 'success'):
                            wallet = models.Wallet.objects.get(member__id=request.session['member_id'])
                            if wallet:
                                # recharge campaign
                                campaign_return_cash = 0
                                campaignTopup = models.CampaignTopup.objects.first()
                                member = models.Member.objects.get(id=request.session['member_id'])
                                if member:
                                    topup_10_times = 0 if member.topup_10_times is None else member.topup_10_times
                                    topup_20_times = 0 if member.topup_20_times is None else member.topup_20_times
                                    topup_50_times = 0 if member.topup_50_times is None else member.topup_50_times
                                    topup_100_times = 0 if member.topup_100_times is None else member.topup_100_times
                                if campaignTopup:

                                    activity_flag = campaignTopup.activity_flag
                                    date_limit_flag = campaignTopup.date_limit_flag
                                    times_limit_flag = campaignTopup.times_limit_flag
                                    if activity_flag:
                                        if times_limit_flag:
                                            if date_limit_flag:
                                                pass

                                            else:
                                                if campaignTopup.topup_10_limit_times > topup_10_times and amount == 1000:
                                                    campaign_return_cash = campaignTopup.topup_10_return_cash
                                                if campaignTopup.topup_20_limit_times > topup_20_times and amount == 2000:
                                                    campaign_return_cash = campaignTopup.topup_20_return_cash
                                                if campaignTopup.topup_50_limit_times > topup_50_times and amount == 5000:
                                                    campaign_return_cash = campaignTopup.topup_50_return_cash
                                                if campaignTopup.topup_100_limit_times > topup_100_times and amount == 10000:
                                                    campaign_return_cash = campaignTopup.topup_100_return_cash

                                        else:
                                            if date_limit_flag:
                                                pass

                                            else:
                                                if amount == 1000:
                                                    campaign_return_cash = campaignTopup.topup_10_return_cash
                                                if amount == 2000:
                                                    campaign_return_cash = campaignTopup.topup_20_return_cash
                                                if amount == 5000:
                                                    campaign_return_cash = campaignTopup.topup_50_return_cash
                                                if amount == 10000:
                                                    campaign_return_cash = campaignTopup.topup_100_return_cash

                                # if member and (member.mobile_no == '84848166' or member.mobile_no == '98524980' or member.mobile_no == '91489401'):
                                wallet.balance += float(amount / 100) + campaign_return_cash
                                wallet.lastest_top_up = time.strftime("%Y-%m-%d", time.localtime())
                                wallet.save()
                                serializer = RechargeRecordCreateSerializer(
                                    data={'money': float(amount / 100), 'wallet': wallet.id, 'type': 0,
                                          'request_id': request.session['partnerTxId'],
                                          'status': 1, 'grab_txID': txID, 'topup_type': 1})
                                if serializer.is_valid():
                                    models.RechargeRecord.objects.create(**serializer.validated_data)
                                if campaign_return_cash:
                                    serializer = RechargeRecordCreateSerializer(
                                        data={'money': campaign_return_cash, 'wallet': wallet.id, 'type': 3,
                                              'grab_txID': txID,
                                              'status': 1})
                                    if serializer.is_valid():
                                        instance = models.RechargeRecord.objects.create(**serializer.validated_data)

                                    if member.device_token:
                                        send_message_to_token(member.device_token, 'Top up reward',
                                                              'Amout: $' + str(campaign_return_cash))

                                if member:
                                    if amount == 1000:
                                        if member.topup_10_times:
                                            member.topup_10_times = member.topup_10_times + 1
                                        else:
                                            member.topup_10_times = 1
                                    elif amount == 2000:
                                        if member.topup_20_times:
                                            member.topup_20_times = member.topup_20_times + 1
                                        else:
                                            member.topup_20_times = 1
                                    elif amount == 5000:
                                        if member.topup_50_times:
                                            member.topup_50_times = member.topup_50_times + 1
                                        else:
                                            member.topup_50_times = 1
                                    elif amount == 10000:
                                        if member.topup_100_times:
                                            member.topup_100_times = member.topup_100_times + 1
                                        else:
                                            member.topup_100_times = 1
                                    member.save()
                                # send mail
                                '''
                                countTable = "<h4 style='text-align:center'  >Mobile top up payment</h4><table border='1' cellspacing='0' style='text-align:center' ><tr><td colspan='4'  style='text-align:left' >Grab TxId:" + txID + "</td></tr><tr><td>member mobile</td><td>amount</td><td>payment method</td><td>payment time </td></tr><tr>" + \
                                             "<td>" + member.mobile_no + "</td><td>" + str(
                                    amount/100) + "</td><td>" + \
                                             "grab pay" + "</td><td>" + time.strftime("%Y-%m-%d %H:%M:%S",
                                                                                          time.localtime()) + "</td></tr></table>"
                                                                                          '''
                                amount_val = float(amount / 100)
                                # countTable = get_topup_mail_table(wallet, member, wallet.id, "Grabpay", amount_val)
                                # utils.send_register_email(utils.RECEIVE_MAIL, countTable, send_type="topup",promotion='')
                                # thread_send_mail(countTable, "topup")
                            # success jump
                            context['hello'] = 'success,' + accessToken['access_token'] + ',' + str(
                                accessToken['expires_in'])

                        else:
                            context['hello'] = json.dumps(completeCharge['txStatus'] + ',' + completeCharge['reason'])
                    elif 'reason' in completeCharge.keys():
                        context['hello'] = json.dumps(completeCharge['reason'])
                    else:
                        context['hello'] = 'errors'
                else:
                    context['hello'] = 'errors'

                # context['hello'] =json.dumps(accessToken)+json.dumps(completeCharge)
                # transStatus=tockenization.checkTransactionStatus(accessToken['access_token'],completeCharge['txID'])
                # context['hello'] =context['hello']+json.dumps(transStatus)

            else:
                if 'errors' in accessToken.keys():
                    context['hello'] = accessToken['errors']

                else:
                    # transaction = models.Transaction.objects.get(id=730)
                    # transaction.remark = json.dumps(accessToken)
                    # transaction.save()
                    context['hello'] = json.dumps(accessToken)
            return HttpResponse(content=template.render(context), content_type='text/html; charset=utf-8', status=200)
        except Exception as e:
            context['hello'] = str(e)
            return HttpResponse(content=template.render(context), content_type='text/html; charset=utf-8', status=200)

    else:

        context['hello'] = 'Access token is error'
        return HttpResponse(content=template.render(context), content_type='text/html; charset=utf-8', status=200)


@api_view(['GET', 'POST'])
@authentication_classes([])
@permission_classes((AllowAny,))
def grab_token_charge_complete_new_for_web(request, *args, **kwargs):
    return_path = 'https://crm.itea.sg/shop#/PaymentResult/'
    response_obj = HttpResponse("", status=301)
    response_url = ''
    # template = loader.get_template('index.html')
    context = {}
    tockenization = tokenization.Tokenization('6962c659-7b30-48a7-9495-2cb6c7b34b32', 'RsEeUPTC6sq5bDnM',
                                              'bb6318fe450b4729adb831a2a87c5c7b', '3ybZRTq8hrd07tnl',
                                              '8be3a726-2c75-4750-af22-a1df55c2ba7f')
    amount = request.session['amount']
    description = 'Test Tokenization Payment'
    partnerGroupTxId = 'OrderID' + tockenization.generateNonce(4)

    if (request.GET.get('code')):

        accessToken = tockenization.getAccessToken(request.GET.get('code'), request.session['redirectUrl'],
                                                   request.session['codeVerifier'])

    else:
        context = {}
        context['hello'] = 'OAuth2 code is missing'
        # return HttpResponse(content=template.render(context), content_type='text/html; charset=utf-8', status=200)

    if accessToken:
        if 'access_token' in accessToken.keys():
            if request.session['member_id']:
                wallet = models.Wallet.objects.get(member__id=request.session['member_id'])
                if wallet:
                    wallet.grab_token = accessToken['access_token']
                    wallet.grab_expire = accessToken['expires_in'] * 1000 + int(round(time.time() * 1000))
                    wallet.save()
                else:
                    models.Wallet.objects.create(balance=0, member=request.session['member_id'],
                                                 grab_token=accessToken['access_token'],
                                                 grab_expire=accessToken['expires_in'])

            completeCharge = tockenization.charge(accessToken['access_token'], request.session['partnerTxId'],
                                                  partnerGroupTxId, amount, description)
            if completeCharge:
                # context['hello'] = json.dumps(accessToken) + json.dumps(completeCharge)
                # return HttpResponse(content=template.render(context), content_type='text/html; charset=utf-8',status=200)
                # transactions = models.Transaction.objects.get(id=730)
                # transactions.remark = json.dumps(completeCharge)
                # transactions.save()
                if 'txID' in completeCharge.keys():
                    txID = completeCharge['txID']
                    status = completeCharge['status']
                    txStatus = completeCharge['txStatus']
                    reason = completeCharge['reason']
                    if (txStatus == 'success'):
                        wallet = models.Wallet.objects.get(member__id=request.session['member_id'])
                        if wallet:
                            # recharge campaign
                            campaign_return_cash = 0
                            campaignTopup = models.CampaignTopup.objects.first()
                            member = models.Member.objects.get(id=request.session['member_id'])
                            if member:
                                topup_10_times = 0 if member.topup_10_times is None else member.topup_10_times
                                topup_20_times = 0 if member.topup_20_times is None else member.topup_20_times
                                topup_50_times = 0 if member.topup_50_times is None else member.topup_50_times
                                topup_100_times = 0 if member.topup_100_times is None else member.topup_100_times
                            if campaignTopup:

                                activity_flag = campaignTopup.activity_flag
                                date_limit_flag = campaignTopup.date_limit_flag
                                times_limit_flag = campaignTopup.times_limit_flag
                                if activity_flag:
                                    if times_limit_flag:
                                        if date_limit_flag:
                                            pass

                                        else:
                                            if campaignTopup.topup_10_limit_times > topup_10_times and amount == 1000:
                                                campaign_return_cash = campaignTopup.topup_10_return_cash
                                            if campaignTopup.topup_20_limit_times > topup_20_times and amount == 2000:
                                                campaign_return_cash = campaignTopup.topup_20_return_cash
                                            if campaignTopup.topup_50_limit_times > topup_50_times and amount == 5000:
                                                campaign_return_cash = campaignTopup.topup_50_return_cash
                                            if campaignTopup.topup_100_limit_times > topup_100_times and amount == 10000:
                                                campaign_return_cash = campaignTopup.topup_100_return_cash

                                    else:
                                        if date_limit_flag:
                                            pass

                                        else:
                                            if amount == 1000:
                                                campaign_return_cash = campaignTopup.topup_10_return_cash
                                            if amount == 2000:
                                                campaign_return_cash = campaignTopup.topup_20_return_cash
                                            if amount == 5000:
                                                campaign_return_cash = campaignTopup.topup_50_return_cash
                                            if amount == 10000:
                                                campaign_return_cash = campaignTopup.topup_100_return_cash

                            # if member and (member.mobile_no == '84848166' or member.mobile_no == '98524980' or member.mobile_no == '91489401'):
                            wallet.balance += float(amount / 100) + campaign_return_cash
                            wallet.lastest_top_up = time.strftime("%Y-%m-%d", time.localtime())
                            wallet.save()
                            serializer = RechargeRecordCreateSerializer(
                                data={'money': float(amount / 100), 'wallet': wallet.id, 'type': 0,
                                      'request_id': request.session['partnerTxId'],
                                      'status': 1, 'grab_txID': txID, 'topup_type': 1})
                            if serializer.is_valid():
                                models.RechargeRecord.objects.create(**serializer.validated_data)
                            if campaign_return_cash:
                                serializer = RechargeRecordCreateSerializer(
                                    data={'money': campaign_return_cash, 'wallet': wallet.id, 'type': 3,
                                          'grab_txID': txID,
                                          'status': 1})
                                if serializer.is_valid():
                                    instance = models.RechargeRecord.objects.create(**serializer.validated_data)

                                if member.device_token:
                                    send_message_to_token(member.device_token, 'Top up reward',
                                                          'Amout: $' + str(campaign_return_cash))

                            if member:
                                if amount == 1000:
                                    if member.topup_10_times:
                                        member.topup_10_times = member.topup_10_times + 1
                                    else:
                                        member.topup_10_times = 1
                                elif amount == 2000:
                                    if member.topup_20_times:
                                        member.topup_20_times = member.topup_20_times + 1
                                    else:
                                        member.topup_20_times = 1
                                elif amount == 5000:
                                    if member.topup_50_times:
                                        member.topup_50_times = member.topup_50_times + 1
                                    else:
                                        member.topup_50_times = 1
                                elif amount == 10000:
                                    if member.topup_100_times:
                                        member.topup_100_times = member.topup_100_times + 1
                                    else:
                                        member.topup_100_times = 1
                                member.save()
                            # send mail
                            '''
                            countTable = "<h4 style='text-align:center'  >Mobile top up payment</h4><table border='1' cellspacing='0' style='text-align:center' ><tr><td colspan='4'  style='text-align:left' >Grab TxId:" + txID + "</td></tr><tr><td>member mobile</td><td>amount</td><td>payment method</td><td>payment time </td></tr><tr>" + \
                                         "<td>" + member.mobile_no + "</td><td>" + str(
                                amount/100) + "</td><td>" + \
                                         "grab pay" + "</td><td>" + time.strftime("%Y-%m-%d %H:%M:%S",
                                                                                      time.localtime()) + "</td></tr></table>"
                                                                                      '''
                            amount_val = float(amount / 100)
                            # countTable = get_topup_mail_table(wallet, member, wallet.id, "Grabpay", amount_val)
                            # utils.send_register_email(utils.RECEIVE_MAIL, countTable, send_type="topup",promotion='')
                            # thread_send_mail(countTable, "topup")
                        # success jump
                        context['hello'] = 'success,' + accessToken['access_token'] + ',' + str(
                            accessToken['expires_in'])

                    else:
                        context['hello'] = json.dumps(completeCharge['txStatus'] + ',' + completeCharge['reason'])
                elif 'reason' in completeCharge.keys():
                    context['hello'] = json.dumps(completeCharge['reason'])
                else:
                    context['hello'] = 'errors'
            else:
                context['hello'] = 'errors'

            # context['hello'] =json.dumps(accessToken)+json.dumps(completeCharge)
            # transStatus=tockenization.checkTransactionStatus(accessToken['access_token'],completeCharge['txID'])
            # context['hello'] =context['hello']+json.dumps(transStatus)

        else:
            if 'errors' in accessToken.keys():
                context['hello'] = accessToken['errors']

            else:
                # transaction = models.Transaction.objects.get(id=730)
                # transaction.remark = json.dumps(accessToken)
                # transaction.save()
                context['hello'] = json.dumps(accessToken)
        # return HttpResponse(content=template.render(context), content_type='text/html; charset=utf-8', status=200)


    else:

        context['hello'] = 'Access token is error'
        # return HttpResponse(content=template.render(context), content_type='text/html; charset=utf-8', status=200)
    response_obj['Location'] = return_path + '?result=' + context['hello']
    return response_obj


@api_view(['GET', 'POST'])
@authentication_classes([])
@permission_classes((AllowAny,))
@renderer_classes((TemplateHTMLRenderer, StaticHTMLRenderer,))
def grab_token_charge_complete_pay_for_web(request, *args, **kwargs):
    return_path = 'https://crm.itea.sg/shop#/PaymentResult/'
    response_obj = HttpResponse("", status=301)
    now = datetime.datetime.now()
    # template = loader.get_template('index.html')
    context = {}
    tockenization = tokenization.Tokenization('6962c659-7b30-48a7-9495-2cb6c7b34b32', 'RsEeUPTC6sq5bDnM',
                                              'bb6318fe450b4729adb831a2a87c5c7b', '3ybZRTq8hrd07tnl',
                                              '8be3a726-2c75-4750-af22-a1df55c2ba7f')
    amount = request.session['amount']
    description = 'Test Tokenization Payment'
    partnerGroupTxId = 'OrderID' + tockenization.generateNonce(4)

    if (request.GET.get('code')):

        accessToken = tockenization.getAccessToken(request.GET.get('code'), request.session['redirectUrl'],
                                                   request.session['codeVerifier'])

    else:
        context = {}
        context['hello'] = 'OAuth2 code is missing'
        # return HttpResponse(content=template.render(context), content_type='text/html; charset=utf-8', status=200)

    if accessToken:
        if 'access_token' in accessToken.keys():
            if request.session['member_id']:
                wallet = models.Wallet.objects.get(member__id=request.session['member_id'])
                if wallet:
                    wallet.grab_token = accessToken['access_token']
                    wallet.grab_expire = accessToken['expires_in'] * 1000 + int(round(time.time() * 1000))
                    wallet.save()
                else:
                    models.Wallet.objects.create(balance=0, member=request.session['member_id'],
                                                 grab_token=accessToken['access_token'],
                                                 grab_expire=accessToken['expires_in'])

            completeCharge = tockenization.charge(accessToken['access_token'], request.session['partnerTxId'],
                                                  partnerGroupTxId, amount, description)
            if completeCharge:
                # context['hello'] = json.dumps(accessToken) + json.dumps(completeCharge)
                # return HttpResponse(content=template.render(context), content_type='text/html; charset=utf-8',status=200)
                # transactions = models.Transaction.objects.get(id=1114)
                # transactions.remark = str(accessToken['expires_in'])+'  '+str(int(round(time.time() * 1000)))
                # transactions.save()
                #models.Userip.objects.create(ip=json.dumps(completeCharge), request=request.session['partnerTxId'],count=6)
                if 'txID' in completeCharge.keys():
                    txID = completeCharge['txID']
                    status = completeCharge['status']
                    txStatus = completeCharge['txStatus']
                    reason = completeCharge['reason']
                    if (txStatus == 'success'):
                        grab_transaction_id = request.session['partnerTxId']

                        trans_arr = request.session['partnerTxId'].split('_')
                        if trans_arr and len(trans_arr) > 0:
                            grab_transaction_id = trans_arr[0]
                        # transactionObj = models.Transaction.objects.filter(order_no=request.session['partnerTxId']).first()
                        transactionObj = models.Transaction.objects.filter(order_no=grab_transaction_id).first()
                        # transactions = models.Transaction.objects.get(id=730)
                        # transactions.remark = json.dumps(completeCharge)
                        # transactions.save()
                        if (transactionObj):

                            if (transactionObj.transaction_status == 0):
                                with transaction.atomic():
                                    # coupon set transaction status=5 directly
                                    temp_transaction_status = 2
                                    has_voucher = False
                                    has_other = False
                                    invicode_num = 0
                                    transDetailsList = models.TransactDetails.objects.filter(
                                        transaction__id=transactionObj.id)
                                    if transDetailsList:
                                        for details in transDetailsList:
                                            temp_product = details.product
                                            quantity = details.quantity
                                            invicode_num = invicode_num + quantity
                                            if temp_product:
                                                voucher = temp_product.voucher
                                                if voucher:
                                                    temp_transaction_status = 5
                                                    voucher_expire_date = voucher.expiring_date
                                                    has_voucher = True

                                                    invicode_register_date = datetime.datetime.now().date()
                                                    interval = voucher_expire_date - invicode_register_date
                                                    valid_days = interval.days
                                                    for i in range(0, quantity):
                                                        models.Invicode.objects.create(
                                                            **{'voucher': voucher, 'code': generate_random_str(),
                                                               'status': 1,
                                                               'member': transactionObj.member,
                                                               'register_date': datetime.datetime.now(),
                                                               'vaild_days': valid_days,
                                                               'expire_date': voucher_expire_date})
                                                else:
                                                    has_other = True
                                    if has_other:
                                        temp_transaction_status = 2
                                    # coupon set transaction status=5 directly
                                    transactionObj.payment_datetime = time.strftime("%Y-%m-%d %H:%M:%S",
                                                                                    time.localtime())
                                    # transactionObj.transact_datetime = time.strftime("%Y-%m-%d %H:%M:%S",time.localtime())
                                    transactionObj.payment_modes = 12
                                    transactionObj.transaction_status = temp_transaction_status
                                    '''
                                    if (transactionObj.pick_up_time == 0):
                                        transactionObj.delay_time = now + datetime.timedelta(minutes=5)
                                    elif (transactionObj.pick_up_time == 1):
                                        transactionObj.delay_time = now + datetime.timedelta(minutes=15)
                                    elif (transactionObj.pick_up_time == 2):
                                        transactionObj.delay_time = now + datetime.timedelta(minutes=30)
                                    elif (transactionObj.pick_up_time == 3):
                                        transactionObj.delay_time = now + datetime.timedelta(minutes=45)
                                    elif (transactionObj.pick_up_time == 4):
                                        transactionObj.delay_time = now + datetime.timedelta(minutes=60)
                                    '''
                                    if transactionObj.delay_time:
                                        delay_time = transactionObj.delay_time
                                        delay_time = delay_time + datetime.timedelta(hours=8)
                                        if delay_time.replace(tzinfo=None) < now:
                                            transactionObj.delay_time = now + datetime.timedelta(minutes=5)
                                    else:
                                        transactionObj.delay_time = now + datetime.timedelta(minutes=5)

                                    transactionObj.grab_txID = txID
                                    transactionObj.save()
                                    # modify invicode status
                                    if transactionObj.redeem_invicode is not None and transactionObj.redeem_invicode != 0:
                                        invicodeObj = models.Invicode.objects.get(
                                            id=transactionObj.redeem_invicode)
                                        if (invicodeObj):
                                            invicodeObj.status = 2
                                            invicodeObj.redeem_date = time.strftime("%Y-%m-%d %H:%M:%S",
                                                                                    time.localtime())
                                            invicodeObj.save()
                                    # update member last purchase datetime
                                    member_id = transactionObj.member.id
                                    member = models.Member.objects.get(id=member_id)
                                    member.last_purchase_date = time.strftime("%Y-%m-%d", time.localtime())
                                    member.save()
                                    # purchase coupon voucher to direct collected,update member points
                                    if has_voucher:
                                        update_member_points(member, transactionObj.total_money, 1, None, None)
                                        if invicode_num > 0:
                                            if voucher:
                                                pass
                                                ''''
                                                invicode_amount = models.Invicode.objects.filter(voucher__id=voucher.id,
                                                                                                 register_date__date=datetime.datetime.now().date()).aggregate(
                                                    count=Count('id'))
                                                if invicode_amount:

                                                    invicodeTable = "<h4 style='text-align:center'  >Mooncake voucher purchase</h4><table border='1' cellspacing='0' style='text-align:center' ><tr><td colspan='5'  style='text-align:left' >order no:" + transactionObj.order_no + "</td></tr><tr><td>member mobile</td><td>register time</td><td>quantity</td><td>today sum</td><td>payment time </td></tr><tr>" + \
                                                                    "<td>" + member.mobile_no + "</td><td>" + datetime.datetime.strftime(
                                                        member.registration_date,
                                                        "%Y-%m-%d %H:%M:%S") + "</td><td>" + str(
                                                        invicode_num) + "</td>" + str(
                                                        invicode_amount['count']) + "<td>" + datetime.datetime.strftime(
                                                        now, "%Y-%m-%d %H:%M:%S") + "</td></tr></table></br></br>"
                                                    thread_send_mail(invicodeTable, "VoucherPurchase")
                                                '''
                                    wallet = models.Wallet.objects.get(member__id=member_id)
                                    # member cashbak
                                    # member_payment_cashback(transactionObj, member, wallet, amount/100, 6)
                                    # return cash to wallet campaign(every payment cash back) start
                                    '''
                                    campaign_Wallet = models.Campaign_Wallet.objects.first()
                                    if campaign_Wallet and campaign_Wallet.activity_status:

                                        if campaign_Wallet.purchase_return_wallet_percent:

                                            campgign_result = float(amount / 100) * campaign_Wallet.purchase_return_wallet_percent
                                    '''
                                    # return cash to wallet campaign(every payment cash back) end
                                    # new cashback from member membership start #
                                    if member:
                                        member_ship = member.membership
                                        if member_ship:
                                            cashback_percent = member_ship.cash_back
                                            campgign_result = float(amount / 100) * cashback_percent
                                            # new cashback from member membership end #
                                            # origin_num = Decimal(campgign_result)
                                            # campaign_return_money=origin_num.quantize(Decimal('0.00'), rounding=ROUND_HALF_UP)
                                            # transactionObj.discount_amount = 1
                                            # transactionObj.save()
                                            campaign_result_str = '%.2f' % campgign_result
                                            campaign_return_money = float(campaign_result_str)
                                            # campaign_return=round(float(amount)*campaign_Wallet.purchase_return_wallet_percent,2)
                                            if (campaign_return_money >= 0.01):
                                                # wallet = models.Wallet.objects.get(member__id=member_id)
                                                if wallet:
                                                    # purchase record
                                                    serializer = RechargeRecordCreateSerializer(
                                                        data={'money': amount / 100, 'wallet': wallet.id, 'type': 6})
                                                    if serializer.is_valid():
                                                        models.RechargeRecord.objects.create(
                                                            **serializer.validated_data)
                                                    outlet = transactionObj.outlet
                                                    if outlet:
                                                        if outlet.has_cashback:
                                                            wallet.balance += campaign_return_money
                                                            wallet.save()
                                                            serializer = RechargeRecordCreateSerializer(
                                                                data={'money': float(campaign_return_money),
                                                                      'wallet': wallet.id, 'type': 3,

                                                                      'status': 1})
                                                            if serializer.is_valid():
                                                                instance = models.RechargeRecord.objects.create(
                                                                    **serializer.validated_data)
                                                            # add campaign return cash to transaction record
                                                            if transactionObj.campaign_return_wallet_cash:
                                                                transactionObj.campaign_return_wallet_cash += campaign_return_money
                                                            else:
                                                                transactionObj.campaign_return_wallet_cash = campaign_return_money
                                                            transactionObj.save()
                                                    # send message
                                                    device_token = member.device_token
                                                    if device_token:
                                                        send_message_to_token(device_token,
                                                                              'GrabPay payment successful', 'thank you')

                                    # purchase campaign return cash to wallet
                                    '''
                                    purchase_return_wallet_amount = campaign_return(member, float(amount / 100))
                                    if purchase_return_wallet_amount>0:
                                        wallet = models.Wallet.objects.get(member__id=member_id)
                                        if wallet:

                                            wallet.balance += purchase_return_wallet_amount
                                            wallet.save()
                                            serializer = RechargeRecordCreateSerializer(
                                                data={'money': float(purchase_return_wallet_amount),
                                                      'wallet': wallet.id, 'type': 3,

                                                      'status': 1})
                                            if serializer.is_valid():
                                                instance = models.RechargeRecord.objects.create(
                                                    **serializer.validated_data)
                                            # add campaign return cash to transaction record
                                            if transactionObj.campaign_return_wallet_cash:
                                                transactionObj.campaign_return_wallet_cash += purchase_return_wallet_amount
                                            else:
                                                transactionObj.campaign_return_wallet_cash = purchase_return_wallet_amount
                                            transactionObj.save()
                                    if member:

                                        if member.non_wallet_pay_times:
                                            member.non_wallet_pay_times = member.non_wallet_pay_times + 1
                                        else:
                                            member.non_wallet_pay_times = 1







                                    member.save()
                                     '''

                                    # send mail
                                    '''
                                    countTable = "<h4 style='text-align:center'  >Mobile ordering payment</h4><table border='1' cellspacing='0' style='text-align:center' ><tr><td colspan='5'  style='text-align:left' >order no:" + transactionObj.order_no + "</td></tr><tr><td>member mobile</td><td>outlet</td><td>amount</td><td>payment method</td><td>payment time </td></tr><tr>" + \
                                                 "<td>" + member.mobile_no + "</td><td>" + transactionObj.outlet.outlet_name + "</td><td>" + str(transactionObj.total_money) + "</td><td>" + \
                                                 "grab pay" + "</td><td>" + time.strftime("%Y-%m-%d %H:%M:%S",time.localtime()) + "</td></tr></table>"
                                                 '''
                                    # countTable=get_payment_mail_table(transactionObj, member, wallet.id, "GrabPay")
                                    # utils.send_register_email(utils.RECEIVE_MAIL, countTable,send_type="payment", promotion='')
                                    # thread_send_mail(countTable, "payment")
                                    # send_mooncake_payment(transactionObj)
                        # success jump
                        context['hello'] = 'success,' + accessToken['access_token'] + ',' + str(
                            accessToken['expires_in'])

                    else:
                        context['hello'] = json.dumps(completeCharge['txStatus'] + ',' + completeCharge['reason'])
                elif 'reason' in completeCharge.keys():
                    context['hello'] = json.dumps(completeCharge['reason'])
                else:
                    context['hello'] = 'errors'
            else:
                context['hello'] = 'errors'

            # context['hello'] =json.dumps(accessToken)+json.dumps(completeCharge)
            # transStatus=tockenization.checkTransactionStatus(accessToken['access_token'],completeCharge['txID'])
            # context['hello'] =context['hello']+json.dumps(transStatus)

        else:
            if 'errors' in accessToken.keys():
                context['hello'] = accessToken['errors']

            else:
                # transaction = models.Transaction.objects.get(id=730)
                # transaction.remark = json.dumps(accessToken)
                # transaction.save()
                context['hello'] = json.dumps(accessToken)
        # return HttpResponse(content=template.render(context), content_type='text/html; charset=utf-8', status=200)


    else:

        context['hello'] = 'Access token is error'
        # return HttpResponse(content=template.render(context), content_type='text/html; charset=utf-8', status=200)
    #models.Userip.objects.create(ip=return_path + '?result=' + context['hello'], request='return url', count=7)
    response_obj['Location'] = return_path + '?result=' + context['hello']
    return response_obj