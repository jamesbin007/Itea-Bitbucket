from django.conf import settings # new
from django.views.generic.base import TemplateView
import stripe # new
from django.shortcuts import render # new
from rest_framework.permissions import AllowAny
from rest_framework.decorators import api_view,authentication_classes,permission_classes
from rest_framework.response import Response
from django.http import HttpResponse
import json
import time
from app01 import models
from wallet import serializers,service

from django.db import connection
import datetime
import base64
import hashlib
import binascii
import os
import urllib.parse
import requests
import hmac
import json
import random
import string
from wsgiref.handlers import format_date_time
from datetime import datetime
from time import mktime
import sys
import base64
class GrabPay(object):
    countryCode = 'SG'
    currency = 'SGD'
    isProduction = True

    stagingApiUrl=base64.b64decode('aHR0cHM6Ly9wYXJ0bmVyLWFwaS5zdGctbXl0ZWtzaS5jb20=').decode('utf-8')
    productionApiUrl=base64.b64decode('aHR0cHM6Ly9wYXJ0bmVyLWFwaS5ncmFiLmNvbQ==').decode('utf-8')
    oauth2Path=base64.b64decode('L2dyYWJpZC92MS9vYXV0aDI=').decode('utf-8')
    partnerV1Path=base64.b64decode('L2dyYWJwYXkvcGFydG5lci92MQ==').decode('utf-8')
    partnerV2Path=base64.b64decode('L2dyYWJwYXkvcGFydG5lci92Mg==').decode('utf-8')
    def __init__(self,partnerId,partnerSecret,clientId,clientSecret,merchantId):
        self.partnerId=partnerId
        self.partnerSecret=partnerSecret
        self.clientId=clientId
        self.clientSecret=clientSecret
        self.merchantId=merchantId

    def useProduction(self):
        self.isProduction=True

    def base64UrlEncode(self,url):
        encodeUrl=base64.b64encode(url)

        enUrl=str(encodeUrl,encoding='utf-8')
        return enUrl.replace('=','').replace('+','-').replace('/','_')



    def generateCodeChallenge(self,codeVerifier):
        hash_obj=hashlib.sha256()
        hash_obj.update(codeVerifier.encode('utf-8'))
        return self.base64UrlEncode(hash_obj.digest())

    def generateNonce(self,length = 16):
        try:
            return str(binascii.b2a_hex(os.urandom(length)), encoding='utf-8')
        except Exception as e:
            print("OS error: {0}".format(e))
            return ''
    def getApiUrl(self):
        return  self.productionApiUrl if self.isProduction  else self.stagingApiUrl

    def getOauth2UrlPath(self,path = ''):
        return self.oauth2Path+path

    def getOauthAuthorizeUrl(self,codeVerifier,requestToken,redirectUri,scope):
        data={
            'acr_values':'consent_ctx:countryCode='+self.countryCode+ ',currency='+self.currency,
            'client_id':self.clientId,
            'code_challenge':self.generateCodeChallenge(codeVerifier),
            'code_challenge_method':'S256',
            'nonce':self.generateNonce(16),
            'redirect_uri' : redirectUri,
            'request' : requestToken,
            'response_type' : 'code',
            'scope' : scope,
            'state' : self.generateNonce(7),
        }
        return  self.getApiUrl()+self.getOauth2UrlPath('/authorize?')+urllib.parse.urlencode(data)




    def getAccessToken(self,code, redirectUri, codeVerifier):
        data={
            'code': code,
            'client_id' : self.clientId,
            'client_secret' : self.clientSecret,
            'grant_type' : 'authorization_code',
            'redirect_uri' : redirectUri,
            'code_verifier' : codeVerifier,
        }
        requestData='{"code":"'+code+'","client_id":"'+self.clientId+'","client_secret":"'+self.clientSecret+'","grant_type":"authorization_code","redirect_uri":"'+redirectUri+'","code_verifier":"'+codeVerifier+'"}'
        #transaction = models.Transaction.objects.get(id=730)
        #transaction.remark = requestData
        #transaction.save()
        print( requestData)
        return self.callApi('POST', self.getOauth2UrlPath('/token'), {'Content-Type' :'application/json'}, requestData)


    '''
    * Refund a full or partial refunds for a specific transaction
    * @param string $accessToken OAuth access token
    * @param string $txId order ID
    * @param string $groupTxId partner transaction ID
    * @param string $originTxID original partner transaction ID
    * @param int $amount ​Transaction amount as integer
    * @param string $description description of the charge (optional)
    * @return object
    
    '''
    def refund(self,accessToken, txId, groupTxId, originTxID, amount, description = ''):
        data={
            'partnerTxID' : txId,
            'partnerGroupTxID' : groupTxId,
            'originTxID' : originTxID,
            'amount' : amount,
            'currency' : self.currency,
            'merchantID' : self.merchantId,
            'description' : description,
        }

        date = self.generateHeaderDate()
        return self.callApi('POST', self.getPartnerUrlPath('v2', '/refund'), {'Date' : date,'Authorization' : 'Bearer ' +accessToken,'X-GID-AUX-POP' : self.generatePopSignature(accessToken, date),}, data)

    '''
    * Generate POP Signature for authentication with API via X-GID-AUX-POP header.
    * @param string $accessToken Access token
    * @param string $date Date
    * @return string
    '''

    def generatePopSignature(self,accessToken, date):

         timestamp = int(time.mktime(time.strptime(date,'%a, %d %b %Y %H:%M:%S GMT')))+28800
         message = str(timestamp)+accessToken
         #transaction = models.Transaction.objects.get(id=730)
         #transaction.remark = transaction.remark+str(timestamp)
         #transaction.save()




         signature = hmac.new(bytes(self.clientSecret, encoding='utf-8'), bytes(message, encoding='utf-8'),
                             digestmod=hashlib.sha256).digest()
         payload = {
             'time_since_epoch' : timestamp,
             'sig' : self.base64UrlEncode(signature),
         }

         payloadStr=json.dumps(payload,separators=(',', ':'),sort_keys=False)
         #transaction = models.Transaction.objects.get(id=730)
         #transaction.remark ='accessToken:'+accessToken+'   '+'Date:'+date+'  '+ 'signature:'+self.base64UrlEncode(payloadStr.encode('utf-8'))+'  '+'message:'+message+'  '+payloadStr
         #transaction.save()
         return self.base64UrlEncode(payloadStr.encode('utf-8'))

    '''
    * Generate HMAC signature for authentication with API.
    * @param string $method Request method
    * @param string $headerContentType Content-Type header
    * @param string $headerDate Date header
    * @param string $requestUrl Request URL
    * @param string $requestBody Request body
    * @return string
    '''
    def generateHmacSignature(self,method,headerContentType,headerDate,requestUrl,requestBody):

        #print(requestBody)


        #print(str(base64.b64encode(hashlib.sha256(requestBody.encode('utf-8')).digest()),'utf-8'))

        data = method+ "\n"+ headerContentType+"\n"+ headerDate+"\n"+ requestUrl+"\n"+str(base64.b64encode(hashlib.sha256(requestBody.encode('utf-8')).digest()),'utf-8')+"\n"


        signature = hmac.new(bytes(self.partnerSecret, encoding='utf-8'), bytes(data, encoding='utf-8'),
                             digestmod=hashlib.sha256).digest()
        #print(str( base64.b64encode(signature),'utf-8'))

        return  str( base64.b64encode(signature),'utf-8')
    '''
    * Call API.
    * @param string $method HTTP method
    * @param string $path Request path
    * @param array $headers Request Headers
    * @param array $body Request JSON body
    * @return object|null
    
    '''
    def callApi(self, method, path, headers, body = ''):
        payload = {
        'headers' : headers,
        'json' : body,

        }
        cursor = connection.cursor()
        r_response=''
        val=''
        try:
            base_uri=self.getApiUrl()
            #transaction = models.Transaction.objects.get(id=730)
            #transaction.remark =base_uri
            #transaction.save()
            if(method=='GET'):
                response = requests.get(base_uri + path, headers=headers)
                r_response =response.text
                val = r_response.replace("'", "").replace("\"", "")
                cursor.execute(
                    "insert into app01_grab_logs (json_from_grabpay,created) values('#method:" + method + "#path:" + path + "#Response:" + val + "','" + datetime.now().strftime(
                        "%Y-%m-%d %H:%M:%S") + "' ) ")
            if(method=='POST'):
                response = requests.post(base_uri+path, headers=headers, data=body)
                ret=response.text
                r_response =ret
                val=ret.replace("'","").replace("\"","")
                cursor.execute("insert into app01_grab_logs (json_from_grabpay,created) values('#method:"+method+"#path:"+path+"#Call Body:"+body+"******Response:"+val+"','" + datetime.now().strftime("%Y-%m-%d %H:%M:%S") + "' ) ")

            #print(json.loads(response.text))

            return json.loads(response.text)
        except Exception as e:
            r_response = r_response.replace("'", "").replace("\"", "")
            e_str=str(e)
            cursor.execute("insert into app01_grab_logs (json_from_grabpay,created) values('Exception:" + (e_str.replace("'","").replace("\"",""))+"#"+method+"#"+path+"******Call Body:"+body+"******Response:"+r_response+ "','" + datetime.now().strftime("%Y-%m-%d %H:%M:%S") + "' ) ")
            return {'msg':'error'}



    def generateHeaderDate(self,dateFormat = 'D, d M Y H:i:s \G\M\T'):
        if(dateFormat==''):
            now = datetime.now()
            stamp = mktime(now.timetuple())
            return self.gmdate('D, d M Y H:i:s \G\M\T', stamp )
        else:

           return self.gmdate(dateFormat,None)


    '''
    pyton gmdate

    '''

    def gmdate(self,str_formate, int_timestamp=None):
        if int_timestamp == None:
            now = datetime.now()
            stamp = mktime(now.timetuple())

            return format_date_time(stamp)

        else:
            #transaction = models.Transaction.objects.get(id=730)
            #transaction.remark = transaction.remark + str(int_timestamp) + "---"
            #transaction.save()
            return format_date_time(int_timestamp)


    def DecodingJson(self,json_file):
        dic = {}
        decode_file = json.loads(json_file)
        for key, value in decode_file.items():
                dic[key] = value
        return dic

    def getPartnerUrlPath(self,version = 'v2', path = ''):
        pPath=GrabPay.partnerV2Path if version == 'v2' else GrabPay.partnerV1Path

        #if(path=='/wallet/info?currency=SGD'):
            #transaction = models.Transaction.objects.get(id=730)
            #transaction.remark = self.getApiUrl()+ pPath+path
            #transaction.save()
        return pPath+path