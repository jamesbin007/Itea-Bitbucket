from  . import grab_pay
import json
from app01 import models
from django.db import connection
from datetime import datetime
class Tokenization(grab_pay.GrabPay):
    def bind(self,txId):
        data={
            'partnerTxID' :txId,
            'countryCode' : self.countryCode,

        }
        date = self.generateHeaderDate()
        requestUri = self.getPartnerUrlPath('v2', '/bind')
        requestData=json.dumps(data,separators=(',', ':'),sort_keys=False)
        hmacSignature = self.generateHmacSignature('POST', 'application/json', date, requestUri, requestData)

        #transaction = models.Transaction.objects.get(id=730)
        #transaction.remark = 'date:  '+date+'   requestUri:'+requestUri+'    requestData:'+requestData+'   Signature:'+hmacSignature
        #transaction.save()


        return self.callApi('POST', requestUri, {'Date': date,'Content-Type':'application/json', 'Authorization': self.partnerId + ':' + hmacSignature, },
                            requestData)

    def charge(self,accessToken, txId, groupTxId, amount, description = ''):
        data ={
            'partnerTxID':txId,
            'partnerGroupTxID' : groupTxId,
            'amount' : amount,
            'isSync': True,
            'currency' : self.currency,
            'merchantID' : self.merchantId,
            'description' : description,



        }
        date = self.generateHeaderDate()
        requestData = json.dumps(data, separators=(',', ':'), sort_keys=False)
        return self.callApi('POST', self.getPartnerUrlPath('v2', '/charge'),{'Date' : date,'Content-Type':'application/json','Authorization': 'Bearer ' +accessToken,'X-GID-AUX-POP' : self.generatePopSignature(accessToken, date),},requestData)

    def getWalletInfo(self,accessToken):
        date = self.generateHeaderDate()
        path=self.getPartnerUrlPath('v2', '/wallet/info?currency=SGD')
        cursor = connection.cursor()
        #transaction = models.Transaction.objects.get(id=730)
        #transaction.remark =transaction.remark+ 'date:  '+date+'   requestUri:'+path+'    accessToken:'+accessToken+'   Signature:'+self.generatePopSignature(accessToken, date)
        #transaction.save()
        cursor.execute("insert into app01_grab_logs (json_from_grabpay,created) values('Url:/wallet/info?currency=SGD******Token:" + accessToken + "','" + datetime.now().strftime("%Y-%m-%d %H:%M:%S") + "' ) ")
        return self.callApi('GET', path,{'Date': date,'Content-Type':'application/json','Authorization' : 'Bearer ' +accessToken,'X-GID-AUX-POP': self.generatePopSignature(accessToken, date),})

    def unbind(self,accessToken, txId):
        data={
            'partnerTxID' : txId,

        }
        date = self.generateHeaderDate()
        requestData = json.dumps(data, separators=(',', ':'), sort_keys=False)
        return self.callApi('DELETE', self.getPartnerUrlPath('v2', '/bind'),{'Date' : date,'Content-Type':'application/json','Authorization' : 'Bearer ' +accessToken,'X-GID-AUX-POP' : self.generatePopSignature(accessToken, date),},requestData)
    def checkTransactionStatus(self,accessToken,partnerTxID):
        date = self.generateHeaderDate()
        requestUri= self.getPartnerUrlPath('v2', '/charge')+'/'+partnerTxID+'/status?currency='+self.currency
        return self.callApi('GET', requestUri,{'Date': date, 'Content-Type': 'application/json', 'Authorization': 'Bearer ' + accessToken,'X-GID-AUX-POP': self.generatePopSignature(accessToken, date),'partnerTxID':partnerTxID,'currency': self.currency,})



