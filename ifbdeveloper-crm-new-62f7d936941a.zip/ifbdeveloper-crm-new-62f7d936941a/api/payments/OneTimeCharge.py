from  . import grab_pay
import json
import os
import sys
from app01 import models
class OneTimeCharge(grab_pay.GrabPay):
    def initCharge(self,txId, groupTxId, amount, description = ''):
        data={
            'partnerTxID' : txId,
            #'partnerTxID': 'IdempotencyKey2b4fda1e',
            'partnerGroupTxID' : groupTxId,
            #'partnerGroupTxID': 'OrderIDcedb80b9',
            'amount': amount,
            'isSync':True,
            'currency': self.currency,
            'merchantID': self.merchantId,
            'description': description
        }
        date = self.generateHeaderDate()



        request_data='{"partnerTxID": "'+txId+'","partnerGroupTxID": "'+groupTxId+'","amount": '+str(amount)+',"currency": "'+self.currency+'","merchantID": "'+self.merchantId+'","description": "'+description+'","isSync":'+'true }'
        #transaction=models.Transaction.objects.get(id=730)
        #transaction.remark=request_data
        #transaction.save()

        requestUri = self.getPartnerUrlPath('v2', '/charge/init')

        requestUri ='/grabpay/partner/v2/charge/init'



        hmacSignature = self.generateHmacSignature('POST', 'application/json', date, requestUri, request_data)

        return self.callApi('POST', requestUri, {'Date' : date,'Content-Type':'application/json','Authorization' : self.partnerId + ':' +hmacSignature,},request_data)

    def completeCharge(self,accessToken, partnerTxId):
        data={
            'partnerTxID' : partnerTxId,

        }

        requestData=json.dumps(data,separators=(',', ':'),sort_keys=False)
        date = self.generateHeaderDate('')
        #transaction = models.Transaction.objects.get(id=730)
        #transaction.remark =transaction.remark+ date+'---'
        #transaction.save()
        return self.callApi('POST', self.getPartnerUrlPath('v2', '/charge/complete'),{'Date':date,'Authorization' : 'Bearer ' +accessToken,'X-GID-AUX-POP' : self.generatePopSignature(accessToken, date),'Content-Type':'application/json'},requestData)