from utils.utils import transaction_wrapper
from app01 import models
from outlet.serializers import OutletSerializer
from django.db.models import Q,Sum,Count
from wallet.serializers import RechargeRecordCreateSerializer
from django.db import transaction
from utils.message_manage import send_message_to_token

import datetime,time

def member_payment_cashback(transactionObj,member,wallet,amount,payment_type=0):
    # wallet pay return cash to wallet campaign
    cashback_percent=0
    if member:
        member_ship=member.membership
        if member_ship:
            cashback_percent=member_ship.cash_back
    if  cashback_percent>0:
        if wallet and float(amount)>0:
            campgign_result = float(amount) * cashback_percent
            campaign_result_str = '%.2f' % campgign_result
            campaign_return = float(campaign_result_str)
            # campaign_return=round(float(amount)*campaign_Wallet.purchase_return_wallet_percent,2)
            if (campaign_return > 0):
                # purchase record 1:wallet payment 5:wirecard 6:grabpay
                if payment_type>1:
                    serializer = RechargeRecordCreateSerializer(
                        data={'money': amount, 'wallet': wallet.id, 'type': payment_type})
                    if serializer.is_valid():
                        models.RechargeRecord.objects.create(**serializer.validated_data)

                wallet.balance += campaign_return
                wallet.save()

                serializer = RechargeRecordCreateSerializer(
                    data={'money': float(campaign_return),
                          'wallet': wallet.id, 'type': 3,

                          'status': 1})
                if serializer.is_valid():
                    instance = models.RechargeRecord.objects.create(
                        **serializer.validated_data)
                # add campaign return cash to transaction record
                if transactionObj.campaign_return_wallet_cash:
                    transactionObj.campaign_return_wallet_cash += campaign_return
                else:
                    transactionObj.campaign_return_wallet_cash = campaign_return
                transactionObj.save()
                # send notification
            if member:
                device_token = member.device_token
                if device_token:
                    if campaign_return >= 0.01:
                        send_message_to_token(device_token, 'Payment successful', '10% amount cash back')
                    else:
                        send_message_to_token(device_token, 'Payment successful','thank you')
