"""api URL Configuration

The `urlpatterns` list routes URLs to views. For more information please see:
    https://docs.djangoproject.com/en/2.1/topics/http/urls/
Examples:
Function views
    1. Add an import:  from my_app import views
    2. Add a URL to urlpatterns:  path('', views.home, name='home')
Class-based views
    1. Add an import:  from other_app.views import Home
    2. Add a URL to urlpatterns:  path('', Home.as_view(), name='home')
Including another URLconf
    1. Import the include() function: from django.urls import include, path
    2. Add a URL to urlpatterns:  path('blog/', include('blog.urls'))
"""
from django.urls import path

from . import views

urlpatterns = [
    path('one_time_charge/', views.one_time_charge, name='one_time_charge'), # new
    path('one_time_charge_complete/', views.one_time_charge_complete, name='one_time_charge_complete'),
    path('grab_token_charge/', views.grab_token_charge, name='grab_token_charge'),
    path('grab_token_charge_new/', views.grab_token_charge_new, name='grab_token_charge_new'),
    path('grab_token_charge_pay/', views.grab_token_charge_pay, name='grab_token_charge_pay'),
    path('grab_token_direct_charge/', views.grab_token_direct_charge, name='grab_token_direct_charge'),
    path('grab_token_direct_charge_new/', views.grab_token_direct_charge_new, name='grab_token_direct_charge_new'),
    path('grab_token_direct_charge_pay/', views.grab_token_direct_charge_pay, name='grab_token_direct_charge_pay'),
    path('grab_token_charge_complete/', views.grab_token_charge_complete, name='grab_token_charge_complete'),
    path('grab_token_charge_complete_new/', views.grab_token_charge_complete_new, name='grab_token_charge_complete_new'),
    path('grab_token_charge_complete_new_for_web/', views.grab_token_charge_complete_new_for_web, name='grab_token_charge_complete_new_for_web'),
    path('grab_token_charge_complete_pay/', views.grab_token_charge_complete_pay, name='grab_token_charge_complete_pay'),
    path('grab_token_charge_complete_pay_for_web/', views.grab_token_charge_complete_pay_for_web, name='grab_token_charge_complete_pay_for_web'),
    path('unbind_grab_pay/', views.unbind_grab_pay, name='unbind_grab_pay'),
    path('grab_get_walletInfo/', views.grab_get_walletInfo, name='grab_get_walletInfo'),
    path('grab_check_transaction_status/', views.grab_check_transaction_status, name='grab_check_transaction_status'),
   
]
