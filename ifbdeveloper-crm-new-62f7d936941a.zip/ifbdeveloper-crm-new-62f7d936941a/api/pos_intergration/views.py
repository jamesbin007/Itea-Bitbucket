import stripe
from rest_framework import viewsets, mixins
from rest_framework.response import Response
from utils.pagination import DefaultPagination
from app01 import models
from . import serializers
from rest_framework.decorators import api_view
from django_filters.rest_framework import DjangoFilterBackend
from rest_framework.filters import SearchFilter, OrderingFilter
from utils.permissions import IsAdmin, IsApp
from .permissions import PosIntergrationOrderPermission
from django.db.models import Q, Sum
from rest_framework import status
from django_filters import rest_framework as filters
from django.db.models.functions import Coalesce
from rest_framework.decorators import action
from django.db import transaction
from django_filters import Filter,FilterSet
import  datetime
from rest_framework.permissions import AllowAny
from rest_framework.decorators import api_view,authentication_classes,permission_classes
from wallet.serializers import RechargeRecordCreateSerializer
from utils.message_manage import send_message_to_token,send_message_to_token_android_tablet
import time
from rest_framework import status
from member.services import update_member_points
from transaction.utils import thread_send_mail
from invicode import utils
from django.db.models import F
from django.db import connection
import json
import threading
class IntegerListFilter(Filter):
    def filter(self,qs,value):
     if value not in (None,''):
          integers = [int(v) for v in value.split(',')]
          return qs.filter(**{'%s__%s'%(self.field_name, self.lookup_expr):integers})
     return qs
class PayMerchantFilter(filters.FilterSet):
    brand = filters.CharFilter(field_name="brand", lookup_expr='exact')
    branch = filters.CharFilter(field_name="branch", lookup_expr='exact')
    token = filters.CharFilter(field_name="token", lookup_expr='exact')
    class Meta:
        model = models.PayMerchant
        fields = ('brand','branch','token', )

class PosIntergrationOrderFilter(filters.FilterSet):
    outlet = filters.CharFilter(field_name="outlet_id", lookup_expr='exact')
    code = filters.CharFilter(field_name="code", lookup_expr='exact')
    pos_response= filters.CharFilter(field_name="pos_response", lookup_expr='exact')

    class Meta:
        model = models.Pos_Intergration_Order
        fields = ('code','outlet','pos_response',)

class MailThread(threading.Thread):
    mail=''
    send_type=''

    def run(self):
        pass
        #utils.send_register_email('zhangjunsp@gmail.com', self.mail, send_type=self.send_type, promotion='')
        #utils.send_register_email('ziyiw2019@gmail.com', self.mail, send_type=self.send_type, promotion='')

def thread_send_mail(mail,send_type):
    mailThread = MailThread()
    mailThread.mail = mail
    mailThread.send_type = send_type
    mailThread.start()

#pos get
class PosIntergrationOrderGetViewSet(viewsets.ModelViewSet):
    authentication_classes=()
    permission_classes = (PosIntergrationOrderPermission,)
    queryset = models.Pos_Intergration_Order.objects.all().filter(pos_response=False)
    #queryset = models.Pos_Intergration_Order.objects.all().filter(pos_response=False ,createdAt__date=datetime.datetime.now().date())
    #queryset = models.Pos_Intergration_Order.objects.all().filter(pos_response=False,createdAt__date=datetime.datetime.now() + datetime.timedelta(hours=8))
    serializer_class = serializers.PosIntergrationOrderGetSerializer
    pagination_class = DefaultPagination
    filter_backends = (
        DjangoFilterBackend,
        SearchFilter,
        OrderingFilter,
    )
    filter_class = PosIntergrationOrderFilter

    ordering_fields = ('id', )

class PosIntergrationOrderViewSet(viewsets.ModelViewSet):
    authentication_classes=()
    permission_classes = (PosIntergrationOrderPermission,)
    queryset = models.Pos_Intergration_Order.objects.all()
    serializer_class = serializers.PosIntergrationOrderSerializer
    pagination_class = DefaultPagination
    filter_backends = (
        DjangoFilterBackend,
        SearchFilter,
        OrderingFilter,
    )
    filter_class = PosIntergrationOrderFilter
    search_fields = ('outlet', )
    ordering_fields = ('id', )

    def create(self, request, *args, **kwargs):
        postBody = request.body
        postBodyStr = postBody.decode('utf-8')
        json_result = json.dumps(postBodyStr)
        with transaction.atomic():
            platformRestaurant=request.data.get('platformRestaurant')
            code=request.data.get('code')
            createdAt=request.data.get('createdAt')
            shortCode = request.data.get('shortCode')
            token = request.data.get('token')
            customer= request.data.get('customer')
            price = request.data.get('price')
            products=request.data.get('products')
            if platformRestaurant:
                platformRestaurant_id=platformRestaurant['id']
            else:
                platformRestaurant_id=''
            #cursor = connection.cursor()
            #cursor.execute("insert into app01_pos_test (order_id,\"remoteCode\") values(0,'"+json_result+"' ) ")
            if customer:
                mobilePhone=customer['mobilePhone']
                firstName = customer['firstName']
                lastName = customer['lastName']
            else:
                mobilePhone = ''
                firstName = ''
                lastName = ''
            if price:
                grandTotal=price['grandTotal']
                subTotal = price['subTotal']

            else:
                grandTotal = 0
                subTotal = 0
            order_item=models.Pos_Intergration_Order.objects.filter(token=token).first()
            if order_item:
                return Response({"remoteResponse": {"remoteOrderId": str(order_item.id)}}, status=status.HTTP_202_ACCEPTED)
            outlet=models.Outlet.objects.filter(pos_intergration_platform_code=platformRestaurant_id).first()

            pos_order=models.Pos_Intergration_Order.objects.create(outlet=outlet,price_grandTotal=grandTotal,price_subTotal=subTotal,customer_phoneNumber=mobilePhone,customer_firstName=firstName,customer_lastName=lastName,platformRestaurant_id=platformRestaurant_id,code=code,createdAt=createdAt,shortCode=shortCode,token=token,pos_response=False,cancel_status=False)
            if pos_order:
                pos_id=pos_order.id
                if products:
                    for product in products:
                        name=product['name']
                        paidPrice = product['paidPrice']
                        remoteCode = product['remoteCode']
                        unitPrice = product['unitPrice']
                        quantity = product['quantity']
                        comment=product['comment']
                        post_data = dict(request.POST.lists())
                        if 'variation' in post_data.keys():
                            variation=product['variation']
                        else:
                            variation=None
                        if variation:
                            size=variation['name']
                        else:
                            size=None

                        comment_cont=product['comment']
                        if comment_cont is None:
                            comment_cont=''
                        #cursor = connection.cursor()
                        #cursor.execute("insert into app01_pos_test (order_id,\"remoteCode\") values("+str(pos_order.id)+","+product['remoteCode']+" ) ")

                        pos_details=models.Pos_Intergration_Order_Details.objects.create(name=name,paidPrice=paidPrice,remoteCode=remoteCode,unitPrice=unitPrice,quantity=quantity,order=pos_order,size=size,comment=comment_cont)
                        if pos_details:
                            if product['selectedToppings']:
                                for topping in product['selectedToppings']:
                                    models.Pos_Intergration_Order_Toppings.objects.create(price=topping['price'],name=topping['name'],remoteCode=topping['remoteCode'],order_details=pos_details,quantity=topping['quantity'])




            #thread_send_mail('Pos data intergration','pos')

            return Response({ "remoteResponse": { "remoteOrderId": str(pos_id) }}, status=status.HTTP_202_ACCEPTED)


@api_view(['GET', 'POST'])
@authentication_classes([])
@permission_classes((AllowAny,))
def responseOrder(request, *args, **kwargs):
    if request.method == 'POST':
        order_id = request.data.get('order_id')

        result_val = models.Pos_Intergration_Order.objects.filter(id=order_id).update(pos_response=True)
        if result_val > 0:
            return Response({'msg': 'ok', })
        else:
            return Response({'msg': 'error', })


@api_view(['PUT',])
@authentication_classes([])
@permission_classes((AllowAny,))
def cancelOrder(request, *args, **kwargs):
    if request.method == 'PUT':
        print(request.path_info)
        path=request.path_info
        path_info=path.split('remoteOrder/')
        if path_info:
            if len(path_info)>1:
                     last_path=path_info[1]
                     if last_path:
                        path_cell_arr=last_path.split('/')
                        if path_cell_arr:
                            remoteId=path_cell_arr[0]
                            if remoteId:
                                if request.data.get('status')=='ORDER_CANCELLED':
                                    result_val = models.Pos_Intergration_Order.objects.filter(id=remoteId).update(cancel_status=True,pos_response=False)
                                    if result_val:
                                        return Response({'message': 'ok', })
                                    else:
                                        return Response({'message': 'error', })
        return Response({'message': 'error', })

class GrabHookViewSet(viewsets.ModelViewSet):
    authentication_classes=()
    permission_classes = (PosIntergrationOrderPermission,)
    queryset = models.Grab_Hook.objects.all()
    serializer_class = serializers.Grab_HookSerializer
    pagination_class = DefaultPagination
    filter_backends = (
        DjangoFilterBackend,
        SearchFilter,
        OrderingFilter,
    )
    #filter_class = Grab_HookFilter
    search_fields = ('txID', )
    ordering_fields = ('id', )

    def create(self, request, *args, **kwargs):

        txType=request.data.get('txType')
        partnerTxID=request.data.get('partnerTxID')
        txID=request.data.get('txID')
        currency = request.data.get('currency')
        status = request.data.get('status')
        amount= request.data.get('amount')
        createdAt = request.data.get('createdAt')
        completedAt=request.data.get('completedAt')

        if txID:
            models.Grab_Hook.objects.create(txType=txType,partnerTxID=partnerTxID,txID=txID,currency=currency,status=status,amount=amount,createdAt=createdAt,completedAt=completedAt)
        return Response({'message': 'ok', })