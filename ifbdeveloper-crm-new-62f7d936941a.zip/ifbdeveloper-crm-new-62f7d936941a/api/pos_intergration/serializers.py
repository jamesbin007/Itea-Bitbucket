from rest_framework import serializers
from app01 import models
from utils.utils import except_validation_error



class Grab_HookSerializer(serializers.ModelSerializer):


    class Meta:
        model = models.Grab_Hook
        fields = '__all__'
class PosIntergrationOrderSerializer(serializers.ModelSerializer):


    class Meta:
        model = models.Pos_Intergration_Order
        fields = '__all__'
class PosIntergrationOrderGetSerializer(serializers.ModelSerializer):
    product_list = serializers.SerializerMethodField()

    class Meta:
        model = models.Pos_Intergration_Order
        fields = '__all__'
    def get_product_list(self, obj):
        ret = models.Pos_Intergration_Order_Details.objects.filter(order=obj.id)
        if (ret is not None):
            return [PosIntergrationOrderDetailsGetSerializer(i).data for i in ret]
        else:
            return []

class PosIntergrationOrderDetailsGetSerializer(serializers.ModelSerializer):
    topping_list = serializers.SerializerMethodField()
    class Meta:
        model = models.Pos_Intergration_Order_Details
        fields = "__all__"
    def get_topping_list(self, obj):
        ret = models.Pos_Intergration_Order_Toppings.objects.filter(order_details=obj.id)
        if (ret is not None):
            return [PosIntergrationOrderToppingsSerializer(i).data for i in ret]
        else:
            return []
class PosIntergrationOrderDetailsSerializer(serializers.ModelSerializer):

    class Meta:
        model = models.Pos_Intergration_Order_Details
        fields = "__all__"

class PosIntergrationOrderToppingsSerializer(serializers.ModelSerializer):

    class Meta:
        model = models.Pos_Intergration_Order_Toppings
        fields = "__all__"

