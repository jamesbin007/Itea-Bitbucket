from django.urls import path, include, re_path
from rest_framework.routers import DefaultRouter
from . import views



router = DefaultRouter()



router.register('', views.PosIntergrationOrderGetViewSet)

urlpatterns = [
    re_path(r'^order/(?P<path>.*)$', views.PosIntergrationOrderViewSet.as_view({'post':'create'}), name="order"),
    path('remoteId/<remote_id>/remoteOrder/<remoteOrder_id>/posOrderStatus', views.cancelOrder, name="posOrderStatus"),
    path('responseOrder/', views.responseOrder, name='responseOrder'),
    path('grabpay/', views.GrabHookViewSet.as_view({'post':'create'}), name="order"),
    path('', include(router.urls)),

]
