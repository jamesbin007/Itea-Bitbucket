from rest_framework.permissions import BasePermission


class PosIntergrationOrderPermission(BasePermission):
    def has_permission(self, request, view):
        if request.method in ( 'DELETE', 'PUT', 'PATCH'):

            return request.user.role.name in (1, 4)
        else:
            return True



