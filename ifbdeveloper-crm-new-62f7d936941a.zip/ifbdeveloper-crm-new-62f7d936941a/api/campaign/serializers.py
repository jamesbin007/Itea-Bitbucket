from rest_framework import serializers
from app01 import models

class PrizeLogSerializer(serializers.ModelSerializer):
    class Meta:
        model = models.PrizeLog
        fields = '__all__'
class PrizeCacheLogSerializer(serializers.ModelSerializer):
    class Meta:
        model = models.PrizeCacheLog
        fields = '__all__'
class OccupationSerializer(serializers.ModelSerializer):
    class Meta:
        model = models.Occupation
        fields = '__all__'


class CampaignTypeSerializer(serializers.ModelSerializer):
    class Meta:
        model = models.CampaignType
        fields = '__all__'

class SignedOrderRecordSerializer(serializers.ModelSerializer):
    class Meta:
        model = models.SignedOrderRecord
        fields = '__all__'

class Promotion_CodeSerializer(serializers.ModelSerializer):
    class Meta:
        model = models.Promotion_Code
        fields = '__all__'

class Terms_ConditionsSerializer(serializers.ModelSerializer):
    class Meta:
        model = models.Terms_Conditions
        fields = '__all__'
class Voucher_Terms_ConditionsSerializer(serializers.ModelSerializer):
    class Meta:
        model = models.Voucher_Terms_Conditions
        fields = '__all__'
class RewardsSerializer(serializers.ModelSerializer):
    class Meta:
        model = models.Rewards
        fields = '__all__'
class Rewards_LogSerializer(serializers.ModelSerializer):
    class Meta:
        model = models.Rewards_Log
        fields = '__all__'
        depth=2

class CampaignOneRedeemtionPerDaySerializer(serializers.ModelSerializer):
    class Meta:
        model = models.CampaignOneRedeemtionPerDay
        fields = '__all__'
        depth = 2

class CampaignOneRedeemtionPerDayPostSerializer(serializers.ModelSerializer):
    class Meta:
            model = models.CampaignOneRedeemtionPerDay
            fields = '__all__'


class CampaignConditionSerializer(serializers.ModelSerializer):
    class Meta:
        model = models.CampaignCondition
        fields = '__all__'


class CampaignCUDSerializer(serializers.ModelSerializer):
    class Meta:
        model = models.Campaign
        fields = '__all__'
class ActivitySerializer(serializers.ModelSerializer):
    class Meta:
        model = models.Activity
        fields = '__all__'

class PrizeMemberLogSerializer(serializers.ModelSerializer):
    class Meta:
        model = models.PrizeMemberLog
        fields = '__all__'
class CampaignRSerializer(serializers.ModelSerializer):
    class CampaignTypeSerializer(serializers.ModelSerializer):
        campaign_condition = CampaignConditionSerializer()

        class Meta:
            model = models.CampaignType
            exclude = ('campaign',)
            # fields = ('id', 'campaign_condition',)

    campaigntypes = CampaignTypeSerializer(many=True, read_only=True)
    # sum_money = serializers.FloatField(required=False, allow_null=True)
    turnover = serializers.FloatField(required=False, allow_null=True)
    # sum_quantity = serializers.FloatField(required=False, allow_null=True)
    products_sold = serializers.FloatField(required=False, allow_null=True)
    transactions_count = serializers.FloatField(required=False, allow_null=True)

    class Meta:
        model = models.Campaign
        fields = '__all__'

    # def to_representation(self, instance):
    #     ret = super(CampaignRSerializer, self).to_representation(instance)
    #     transaction_count = instance.transactions.count()
    #     ret['transactions'] = transaction_count
    #     return ret
