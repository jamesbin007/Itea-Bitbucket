from rest_framework import viewsets
from utils.pagination import DefaultPagination
from utils.permissions import IsAdmin
from app01 import models
from . import serializers
from .permissions import CampaignViewSetPermission
import datetime
from rest_framework.filters import SearchFilter, OrderingFilter
from django_filters.rest_framework import DjangoFilterBackend
from django_filters import rest_framework as filters
from utils.utils import get_sorted_key_func
from product.serializers import ProductPerformanceSerializer
from outlet.serializers import OutletPerformanceSerializer
from django.db.models import Sum, Count,Q
from rest_framework.response import Response
from rest_framework import status
from utils.utils import fun_timer
from utils.query_filter import get_page
from django.db.models.functions import Coalesce
from rest_framework.permissions import AllowAny
from rest_framework.decorators import api_view,authentication_classes,permission_classes,renderer_classes
from rest_framework.renderers import StaticHTMLRenderer,TemplateHTMLRenderer
from django.template import Context, loader
from django.http import HttpResponse,HttpResponseRedirect
import base64
import random
import hashlib
from django.db import transaction
from django.shortcuts import redirect
from invicode.serializers import generate_random_str
from member.services import   update_member_points
import time
import math
from rest_framework_simplejwt import tokens
from utils.auth import CustomAuthentication
class CampaignFilter(filters.FilterSet):
    min_effective_date = filters.DateTimeFilter(field_name="effective_date", lookup_expr='gte')
    max_effective_date = filters.DateTimeFilter(field_name="effective_date", lookup_expr='lte')
    min_expiring_date = filters.DateTimeFilter(field_name="expiring_date", lookup_expr='gte')
    max_expiring_date = filters.DateTimeFilter(field_name="expiring_date", lookup_expr='lte')

    class Meta:
        model = models.Campaign
        fields = ('state', 'min_effective_date', 'max_effective_date', 'min_expiring_date', 'max_expiring_date')

class ActivityFilter(filters.FilterSet):
    activity_flag = filters.CharFilter(field_name="activity_flag", lookup_expr='exact')

    class Meta:
        model = models.Activity
        fields = ('activity_flag', )

class TermsConditionsFilter(filters.FilterSet):
    rewards_id = filters.CharFilter(field_name="rewards__id", lookup_expr='exact')

    class Meta:
        model = models.Terms_Conditions
        fields = ('rewards_id', )
class RewardsFilter(filters.FilterSet):
    reward_type = filters.CharFilter(field_name="reward_type", lookup_expr='exact')
    exchange_points = filters.CharFilter(field_name="exchange_points", lookup_expr='gte')
    effective_date=filters.CharFilter(field_name="effective_date", lookup_expr='lte')
    expiring_date = filters.CharFilter(field_name="expiring_date", lookup_expr='gte')
    status = filters.CharFilter(field_name="status", lookup_expr='exact')
    class Meta:
        model = models.Rewards
        fields = ('reward_type', 'exchange_points','status',)
class RewardsLogFilter(filters.FilterSet):
    member_id = filters.CharFilter(field_name="member__id", lookup_expr='exact')
    reward_type = filters.CharFilter(field_name="rewards__reward_type", lookup_expr='exact')

    class Meta:
        model = models.Rewards_Log
        fields = ('member_id', 'member_id',)
class Promotion_CodeFilter(filters.FilterSet):
    code = filters.CharFilter(field_name="code", lookup_expr='exact')
    outlet_name = filters.CharFilter(field_name="outlet_name", lookup_expr='exact')
    status = filters.CharFilter(field_name="status", lookup_expr='exact')
    class Meta:
        model = models.Promotion_Code
        fields = ('code', 'outlet_name','status',)
class SignedFilter(filters.FilterSet):
    member = filters.CharFilter(field_name="member", lookup_expr='exact')
    electronic_signed = filters.CharFilter(field_name="electronic_signed", lookup_expr='exact')
    circle_status = filters.CharFilter(field_name="circle_status", lookup_expr='exact')
    class Meta:
        model = models.SignedOrderRecord
        fields = ('member', 'electronic_signed','circle_status',)

class OccupationViewSet(viewsets.ModelViewSet):
    permission_classes = (IsAdmin,)
    queryset = models.Occupation.objects.all()
    serializer_class = serializers.OccupationSerializer
    pagination_class = DefaultPagination
    filter_fields = ('name',)
    search_fields = ('name',)
    ordering_fields = ('name',)


class CampaignTypeViewSet(viewsets.ModelViewSet):
    permission_classes = (IsAdmin,)
    queryset = models.CampaignType.objects.all()
    serializer_class = serializers.CampaignTypeSerializer
    pagination_class = DefaultPagination
    filter_fields = ('campaign', 'campaign_condition',)
    search_fields = ('campaign', 'campaign_condition',)
    ordering_fields = ('campaign', 'campaign_condition',)

    def get_queryset(self):
        self.queryset = self.queryset.prefetch_related('free_vouchers')
        return super(CampaignTypeViewSet, self).get_queryset()

class VoucherTermsConditionsViewSet(viewsets.ModelViewSet):
    permission_classes = (CampaignViewSetPermission,)
    queryset = models.Voucher_Terms_Conditions.objects.all().order_by('index')
    serializer_class = serializers.Voucher_Terms_ConditionsSerializer
    pagination_class = DefaultPagination
    filter_backends = (
        DjangoFilterBackend,
        SearchFilter,
        OrderingFilter,
    )


    def get_queryset(self):

        return super(VoucherTermsConditionsViewSet, self).get_queryset()
class RewardsTermsConditionsViewSet(viewsets.ModelViewSet):
    permission_classes = (CampaignViewSetPermission,)
    queryset = models.Terms_Conditions.objects.all()
    serializer_class = serializers.Terms_ConditionsSerializer
    pagination_class = DefaultPagination
    filter_backends = (
        DjangoFilterBackend,
        SearchFilter,
        OrderingFilter,
    )
    filter_class = TermsConditionsFilter

    def get_queryset(self):

        return super(RewardsTermsConditionsViewSet, self).get_queryset()
class RewardsViewSet(viewsets.ModelViewSet):
    permission_classes = (CampaignViewSetPermission,)
    queryset = models.Rewards.objects.all()
    serializer_class = serializers.RewardsSerializer
    pagination_class = DefaultPagination
    filter_backends = (
        DjangoFilterBackend,
        SearchFilter,
        OrderingFilter,
    )
    filter_class = RewardsFilter

    def get_queryset(self):

        return super(RewardsViewSet, self).get_queryset()

class RewardsLogViewSet(viewsets.ModelViewSet):
    permission_classes = (CampaignViewSetPermission,)
    queryset = models.Rewards_Log.objects.all()
    serializer_class = serializers.Rewards_LogSerializer
    pagination_class = DefaultPagination
    filter_backends = (
        DjangoFilterBackend,
        SearchFilter,
        OrderingFilter,
    )
    filter_class = RewardsLogFilter

    def get_queryset(self):

        return super(RewardsLogViewSet, self).get_queryset()
class PromotionCodeViewSet(viewsets.ModelViewSet):
    permission_classes = (CampaignViewSetPermission,)
    queryset = models.Promotion_Code.objects.all()
    serializer_class = serializers.Promotion_CodeSerializer
    pagination_class = DefaultPagination
    filter_backends = (
        DjangoFilterBackend,
        SearchFilter,
        OrderingFilter,
    )
    filter_class = Promotion_CodeFilter

    def get_queryset(self):
        #self.queryset = self.queryset.prefetch_related('free_vouchers')
        return super(PromotionCodeViewSet, self).get_queryset()

class SignedViewSet(viewsets.ModelViewSet):
    permission_classes = (CampaignViewSetPermission,)
    queryset = models.SignedOrderRecord.objects.all()
    serializer_class = serializers.SignedOrderRecordSerializer
    pagination_class = DefaultPagination
    filter_backends = (
        DjangoFilterBackend,
        SearchFilter,
        OrderingFilter,
    )
    filter_class = SignedFilter

    def get_queryset(self):
        #self.queryset = self.queryset.prefetch_related('free_vouchers')
        return super(SignedViewSet, self).get_queryset()

class CampaignConditionViewSet(viewsets.ModelViewSet):
    permission_classes = (IsAdmin,)
    queryset = models.CampaignCondition.objects.all()
    serializer_class = serializers.CampaignConditionSerializer
    pagination_class = DefaultPagination
    filter_fields = ('campaign',)
    search_fields = ('campaign',)
    ordering_fields = ('campaign',)

    def get_queryset(self):
        self.queryset = self.queryset.prefetch_related('every_purchase_m_drinks_flavors',
                                                       'every_purchase_l_drinks_flavors',
                                                       'every_purchase_products')
        return super(CampaignConditionViewSet, self).get_queryset()


class ActivityViewSet(viewsets.ModelViewSet):
    permission_classes = (CampaignViewSetPermission,)
    queryset = models.Activity.objects.all()
    serializer_class = serializers.ActivitySerializer
    pagination_class = DefaultPagination
    filter_backends = (
        DjangoFilterBackend,
        SearchFilter,
        OrderingFilter,
    )
    filter_class = ActivityFilter

class CampaignViewSet(viewsets.ModelViewSet):
    permission_classes = (CampaignViewSetPermission,)
    queryset = models.Campaign.objects.all()
    serializer_class = serializers.CampaignCUDSerializer
    pagination_class = DefaultPagination
    filter_backends = (
        DjangoFilterBackend,
        SearchFilter,
        OrderingFilter,
    )
    filter_class = CampaignFilter
    search_fields = ['name']
    ordering_fields = ['turnover', 'products_sold', 'transactions_count']

    def get_queryset(self):
        self.queryset = self.queryset.prefetch_related(
            'campaigntypes__campaign_condition__every_purchase_m_drinks_flavors',
            'campaigntypes__campaign_condition__every_purchase_l_drinks_flavors',
            'campaigntypes__campaign_condition__every_purchase_products',
            'campaigntypes__free_vouchers',
            'occupations', 'memberships', 'outlets',
            'transactions__transact_details'
        ).annotate(
            transactions_count=Coalesce(Count('transactions__id', distinct=True), 0),
            turnover=Coalesce(Sum('transactions__transact_details__price'), 0),
            products_sold=Coalesce(Sum('transactions__transact_details__quantity'), 0))
        if self.request.user.role.name != 0:
            self.queryset = self.queryset.filter(effective_date__lt=datetime.datetime.now(),
                                                 expiring_date__gt=datetime.datetime.now())
        return super(CampaignViewSet, self).get_queryset()

    def get_serializer_class(self):
        if self.request.method == "GET":
            return serializers.CampaignRSerializer
        else:
            return super(CampaignViewSet, self).get_serializer_class()

    # @fun_timer
    # def list(self, request, *args, **kwargs):
    #     queryset = self.filter_queryset(self.get_queryset())
    #     serializer = self.get_serializer(queryset, many=True)
    #     ret = serializer.data
    #     # Order by turnover, products_sold, transactions
    #     order_field = request.GET.get('ordering')
    #     order_fields = ['turnover', 'products_sold', 'transactions']
    #     desc_order_fields = ['-turnover', '-products_sold', '-transactions']
    #     if order_field in order_fields:
    #         sorted_key_func = get_sorted_key_func(order_field)
    #         ret = sorted(ret, key=sorted_key_func)
    #     elif order_field in desc_order_fields:
    #         sorted_key_func = get_sorted_key_func(order_field[1:])
    #         ret = sorted(ret, key=sorted_key_func, reverse=True)
    #     # Pagination
    #     page = self.paginate_queryset(ret)
    #     response = self.get_paginated_response(page)
    #     return response
class CampaignChackViewSet(viewsets.ModelViewSet):
    permission_classes = (AllowAny,)
    queryset = models.CampaignOneRedeemtionPerDay.objects.all()
    serializer_class = serializers.CampaignOneRedeemtionPerDaySerializer
    filter_backends = (
        DjangoFilterBackend,
        SearchFilter,
        OrderingFilter,
    )



    filter_fields = [ 'ic_number','redeemtion_date']

    search_fields = ['ic_number','redeemtion_date',]
    ordering_fields = ['redeemtion_date', ]

    def get(self, request, *args, **kwargs):
        ic_number = request.GET.get('ic_number')
        redeemtion_date1 = request.GET.get('redeemtion_date')
        pre_num = ic_number[-4:]
        obj = models.CampaignOneRedeemtionPerDay.objects.get(ic_number=pre_num, redeemtion_date=redeemtion_date1)
        mask_code_sum = 0
        for iChar in ic_number:
            mask_code_sum = mask_code_sum + ord(iChar)

        mask_code = str(mask_code_sum)
        if obj:
                if (obj.mask_code == mask_code):
                    return Response(serializers.CampaignOneRedeemtionPerDaySerializer(obj), status=status.HTTP_200_OK)

        return Response(serializers.CampaignOneRedeemtionPerDaySerializer(obj), status=status.HTTP_201_CREATED)

    def create(self, request, *args, **kwargs):

        serializer = self.get_serializer(data=request.data)
        serializer.is_valid(raise_exception=True)
        ic_number = request.data.get('ic_number')
        redeemtion_date1 = request.data.get('redeemtion_date')
        redeemtion_time = request.data.get('redeemtion_time')
        redeemtion_outlet = request.data.get('redeemtion_outlet')

        if (len(ic_number) >= 4):

            pre_num=ic_number[-4:]
            mask_code_sum = 0
            for iChar in ic_number:
                mask_code_sum = mask_code_sum + ord(iChar)

            mask_code = str(mask_code_sum)
            obj=models.CampaignOneRedeemtionPerDay.objects.get(ic_number=pre_num,redeemtion_date=redeemtion_date1)
            if obj:

                if (obj.mask_code==mask_code):
                    return Response(serializer.data, status=status.HTTP_200_OK)

            item=models.CampaignOneRedeemtionPerDay(ic_number=pre_num,mask_code=mask_code,redeemtion_date=redeemtion_date1,redeemtion_time=redeemtion_time,redeemtion_outlet=redeemtion_outlet)
            item.create()

        return Response(serializer.data, status=status.HTTP_201_CREATED)

    def get_queryset(self):


        return super(CampaignOneRedeemtionPerdayViewSet, self).get_queryset()

    def get_serializer_class(self):
        if self.request.method == "GET":
            return serializers.CampaignOneRedeemtionPerDaySerializer
        else:
            return serializers.CampaignOneRedeemtionPerDayPostSerializer



class CampaignOneRedeemtionPerdayViewSet(viewsets.ModelViewSet):
    permission_classes = (AllowAny,)
    queryset = models.CampaignOneRedeemtionPerDay.objects.all()
    serializer_class = serializers.CampaignOneRedeemtionPerDaySerializer
    filter_backends = (
        DjangoFilterBackend,
        SearchFilter,
        OrderingFilter,
    )



    filter_fields = [ 'ic_number','redeemtion_date']

    search_fields = ['ic_number','redeemtion_date',]
    ordering_fields = ['redeemtion_date', ]
    def get_queryset(self):


        return super(CampaignOneRedeemtionPerdayViewSet, self).get_queryset()

    def get_serializer_class(self):
        if self.request.method == "GET":
            return serializers.CampaignOneRedeemtionPerDaySerializer
        else:
            return serializers.CampaignOneRedeemtionPerDayPostSerializer
class CampaignPerformanceOfProductViewSet(viewsets.ReadOnlyModelViewSet):
    permission_classes = (IsAdmin,)
    queryset = models.Product.objects.all()
    serializer_class = ProductPerformanceSerializer
    filter_backends = (
        DjangoFilterBackend,
        SearchFilter,
        OrderingFilter,
    )
    #暫時去掉category_name
    filter_fields = [ 'tea_base']
    #filter_fields = ['category_name', 'tea_base']
    search_fields = ['name']
    ordering_fields = ['products_sold', 'products_sold_incr', 'turnover', 'turnover_incr']

    def list(self, request, *args, **kwargs):
        # the campaign performance of products
        campaign_id = request.GET.get('campaign_id')
        if not campaign_id:
            return Response({'msg': 'Please input campaign_id in url parameters, e.g. http://{url}?campaign_id=1'},
                            status=status.HTTP_403_FORBIDDEN)
        campaign = models.Campaign.objects.filter(pk=campaign_id).filter(pk=campaign_id).first()
        if not campaign:
            return Response({'msg': 'The campaign_id is not exist'}, status=status.HTTP_403_FORBIDDEN)
        # previous campaign
        pre_campaign = models.Campaign.objects.filter(effective_date__lt=campaign.effective_date).order_by(
            '-effective_date').first()
        if not pre_campaign:
            pre_campaign_id = 0
        else:
            pre_campaign_id = pre_campaign.pk
        sql = """select *,COALESCE(turnover1, 0) AS turnover,COALESCE(products_sold1, 0) AS products_sold,COALESCE((turnover1-pre_turnover)/pre_turnover, 0) AS turnover_incr,COALESCE((products_sold1-pre_products_sold)/pre_products_sold, 0) AS products_sold_incr from
	(
		select A.*,B.*,app01_category.name AS category_name from
			(SELECT "app01_product"."id", "app01_product"."name", "app01_product"."description", "app01_product"."price", "app01_product"."tea_base", "app01_product"."item_code", "app01_product"."category_id", "app01_product"."created",COALESCE(SUM("app01_transaction"."total_money"), 0) AS "turnover1", COALESCE(SUM("app01_transactdetails"."quantity"), 0) AS "products_sold1" FROM "app01_product" INNER JOIN "app01_transactdetails" ON ("app01_product"."id" = "app01_transactdetails"."product_id") INNER JOIN "app01_transaction" ON ("app01_transactdetails"."transaction_id" = "app01_transaction"."id") INNER JOIN "app01_transaction_campaigns" ON ("app01_transaction"."id" = "app01_transaction_campaigns"."transaction_id") WHERE "app01_transaction_campaigns"."campaign_id" = %(campaign_id1)s GROUP BY "app01_product"."id") AS A
				left JOIN
			(SELECT "app01_product"."id" AS "id2","app01_product"."name" AS "name2", "app01_product"."description" AS "description2", "app01_product"."price" AS "price2", "app01_product"."tea_base" AS "tea_base2", "app01_product"."item_code" AS "item_code2", "app01_product"."category_id" AS "category_id2", "app01_product"."created" AS "created2",SUM("app01_transaction"."total_money") AS "pre_turnover", SUM("app01_transactdetails"."quantity") AS "pre_products_sold" FROM "app01_product" INNER JOIN "app01_transactdetails" ON ("app01_product"."id" = "app01_transactdetails"."product_id") INNER JOIN "app01_transaction" ON ("app01_transactdetails"."transaction_id" = "app01_transaction"."id") INNER JOIN "app01_transaction_campaigns" ON ("app01_transaction"."id" = "app01_transaction_campaigns"."transaction_id") WHERE "app01_transaction_campaigns"."campaign_id" = %(pre_campaign_id1)s GROUP BY "app01_product"."id") AS B
			ON A.id=B.id2
				inner join app01_category on app01_category.id=A.category_id
	union
		select A.*,B.*,app01_category.name AS category_name from
		(SELECT "app01_product"."id", "app01_product"."name", "app01_product"."description", "app01_product"."price", "app01_product"."tea_base", "app01_product"."item_code", "app01_product"."category_id", "app01_product"."created",COALESCE(SUM("app01_transaction"."total_money"), 0) AS "turnover1", COALESCE(SUM("app01_transactdetails"."quantity"), 0) AS "products_sold1" FROM "app01_product" INNER JOIN "app01_transactdetails" ON ("app01_product"."id" = "app01_transactdetails"."product_id") INNER JOIN "app01_transaction" ON ("app01_transactdetails"."transaction_id" = "app01_transaction"."id") INNER JOIN "app01_transaction_campaigns" ON ("app01_transaction"."id" = "app01_transaction_campaigns"."transaction_id") WHERE "app01_transaction_campaigns"."campaign_id" = %(campaign_id2)s GROUP BY "app01_product"."id") AS A
			right JOIN
		(SELECT "app01_product"."id" AS "id2","app01_product"."name" AS "name2", "app01_product"."description" AS "description2", "app01_product"."price" AS "price2", "app01_product"."tea_base" AS "tea_base2", "app01_product"."item_code" AS "item_code2", "app01_product"."category_id" AS "category_id2", "app01_product"."created" AS "created2",SUM("app01_transaction"."total_money") AS "pre_turnover", SUM("app01_transactdetails"."quantity") AS "pre_products_sold" FROM "app01_product" INNER JOIN "app01_transactdetails" ON ("app01_product"."id" = "app01_transactdetails"."product_id") INNER JOIN "app01_transaction" ON ("app01_transactdetails"."transaction_id" = "app01_transaction"."id") INNER JOIN "app01_transaction_campaigns" ON ("app01_transaction"."id" = "app01_transaction_campaigns"."transaction_id") WHERE "app01_transaction_campaigns"."campaign_id" = %(pre_campaign_id2)s GROUP BY "app01_product"."id") AS B
		ON A.id=B.id2
			inner join app01_category on app01_category.id=A.category_id
	) AS C """

        # filter sql
        filter_sql = ''
        filter_fields_dict = {}
        for filter_field in self.filter_fields:
            filter_field_value = request.GET.get(filter_field)
            if filter_field_value:
                filter_fields_dict[filter_field] = filter_field_value
        if filter_fields_dict:
            filter_sql += ' WHERE '
            for filter_field, filter_field_value in filter_fields_dict.items():
                if filter_sql == ' WHERE ':
                    filter_sql += ' UPPER("{0}") '.format(filter_field) + "LIKE UPPER('%%{0}%%') ".format(
                        filter_field_value)
                else:
                    filter_sql += ' AND UPPER("{0}") '.format(filter_field) + "LIKE UPPER('%%{0}%%') ".format(
                        filter_field_value)
        # search sql
        search_sql = ''
        search_value = request.GET.get('search')
        if search_value:
            if filter_sql == '':
                search_sql += ' WHERE ( '
            else:
                search_sql += ' AND ( '
            for search_field in self.search_fields:
                if search_sql in (' WHERE ( ', ' AND ( '):
                    search_sql += ' UPPER("{0}") '.format(search_field) + "LIKE UPPER('%%{0}%%') ".format(search_value)
                else:
                    search_sql += ' OR UPPER("{0}") '.format(search_field) + "LIKE UPPER('%%{0}%%') ".format(
                        search_value)
            else:
                search_sql += ' ) '
        # where sql(filter sql + search sql)
        where_sql = filter_sql + search_sql
        # Order by products_sold, products_sold_incr, turnover, turnover_incr
        order_sql = ''
        order_field = request.GET.get('ordering')
        desc_order_fields = ['-products_sold', '-products_sold_incr', '-turnover', '-turnover_incr']
        if order_field in self.ordering_fields:
            order_sql = " order by %s " % order_field
        elif order_field in desc_order_fields:
            order_sql = " order by %s desc " % order_field[1:]
        # get page
        page_size, page = get_page(request, self.paginator.page_size)
        limit_sql = ' limit %s offset %s ' % (page_size, (page - 1) * page_size)
        all_sql = sql + where_sql + order_sql + limit_sql
        all_queryset = models.Product.objects.raw(all_sql,
                                                  params={'campaign_id1': campaign.pk, 'campaign_id2': campaign.pk,
                                                          'pre_campaign_id1': pre_campaign_id,
                                                          'pre_campaign_id2': pre_campaign_id})
        all_queryset = list(all_queryset)
        # for i in all_queryset:
        #     print(i.__dict__)
        # Custom queryset
        # 1.remove duplicates
        import copy
        for item in all_queryset:
            item_dict = copy.deepcopy(item.__dict__)
            for field_key, field_value in item_dict.items():
                if not field_key.startswith('_'):
                    if field_key.endswith('2') and field_value:
                        delattr(item, field_key)
                        setattr(item, field_key[:-1], field_value)
        # 2.add product's category
        products = models.Product.objects.select_related('category').all()
        for item in all_queryset:
            for product in products:
                if item.id == product.id:
                    setattr(item, 'category', product.category)
        # for i in all_queryset:
        #     print(i.__dict__)
        serializer = self.get_serializer(all_queryset, many=True)
        # Pagination
        from collections import OrderedDict
        return Response(OrderedDict([
            ('count', len(all_queryset)),
            # ('next', self.get_next_link()),
            # ('previous', self.get_previous_link()),
            ('results', serializer.data)
        ]))


class CampaignPerformanceOfOutletViewSet(viewsets.ReadOnlyModelViewSet):
    permission_classes = (IsAdmin,)
    queryset = models.Outlet.objects.all()
    serializer_class = OutletPerformanceSerializer
    filter_backends = (
        DjangoFilterBackend,
        SearchFilter,
        OrderingFilter,
    )
    filter_fields = ['outlet_name', 'outlet_district']
    search_fields = ['outlet_name']
    ordering_fields = ['products_sold', 'products_sold_incr', 'turnover', 'turnover_incr', 'transactions',
                       'transactions_incr']

    def list(self, request, *args, **kwargs):
        # the campaign performance of outlets
        campaign_id = request.GET.get('campaign_id')
        if not campaign_id:
            return Response({'msg': 'Please input campaign_id in url parameters, e.g. http://{url}?campaign_id=1'},
                            status=status.HTTP_403_FORBIDDEN)
        campaign = models.Campaign.objects.filter(pk=campaign_id).filter(pk=campaign_id).first()
        if not campaign:
            return Response({'msg': 'The campaign_id is not exist'}, status=status.HTTP_403_FORBIDDEN)
        # previous campaign
        pre_campaign = models.Campaign.objects.filter(effective_date__lt=campaign.effective_date).order_by(
            '-effective_date').first()
        if not pre_campaign:
            pre_campaign_id = 0
        else:
            pre_campaign_id = pre_campaign.pk
        sql = """select *,COALESCE(turnover1, 0) AS turnover,COALESCE(products_sold1, 0) AS products_sold,COALESCE(transactions1, 0) AS transactions,COALESCE((turnover1-pre_turnover)/pre_turnover, 0) AS turnover_incr,COALESCE((products_sold1-pre_products_sold)/pre_products_sold, 0) AS products_sold_incr,COALESCE((transactions1-pre_transactions)/pre_transactions, 0) AS transactions_incr from
	(select A.*,B.* from
			(SELECT "app01_outlet"."id", "app01_outlet"."outlet_name", "app01_outlet"."outlet_code", "app01_outlet"."outlet_manager", "app01_outlet"."outlet_district", "app01_outlet"."outlet_floor_area", "app01_outlet"."outlet_address",COALESCE(SUM("app01_transaction"."total_money"), 0) AS "turnover1", COALESCE(SUM("app01_transactdetails"."quantity"), 0) AS "products_sold1", COALESCE(COUNT("app01_transaction"."id"), 0) AS "transactions1"
			FROM "app01_outlet"
			INNER JOIN "app01_transaction" ON ("app01_outlet"."id" = "app01_transaction"."outlet_id")
			INNER JOIN "app01_transactdetails" ON ("app01_transaction"."id" = "app01_transactdetails"."transaction_id")
			INNER JOIN "app01_transaction_campaigns" ON ("app01_transaction"."id" = "app01_transaction_campaigns"."transaction_id")
			WHERE "app01_transaction_campaigns"."campaign_id" = %(campaign_id1)s
			GROUP BY "app01_outlet"."id") AS A
		LEFT JOIN
			(SELECT "app01_outlet"."id" AS "id2", "app01_outlet"."outlet_name" AS "outlet_name2", "app01_outlet"."outlet_code" AS "outlet_code2", "app01_outlet"."outlet_manager" AS "outlet_manager2", "app01_outlet"."outlet_district" AS "outlet_district2", "app01_outlet"."outlet_floor_area" AS "outlet_floor_area2", "app01_outlet"."outlet_address" AS "outlet_address2",COALESCE(SUM("app01_transaction"."total_money"), 0) AS "pre_turnover", COALESCE(SUM("app01_transactdetails"."quantity"), 0) AS "pre_products_sold", COALESCE(COUNT("app01_transaction"."id"), 0) AS "pre_transactions"
			FROM "app01_outlet"
			INNER JOIN "app01_transaction" ON ("app01_outlet"."id" = "app01_transaction"."outlet_id")
			INNER JOIN "app01_transactdetails" ON ("app01_transaction"."id" = "app01_transactdetails"."transaction_id")
			INNER JOIN "app01_transaction_campaigns" ON ("app01_transaction"."id" = "app01_transaction_campaigns"."transaction_id")
			WHERE "app01_transaction_campaigns"."campaign_id" = %(pre_campaign_id1)s
			GROUP BY "app01_outlet"."id") AS B
		ON A.id=B.id2) AS C """

        # filter sql
        filter_sql = ''
        filter_fields_dict = {}
        for filter_field in self.filter_fields:
            filter_field_value = request.GET.get(filter_field)
            if filter_field_value:
                filter_fields_dict[filter_field] = filter_field_value
        if filter_fields_dict:
            filter_sql += ' WHERE '
            for filter_field, filter_field_value in filter_fields_dict.items():
                if filter_sql == ' WHERE ':
                    filter_sql += ' UPPER("{0}") '.format(filter_field) + "LIKE UPPER('%%{0}%%') ".format(
                        filter_field_value)
                else:
                    filter_sql += ' AND UPPER("{0}") '.format(filter_field) + "LIKE UPPER('%%{0}%%') ".format(
                        filter_field_value)
        # search sql
        search_sql = ''
        search_value = request.GET.get('search')
        if search_value:
            if filter_sql == '':
                search_sql += ' WHERE ( '
            else:
                search_sql += ' AND ( '
            for search_field in self.search_fields:
                if search_sql in (' WHERE ( ', ' AND ( '):
                    search_sql += ' UPPER("{0}") '.format(search_field) + "LIKE UPPER('%%{0}%%') ".format(search_value)
                else:
                    search_sql += ' OR UPPER("{0}") '.format(search_field) + "LIKE UPPER('%%{0}%%') ".format(
                        search_value)
            else:
                search_sql += ' ) '
        # where sql(filter sql + search sql)
        where_sql = filter_sql + search_sql
        # Order by products_sold, products_sold_incr, turnover, turnover_incr
        order_sql = ''
        order_field = request.GET.get('ordering')
        desc_order_fields = ['-products_sold', '-products_sold_incr', '-turnover', '-turnover_incr']
        if order_field in self.ordering_fields:
            order_sql = " order by %s " % order_field
        elif order_field in desc_order_fields:
            order_sql = " order by %s desc " % order_field[1:]
        # get page
        page_size, page = get_page(request, self.paginator.page_size)
        limit_sql = ' limit %s offset %s ' % (page_size, (page - 1) * page_size)
        all_sql = sql + where_sql + order_sql + limit_sql
        all_queryset = models.Outlet.objects.raw(all_sql,
                                                 {'campaign_id1': campaign.pk, 'campaign_id2': campaign.pk,
                                                  'pre_campaign_id1': pre_campaign_id,
                                                  'pre_campaign_id2': pre_campaign_id})
        all_queryset = list(all_queryset)
        # for i in all_queryset:
        #     print(i.__dict__)
        # Custom queryset
        # 1.remove duplicates
        import copy
        for item in all_queryset:
            item_dict = copy.deepcopy(item.__dict__)
            for field_key, field_value in item_dict.items():
                if not field_key.startswith('_'):
                    if field_key.endswith('2') and field_value:
                        delattr(item, field_key)
                        setattr(item, field_key[:-1], field_value)
        # for i in all_queryset:
        #     print(i.__dict__)
        serializer = self.get_serializer(all_queryset, many=True)
        # Pagination
        from collections import OrderedDict
        return Response(OrderedDict([
            ('count', len(all_queryset)),
            # ('next', self.get_next_link()),
            # ('previous', self.get_previous_link()),
            ('results', serializer.data)
        ]))


@api_view(['GET'])
def deal_data(request, *args, **kwargs):
    list=models.CampaignOneRedeemtionPerDay.objects.all()
    if list:

        for item in list:
            ic_number=item.ic_number
            mask_code=0
            for iChar in ic_number:
                mask_code=mask_code+ord(iChar)
                #print (str(ord(iChar)))
            item.mask_code=str(mask_code)
            item.save()



    return Response({'msg': 'error', }, status=status.HTTP_200_OK)


@api_view(['GET', 'POST'])
@authentication_classes([])
@permission_classes((AllowAny,))
def checkCampaign(request, *args, **kwargs):
    if request.method=="GET":
        ic_number = request.GET.get('ic_number')
        redeemtion_date1 = request.GET.get('redeemtion_date')
        pre_num = ic_number[-4:]
        list = models.CampaignOneRedeemtionPerDay.objects.filter(ic_number=pre_num, redeemtion_date=redeemtion_date1)
        #mask_code_sum = 0
        #for iChar in ic_number:
         #   mask_code_sum = mask_code_sum + ord(iChar)

        mask_code = md5(str( base64.b64encode(ic_number.encode('utf-8')),'utf-8'))
        if list:

            for i in list:
                #print(mask_code)
                #print(i.mask_code)
                if (i.mask_code == mask_code):
                    return Response(serializers.CampaignOneRedeemtionPerDaySerializer(list[0]).data, status=status.HTTP_200_OK)

        return Response({}, status=status.HTTP_201_CREATED)
    if request.method == "POST":
        ic_number = request.data.get('ic_number')
        redeemtion_date1 = request.data.get('redeemtion_date')
        redeemtion_time = request.data.get('redeemtion_time')
        redeemtion_outlet = request.data.get('redeemtion_outlet')

        if (len(ic_number) >= 4):

            pre_num = ic_number[-4:]
            #mask_code_sum = 0
            #for iChar in ic_number:
             #   mask_code_sum = mask_code_sum + ord(iChar)

            mask_code =  md5(str( base64.b64encode(ic_number.encode('utf-8')),'utf-8'))
            list = models.CampaignOneRedeemtionPerDay.objects.filter(ic_number=pre_num, redeemtion_date=redeemtion_date1)
            if (list):
                for i in list:
                    if (i.mask_code == mask_code):
                        return Response(serializers.CampaignOneRedeemtionPerDayPostSerializer(list[0]).data, status=status.HTTP_201_CREATED)

            item = models.CampaignOneRedeemtionPerDay.objects.create(ic_number=pre_num, mask_code=mask_code,
                                                      redeemtion_date=redeemtion_date1, redeemtion_time=redeemtion_time,
                                                      redeemtion_outlet=models.Outlet.objects.get(id=redeemtion_outlet))


        return Response(serializers.CampaignOneRedeemtionPerDayPostSerializer(item).data, status=status.HTTP_201_CREATED)

def md5(str):
    m = hashlib.md5()
    m.update(str.encode("utf8"))
    #print(m.hexdigest())
    return m.hexdigest()



@api_view(['GET','POST'])
@authentication_classes([])
@permission_classes((AllowAny,))
@renderer_classes((TemplateHTMLRenderer,StaticHTMLRenderer,))
def get_activity_campaign(request, *args, **kwargs):
    template = loader.get_template('campaign_8.html')
    context = {}

    return HttpResponse(content=template.render(context), content_type='text/html; charset=utf-8', status=200)

@api_view(['GET','POST'])
@authentication_classes([])
@permission_classes((AllowAny,))
@renderer_classes((TemplateHTMLRenderer,StaticHTMLRenderer,))
def getCampaign(request, *args, **kwargs):
    '''
    template = loader.get_template('campaign_3.html')
    context={}
    return HttpResponse(content=template.render(context), content_type='text/html; charset=utf-8', status=200)
    '''
    #get token
    '''
    token=request.META.get("HTTP_AUTHORIZATION")
    if token is None:
        pass
        #template = loader.get_template('error.html')
        #context={}
        #return HttpResponse(content=template.render(context), content_type='text/html; charset=utf-8', status=200)
    else:
        if token!='Token fa3c5db850ada70422a02e4638984dc08822f010':
            template = loader.get_template('error.html')
            context={}
            return HttpResponse(content=template.render(context), content_type='text/html; charset=utf-8', status=200)
    '''
    #print(request)
    token = request.META.get("HTTP_AUTHORIZATION")
    #print(token)

    token_arr = token.split(' ') if token is not None else None
    new_token = None
    if token_arr and len(token_arr) > 1:
        new_token = token_arr[1]
    #print(new_token)
    if new_token is None:
        #pass
        template = loader.get_template('error.html')
        context = {}
        return HttpResponse(content=template.render(context), content_type='text/html; charset=utf-8', status=200)
    else:
        auth = CustomAuthentication()
        try:
            user_obj = auth.authenticate_credentials(new_token)
            if user_obj is not None:
                pass
        except:
            template = loader.get_template('error.html')
            context = {}
            return HttpResponse(content=template.render(context), content_type='text/html; charset=utf-8', status=200)
    #template = loader.get_template('campaign_8.html')
    #context = {}

    #return HttpResponse(content=template.render(context), content_type='text/html; charset=utf-8', status=200)
    #request.session['prize'] = 0
    now=datetime.datetime.now()
    now_date_str=time.strftime("%Y-%m-%d", time.localtime())
    prize_activity=models.PrizeActivity.objects.all().first()
    activity_times=models.ActivityTimes.objects.all().order_by('id')
    activity_flag=False
    activity_index=1
    if  prize_activity:
        if    prize_activity.activity_status:

            if activity_times:
                for item in activity_times:
                        start_date_str=now_date_str+' '+item.start_time
                        end_date_str=now_date_str+' '+item.end_time
                        start_date=datetime.datetime.strptime(start_date_str, "%Y-%m-%d %H:%M")
                        end_date = datetime.datetime.strptime(end_date_str, "%Y-%m-%d %H:%M")
                        if now>=start_date and now <=end_date:
                            activity_flag = True
                            break
                        activity_index+=1

            #template = loader.get_template('campaign_8.html')
            #context = {}

            #return HttpResponse(content=template.render(context), content_type='text/html; charset=utf-8', status=200)
            #request.META['Authorization']='Token fa3c5db850ada70422a02e4638984dc08822f010'
            #print(request.META.get('Authorization'))
            #return HttpResponseRedirect(prize_activity.url+'?member_id='+request.GET.get('member_id'),)
            #return(redirect(prize_activity.url+'?member_id='+request.GET.get('member_id'),authorization='Token fa3c5db850ada70422a02e4638984dc0882',content_type='text/html; charset=utf-8'))

    prize_chances=0
    with transaction.atomic():
        now=datetime.datetime.now()
        if request.method == "GET":
            member_id=request.GET.get('member_id')
            if activity_flag:
                if prize_activity.url:
                    template = loader.get_template(prize_activity.url)
                else:
                    template = loader.get_template('v_raffle.html')
            else:
                template = loader.get_template('v_raffle.html')
            if  member_id:
                pass
            else:

                template = loader.get_template('campaign_8.html')
                context = {}

                return HttpResponse(content=template.render(context), content_type='text/html; charset=utf-8', status=200)
            #check member prize times

            prizeTimesSet=models.PrizeTimesSet.objects.first()
            if prizeTimesSet:

                none_purchase_prize_times=prizeTimesSet.none_purchase_prize_times
                activity_prize_times=prizeTimesSet.activity_prize_times
                activity_circles=prizeTimesSet.activity_circles
                purchase_prize_times=prizeTimesSet.purchase_prize_times
                # count member purchase times
                total_amount=0
                total_amount_num=0
                app_purchase_amount = models.Transaction.objects.filter(member__id=member_id, transaction_status__in=(4, 5),
                                                                   payment_datetime__date=now.date()).aggregate(sum=Sum('total_money'))
                ipay_amount=models.IpayRecord.objects.filter(member__id=member_id,created_date=now.date()).aggregate(sum=Sum('money'))
                if app_purchase_amount['sum'] is not None:
                    total_amount=total_amount+app_purchase_amount['sum']
                if ipay_amount['sum'] is not None:
                    total_amount=total_amount+ipay_amount['sum']
                purchase_flag = False
                if total_amount>0:
                    purchase_flag = True
                    total_amount_num=int(total_amount//5+0.5)

                if total_amount_num>0:
                    #activity prize times increase
                    if activity_flag:
                        if activity_circles>=activity_index:
                            all_prize_chances = none_purchase_prize_times+activity_prize_times*activity_index + purchase_prize_times * total_amount_num
                        else:
                            all_prize_chances = none_purchase_prize_times+activity_prize_times + purchase_prize_times * total_amount_num
                    else:
                        all_prize_chances = none_purchase_prize_times + purchase_prize_times * total_amount_num
                else:
                    if activity_flag:
                        if activity_circles >= activity_index:
                            all_prize_chances = none_purchase_prize_times+activity_prize_times*activity_index
                        else:
                            all_prize_chances = none_purchase_prize_times + activity_prize_times
                    else:
                        all_prize_chances = none_purchase_prize_times

                prizeMemberLog=models.PrizeMemberLog.objects.filter(member__id=member_id,prize_date=now.date()).first()
                if prizeMemberLog:

                    used_prize_times=prizeMemberLog.used_prize_times

                    prizeMemberLog.prize_times=all_prize_chances
                    if all_prize_chances>used_prize_times:
                        prize_chances=all_prize_chances-used_prize_times

                    else:
                        prize_chances=0
                    prizeMemberLog.save()

                else:
                    prizeMemberLog = models.PrizeMemberLog.objects.filter(member__id=member_id).first()
                    if prizeMemberLog:
                        prizeMemberLog.prize_times=all_prize_chances
                        prizeMemberLog.used_prize_times=0
                        #prizeMemberLog.prize_times = prizeMemberLog.prize_times + all_prize_chances
                        ## prizeMemberLog.used_prize_times=0
                        prizeMemberLog.prize_date=now.date()
                        prizeMemberLog.save()
                        prize_chances = all_prize_chances
                    else:
                        serializer = serializers.PrizeMemberLogSerializer(data={'member': member_id, 'used_prize_times':0, 'prize_times': all_prize_chances,'prize_date':now.date()})
                        if serializer.is_valid():
                            models.PrizeMemberLog.objects.create(**serializer.validated_data)
                            prize_chances = all_prize_chances
                        else:
                            prize_chances = 0

            #prize_enable_arr what prize to enable
            #used_times_sum=models.PrizeMemberLog.objects.filter(prize_date=now.date()).aggregate(used_sum=Sum('used_prize_times'))
            #init today total prize times count
            #today_prize_count=0
            #if used_times_sum:
            #    if used_times_sum['used_sum'] is not None:
            #        today_prize_count = used_times_sum['used_sum']
            #    else:
            #        today_prize_count = 0
            #else:
            #    today_prize_count = 0
            #record load times
            recent_times=1
            prize_times_cache = models.PrizeTimesCache.objects.first()
            if prize_times_cache:
                now_date=prize_times_cache.now_date
                if now_date:
                    if now_date==datetime.datetime.now().date():
                        recent_times=prize_times_cache.prize_times+1
                        prize_times_cache.prize_times=recent_times
                        if prize_chances>0:
                            prize_times_cache.save()
                    else:
                        recent_times = 1
                        prize_times_cache.now_date = datetime.datetime.now().date()
                        prize_times_cache.prize_times=1
                        if prize_chances > 0:
                           prize_times_cache.save()
                else:
                    recent_times = 1
                    prize_times_cache.now_date=datetime.datetime.now().date()
                    prize_times_cache.prize_times = 1
                    if prize_chances > 0:
                        prize_times_cache.save()


            else:

                recent_times =  1
                if prize_chances > 0:
                    models.PrizeTimesCache.objects.create(prize_times=recent_times,now_date=datetime.datetime.now().date())



            mod_100=recent_times % 100
            #exact query prize times
            query_rand_number=0
            if mod_100==0:
                query_rand_number=100
            else:
                query_rand_number=mod_100
            if activity_flag:
                prize_probability = models.PrizeProbabilityActivity.objects.filter(rand_number=query_rand_number).first()
            else:
                prize_probability=models.PrizeProbability.objects.filter(rand_number=query_rand_number).first()
            # prize_enable_arr what prize to enable
            prize_enable_arr = []
            item_prize_index_list = []
            # prize_class recently generate prize area
            prize_area_list = []
            if prize_probability:
                prizeClassSet_item=prize_probability.prize_class_set


                if prizeClassSet_item:

                    # prize_class corresponding  prize list
                    item_prize_id_list = []

                    prize_list = prizeClassSet_item.prize.all()
                    voucher_list = []
                    prize_is_voucher = False
                    if prize_list:
                        for prize_item in prize_list:
                            #check is none purchase or purchase
                            if activity_flag:
                                item_prize_index_list.append(prize_item.index)
                                item_prize_id_list.append(prize_item.id)
                                if prize_item.prize_type==0:
                                    prize_is_voucher=True
                                    if prize_item.voucher:
                                        voucher_list.append(prize_item.voucher.id)
                            else:
                                #limit none purchase prize item
                                if purchase_flag:
                                    item_prize_index_list.append(prize_item.index)
                                    item_prize_id_list.append(prize_item.id)
                                    if prize_item.prize_type == 0:
                                        prize_is_voucher = True
                                        if prize_item.voucher:
                                            voucher_list.append(prize_item.voucher.id)
                                else:
                                    if prize_item.none_purchase_enable:
                                        item_prize_index_list.append(prize_item.index)
                                        item_prize_id_list.append(prize_item.id)
                                        if prize_item.prize_type == 0:
                                            prize_is_voucher = True
                                            if prize_item.voucher:
                                                voucher_list.append(prize_item.voucher.id)

                    if item_prize_id_list is not None:
                        prize_id_tupple=tuple(item_prize_id_list)
                        prize_class_generated_number=0
                        if prize_id_tupple:
                            if activity_flag:
                                if start_date and end_date:
                                    prize_generated_count_dict = models.PrizeLog.objects.filter(created__gte=start_date,created__lte=end_date,prize__id__in=prize_id_tupple).aggregate(count=Count('id'))
                                else:
                                    prize_generated_count_dict = models.PrizeLog.objects.filter(created__date=now.date(), prize__id__in=prize_id_tupple).aggregate(count=Count('id'))
                            else:
                                prize_generated_count_dict = models.PrizeLog.objects.filter(created__date=now.date(),prize__id__in=prize_id_tupple).aggregate(count=Count('id'))
                            if prize_generated_count_dict:
                                if prize_generated_count_dict['count'] is not None:
                                    prize_class_generated_number=prize_generated_count_dict['count']
                                else:
                                    prize_class_generated_number=0
                        if  prize_class_generated_number<prizeClassSet_item.max_number_per_day:
                            if prize_is_voucher:
                                voucher_tuple = tuple(voucher_list)
                                if voucher_tuple:
                                    #invicode_count = models.Invicode.objects.filter(voucher__id__in=voucher_tuple,status=0).count()
                                    #if invicode_count:
                                    #    pass
                                    #else:
                                    #    item_prize_id_list = []


                                    prize_enable_arr = item_prize_id_list


                                    # add prize cache log


                                    if  prize_chances > 0 and prize_enable_arr:
                                        # save prize cache


                                        prize_list_str = ','.join([str(x) for x in prize_enable_arr])
                                        serializer = serializers.PrizeCacheLogSerializer(
                                            data={'member': member_id, 'prize_selected_list': prize_list_str, 'prize_status': False})
                                        if serializer.is_valid():
                                            models.PrizeCacheLog.objects.create(**serializer.validated_data)







            if prize_enable_arr:
                #prize_enable_index_arr = [x - 1 for x in prize_enable_arr]
                prize_enable_index_arr=item_prize_index_list
                random.shuffle(prize_enable_index_arr)
                prize_return_str = ','.join([str(x) for x in prize_enable_index_arr])
                prize_return_str = "[" + prize_return_str + "];"


            else:

                prize_return_str = '[0];'






            '''
            prizeClassSet=models.PrizeClassSet.objects.all().order_by('id')
            if prizeClassSet:
                for item in prizeClassSet:
                    #prize_class corresponding  prize list
                    item_prize_id_list=[]
                    # prize_enable_arr what prize to enable
                    prize_enable_arr = []
                    #prize_class recently generate prize area
                    prize_area_list=[]
                    prize_list=item.prize.all()
                    voucher_list=[]
                    prize_is_voucher=False
                    if prize_list:
                        for prize_item in prize_list:
                            item_prize_id_list.append(prize_item.id)
                            if prize_item.prize_type==0:
                                prize_is_voucher=True
                                if prize_item.voucher:
                                    voucher_list.append(prize_item.voucher.id)
                    if item_prize_id_list is not None:
                        prize_id_tupple=tuple(item_prize_id_list)
                        #today prize class generated times
                        if prize_id_tupple:
                            prize_generated_count_dict = models.PrizeLog.objects.filter(created__date=now.date(),prize__id__in=prize_id_tupple).aggregate(count=Count('id'))
                            if prize_generated_count_dict:
                                if prize_generated_count_dict['count'] is not None:
                                    prize_class_generated_number=prize_generated_count_dict['count']
                                else:
                                    prize_class_generated_number=0
                    prize_count_dict=models.PrizeMemberLog.objects.filter(prize_date=now.date()).aggregate(sum=Sum('used_prize_times'))
                    if prize_count_dict:
                        if prize_count_dict['sum'] is not None:
                            prize_count=prize_count_dict['sum']
                        else:
                            prize_count=0
                    else:
                        prize_count =0
                    #init prize_class_set
                    if item.now_date is None:
                        item.now_date=now.date()
                        item.today_generate_status=False
                        item.today_generate_interval_times=1
                        item.save()
                    elif  item.now_date!=now.date():
                        item.now_date = now.date()
                        item.today_generate_status = False
                        item.today_generate_interval_times = 1
                        item.save()
                    #init prize_area(times)
                    prize_generate_interval_times=item.prize_generate_interval_times
                    prize_generate_excursion_times=item.prize_generate_excursion_times
                    prize_area_list=[(prize_generate_interval_times*item.today_generate_interval_times-prize_generate_excursion_times),(prize_generate_interval_times*item.today_generate_interval_times+prize_generate_excursion_times)]
                    if (prize_count>=prize_area_list[0] and prize_count<=prize_area_list[1])  :
                        random_val=random.randint(prize_area_list[0],prize_area_list[1])
                        if(prize_count>=random_val):
                            #print(str(item.max_number_per_day) +'   compare    '+str(prize_class_generated_number))
                            if item.max_number_per_day>prize_class_generated_number:
                                if prize_is_voucher:
                                    voucher_tuple=tuple(voucher_list)
                                    if voucher_tuple:
                                        invicode_count = models.Invicode.objects.filter(voucher__id__in=voucher_tuple, status=0).count()
                                        if invicode_count:
                                            pass
                                        else:
                                            prize_enable_arr=[]
                                            continue

                                prize_enable_arr=item_prize_id_list

                                item.today_generate_status = False
                                item.today_generate_interval_times = item.today_generate_interval_times + 1
                                print('today_times:'+str(item.today_generate_interval_times))
                                item.save()
                                #request.session['prize'] = 1
                                #add prize cache log
                                prize_list_str=''
                                if prize_enable_arr:
                                    prize_list_str = ','.join([str(x) for x in prize_enable_arr])
                                serializer = serializers.PrizeCacheLogSerializer(
                                    data={'member': member_id, 'prize_selected_list': prize_list_str,'prize_status':False})
                                if serializer.is_valid():
                                    models.PrizeCacheLog.objects.create(**serializer.validated_data)
                                break


                if prize_enable_arr:
                    prize_enable_index_arr = [x - 1 for x in prize_enable_arr]
                    random.shuffle(prize_enable_index_arr)
                    prize_return_str = ','.join([str(x) for x in prize_enable_index_arr])
                    prize_return_str="["+prize_return_str+"];"


                else :
                    prize_enable_arr = [0]
                    prize_return_str = '[0];'

            '''














            if activity_flag:
                prize_list = models.Prize.objects.all().filter(activity_prize_flag=True).order_by('index')
            else :

                prize_list=models.Prize.objects.all().filter(activity_prize_flag=False).order_by('index')
            prize_arr=''
            num=0
            if prize_list:
                for  prize in prize_list:
                    if num==0:
                        if prize.img_url is not None and prize.img_url!='':
                            prize_arr = "{ text : '" + prize.name + "' , img: \"/static/"+prize.img_url+"\" }"
                        else:
                           prize_arr="{ text : '"+prize.name+"' }"
                    else:
                        if prize.img_url is not None and prize.img_url != '':
                            prize_arr =prize_arr+ ",{ text : '" + prize.name + "' , img: \"/static/" + prize.img_url + "\" }"
                        else:
                            prize_arr =prize_arr+ ",{ text:'" + prize.name + "' }"
                    num=num+1
            #prize_marquee
            prize_marquee=""
            prize_log_list=models.PrizeLog.objects.filter(~Q(prize__prize_type=3)).order_by('-id')[:8]
            if prize_log_list:
                for log in prize_log_list:
                    mobile_no=log.member.mobile_no
                    prize_name=log.prize.name
                    pre_mobile_no=mobile_no[:1]
                    back_mobile_no=mobile_no[-2:]
                    hide_mobile_no=pre_mobile_no+'*****'+back_mobile_no
                    prize_marquee=prize_marquee+"<li>"+hide_mobile_no +" gained "+prize_name+"</li>"
            #prize count
            prize_remain_count=''

            if activity_flag:
                prizeClassSet = models.PrizeClassSet.objects.filter(activity_flag=True).order_by('-id')

                if prizeClassSet:
                    for item in prizeClassSet:
                        # prize_class corresponding  prize list
                        prize_classset_name=item.prize_name
                        prize_classset_total=item.max_number_per_day
                        prize_classset_used=0
                        item_prize_id_list = []
                        prize_list = item.prize.all()
                        if prize_list:
                            for prize_item in prize_list:
                                item_prize_id_list.append(prize_item.id)

                        if item_prize_id_list is not None:
                            prize_id_tupple = tuple(item_prize_id_list)
                            # today prize class generated times
                            if prize_id_tupple:
                                prize_generated_count_dict = models.PrizeLog.objects.filter(created__gte=start_date,created__lte=end_date,
                                                                                            prize__id__in=prize_id_tupple).aggregate(
                                    count=Count('id'))
                                if prize_generated_count_dict:
                                    if prize_generated_count_dict['count'] is not None:
                                        prize_class_generated_number = prize_generated_count_dict['count']
                                    else:
                                        prize_class_generated_number = 0
                                    prize_classset_used=prize_class_generated_number

                        prize_remain_count=prize_remain_count+'<li>'+prize_classset_name+':'+str(prize_classset_used)+'/'+str(prize_classset_total)+'(remain/total)</li>'


            context = {}
            if activity_flag:
                context['prize_remain'] = prize_remain_count
            context['prize_marquee']=prize_marquee
            #context['prize_enable_arr'] = "[0,1];"
            context['prize_enable_arr'] = prize_return_str
            context['member_id'] = member_id
            context['chances_times'] = prize_chances
            context['prize_list']=prize_arr
            #print('session get     '+str(request.session['prize']))
            return HttpResponse(content=template.render(context), content_type='text/html; charset=utf-8', status=200)


@api_view(['GET', 'POST'])
@authentication_classes([])
@permission_classes((AllowAny,))
def handle_prize(request, *args, **kwargs):
    with transaction.atomic():
        if request.method == "POST":
            #print('session  handle    ' + str(request.session.get('prize','None')))
            now=datetime.datetime.now()
            member_id = request.data.get('member_id')
            prize= request.data.get('prize')
            #print(prize)
            # add memberLog prize times
            prizeMemberLog = models.PrizeMemberLog.objects.select_for_update(nowait=True).filter(member__id=member_id, prize_date=now.date()).first()
            if prizeMemberLog:

                used_prize_times = prizeMemberLog.used_prize_times
                prizeMemberLog.used_prize_times = used_prize_times + 1
                if prizeMemberLog.all_used_prize_times:
                    prizeMemberLog.all_used_prize_times=prizeMemberLog.all_used_prize_times+1
                else:
                    prizeMemberLog.all_used_prize_times=1
                #limit prize times
                if prizeMemberLog.used_prize_times>prizeMemberLog.prize_times:
                    return Response({'msg': 'error'}, status=status.HTTP_200_OK)
                prizeMemberLog.save()



            else:
                prizeTimesSet = models.PrizeTimesSet.objects.first()
                if prizeTimesSet:

                    none_purchase_prize_times = prizeTimesSet.none_purchase_prize_times
                    purchase_prize_times = prizeTimesSet.purchase_prize_times
                    # count member purchase times
                    purchase_times = models.Transaction.objects.filter(member__id=member_id,
                                                                       transaction_status__in=(4, 5),
                                                                       payment_datetime__date=now.date()).aggregate(
                        count=Count('id'))
                    if purchase_times['count'] is not None:
                        member_purchase_times = purchase_times['count']
                        all_prize_chances = none_purchase_prize_times + purchase_prize_times * member_purchase_times
                    else:
                        all_prize_chances = none_purchase_prize_times
                prizeMemberLog = models.PrizeMemberLog.objects.filter(member__id=member_id).first()
                if prizeMemberLog:
                    prizeMemberLog.prize_times = all_prize_chances
                    prizeMemberLog.used_prize_times = 1
                    if prizeMemberLog.all_used_prize_times:
                        prizeMemberLog.all_used_prize_times = prizeMemberLog.all_used_prize_times + 1
                    else:
                        prizeMemberLog.all_used_prize_times = 1
                    prizeMemberLog.prize_date = now.date()
                    prizeMemberLog.save()

                else:
                    serializer = serializers.PrizeMemberLogSerializer(
                        data={'member': member_id, 'used_prize_times': 1, 'prize_times': all_prize_chances,
                              'prize_date': now.date(), 'all_used_prize_times': 1})
                    if serializer.is_valid():
                        models.PrizeMemberLog.objects.create(**serializer.validated_data)
            #add prize log
            prize_obj=models.Prize.objects.filter(name=prize).first()
            if prize_obj:

                prize_id=prize_obj.id
                if prize_obj.prize_type!=3:
                    #check prize log cache
                    prize_cache_list=models.PrizeCacheLog.objects.filter(member__id=member_id,created__date=now.date(),prize_status=False)
                    if prize_cache_list:
                        prize_cash_flag=False
                        for prize_cache in prize_cache_list:
                            prize_list_str=prize_cache.prize_selected_list
                            prize_list_arr=prize_list_str.split(',')
                            if prize_list_arr:
                                if str(prize_id) in prize_list_arr:
                                    prize_cache.prize_status=True
                                    prize_cache.save()
                                    prize_cash_flag=True
                                    break

                        if not prize_cash_flag:
                            return Response({'msg': 'error'}, status=status.HTTP_200_OK)
                    else:
                        return Response({'msg': 'error'}, status=status.HTTP_200_OK)
                    #if request.session['prize']=='0':
                    #   return Response({'msg': 'error'}, status=status.HTTP_200_OK)
                    serializer = serializers.PrizeLogSerializer(
                        data={'member': member_id, 'prize': prize_id})
                    if serializer.is_valid():
                        models.PrizeLog.objects.create(**serializer.validated_data)
                        member = models.Member.objects.filter(id=member_id).first()
                    #bind prize
                    if prize_obj.prize_type==0:
                        if prize_obj.voucher and member:
                            #direct insert invicode

                            models.Invicode.objects.create(**{'voucher': prize_obj.voucher, 'code': generate_random_str(), 'status': 1, 'member': member,'register_date': datetime.datetime.now(),'vaild_days':14, 'expire_date': datetime.datetime.now().date()+datetime.timedelta(days=14)})
                            #invicode = models.Invicode.objects.filter(member__id=member_id, voucher__id=prize_obj.voucher.id).first()
                            #if invicode:
                            #    pass
                            #else:

                            #cancel the old style of insert invicode

                            '''
                                invicode_first = models.Invicode.objects.select_for_update(nowait=True).filter(
                                    voucher__id=prize_obj.voucher.id, status=0).first()
                                if invicode_first:
                                    member=models.Member.objects.filter(id=member_id).first()
                                    if member:
                                        invicode_first.member = member
                                        invicode_first.invicode_user = member.mobile_no
                                        invicode_first.status = 1
                                        invicode_first.register_date = datetime.datetime.now()
                                        voucher=invicode_first.voucher
                                        if voucher:
                                            voucher_expire_date = voucher.expiring_date

                                            invicode_register_date = invicode_first.register_date
                                            valid_days = invicode_first.vaild_days
                                            voucher_expire_date_8 = voucher_expire_date
                                            # voucher_expire_zone_date=voucher_expire_date_8.replace(tzinfo=None)
                                            invicode_register_date_8 = invicode_register_date
                                            # invicode_register_zone_date = invicode_register_date_8.replace(tzinfo=None)
                                            if (valid_days and valid_days > 0):
                                                v_days = valid_days - 1
                                                invicode_exp_date = invicode_register_date_8 + datetime.timedelta(
                                                    days=v_days)
                                                if invicode_exp_date.date() >= voucher_expire_date_8:

                                                    invicode_first.expire_date = voucher_expire_date_8
                                                else:
                                                    invicode_first.expire_date = invicode_exp_date
                                            else:
                                                invicode_first.expire_date = voucher_expire_date_8


                                        invicode_first.save()
                                else:
                                    pass
                            '''
                        else:
                            return Response({'msg': 'error'}, status=status.HTTP_200_OK)



            return Response({'msg':'ok'},status=status.HTTP_200_OK)

@api_view(['GET', 'POST'])
@authentication_classes([])
@permission_classes((AllowAny,))
def campaign_advertising(request, *args, **kwargs):
    template = loader.get_template('campaign_8.html')
    context = {}

    return HttpResponse(content=template.render(context), content_type='text/html; charset=utf-8', status=200)

@api_view(['GET', 'POST'])
@authentication_classes([])
@permission_classes((AllowAny,))
def member_ship(request, *args, **kwargs):
    template = loader.get_template('campaign_8.html')
    context = {}

    return HttpResponse(content=template.render(context), content_type='text/html; charset=utf-8', status=200)

@api_view(['GET', 'POST'])
@authentication_classes([])
@permission_classes((AllowAny,))
def redeem(request, *args, **kwargs):

    if request.method == "GET":
        rewards_id=request.GET.get('rewards_id')
        member_id=request.GET.get('member_id')
        rewards=models.Rewards.objects.filter(id=rewards_id).first()
        if rewards:
            if rewards.status and (datetime.datetime.now().date()>=rewards.effective_date and datetime.datetime.now().date()<=rewards.expiring_date ):
                if rewards.reward_type == 0:
                     voucher=rewards.voucher
                     member=models.Member.objects.filter(id=member_id).first()
                     if voucher and member:
                         with transaction.atomic():
                             if member.points_bal>=rewards.exchange_points:
                                 #member points deduck
                                 member.points_bal=member.points_bal-rewards.exchange_points
                                 member.save()
                                 #poists history log
                                 models.Points_Member.objects.create(member=member,points_number=math.ceil(float(rewards.exchange_points)),method=3,rewards=rewards)

                                 #voucher dispatch
                                 objs=[]
                                 obj = models.Invicode(
                                     **{'voucher': voucher, 'code': generate_random_str(), 'status': 1, 'member': member,
                                        'register_date': datetime.datetime.now(), 'vaild_days': 180,
                                        'expire_date': datetime.datetime.now().date() + datetime.timedelta(days=180)})
                                 objs.append(obj)
                                 models.Invicode.objects.bulk_create(objs)
                                 #redeem history log
                                 invicode=models.Invicode.objects.filter(member__id=member.id,voucher__id=voucher.id,status=1).order_by('-id').first()
                                 if invicode:
                                     objs = []
                                     obj = models.Rewards_Log(
                                         **{'rewards': rewards, 'invicode': invicode,
                                            'member': member,
                                           })
                                     objs.append(obj)
                                     models.Rewards_Log.objects.bulk_create(objs)
                                 return Response({'msg': 'ok'}, status=status.HTTP_200_OK)
                             else:
                                 return Response({'msg': 'Credits not enough!'}, status=status.HTTP_200_OK)

            else:
                return Response({'msg': 'This rewards ended!'}, status=status.HTTP_200_OK)

    return Response({'msg': 'This rewards ended!'}, status=status.HTTP_200_OK)

@api_view(['GET', 'POST'])
@authentication_classes([])
@permission_classes((AllowAny,))
def getLuckTimes(request, *args, **kwargs):
    prize_chances = 0
    if request.method == "GET":
        now = datetime.datetime.now()
        now_date_str = time.strftime("%Y-%m-%d", time.localtime())
        prize_activity = models.PrizeActivity.objects.all().first()
        activity_times = models.ActivityTimes.objects.all().order_by('id')
        activity_index = 1
        is_activity = False
        backgroud_color=''
        img_url=""
        if prize_activity:
            backgroud_color=prize_activity.backgroud_color
            img_url=prize_activity.img_url
            if prize_activity.activity_status:
                #is_activity=True
                if activity_times:
                    for item in activity_times:
                        start_date_str = now_date_str + ' ' + item.start_time
                        end_date_str = now_date_str + ' ' + item.end_time
                        start_date = datetime.datetime.strptime(start_date_str, "%Y-%m-%d %H:%M")
                        end_date = datetime.datetime.strptime(end_date_str, "%Y-%m-%d %H:%M")
                        if now >= start_date and now <= end_date:
                            is_activity=True
                            break
                        activity_index += 1


        '''
        if activity_flag:
            pass
        else:
            return Response({'lucky_times': prize_chances}, status=status.HTTP_200_OK)
        '''
        # print('session  handle    ' + str(request.session.get('prize','None')))
        now = datetime.datetime.now()
        member_id = request.GET.get('member_id')
        # check member prize times
        prizeTimesSet = models.PrizeTimesSet.objects.first()
        if prizeTimesSet:

            none_purchase_prize_times = prizeTimesSet.none_purchase_prize_times
            purchase_prize_times = prizeTimesSet.purchase_prize_times
            activity_prize_times = prizeTimesSet.activity_prize_times
            activity_circles = prizeTimesSet.activity_circles
            # count member purchase times
            total_amount = 0
            total_amount_num = 0
            app_purchase_amount = models.Transaction.objects.filter(member__id=member_id, transaction_status__in=(4, 5),
                                                                    payment_datetime__date=now.date()).aggregate(
                sum=Sum('total_money'))
            ipay_amount = models.IpayRecord.objects.filter(member__id=member_id, created_date=now.date()).aggregate(
                sum=Sum('money'))
            if app_purchase_amount['sum'] is not None:
                total_amount = total_amount + app_purchase_amount['sum']
            if ipay_amount['sum'] is not None:
                total_amount = total_amount + ipay_amount['sum']
            if total_amount > 0:
                total_amount_num = int(total_amount // 5 + 0.5)

            if total_amount_num > 0:
                if is_activity:
                    if activity_circles >= activity_index:
                        all_prize_chances = none_purchase_prize_times + activity_prize_times * activity_index + purchase_prize_times * total_amount_num
                    else:
                        all_prize_chances = none_purchase_prize_times + activity_prize_times + purchase_prize_times * total_amount_num
                else:

                    all_prize_chances = none_purchase_prize_times + purchase_prize_times * total_amount_num
            else:
                if is_activity:
                    if activity_circles >= activity_index:
                        all_prize_chances = none_purchase_prize_times + activity_prize_times * activity_index
                    else:
                        all_prize_chances = none_purchase_prize_times + activity_prize_times
                else:
                    all_prize_chances = none_purchase_prize_times

            prizeMemberLog = models.PrizeMemberLog.objects.filter(member__id=member_id, prize_date=now.date()).first()
            if prizeMemberLog:

                used_prize_times = prizeMemberLog.used_prize_times

                prizeMemberLog.prize_times = all_prize_chances
                if all_prize_chances > used_prize_times:
                    prize_chances = all_prize_chances - used_prize_times

                else:
                    prize_chances = 0
                #prizeMemberLog.save()

            else:


                prize_chances = all_prize_chances
        return  Response({'lucky_times':prize_chances,'is_activity':is_activity,'backgroud_color':backgroud_color,'img_url':img_url},status=status.HTTP_200_OK)


@api_view(['GET', 'POST'])
@authentication_classes([])
@permission_classes((AllowAny,))
def getTopupStatus(request, *args, **kwargs):
    if request.method=="GET":
        member_id = request.GET.get('member_id')
        campaignTopup = models.CampaignTopup.objects.all().first()
        if campaignTopup:

            if   campaignTopup.activity_flag:
                if campaignTopup.times_limit_flag:

                    if member_id:
                        member=models.Member.objects.filter(id=member_id).first()
                        if member:

                            if member.topup_10_times is not None and member.topup_10_times<campaignTopup.topup_10_limit_times:
                                topup_10_return_cash=campaignTopup.topup_10_return_cash
                            else:
                                topup_10_return_cash=0

                            if member.topup_20_times is not None and member.topup_20_times<campaignTopup.topup_20_limit_times:
                                topup_20_return_cash=campaignTopup.topup_20_return_cash
                                #print(topup_20_return_cash)
                            else:
                                topup_20_return_cash=0
                            if member.topup_50_times is not None and member.topup_50_times<campaignTopup.topup_50_limit_times:
                                topup_50_return_cash=campaignTopup.topup_50_return_cash
                            else:
                                topup_50_return_cash=0
                            return Response({'member':member_id,'topup_10_return_cash':topup_10_return_cash,'topup_20_return_cash': topup_20_return_cash,'topup_50_return_cash': topup_50_return_cash},status=status.HTTP_200_OK)

                else:
                    return Response({'member':member_id,'topup_10_return_cash': campaignTopup.topup_10_return_cash,'topup_20_return_cash': campaignTopup.topup_20_return_cash,'topup_50_return_cash': campaignTopup.topup_50_return_cash }, status=status.HTTP_200_OK)
        return Response({'member':member_id,'topup_10_return_cash': 0,'topup_20_return_cash': 0,'topup_50_return_cash': 0}, status=status.HTTP_200_OK)


@api_view(['GET','POST'])
@authentication_classes([])
@permission_classes((AllowAny,))
@renderer_classes((TemplateHTMLRenderer,StaticHTMLRenderer,))
def getPromotionCampaign(request, *args, **kwargs):
    #template = loader.get_template('campaign_3.html')
    #context={}
    #return HttpResponse(content=template.render(context), content_type='text/html; charset=utf-8', status=200)
    #get token
    print(request)
    token=request.META.get("HTTP_AUTHORIZATION")
    print(token)

    token_arr=token.split(' ') if token is not None else None
    new_token=None
    if token_arr and len(token_arr)>1:
        new_token=token_arr[1]
    print(new_token)
    if new_token is None:
        #pass
        template = loader.get_template('error.html')
        context={}
        return HttpResponse(content=template.render(context), content_type='text/html; charset=utf-8', status=200)
    else:
        auth=CustomAuthentication()
        try:
            user_obj=auth.authenticate_credentials(new_token)
            if user_obj is not None:
                pass
        except:
            template = loader.get_template('error.html')
            context={}
            return HttpResponse(content=template.render(context), content_type='text/html; charset=utf-8', status=200)






    #template = loader.get_template('campaign_8.html')
    #context = {}

    #return HttpResponse(content=template.render(context), content_type='text/html; charset=utf-8', status=200)
    #request.session['prize'] = 0
    now=datetime.datetime.now()
    now_date_str=time.strftime("%Y-%m-%d", time.localtime())

    prize_activity=models.PrizeActivity.objects.all().first()
    activity_times=models.ActivityTimes.objects.all().order_by('id')
    activity_flag=False
    start_date=None
    end_date=None
    activity_index=1
    if  prize_activity:
        if    prize_activity.activity_status:

            if activity_times:
                for item in activity_times:
                        start_date_str=now_date_str+' '+item.start_time
                        end_date_str=now_date_str+' '+item.end_time
                        start_date=datetime.datetime.strptime(start_date_str, "%Y-%m-%d %H:%M")
                        end_date = datetime.datetime.strptime(end_date_str, "%Y-%m-%d %H:%M")
                        if now>=start_date and now <=end_date:
                            activity_flag = True
                            break
                        activity_index+=1

            #template = loader.get_template('campaign_8.html')
            #context = {}

            #return HttpResponse(content=template.render(context), content_type='text/html; charset=utf-8', status=200)
            #request.META['Authorization']='Token fa3c5db850ada70422a02e4638984dc08822f010'
            #print(request.META.get('Authorization'))
            #return HttpResponseRedirect(prize_activity.url+'?member_id='+request.GET.get('member_id'),)
            #return(redirect(prize_activity.url+'?member_id='+request.GET.get('member_id'),authorization='Token fa3c5db850ada70422a02e4638984dc0882',content_type='text/html; charset=utf-8'))
    activity_flag = False
    prize_chances=0
    with transaction.atomic():
        now=datetime.datetime.now()
        if request.method == "GET":
            member_id=request.GET.get('member_id')
            promotion_code = request.GET.get('promotion_code')
            promotion_type=request.GET.get('promotion_type')
            if activity_flag:
                if prize_activity.url:
                    template = loader.get_template(prize_activity.url)
                else:
                    template = loader.get_template('v_raffle.html')
            else:
                template = loader.get_template('v_raffle_'+promotion_type+'.html')
            if  member_id:
                pass
            else:

                template = loader.get_template('campaign_8.html')
                context = {}

                return HttpResponse(content=template.render(context), content_type='text/html; charset=utf-8', status=200)
            #check member prize times

            prizeTimesSet=models.PrizeTimesSet.objects.first()
            if prizeTimesSet:

                none_purchase_prize_times=prizeTimesSet.none_purchase_prize_times
                activity_prize_times=prizeTimesSet.activity_prize_times
                activity_circles=prizeTimesSet.activity_circles
                purchase_prize_times=prizeTimesSet.purchase_prize_times
                #check code
                all_prize_chances = 0
                promotion_code=models.Promotion_Code.objects.filter(code=promotion_code).first()
                if promotion_code:
                    if promotion_code.status:
                            pass
                    else:
                        all_prize_chances =1
                        promotion_code.status=True
                        promotion_code.save()


                        # count member purchase times

                '''
                total_amount=0
                total_amount_num=0
                app_purchase_amount = models.Transaction.objects.filter(member__id=member_id, transaction_status__in=(4, 5),
                                                                   payment_datetime__date=now.date()).aggregate(sum=Sum('total_money'))
                ipay_amount=models.IpayRecord.objects.filter(member__id=member_id,created_date=now.date()).aggregate(sum=Sum('money'))
                if app_purchase_amount['sum'] is not None:
                    total_amount=total_amount+app_purchase_amount['sum']
                if ipay_amount['sum'] is not None:
                    total_amount=total_amount+ipay_amount['sum']
                purchase_flag = False
                if total_amount>0:
                    purchase_flag = True
                    total_amount_num=int(total_amount//5+0.5)

                if total_amount_num>0:
                    #activity prize times increase
                    if activity_flag:
                        if activity_circles>=activity_index:
                            all_prize_chances = none_purchase_prize_times+activity_prize_times*activity_index + purchase_prize_times * total_amount_num
                        else:
                            all_prize_chances = none_purchase_prize_times+activity_prize_times + purchase_prize_times * total_amount_num
                    else:
                        all_prize_chances = none_purchase_prize_times + purchase_prize_times * total_amount_num
                else:
                    if activity_flag:
                        if activity_circles >= activity_index:
                            all_prize_chances = none_purchase_prize_times+activity_prize_times*activity_index
                        else:
                            all_prize_chances = none_purchase_prize_times + activity_prize_times
                    else:
                        all_prize_chances = none_purchase_prize_times
                '''
                prizeMemberLog=models.PrizeMemberLog.objects.filter(member__id=member_id,prize_date=now.date()).first()
                if prizeMemberLog:

                    used_prize_times=prizeMemberLog.used_prize_times

                    prizeMemberLog.prize_times=prizeMemberLog.prize_times+all_prize_chances

                    prize_chances=prizeMemberLog.prize_times-used_prize_times
                    prizeMemberLog.save()
                    if prize_chances<0:

                        prize_chances=0


                else:
                    prizeMemberLog = models.PrizeMemberLog.objects.filter(member__id=member_id).first()
                    if prizeMemberLog:
                        prizeMemberLog.prize_times=prizeMemberLog.prize_times+all_prize_chances
                        #prizeMemberLog.used_prize_times=0
                        prizeMemberLog.prize_date=now.date()
                        prizeMemberLog.save()
                        prize_chances =prizeMemberLog.prize_times-prizeMemberLog.used_prize_times
                        if prize_chances<0:
                            prize_chances=0
                        #prize_chances = all_prize_chances
                    else:
                        serializer = serializers.PrizeMemberLogSerializer(data={'member': member_id, 'used_prize_times':0, 'prize_times': all_prize_chances,'prize_date':now.date()})
                        if serializer.is_valid():
                            models.PrizeMemberLog.objects.create(**serializer.validated_data)
                            prize_chances = all_prize_chances
                        else:
                            prize_chances = 0

            #prize_enable_arr what prize to enable
            #used_times_sum=models.PrizeMemberLog.objects.filter(prize_date=now.date()).aggregate(used_sum=Sum('used_prize_times'))
            #init today total prize times count
            #today_prize_count=0
            #if used_times_sum:
            #    if used_times_sum['used_sum'] is not None:
            #        today_prize_count = used_times_sum['used_sum']
            #    else:
            #        today_prize_count = 0
            #else:
            #    today_prize_count = 0
            #record load times
            recent_times=1
            prize_times_cache = models.PrizeTimesCache.objects.first()
            if prize_times_cache:
                now_date=prize_times_cache.now_date
                if now_date:
                    if now_date==datetime.datetime.now().date():
                        recent_times=prize_times_cache.prize_times+1
                        prize_times_cache.prize_times=recent_times
                        if prize_chances>0:
                            prize_times_cache.save()
                    else:
                        recent_times = 1
                        prize_times_cache.now_date = datetime.datetime.now().date()
                        prize_times_cache.prize_times=1
                        if prize_chances > 0:
                           prize_times_cache.save()
                else:
                    recent_times = 1
                    prize_times_cache.now_date=datetime.datetime.now().date()
                    prize_times_cache.prize_times = 1
                    if prize_chances > 0:
                        prize_times_cache.save()


            else:

                recent_times =  1
                if prize_chances > 0:
                    models.PrizeTimesCache.objects.create(prize_times=recent_times,now_date=datetime.datetime.now().date())



            mod_100=recent_times % 100
            #exact query prize times
            query_rand_number=0
            if mod_100==0:
                query_rand_number=100
            else:
                query_rand_number=mod_100
            if activity_flag:
                prize_probability = models.PrizeProbabilityActivity.objects.filter(rand_number=query_rand_number).first()
            else:
                prize_probability=models.PrizeProbability.objects.filter(rand_number=query_rand_number).first()
            # prize_enable_arr what prize to enable
            prize_enable_arr = []
            item_prize_index_list = []
            # prize_class recently generate prize area
            prize_area_list = []
            #promotion campaign is purchased
            purchase_flag=True
            if prize_probability:
                prizeClassSet_item=prize_probability.prize_class_set


                if prizeClassSet_item:

                    # prize_class corresponding  prize list
                    item_prize_id_list = []

                    prize_list = prizeClassSet_item.prize.all()
                    voucher_list = []
                    prize_is_voucher = False
                    if prize_list:
                        for prize_item in prize_list:
                            #check is none purchase or purchase
                            if activity_flag:
                                item_prize_index_list.append(prize_item.index)
                                item_prize_id_list.append(prize_item.id)
                                if prize_item.prize_type==0:
                                    prize_is_voucher=True
                                    if prize_item.voucher:
                                        voucher_list.append(prize_item.voucher.id)
                            else:
                                #limit none purchase prize item
                                if purchase_flag:
                                    item_prize_index_list.append(prize_item.index)
                                    item_prize_id_list.append(prize_item.id)
                                    if prize_item.prize_type == 0:
                                        prize_is_voucher = True
                                        if prize_item.voucher:
                                            voucher_list.append(prize_item.voucher.id)
                                else:
                                    if prize_item.none_purchase_enable:
                                        item_prize_index_list.append(prize_item.index)
                                        item_prize_id_list.append(prize_item.id)
                                        if prize_item.prize_type == 0:
                                            prize_is_voucher = True
                                            if prize_item.voucher:
                                                voucher_list.append(prize_item.voucher.id)

                    if item_prize_id_list is not None:
                        prize_id_tupple=tuple(item_prize_id_list)
                        prize_class_generated_number=0
                        if prize_id_tupple:
                            if activity_flag:
                                if start_date and end_date:
                                    prize_generated_count_dict = models.PrizeLog.objects.filter(created__gte=start_date,created__lte=end_date,prize__id__in=prize_id_tupple).aggregate(count=Count('id'))
                                else:
                                    prize_generated_count_dict = models.PrizeLog.objects.filter(created__date=now.date(), prize__id__in=prize_id_tupple).aggregate(count=Count('id'))
                            else:
                                prize_generated_count_dict = models.PrizeLog.objects.filter(created__date=now.date(),prize__id__in=prize_id_tupple).aggregate(count=Count('id'))
                            if prize_generated_count_dict:
                                if prize_generated_count_dict['count'] is not None:
                                    prize_class_generated_number=prize_generated_count_dict['count']
                                else:
                                    prize_class_generated_number=0
                        if  prize_class_generated_number<prizeClassSet_item.max_number_per_day:
                            if prize_is_voucher:
                                voucher_tuple = tuple(voucher_list)
                                if voucher_tuple:
                                    #invicode_count = models.Invicode.objects.filter(voucher__id__in=voucher_tuple,status=0).count()
                                    #if invicode_count:
                                    #    pass
                                    #else:
                                    #    item_prize_id_list = []


                                    prize_enable_arr = item_prize_id_list


                                    # add prize cache log


                                    if  prize_chances > 0 and prize_enable_arr:
                                        # save prize cache


                                        prize_list_str = ','.join([str(x) for x in prize_enable_arr])
                                        serializer = serializers.PrizeCacheLogSerializer(
                                            data={'member': member_id, 'prize_selected_list': prize_list_str, 'prize_status': False})
                                        if serializer.is_valid():
                                            models.PrizeCacheLog.objects.create(**serializer.validated_data)







            if prize_enable_arr:
                #prize_enable_index_arr = [x - 1 for x in prize_enable_arr]
                prize_enable_index_arr=item_prize_index_list
                random.shuffle(prize_enable_index_arr)
                prize_return_str = ','.join([str(x) for x in prize_enable_index_arr])
                prize_return_str = "[" + prize_return_str + "];"


            else:

                prize_return_str = '[0];'






            '''
            prizeClassSet=models.PrizeClassSet.objects.all().order_by('id')
            if prizeClassSet:
                for item in prizeClassSet:
                    #prize_class corresponding  prize list
                    item_prize_id_list=[]
                    # prize_enable_arr what prize to enable
                    prize_enable_arr = []
                    #prize_class recently generate prize area
                    prize_area_list=[]
                    prize_list=item.prize.all()
                    voucher_list=[]
                    prize_is_voucher=False
                    if prize_list:
                        for prize_item in prize_list:
                            item_prize_id_list.append(prize_item.id)
                            if prize_item.prize_type==0:
                                prize_is_voucher=True
                                if prize_item.voucher:
                                    voucher_list.append(prize_item.voucher.id)
                    if item_prize_id_list is not None:
                        prize_id_tupple=tuple(item_prize_id_list)
                        #today prize class generated times
                        if prize_id_tupple:
                            prize_generated_count_dict = models.PrizeLog.objects.filter(created__date=now.date(),prize__id__in=prize_id_tupple).aggregate(count=Count('id'))
                            if prize_generated_count_dict:
                                if prize_generated_count_dict['count'] is not None:
                                    prize_class_generated_number=prize_generated_count_dict['count']
                                else:
                                    prize_class_generated_number=0
                    prize_count_dict=models.PrizeMemberLog.objects.filter(prize_date=now.date()).aggregate(sum=Sum('used_prize_times'))
                    if prize_count_dict:
                        if prize_count_dict['sum'] is not None:
                            prize_count=prize_count_dict['sum']
                        else:
                            prize_count=0
                    else:
                        prize_count =0
                    #init prize_class_set
                    if item.now_date is None:
                        item.now_date=now.date()
                        item.today_generate_status=False
                        item.today_generate_interval_times=1
                        item.save()
                    elif  item.now_date!=now.date():
                        item.now_date = now.date()
                        item.today_generate_status = False
                        item.today_generate_interval_times = 1
                        item.save()
                    #init prize_area(times)
                    prize_generate_interval_times=item.prize_generate_interval_times
                    prize_generate_excursion_times=item.prize_generate_excursion_times
                    prize_area_list=[(prize_generate_interval_times*item.today_generate_interval_times-prize_generate_excursion_times),(prize_generate_interval_times*item.today_generate_interval_times+prize_generate_excursion_times)]
                    if (prize_count>=prize_area_list[0] and prize_count<=prize_area_list[1])  :
                        random_val=random.randint(prize_area_list[0],prize_area_list[1])
                        if(prize_count>=random_val):
                            #print(str(item.max_number_per_day) +'   compare    '+str(prize_class_generated_number))
                            if item.max_number_per_day>prize_class_generated_number:
                                if prize_is_voucher:
                                    voucher_tuple=tuple(voucher_list)
                                    if voucher_tuple:
                                        invicode_count = models.Invicode.objects.filter(voucher__id__in=voucher_tuple, status=0).count()
                                        if invicode_count:
                                            pass
                                        else:
                                            prize_enable_arr=[]
                                            continue

                                prize_enable_arr=item_prize_id_list

                                item.today_generate_status = False
                                item.today_generate_interval_times = item.today_generate_interval_times + 1
                                print('today_times:'+str(item.today_generate_interval_times))
                                item.save()
                                #request.session['prize'] = 1
                                #add prize cache log
                                prize_list_str=''
                                if prize_enable_arr:
                                    prize_list_str = ','.join([str(x) for x in prize_enable_arr])
                                serializer = serializers.PrizeCacheLogSerializer(
                                    data={'member': member_id, 'prize_selected_list': prize_list_str,'prize_status':False})
                                if serializer.is_valid():
                                    models.PrizeCacheLog.objects.create(**serializer.validated_data)
                                break


                if prize_enable_arr:
                    prize_enable_index_arr = [x - 1 for x in prize_enable_arr]
                    random.shuffle(prize_enable_index_arr)
                    prize_return_str = ','.join([str(x) for x in prize_enable_index_arr])
                    prize_return_str="["+prize_return_str+"];"


                else :
                    prize_enable_arr = [0]
                    prize_return_str = '[0];'

            '''














            if activity_flag:
                prize_list = models.Prize.objects.all().filter(activity_prize_flag=True).order_by('index')
            else :

                prize_list=models.Prize.objects.all().filter(activity_prize_flag=False).order_by('index')
            prize_arr=''
            num=0
            if prize_list:
                for  prize in prize_list:
                    if num==0:
                        if prize.img_url is not None and prize.img_url!='':
                            prize_arr = "{ text : '" + prize.name + "' , img: \"/static/"+prize.img_url+"\" }"
                        else:
                           prize_arr="{ text : '"+prize.name+"' }"
                    else:
                        if prize.img_url is not None and prize.img_url != '':
                            prize_arr =prize_arr+ ",{ text : '" + prize.name + "' , img: \"/static/" + prize.img_url + "\" }"
                        else:
                            prize_arr =prize_arr+ ",{ text:'" + prize.name + "' }"
                    num=num+1
            #prize_marquee
            prize_marquee=""
            prize_log_list=models.PrizeLog.objects.filter(~Q(prize__prize_type=3)).order_by('-id')[:8]
            if prize_log_list:
                for log in prize_log_list:
                    mobile_no=log.member.mobile_no
                    prize_name=log.prize.name
                    pre_mobile_no=mobile_no[:1]
                    back_mobile_no=mobile_no[-2:]
                    hide_mobile_no=pre_mobile_no+'*****'+back_mobile_no
                    prize_marquee=prize_marquee+"<li>"+hide_mobile_no +" gained "+prize_name+"</li>"
            #prize count
            prize_remain_count=''

            if activity_flag:
                prizeClassSet = models.PrizeClassSet.objects.filter(activity_flag=True).order_by('-id')

                if prizeClassSet:
                    for item in prizeClassSet:
                        # prize_class corresponding  prize list
                        prize_classset_name=item.prize_name
                        prize_classset_total=item.max_number_per_day
                        prize_classset_used=0
                        item_prize_id_list = []
                        prize_list = item.prize.all()
                        if prize_list:
                            for prize_item in prize_list:
                                item_prize_id_list.append(prize_item.id)

                        if item_prize_id_list is not None:
                            prize_id_tupple = tuple(item_prize_id_list)
                            # today prize class generated times
                            if prize_id_tupple:
                                prize_generated_count_dict = models.PrizeLog.objects.filter(created__gte=start_date,created__lte=end_date,
                                                                                            prize__id__in=prize_id_tupple).aggregate(
                                    count=Count('id'))
                                if prize_generated_count_dict:
                                    if prize_generated_count_dict['count'] is not None:
                                        prize_class_generated_number = prize_generated_count_dict['count']
                                    else:
                                        prize_class_generated_number = 0
                                    prize_classset_used=prize_class_generated_number

                        prize_remain_count=prize_remain_count+'<li>'+prize_classset_name+':'+str(prize_classset_used)+'/'+str(prize_classset_total)+'(remain/total)</li>'


            context = {}
            if activity_flag:
                context['prize_remain'] = prize_remain_count
            context['prize_marquee']=prize_marquee
            #context['prize_enable_arr'] = "[0,1];"
            context['prize_enable_arr'] = prize_return_str
            context['member_id'] = member_id
            context['chances_times'] = prize_chances
            context['prize_list']=prize_arr
            #print('session get     '+str(request.session['prize']))
            return HttpResponse(content=template.render(context), content_type='text/html; charset=utf-8', status=200)



