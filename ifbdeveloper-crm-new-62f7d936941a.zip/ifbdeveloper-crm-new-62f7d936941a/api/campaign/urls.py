from django.urls import path, include
from rest_framework.routers import DefaultRouter
from . import views






router = DefaultRouter()

router.register('campaign-type', views.CampaignTypeViewSet, base_name='campaign_type')
router.register('activity_list', views.ActivityViewSet, base_name='activity_list')
router.register('campaign-condition', views.CampaignConditionViewSet, base_name='campaign_condition')
router.register('occupation', views.OccupationViewSet, base_name='occupation')
router.register('performance-product', views.CampaignPerformanceOfProductViewSet, base_name='performance_product')
router.register('performance-outlet', views.CampaignPerformanceOfOutletViewSet, base_name='performance_outlet')
router.register('signed_electronic', views.SignedViewSet, base_name='signed_electronic')
router.register('promotion_code', views.PromotionCodeViewSet, base_name='promotion_code')
router.register('points_rewards', views.RewardsViewSet, base_name='points_rewards')
router.register('rewards_terms_conditions', views.RewardsTermsConditionsViewSet, base_name='rewards_terms_conditions')
router.register('voucher_terms_conditions', views.VoucherTermsConditionsViewSet, base_name='voucher_terms_conditions')
router.register('points_rewards_log', views.RewardsLogViewSet, base_name='points_rewards_log')
#router.register('campaign_one_redeemtion_perday', views.CampaignOneRedeemtionPerdayViewSet, base_name='campaign_one_redeemtion_perday')
#router.register('campaign_check', views.CampaignChackViewSet, base_name='campaign_check')
router.register('', views.CampaignViewSet)

urlpatterns = [
    path('deal_data/', views.deal_data, name='deal_data'),
    path('campaign_check/', views.checkCampaign, name='campaign_check'),
    path('getCampaign/', views.getCampaign, name="getCampaign"),
    path('getPromotionCampaign/', views.getPromotionCampaign, name="getPromotionCampaign"),
    path('get_activity_campaign/', views.get_activity_campaign, name="get_activity_campaign"),

    path('getLuckTimes/', views.getLuckTimes, name="getLuckTimes"),
    path('getTopupStatus/', views.getTopupStatus, name="getTopupStatus"),
    path('handle_prize/', views.handle_prize, name="handle_prize"),
    path('campaign_advertising/', views.campaign_advertising, name="campaign_advertising"),
    path('member_ship/', views.member_ship, name="member_ship"),
    path('redeem/', views.redeem, name="redeem"),
    path('', include(router.urls)),

]
