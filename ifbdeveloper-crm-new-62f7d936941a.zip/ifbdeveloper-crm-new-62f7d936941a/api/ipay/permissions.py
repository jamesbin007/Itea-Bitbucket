from rest_framework.permissions import BasePermission


class PayMerchantViewSetPermission(BasePermission):
    def has_permission(self, request, view):
        if request.method in ('POST', 'DELETE', 'PUT', 'PATCH'):

            return request.user.role.name in (1, 4)
        else:
            return True


class IpayRecordPermission(BasePermission):
    def has_permission(self, request, view):
        if request.method in ('POST', 'GET'):

            return True

        else:
            return False
