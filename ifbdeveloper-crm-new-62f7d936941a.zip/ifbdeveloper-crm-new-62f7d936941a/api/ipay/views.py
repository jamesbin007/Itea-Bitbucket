import stripe
from rest_framework import viewsets, mixins
from rest_framework.response import Response
from utils.pagination import DefaultPagination
from app01 import models
from . import serializers
from rest_framework.decorators import api_view
from django_filters.rest_framework import DjangoFilterBackend
from rest_framework.filters import SearchFilter, OrderingFilter
from utils.permissions import IsAdmin, IsApp
from .permissions import PayMerchantViewSetPermission,IpayRecordPermission
from django.db.models import Q, Sum
from rest_framework import status
from django_filters import rest_framework as filters
from django.db.models.functions import Coalesce
from rest_framework.decorators import action
from django.db import transaction
from django_filters import Filter,FilterSet
import  datetime
from rest_framework.permissions import AllowAny
from rest_framework.decorators import api_view,authentication_classes,permission_classes
from wallet.serializers import RechargeRecordCreateSerializer
from utils.message_manage import send_message_to_token,send_message_to_token_android_tablet
import time
from rest_framework import status
from member.services import update_member_points
class IntegerListFilter(Filter):
    def filter(self,qs,value):
     if value not in (None,''):
          integers = [int(v) for v in value.split(',')]
          return qs.filter(**{'%s__%s'%(self.field_name, self.lookup_expr):integers})
     return qs
class PayMerchantFilter(filters.FilterSet):
    brand = filters.CharFilter(field_name="brand", lookup_expr='exact')
    branch = filters.CharFilter(field_name="branch", lookup_expr='exact')
    token = filters.CharFilter(field_name="token", lookup_expr='exact')
    class Meta:
        model = models.PayMerchant
        fields = ('brand','branch','token', )

class IpayRecordFilter(filters.FilterSet):
    member = filters.CharFilter(field_name="member", lookup_expr='exact')
    paymerchant = filters.CharFilter(field_name="paymerchant", lookup_expr='exact')
    outlet = filters.CharFilter(field_name="outlet", lookup_expr='exact')
    created_date=filters.CharFilter(field_name="created_date", lookup_expr='exact')
    class Meta:
        model = models.IpayRecord
        fields = ('member','paymerchant','outlet','created_date', )

class PayMerchantViewSet(viewsets.ModelViewSet):
    permission_classes = (PayMerchantViewSetPermission,)
    queryset = models.PayMerchant.objects.all()
    serializer_class = serializers.PayMerchantSerializer
    pagination_class = DefaultPagination
    filter_backends = (
        DjangoFilterBackend,
        SearchFilter,
        OrderingFilter,
    )

    search_fields = ('id',)
    filter_class = PayMerchantFilter


@api_view(['GET','POST'])
@authentication_classes([])
@permission_classes((AllowAny,))
def qrcode_pay(request, *args, **kwargs):
    pass
    return Response({'msg':'ok'})

#manual topup
class IpayRecordViewSet(viewsets.ModelViewSet):
    authentication_classes=()
    permission_classes = (IpayRecordPermission,)
    queryset = models.IpayRecord.objects.all()
    serializer_class = serializers.IpayRecordSerializer
    pagination_class = DefaultPagination
    filter_backends = (
        DjangoFilterBackend,
        SearchFilter,
        OrderingFilter,
    )
    filter_class = IpayRecordFilter
    search_fields = ('created', )
    ordering_fields = ('id', )

    def create(self, request, *args, **kwargs):
        member_id=request.data.get('member_id')
        token=request.data.get('token')
        money=request.data.get('money')
        bid_amount = request.data.get('amount')

        amount=float(money)
        bid_amount=float(bid_amount)
        list={}

        if amount<0.001:
            list['error'] = 'Payment amount less 0.'
            return Response(list, status.HTTP_200_OK)
        if bid_amount<amount:
            list['error'] = 'Payment amount error.'
            return Response(list, status.HTTP_200_OK)
        if member_id:
            with transaction.atomic():
                member_obj=models.Member.objects.get(id=member_id)
                if member_obj:
                    mobile=member_obj.mobile_no
                    member_ship=member_obj.membership
                    cash_back=0
                    if member_ship:
                        cash_back = member_ship.cash_back

                    if token:
                        paymerchant=models.PayMerchant.objects.filter(token=token).first()
                        if paymerchant:
                            paymerchant_id=paymerchant.id
                            outlet_obj=paymerchant.outlet
                            #cash_back=paymerchant.cash_back

                            if outlet_obj:
                                outlet_device_token=outlet_obj.device_token
                                outlet=outlet_obj.id
                                outlet_name=outlet_obj.outlet_name
                            else:
                                outlet=None
                                outlet_name=None

                            ipay_record = {'member': member_id,'paymerchant':paymerchant_id,'amount':bid_amount, 'mobile': mobile, 'outlet': outlet,'outlet_name': outlet_name, 'money': money}
                            serializer = serializers.IpayRecordSerializer(data=ipay_record)

                            if serializer.is_valid():
                                ipay_obj = self.perform_create(serializer)

                                headers = self.get_success_headers(serializer.data)
                                # wallet rechargeRecord
                                wallet = models.Wallet.objects.get(member__id=member_id)
                                ipay_list = serializer.data

                                if wallet:
                                    if wallet.balance<float(money):
                                        list['error'] = 'Wallet balance not enough.'
                                        raise RuntimeError('Wallet balance not enough')
                                        return Response(list, status.HTTP_200_OK)
                                    wallet.balance -= float(money)
                                    wallet.save()
                                    serializer_recharge = RechargeRecordCreateSerializer(
                                        data={'money': money, 'wallet': wallet.id, 'type': 7, 'status': 0})
                                    #update member membership
                                    update_member_points(member_obj,money,1,None,None)
                                    if serializer_recharge.is_valid():
                                        models.RechargeRecord.objects.create(**serializer_recharge.validated_data)
                                    if cash_back is not None and cash_back>0.001:
                                        cash_back_amount=round(bid_amount*cash_back,2)
                                        if cash_back_amount>=0.01:
                                            wallet.balance += float(cash_back_amount)
                                            wallet.save()
                                            serializer_recharge = RechargeRecordCreateSerializer(
                                                data={'money': cash_back_amount, 'wallet': wallet.id, 'type': 3, 'status': 0})
                                            if serializer_recharge.is_valid():
                                                models.RechargeRecord.objects.create(**serializer_recharge.validated_data)
                                    list['balance'] = wallet.balance
                                if member_obj.device_token:
                                    pass
                                    #send_message_to_token(member_obj.device_token, 'iPay payment successfully','Amout: $' + str('%.2f' % float(money)))
                                #time.sleep(0.25)
                                if outlet_device_token:
                                    print(outlet_device_token)
                                    send_message_to_token_android_tablet(outlet_device_token, 'iPay payment successfully','Amout: $' + str('%.2f' % float(money)))
                                return Response(ipay_list, status.HTTP_200_OK, headers=headers)
        return Response(None,status.HTTP_500_INTERNAL_SERVER_ERROR)


@api_view(['GET', 'POST'])
@authentication_classes([])
@permission_classes((AllowAny,))
def sumIpay(request, *args, **kwargs):

    if request.method == 'GET' :
        outlet_id=request.GET.get('outlet_id')
        req_date=request.GET.get('created_date')
        bill_sum={'sum':0}
        payable_sum={'sum':0}
        today_payable_sum={'sum':0}
        today_bill_sum={'sum':0}
        print(req_date)
        if (outlet_id):

            today_payable_sum = models.IpayRecord.objects.filter(created_date=time.strftime("%Y-%m-%d",time.localtime(time.time())),outlet__id=outlet_id).aggregate(sum=Sum('money'))
            today_bill_sum = models.IpayRecord.objects.filter(created_date=time.strftime("%Y-%m-%d",time.localtime(time.time())), outlet__id=outlet_id).aggregate(
                sum=Sum('amount'))

            payable_sum = models.IpayRecord.objects.filter(outlet__id=outlet_id).aggregate(sum=Sum('money'))
            bill_sum = models.IpayRecord.objects.filter(outlet__id=outlet_id).aggregate(sum=Sum('amount'))


        #if(bill_sum and payable_sum):
            if payable_sum['sum'] is None:
                payable_sum = {}
                payable_sum['sum'] = 0
            if bill_sum['sum'] is None:
                bill_sum = {}
                bill_sum['sum'] = 0
            if today_payable_sum['sum'] is None:
                today_payable_sum = {}
                today_payable_sum['sum'] = 0
            if today_bill_sum['sum'] is None:
                today_bill_sum = {}
                today_bill_sum['sum'] = 0

        return Response({'payable_sum':round( payable_sum['sum'],2),'bill_sum':round(bill_sum['sum'],2),'today_payable_sum': round(today_payable_sum['sum'],2),'today_bill_sum':round(today_bill_sum['sum'],2)})

@api_view(['GET', 'POST'])
@authentication_classes([])
@permission_classes((AllowAny,))
def wirecard_log_update(request, *args, **kwargs):
    if request.method == 'GET' :
        request_id=request.GET.get('request_id')
        status=request.GET.get('status')
        result_val= models.WirecardLog.objects.filter(request_id=request_id).update(status=status)
        if result_val>0:
            return Response({'msg': 'ok', })
        else:
            return Response({'msg': 'error', })

