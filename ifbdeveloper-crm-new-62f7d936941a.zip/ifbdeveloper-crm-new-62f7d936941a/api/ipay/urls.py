from django.urls import path, include
from rest_framework.routers import DefaultRouter
from . import views



router = DefaultRouter()


router.register('ipay_scan_pay', views.IpayRecordViewSet, base_name='ipay_scan_pay')
router.register('', views.PayMerchantViewSet)

urlpatterns = [
    path('qrcode_pay/', views.qrcode_pay, name='qrcode_pay'),
    path('sumIpay/', views.sumIpay, name="sumIpay"),
    path('wirecard_log_update/', views.wirecard_log_update, name="wirecard_log_update"),
    path('', include(router.urls)),

]
