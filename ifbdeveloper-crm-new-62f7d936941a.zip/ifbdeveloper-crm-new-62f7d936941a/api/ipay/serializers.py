from rest_framework import serializers
from app01 import models
from utils.utils import except_validation_error



class PayMerchantSerializer(serializers.ModelSerializer):


    class Meta:
        model = models.PayMerchant
        fields = '__all__'
class IpayRecordSerializer(serializers.ModelSerializer):

    class Meta:
        model = models.IpayRecord
        fields = "__all__"



