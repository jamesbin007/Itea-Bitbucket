import stripe
from rest_framework import viewsets, mixins
from rest_framework.response import Response
from utils.pagination import DefaultPagination
from app01 import models
#from . import serializers
from rest_framework.decorators import api_view,authentication_classes,permission_classes
from rest_framework.permissions import AllowAny
from django_filters.rest_framework import DjangoFilterBackend
from rest_framework.filters import SearchFilter, OrderingFilter
from utils.permissions import IsAdmin, IsApp
from .permissions import CardViewSetPermission
from django.db.models import Q, Sum
from rest_framework import status
from django_filters import rest_framework as filters
from django.db.models.functions import Coalesce
from rest_framework.decorators import action
from . import utils
import json
import urllib.parse
import requests
from django.http import HttpResponse
from utils.message_manage import send_message_to_token
import time
from wallet.serializers import RechargeRecordCreateSerializer
import datetime
from invicode.serializers import generate_random_str
from member.services import update_member_points,deal_electric_sign
from django.db.models import Q,Sum,Count
from transaction.utils import thread_send_mail,send_mooncake_payment

import urllib.parse
import urllib.request

class CardViewSet(viewsets.ModelViewSet):
    permission_classes = (CardViewSetPermission,)
    queryset = models.Card.objects.all()
    #serializer_class = serializers.CardSerializer
    pagination_class = DefaultPagination
    filter_backends = (
        DjangoFilterBackend,
        SearchFilter,
        OrderingFilter,
    )
    filter_fields = ('card_no', 'member')
    search_fields = ('card_no', 'member')
    ordering_fields = ('card_no', 'member')

    def get_queryset(self):
        ret = super(CardViewSet, self).get_queryset()
        if self.request.user.role.name in (0, 1):
            return ret
        else:
            return ret.filter(member=self.request.user)


@api_view(['POST'])
def check(request, *args, **kwargs):
    stripe.api_key = "sk_test_w7fCOG7fBrG7WPc4OujYDsHj"
    amount = request.data.get('amount')
    source = request.data.get('source')
    charge = stripe.Charge.create(
        amount=amount,
        currency='sgd',
        source=source,
        receipt_email='admin@itea.sg',
    )
    return Response(charge)
@api_view(['GET'])
def wirecard_status(request, *args, **kwargs):
    w_status=models.Wirecard_Status.objects.first()
    if w_status:
        status=w_status.w_status
    else:
        status=False

    return Response({'w_status':status})

@api_view(['POST'])
def session(request, *args, **kwargs):
    #master_card = utils.MasterCard('TEST168900001330', '44eb5f5f0e64ac2a12b1c8bf7c3eab53', 'ASIA_PACIFIC', '62')
    #master_card=utils.MasterCard('TEST168900001330','7563c4fd2a10330755a3581e2c705d85','ASIA_PACIFIC','62')
    master_card=utils.MasterCard('168900000379','7563c4fd2a10330755a3581e2c705d85','ASIA_PACIFIC','62')
    '''
    base_url=master_card.getApiUrl()
    header=master_card.buildHeader()
    json_pay_load=master_card.getJsonPayload(request)
    page_url=master_card.buildPageUrl(request)
    '''
    body = master_card.getJsonPayload(request)
    session_response=master_card.requestSession(request)
    rep_string = json.dumps(session_response)
    #models.Userip.objects.create(ip=rep_string, request=body, count=1)

    return Response(session_response)
@api_view(['POST'])
def token(request, *args, **kwargs):
    #master_card = utils.MasterCard('TEST168900001330', '44eb5f5f0e64ac2a12b1c8bf7c3eab53', 'ASIA_PACIFIC', '62')
    #master_card = utils.MasterCard('TEST168900001330', '7563c4fd2a10330755a3581e2c705d85', 'ASIA_PACIFIC', '62')
    master_card=utils.MasterCard('168900000379','7563c4fd2a10330755a3581e2c705d85','ASIA_PACIFIC','62')
    '''
    base_url=master_card.getApiUrl()
    header=master_card.buildHeader()
    json_pay_load=master_card.getJsonPayload(request)
    page_url=master_card.buildPageUrl(request)
    '''
    session_response=master_card.requestToken(request)


    return Response(session_response)
@api_view(['PUT'])
def transaction(request, *args, **kwargs):
    from django.db import transaction
    #master_card = utils.MasterCard('TEST168900001330', '44eb5f5f0e64ac2a12b1c8bf7c3eab53', 'ASIA_PACIFIC', '62')
    #master_card = utils.MasterCard('TEST168900001330', '7563c4fd2a10330755a3581e2c705d85', 'ASIA_PACIFIC', '62')
    master_card=utils.MasterCard('168900000379','7563c4fd2a10330755a3581e2c705d85','ASIA_PACIFIC','62')
    '''
    base_url=master_card.getApiUrl()
    header=master_card.buildHeader()
    json_pay_load=master_card.getJsonPayload(request)
    page_url=master_card.buildPageUrl(request)
    '''
    order_id=request.query_params.get('order')
    transaction_id = request.query_params.get('transaction')
    member_id = request.query_params.get('member_id')
    status='1'
    order_prefix=order_id[0:1]
    if order_id is None :
        return Response({'msg':'Missing required query param order'})
    if transaction_id is None:
        return Response({'msg':'Missing required query param transaction'})


    transaction_response=master_card.requestTransaction(order_id,transaction_id,request)
    #response_json=json.loads(transaction_response.text)
    if 'gatewayResponse' in transaction_response.keys():
        response_json = transaction_response['gatewayResponse']

        if 'result' in response_json.keys():
            result = response_json['result']
            if result=='SUCCESS':
                #top up
                if order_prefix=='t':
                    if 'order' in response_json.keys():
                        order_dict=response_json['order']
                        if 'amount' in order_dict.keys():
                            amount = (str(order_dict['amount'])).strip()
                            transactionObj = models.Wallet.objects.get(member__id=member_id)
                            if (transactionObj):

                                with transaction.atomic():
                                    if (status == '1'):


                                        # recharge campaign
                                        campaign_return_cash = 0
                                        campaignTopup = models.CampaignTopup.objects.first()
                                        member = models.Member.objects.get(id=member_id)

                                        if member.device_token:
                                            send_message_to_token(member.device_token, 'Top up successfully',
                                                                  'Amout: $' + str(amount))
                                        if member:
                                            topup_10_times = 0 if member.topup_10_times is None else member.topup_10_times
                                            topup_20_times = 0 if member.topup_20_times is None else member.topup_20_times
                                            topup_50_times = 0 if member.topup_50_times is None else member.topup_50_times
                                        if campaignTopup:

                                            activity_flag = campaignTopup.activity_flag
                                            date_limit_flag = campaignTopup.date_limit_flag
                                            times_limit_flag = campaignTopup.times_limit_flag
                                            if activity_flag:
                                                if times_limit_flag:
                                                    if date_limit_flag:
                                                        pass

                                                    else:
                                                        if campaignTopup.topup_10_limit_times > topup_10_times and str(amount)[
                                                                                                                   0:2] == '10':
                                                            campaign_return_cash = campaignTopup.topup_10_return_cash
                                                        if campaignTopup.topup_20_limit_times > topup_20_times and str(amount)[
                                                                                                                   0:2] == '20':
                                                            campaign_return_cash = campaignTopup.topup_20_return_cash
                                                        if campaignTopup.topup_50_limit_times > topup_50_times and str(amount)[
                                                                                                                   0:2] == '50':
                                                            campaign_return_cash = campaignTopup.topup_50_return_cash

                                                else:
                                                    if date_limit_flag:
                                                        pass

                                                    else:
                                                        if str(amount)[0:2] == '10':
                                                            campaign_return_cash = campaignTopup.topup_10_return_cash
                                                        if str(amount)[0:2] == '20':
                                                            campaign_return_cash = campaignTopup.topup_20_return_cash
                                                        if str(amount)[0:2] == '50':
                                                            campaign_return_cash = campaignTopup.topup_50_return_cash

                                        transactionObj.balance += float(amount) + campaign_return_cash
                                        transactionObj.lastest_top_up = time.strftime("%Y-%m-%d", time.localtime())
                                        transactionObj.save()
                                        serializer = RechargeRecordCreateSerializer(
                                            data={'money': amount, 'wallet': transactionObj.id, 'type': 0, 'request_id': order_id,
                                                  'status': status})
                                        if serializer.is_valid():
                                            instance = models.RechargeRecord.objects.create(**serializer.validated_data)
                                        if campaign_return_cash:
                                            serializer = RechargeRecordCreateSerializer(
                                                data={'money': campaign_return_cash, 'wallet': transactionObj.id, 'type': 3,
                                                      'request_id': order_id,
                                                      'status': status})
                                            if serializer.is_valid():
                                                instance = models.RechargeRecord.objects.create(**serializer.validated_data)
                                            if member.device_token:
                                                send_message_to_token(member.device_token, 'Top up reward',
                                                                      'Amout: $' + str(campaign_return_cash))
                                            # service.recharge(instance)
                                        # memeber add topup times

                                        if member:
                                            if str(amount)[0:2] == '10':
                                                if member.topup_10_times:
                                                    member.topup_10_times = member.topup_10_times + 1
                                                else:
                                                    member.topup_10_times = 1
                                            elif str(amount)[0:2] == '20':
                                                if member.topup_20_times:
                                                    member.topup_20_times = member.topup_20_times + 1
                                                else:
                                                    member.topup_20_times = 1
                                            else:
                                                if member.topup_50_times:
                                                    member.topup_50_times = member.topup_50_times + 1
                                                else:
                                                    member.topup_50_times = 1
                                            member.save()

                #order payment
                else:
                    now = datetime.datetime.now()
                    if 'order' in response_json.keys():
                        order_dict=response_json['order']
                        if 'amount' in order_dict.keys():
                            amount = order_dict['amount']
                    # mutiple transaction id
                    trans_arr = transaction_id.split('_')
                    if trans_arr and len(trans_arr) > 0:
                        transaction_id = trans_arr[0]
                    transactionObj = models.Transaction.objects.get(id=transaction_id)
                    if (transactionObj):

                        if (transactionObj.transaction_status == 0):

                            with transaction.atomic():

                                # coupon set transaction status=5 directly
                                temp_transaction_status = 2
                                has_voucher = False
                                has_other = False
                                invicode_num = 0
                                transDetailsList = models.TransactDetails.objects.filter(transaction__id=transactionObj.id)
                                if transDetailsList:
                                    for details in transDetailsList:
                                        temp_product = details.product
                                        quantity = details.quantity
                                        invicode_num = invicode_num + quantity
                                        if temp_product:
                                            voucher = temp_product.voucher
                                            if voucher:
                                                temp_transaction_status = 5
                                                voucher_expire_date = voucher.expiring_date
                                                has_voucher = True

                                                invicode_register_date = datetime.datetime.now().date()
                                                interval = voucher_expire_date - invicode_register_date
                                                valid_days = interval.days
                                                for i in range(0, quantity):
                                                    models.Invicode.objects.create(
                                                        **{'voucher': voucher, 'code': generate_random_str(), 'status': 1,
                                                           'member': transactionObj.member,
                                                           'register_date': datetime.datetime.now(),
                                                           'vaild_days': valid_days,
                                                           'expire_date': voucher_expire_date})
                                            else:
                                                has_other = True
                                if has_other:
                                    temp_transaction_status = 2
                                # coupon set transaction status=5 directly

                                transactionObj.payment_datetime = time.strftime("%Y-%m-%d %H:%M:%S", time.localtime())
                                # transactionObj.transact_datetime = time.strftime("%Y-%m-%d %H:%M:%S", time.localtime())
                                transactionObj.payment_modes = 9
                                transactionObj.transaction_status = temp_transaction_status
                                # if transactionObj.delay_time:
                                #   print('ok')
                                #  delay_time = getDelay_time(transactionObj)
                                # transactionObj.delay_time = delay_time
                                # else:
                                '''
                                if (transactionObj.pick_up_time == 0):
                                    transactionObj.delay_time = now + datetime.timedelta(minutes=5)
                                    # print(now + datetime.timedelta(minutes=5))
                                elif (transactionObj.pick_up_time == 1):
                                    transactionObj.delay_time = now + datetime.timedelta(minutes=15)
                                elif (transactionObj.pick_up_time == 2):
                                    transactionObj.delay_time = now + datetime.timedelta(minutes=30)
                                elif (transactionObj.pick_up_time == 3):
                                    transactionObj.delay_time = now + datetime.timedelta(minutes=45)
                                elif (transactionObj.pick_up_time == 4):
                                    transactionObj.delay_time = now + datetime.timedelta(minutes=60)
                                    '''
                                if transactionObj.delay_time:
                                    delay_time = transactionObj.delay_time
                                    delay_time = delay_time + datetime.timedelta(hours=8)
                                    if delay_time.replace(tzinfo=None) < now:
                                        transactionObj.delay_time = now + datetime.timedelta(minutes=5)
                                else:
                                    transactionObj.delay_time = now + datetime.timedelta(minutes=5)
                                # delay_time = getDelay_time(transactionObj)
                                # transactionObj.delay_time = delay_time

                                transactionObj.save()
                                # modify invicode status
                                if transactionObj.redeem_invicode is not None and transactionObj.redeem_invicode != 0:
                                    invicodeObj = models.Invicode.objects.get(id=transactionObj.redeem_invicode)
                                    if (invicodeObj):
                                        invicodeObj.status = 2
                                        invicodeObj.redeem_date = time.strftime("%Y-%m-%d %H:%M:%S", time.localtime())
                                        invicodeObj.save()
                                # update member last purchase datetime
                                member_id = transactionObj.member.id
                                member = models.Member.objects.get(id=member_id)
                                member.last_purchase_date = time.strftime("%Y-%m-%d", time.localtime())
                                # purchase coupon voucher to direct collected,update member points
                                if has_voucher:
                                    update_member_points(member, transactionObj.total_money, 1, None, None)
                                    if invicode_num > 0:
                                        if voucher:
                                            invicode_amount = models.Invicode.objects.filter(voucher__id=voucher.id,
                                                                                             register_date__date=datetime.datetime.now().date()).aggregate(
                                                count=Count('id'))
                                            if invicode_amount:
                                                invicodeTable = "<h4 style='text-align:center'  >Mooncake voucher purchase</h4><table border='1' cellspacing='0' style='text-align:center' ><tr><td colspan='5'  style='text-align:left' >order no:" + transactionObj.order_no + "</td></tr><tr><td>member mobile</td><td>register time</td><td>quantity</td><td>today sum</td><td>payment time </td></tr><tr>" + \
                                                                "<td>" + member.mobile_no + "</td><td>" + datetime.datetime.strftime(
                                                    member.registration_date, "%Y-%m-%d %H:%M:%S") + "</td><td>" + str(
                                                    invicode_num) + "</td>" + str(
                                                    invicode_amount['count']) + "<td>" + datetime.datetime.strftime(now,
                                                                                                                    "%Y-%m-%d %H:%M:%S") + "</td></tr></table></br></br>"
                                                thread_send_mail(invicodeTable, "VoucherPurchase")

                                wallet = models.Wallet.objects.get(member__id=member_id)
                                # member cash back
                                # member_payment_cashback(transactionObj, member, wallet, amount,5)

                                # return cash 10% to wallet campaign(every payment cash back) start
                                '''
                                campaign_Wallet = models.Campaign_Wallet.objects.first()
                                if campaign_Wallet and campaign_Wallet.activity_status:
    
                                    if campaign_Wallet.purchase_return_wallet_percent:
                                        campgign_result = float(amount) * campaign_Wallet.purchase_return_wallet_percent
                                '''
                                # return cash 10% to wallet campaign(every payment cash back) end
                                # new cashback from member membership start #
                                if member:
                                    member_ship = member.membership
                                    if member_ship:
                                        cashback_percent = member_ship.cash_back
                                        campgign_result = float(amount) * cashback_percent
                                        # new cashback from member membership end #
                                        campaign_result_str = '%.2f' % campgign_result
                                        campaign_return_money = float(campaign_result_str)
                                        # campaign_return=round(float(amount)*campaign_Wallet.purchase_return_wallet_percent,2)
                                        if (campaign_return_money > 0):
                                            # wallet = models.Wallet.objects.get(member__id=member_id)
                                            if wallet:
                                                # purchase record
                                                serializer = RechargeRecordCreateSerializer(
                                                    data={'money': amount, 'wallet': wallet.id, 'type': 5})
                                                if serializer.is_valid():
                                                    models.RechargeRecord.objects.create(**serializer.validated_data)

                                                outlet = transactionObj.outlet
                                                if outlet:
                                                    if outlet.has_cashback:
                                                        wallet.balance += campaign_return_money
                                                        wallet.save()
                                                        serializer = RechargeRecordCreateSerializer(
                                                            data={'money': float(campaign_return_money),
                                                                  'wallet': wallet.id, 'type': 3,

                                                                  'status': 1})
                                                        if serializer.is_valid():
                                                            instance = models.RechargeRecord.objects.create(
                                                                **serializer.validated_data)
                                                        # add campaign return cash to transaction record
                                                        if transactionObj.campaign_return_wallet_cash:
                                                            transactionObj.campaign_return_wallet_cash += campaign_return_money
                                                        else:
                                                            transactionObj.campaign_return_wallet_cash = campaign_return_money
                                                        transactionObj.save()

                                # purchase campaign return cash to wallet
                                '''
                                purchase_return_wallet_amount=campaign_return(member,amount)
                                if purchase_return_wallet_amount >0:
                                    wallet=models.Wallet.objects.get(member__id=member_id)
                                    if wallet:
    
                                        wallet.balance +=purchase_return_wallet_amount
                                        wallet.save()
                                        serializer = RechargeRecordCreateSerializer(
                                            data={'money': float(purchase_return_wallet_amount), 'wallet': wallet.id, 'type': 3,
    
                                                  'status': 1})
                                        if serializer.is_valid():
                                            instance = models.RechargeRecord.objects.create(**serializer.validated_data)
                                        # add campaign return cash to transaction record
                                        if transactionObj.campaign_return_wallet_cash:
                                            transactionObj.campaign_return_wallet_cash += purchase_return_wallet_amount
                                        else:
                                            transactionObj.campaign_return_wallet_cash = purchase_return_wallet_amount
                                        transactionObj.save()
                                if member:
    
                                        if member.non_wallet_pay_times:
                                            member.non_wallet_pay_times = member.non_wallet_pay_times + 1
                                        else:
                                            member.non_wallet_pay_times = 1
                                        member.save()
                                '''

                                '''
                                countTable = "<h4 style='text-align:center'  >Mobile ordering payment</h4><table border='1' cellspacing='0' style='text-align:center' ><tr><td colspan='5'  style='text-align:left' >order no:" + transactionObj.order_no + "</td></tr><tr><td>member mobile</td><td>outlet</td><td>amount</td><td>payment method</td><td>payment time </td></tr><tr>" + \
                                             "<td>" + member.mobile_no + "</td><td>" + transactionObj.outlet.outlet_name + "</td><td>" + str(
                                    transactionObj.total_money) + "</td><td>" + \
                                             "wirecard pay" + "</td><td>" + time.strftime("%Y-%m-%d %H:%M:%S",time.localtime()) + "</td></tr></table>"
                                  '''
                                # countTable = get_payment_mail_table(transactionObj, member, wallet.id, 'Wirecard')
                                # utils.send_register_email(utils.RECEIVE_MAIL, countTable, send_type="payment", promotion='')
                                # thread_send_mail(countTable, "payment")

                                send_mooncake_payment(transactionObj)
                #pass

    print(response_json)
    return Response(transaction_response)


@api_view(['PUT'])
def payment(request, *args, **kwargs):
    from django.db import transaction
    #master_card = utils.MasterCard('TEST168900001330', '44eb5f5f0e64ac2a12b1c8bf7c3eab53', 'ASIA_PACIFIC', '62')
    # master_card = utils.MasterCard('TEST168900001330', '7563c4fd2a10330755a3581e2c705d85', 'ASIA_PACIFIC', '62')
    master_card=utils.MasterCard('168900000379','7563c4fd2a10330755a3581e2c705d85','ASIA_PACIFIC','62')
    '''
    base_url=master_card.getApiUrl()
    header=master_card.buildHeader()
    json_pay_load=master_card.getJsonPayload(request)
    page_url=master_card.buildPageUrl(request)
    '''
    order_id = request.query_params.get('order')
    transaction_id = request.query_params.get('transaction')
    member_id = request.query_params.get('member_id')
    status = '1'
    order_prefix = order_id[0:1]
    if order_id is None:
        return Response({'msg': 'Missing required query param order'})
    if transaction_id is None:
        return Response({'msg': 'Missing required query param transaction'})

    transaction_response = master_card.requestTransaction(order_id, transaction_id, request)
    # response_json=json.loads(transaction_response.text)
    if 'gatewayResponse' in transaction_response.keys():
        response_json = transaction_response['gatewayResponse']

        if 'result' in response_json.keys():
            result = response_json['result']
            if result == 'SUCCESS':
                # top up
                if order_prefix == 't':
                    if 'order' in response_json.keys():
                        order_dict = response_json['order']
                        if 'amount' in order_dict.keys():
                            amount = (str(order_dict['amount'])).strip()
                            transactionObj = models.Wallet.objects.get(member__id=member_id)
                            if (transactionObj):

                                with transaction.atomic():
                                    if (status == '1'):

                                        # recharge campaign
                                        campaign_return_cash = 0
                                        campaignTopup = models.CampaignTopup.objects.first()
                                        member = models.Member.objects.get(id=member_id)

                                        if member.device_token:
                                            send_message_to_token(member.device_token, 'Top up successfully',
                                                                  'Amout: $' + str(amount))
                                        if member:
                                            topup_10_times = 0 if member.topup_10_times is None else member.topup_10_times
                                            topup_20_times = 0 if member.topup_20_times is None else member.topup_20_times
                                            topup_50_times = 0 if member.topup_50_times is None else member.topup_50_times
                                        if campaignTopup:

                                            activity_flag = campaignTopup.activity_flag
                                            date_limit_flag = campaignTopup.date_limit_flag
                                            times_limit_flag = campaignTopup.times_limit_flag
                                            if activity_flag:
                                                if times_limit_flag:
                                                    if date_limit_flag:
                                                        pass

                                                    else:
                                                        if campaignTopup.topup_10_limit_times > topup_10_times and str(
                                                                amount)[
                                                                                                                   0:2] == '10':
                                                            campaign_return_cash = campaignTopup.topup_10_return_cash
                                                        if campaignTopup.topup_20_limit_times > topup_20_times and str(
                                                                amount)[
                                                                                                                   0:2] == '20':
                                                            campaign_return_cash = campaignTopup.topup_20_return_cash
                                                        if campaignTopup.topup_50_limit_times > topup_50_times and str(
                                                                amount)[
                                                                                                                   0:2] == '50':
                                                            campaign_return_cash = campaignTopup.topup_50_return_cash

                                                else:
                                                    if date_limit_flag:
                                                        pass

                                                    else:
                                                        if str(amount)[0:2] == '10':
                                                            campaign_return_cash = campaignTopup.topup_10_return_cash
                                                        if str(amount)[0:2] == '20':
                                                            campaign_return_cash = campaignTopup.topup_20_return_cash
                                                        if str(amount)[0:2] == '50':
                                                            campaign_return_cash = campaignTopup.topup_50_return_cash

                                        transactionObj.balance += float(amount) + campaign_return_cash
                                        transactionObj.lastest_top_up = time.strftime("%Y-%m-%d", time.localtime())
                                        transactionObj.save()
                                        serializer = RechargeRecordCreateSerializer(
                                            data={'money': amount, 'wallet': transactionObj.id, 'type': 0,
                                                  'request_id': order_id,
                                                  'status': status})
                                        if serializer.is_valid():
                                            instance = models.RechargeRecord.objects.create(**serializer.validated_data)
                                        if campaign_return_cash:
                                            serializer = RechargeRecordCreateSerializer(
                                                data={'money': campaign_return_cash, 'wallet': transactionObj.id,
                                                      'type': 3,
                                                      'request_id': order_id,
                                                      'status': status})
                                            if serializer.is_valid():
                                                instance = models.RechargeRecord.objects.create(
                                                    **serializer.validated_data)
                                            if member.device_token:
                                                send_message_to_token(member.device_token, 'Top up reward',
                                                                      'Amout: $' + str(campaign_return_cash))
                                            # service.recharge(instance)
                                        # memeber add topup times

                                        if member:
                                            if str(amount)[0:2] == '10':
                                                if member.topup_10_times:
                                                    member.topup_10_times = member.topup_10_times + 1
                                                else:
                                                    member.topup_10_times = 1
                                            elif str(amount)[0:2] == '20':
                                                if member.topup_20_times:
                                                    member.topup_20_times = member.topup_20_times + 1
                                                else:
                                                    member.topup_20_times = 1
                                            else:
                                                if member.topup_50_times:
                                                    member.topup_50_times = member.topup_50_times + 1
                                                else:
                                                    member.topup_50_times = 1
                                            member.save()

                # order payment
                else:
                    now = datetime.datetime.now()
                    if 'order' in response_json.keys():
                        order_dict = response_json['order']
                        if 'amount' in order_dict.keys():
                            amount = order_dict['amount']
                    # mutiple transaction id
                    trans_arr = transaction_id.split('_')
                    if trans_arr and len(trans_arr) > 0:
                        transaction_id = trans_arr[0]
                    transactionObj = models.Transaction.objects.get(id=transaction_id)
                    if (transactionObj):

                        if (transactionObj.transaction_status == 0):

                            with transaction.atomic():

                                # coupon set transaction status=5 directly
                                temp_transaction_status = 2
                                has_voucher = False
                                has_other = False
                                invicode_num = 0
                                transDetailsList = models.TransactDetails.objects.filter(
                                    transaction__id=transactionObj.id)
                                if transDetailsList:
                                    for details in transDetailsList:
                                        temp_product = details.product
                                        quantity = details.quantity
                                        invicode_num = invicode_num + quantity
                                        if temp_product:
                                            voucher = temp_product.voucher
                                            if voucher:
                                                temp_transaction_status = 5
                                                voucher_expire_date = voucher.expiring_date
                                                has_voucher = True

                                                invicode_register_date = datetime.datetime.now().date()
                                                interval = voucher_expire_date - invicode_register_date
                                                valid_days = interval.days
                                                for i in range(0, quantity):
                                                    models.Invicode.objects.create(
                                                        **{'voucher': voucher, 'code': generate_random_str(),
                                                           'status': 1,
                                                           'member': transactionObj.member,
                                                           'register_date': datetime.datetime.now(),
                                                           'vaild_days': valid_days,
                                                           'expire_date': voucher_expire_date})
                                            else:
                                                has_other = True
                                if has_other:
                                    temp_transaction_status = 2
                                # coupon set transaction status=5 directly

                                transactionObj.payment_datetime = time.strftime("%Y-%m-%d %H:%M:%S", time.localtime())
                                # transactionObj.transact_datetime = time.strftime("%Y-%m-%d %H:%M:%S", time.localtime())
                                transactionObj.payment_modes = 9
                                transactionObj.transaction_status = temp_transaction_status
                                # if transactionObj.delay_time:
                                #   print('ok')
                                #  delay_time = getDelay_time(transactionObj)
                                # transactionObj.delay_time = delay_time
                                # else:
                                '''
                                if (transactionObj.pick_up_time == 0):
                                    transactionObj.delay_time = now + datetime.timedelta(minutes=5)
                                    # print(now + datetime.timedelta(minutes=5))
                                elif (transactionObj.pick_up_time == 1):
                                    transactionObj.delay_time = now + datetime.timedelta(minutes=15)
                                elif (transactionObj.pick_up_time == 2):
                                    transactionObj.delay_time = now + datetime.timedelta(minutes=30)
                                elif (transactionObj.pick_up_time == 3):
                                    transactionObj.delay_time = now + datetime.timedelta(minutes=45)
                                elif (transactionObj.pick_up_time == 4):
                                    transactionObj.delay_time = now + datetime.timedelta(minutes=60)
                                    '''
                                if transactionObj.delay_time:
                                    delay_time = transactionObj.delay_time
                                    delay_time = delay_time + datetime.timedelta(hours=8)
                                    if delay_time.replace(tzinfo=None) < now:
                                        transactionObj.delay_time = now + datetime.timedelta(minutes=5)
                                else:
                                    transactionObj.delay_time = now + datetime.timedelta(minutes=5)
                                # delay_time = getDelay_time(transactionObj)
                                # transactionObj.delay_time = delay_time

                                transactionObj.save()
                                # modify invicode status
                                if transactionObj.redeem_invicode is not None and transactionObj.redeem_invicode != 0:
                                    invicodeObj = models.Invicode.objects.get(id=transactionObj.redeem_invicode)
                                    if (invicodeObj):
                                        invicodeObj.status = 2
                                        invicodeObj.redeem_date = time.strftime("%Y-%m-%d %H:%M:%S", time.localtime())
                                        invicodeObj.save()
                                # update member last purchase datetime
                                member_id = transactionObj.member.id
                                member = models.Member.objects.get(id=member_id)
                                member.last_purchase_date = time.strftime("%Y-%m-%d", time.localtime())
                                # purchase coupon voucher to direct collected,update member points
                                if has_voucher:
                                    update_member_points(member, transactionObj.total_money, 1, None, None)
                                    if invicode_num > 0:
                                        if voucher:
                                            invicode_amount = models.Invicode.objects.filter(voucher__id=voucher.id,
                                                                                             register_date__date=datetime.datetime.now().date()).aggregate(
                                                count=Count('id'))
                                            if invicode_amount:
                                                invicodeTable = "<h4 style='text-align:center'  >Mooncake voucher purchase</h4><table border='1' cellspacing='0' style='text-align:center' ><tr><td colspan='5'  style='text-align:left' >order no:" + transactionObj.order_no + "</td></tr><tr><td>member mobile</td><td>register time</td><td>quantity</td><td>today sum</td><td>payment time </td></tr><tr>" + \
                                                                "<td>" + member.mobile_no + "</td><td>" + datetime.datetime.strftime(
                                                    member.registration_date, "%Y-%m-%d %H:%M:%S") + "</td><td>" + str(
                                                    invicode_num) + "</td>" + str(
                                                    invicode_amount['count']) + "<td>" + datetime.datetime.strftime(now,
                                                                                                                    "%Y-%m-%d %H:%M:%S") + "</td></tr></table></br></br>"
                                                thread_send_mail(invicodeTable, "VoucherPurchase")

                                wallet = models.Wallet.objects.get(member__id=member_id)
                                # member cash back
                                # member_payment_cashback(transactionObj, member, wallet, amount,5)

                                # return cash 10% to wallet campaign(every payment cash back) start
                                '''
                                campaign_Wallet = models.Campaign_Wallet.objects.first()
                                if campaign_Wallet and campaign_Wallet.activity_status:

                                    if campaign_Wallet.purchase_return_wallet_percent:
                                        campgign_result = float(amount) * campaign_Wallet.purchase_return_wallet_percent
                                '''
                                # return cash 10% to wallet campaign(every payment cash back) end
                                # new cashback from member membership start #
                                if member:
                                    member_ship = member.membership
                                    if member_ship:
                                        cashback_percent = member_ship.cash_back
                                        campgign_result = float(amount) * cashback_percent
                                        # new cashback from member membership end #
                                        campaign_result_str = '%.2f' % campgign_result
                                        campaign_return_money = float(campaign_result_str)
                                        # campaign_return=round(float(amount)*campaign_Wallet.purchase_return_wallet_percent,2)
                                        if (campaign_return_money > 0):
                                            # wallet = models.Wallet.objects.get(member__id=member_id)
                                            if wallet:
                                                # purchase record
                                                serializer = RechargeRecordCreateSerializer(
                                                    data={'money': amount, 'wallet': wallet.id, 'type': 5})
                                                if serializer.is_valid():
                                                    models.RechargeRecord.objects.create(**serializer.validated_data)

                                                outlet = transactionObj.outlet
                                                if outlet:
                                                    if outlet.has_cashback:
                                                        wallet.balance += campaign_return_money
                                                        wallet.save()
                                                        serializer = RechargeRecordCreateSerializer(
                                                            data={'money': float(campaign_return_money),
                                                                  'wallet': wallet.id, 'type': 3,

                                                                  'status': 1})
                                                        if serializer.is_valid():
                                                            instance = models.RechargeRecord.objects.create(
                                                                **serializer.validated_data)
                                                        # add campaign return cash to transaction record
                                                        if transactionObj.campaign_return_wallet_cash:
                                                            transactionObj.campaign_return_wallet_cash += campaign_return_money
                                                        else:
                                                            transactionObj.campaign_return_wallet_cash = campaign_return_money
                                                        transactionObj.save()

                                # purchase campaign return cash to wallet
                                '''
                                purchase_return_wallet_amount=campaign_return(member,amount)
                                if purchase_return_wallet_amount >0:
                                    wallet=models.Wallet.objects.get(member__id=member_id)
                                    if wallet:

                                        wallet.balance +=purchase_return_wallet_amount
                                        wallet.save()
                                        serializer = RechargeRecordCreateSerializer(
                                            data={'money': float(purchase_return_wallet_amount), 'wallet': wallet.id, 'type': 3,

                                                  'status': 1})
                                        if serializer.is_valid():
                                            instance = models.RechargeRecord.objects.create(**serializer.validated_data)
                                        # add campaign return cash to transaction record
                                        if transactionObj.campaign_return_wallet_cash:
                                            transactionObj.campaign_return_wallet_cash += purchase_return_wallet_amount
                                        else:
                                            transactionObj.campaign_return_wallet_cash = purchase_return_wallet_amount
                                        transactionObj.save()
                                if member:

                                        if member.non_wallet_pay_times:
                                            member.non_wallet_pay_times = member.non_wallet_pay_times + 1
                                        else:
                                            member.non_wallet_pay_times = 1
                                        member.save()
                                '''

                                '''
                                countTable = "<h4 style='text-align:center'  >Mobile ordering payment</h4><table border='1' cellspacing='0' style='text-align:center' ><tr><td colspan='5'  style='text-align:left' >order no:" + transactionObj.order_no + "</td></tr><tr><td>member mobile</td><td>outlet</td><td>amount</td><td>payment method</td><td>payment time </td></tr><tr>" + \
                                             "<td>" + member.mobile_no + "</td><td>" + transactionObj.outlet.outlet_name + "</td><td>" + str(
                                    transactionObj.total_money) + "</td><td>" + \
                                             "wirecard pay" + "</td><td>" + time.strftime("%Y-%m-%d %H:%M:%S",time.localtime()) + "</td></tr></table>"
                                  '''
                                # countTable = get_payment_mail_table(transactionObj, member, wallet.id, 'Wirecard')
                                # utils.send_register_email(utils.RECEIVE_MAIL, countTable, send_type="payment", promotion='')
                                # thread_send_mail(countTable, "payment")

                                send_mooncake_payment(transactionObj)
                # pass

    print(response_json)
    return Response(transaction_response)
@api_view(['POST','PUT'])
def three_d_secure(request, *args, **kwargs):
    #master_card = utils.MasterCard('TEST168900001330', '44eb5f5f0e64ac2a12b1c8bf7c3eab53', 'ASIA_PACIFIC', '62')
    #master_card = utils.MasterCard('TEST168900001330', '7563c4fd2a10330755a3581e2c705d85', 'ASIA_PACIFIC', '62')
    master_card=utils.MasterCard('168900000379','7563c4fd2a10330755a3581e2c705d85','ASIA_PACIFIC','62')
    '''
    base_url=master_card.getApiUrl()
    header=master_card.buildHeader()
    json_pay_load=master_card.getJsonPayload(request)
    page_url=master_card.buildPageUrl(request)
    '''
    three_d_secure_id=request.query_params.get('3DSecureId')
    print(three_d_secure_id)
    if three_d_secure_id is None :
        return Response({'msg':'Missing required query param 3DSecureId'})
    path='/3DSecureId/'+three_d_secure_id
    print(path)
    header = master_card.buildHeader()
    body = master_card.getJsonPayload(request)
    print(body)

    #time.sleep(2)
    result = master_card.callApi(request.META['REQUEST_METHOD'] , path, header, body)

    rep_string = json.dumps(result)
    models.Userip.objects.create(ip=rep_string,request=body, count=0)
    return Response(result)




@api_view(['POST',])
@authentication_classes([])
@permission_classes((AllowAny,))
def three_d_secure_result(request, *args, **kwargs):
    #master_card = utils.MasterCard('TEST168900001330', '44eb5f5f0e64ac2a12b1c8bf7c3eab53', 'ASIA_PACIFIC', '62')
    #master_card=utils.MasterCard('TEST168900001330','7563c4fd2a10330755a3581e2c705d85','ASIA_PACIFIC','62')
    master_card = utils.MasterCard('168900000379', '7563c4fd2a10330755a3581e2c705d85', 'ASIA_PACIFIC', '62')
    '''
    base_url=master_card.getApiUrl()
    header=master_card.buildHeader()
    json_pay_load=master_card.getJsonPayload(request)
    page_url=master_card.buildPageUrl(request)
    '''
    three_d_secure_id=request.query_params.get('3DSecureId')

    if three_d_secure_id is None :
        return Response({'msg':'Missing required query param 3DSecureId'})

    post_data=dict_change_key_case(request.data,0)
    paResParam='pares'
    print(post_data)
    if paResParam in post_data and post_data[paResParam] is not None:
        pass
    else:
        return Response({'msg': 'Missing required issuer response information'})

    data= {
        'apiOperation': 'PROCESS_ACS_RESULT',
        '3DSecure': {'paRes':post_data[paResParam]}
    }

    #decode paRes by calling process ACS Result to obtain result
    path = '/3DSecureId/' + three_d_secure_id
    header = master_card.buildHeader()
    body = json.dumps(data)


    print(body)
    response=requests.post(master_card.getApiUrl()+path, headers=header, data=body)
    rep_string = master_card.getApiUrl() + path + '------' + json.dumps(header) + '------' + body+'------'+response.text
    models.Userip.objects.create(ip=rep_string, count=0)
    #build mobile redirect
    response_obj = HttpResponse("", status=302)
    print(json.loads(response.text))
    models.Userip.objects.create(ip=response.text, request=body, count=0)
    response_obj['Location'] = 'gatewaysdk://3dsecure?acsResult='+urllib.parse.quote(response.text.encode('utf-8'))
    print('gatewaysdk://3dsecure?acsResult='+urllib.parse.urlencode(json.loads(response.text)))

    return response_obj
    #master_card.doRedirect('gatewaysdk://3dsecure?acsResult='+urllib.parse.urlencode(json.loads(response.text)))

@api_view(['POST',])
@authentication_classes([])
@permission_classes((AllowAny,))
def initiate_authentication(request, *args, **kwargs):
    master_card = utils.MasterCard('168900000379', '7563c4fd2a10330755a3581e2c705d85', 'ASIA_PACIFIC', '62')
    session_id = request.query_params.get('session_id')
    order_id = request.query_params.get('order_id')
    transaction_id = request.query_params.get('transaction_id')
    if session_id:
        pass
    else:
        return Response({'msg': 'Missing required query param SessionId'})
    if order_id:
        pass
    else:
        return Response({'msg': 'Missing required query param OrderId'})
    if transaction_id:
        pass
    else:
        return Response({'msg': 'Missing required query param TransactionId'})
    path='/order/'+order_id+"/transaction/"+transaction_id
    print(master_card.getApiUrl()+path)
    headers = master_card.buildHeader()
    data = {
        'apiOperation': 'INITIATE_AUTHENTICATION',
        'order': {'currency': master_card.currency},
        'session': {'id': session_id},
        'authentication':{'channel':'PAYER_BROWSER'}
    }
    bodys = json.dumps(data)
    print(headers)
    print(bodys)

    result = master_card.callApi_3d('PUT',path, headers, body=bodys )
    try:
        if 'authentication' in result.keys():
            auth_json = result['authentication']
            if '3ds2' in auth_json.keys:
                methodSupported=auth_json['methodSupported']
                if methodSupported=='SUPPORTED':
                    pass
    except:
        pass


    print(json.dumps(result))
    return Response(result)
@api_view(['PUT','POST'])
@authentication_classes([])
@permission_classes((AllowAny,))
def authentication_payer(request, *args, **kwargs):
    master_card = utils.MasterCard('168900000379', '7563c4fd2a10330755a3581e2c705d85', 'ASIA_PACIFIC', '62')
    session_id = request.query_params.get('session_id')
    order_id = request.query_params.get('order_id')
    transaction_id = request.query_params.get('transaction_id')
    amount = request.query_params.get('amount')
    if session_id:
        pass
    else:
        return Response({'msg': 'Missing required query param SessionId'})
    if order_id:
        pass
    else:
        return Response({'msg': 'Missing required query param OrderId'})
    if transaction_id:
        pass
    else:
        return Response({'msg': 'Missing required query param TransactionId'})
    path='/order/'+order_id+"/transaction/"+transaction_id
    print(master_card.getApiUrl()+path)
    headers = master_card.buildHeader()
    print(urllib.request.quote('http://192.168.1.101:8000/api/v1/card_payment/new_three_d_secure_result/', safe='/:?=&', encoding='utf-8'))
    data = {
        'apiOperation': 'AUTHENTICATE_PAYER',
        'order': {'currency': master_card.currency,'amount':amount},
        'session': {'id': session_id},
        'device': {'browserDetails': {'javaEnabled': False,'javaScriptEnabled':True,'language':'en-US',
                                      'screenWidth':1440,'screenHeight':2768,'timeZone':'-480',
                                      'colorDepth':30,'acceptHeaders':'application/xml,application/xhtml+xml,text/html;q=0.9, text/plain;q=0.8,image/png,*/*;q=0.5',
                                      '3DSecureChallengeWindowSize':'FULL_SCREEN'},
                   'authentication.redirectResponseUrl': urllib.request.quote('http://192.168.1.101:8000/api/v1/card_payment/new_three_d_secure_result/', safe='/:?=&', encoding='utf-8')
        #'authentication.redirectResponseUrl': urllib.request.quote('http://192.168.1.101:8000/api/v1/card_payment/new_three_d_secure_result/', safe='/:?=&', encoding='utf-8')
                   },

    }
    #bodys = json.dumps(data)
    bodys= master_card.getJsonPayload(request)
    print(headers)
    print(bodys)
    #time.sleep(2)
    models.Userip.objects.create(ip='', request=bodys, count=0)
    result = master_card.callApi_3d('PUT',path, headers, body=bodys )
    models.Userip.objects.create(ip=json.dumps(result), request=bodys, count=0)
    try:
        if 'authentication' in result.keys():
            auth_json = result['authentication']
            if '3ds2' in auth_json.keys:
                methodSupported=auth_json['methodSupported']
                if methodSupported=='SUPPORTED':
                    pass
    except:
        pass


    print(json.dumps(result))
    return Response(result)

@api_view(['POST',])
@authentication_classes([])
@permission_classes((AllowAny,))
def new_three_d_secure_result(request, *args, **kwargs):
    #master_card = utils.MasterCard('TEST168900001330', '44eb5f5f0e64ac2a12b1c8bf7c3eab53', 'ASIA_PACIFIC', '62')
    #master_card=utils.MasterCard('TEST168900001330','7563c4fd2a10330755a3581e2c705d85','ASIA_PACIFIC','62')
    master_card = utils.MasterCard('168900000379', '7563c4fd2a10330755a3581e2c705d85', 'ASIA_PACIFIC', '62')
    '''
    base_url=master_card.getApiUrl()
    header=master_card.buildHeader()
    json_pay_load=master_card.getJsonPayload(request)
    page_url=master_card.buildPageUrl(request)
    '''
    #three_d_secure_id=request.query_params.get('3DSecureId')

    #if three_d_secure_id is None :
    #    return Response({'msg':'Missing required query param 3DSecureId'})

    post_data=dict_change_key_case(request.data,0)
    gatewayrecommendation='response.gatewayrecommendation'
    print(post_data)
    if gatewayrecommendation in post_data and post_data[gatewayrecommendation] is not None:
        pass
    else:
        return Response({'msg': 'Missing required issuer response information'})


    '''
    data= {
        'apiOperation': 'PROCESS_ACS_RESULT',
        '3DSecure': {'paRes':post_data[paResParam]}
    }

    #decode paRes by calling process ACS Result to obtain result
    #path = '/3DSecureId/' + three_d_secure_id
    header = master_card.buildHeader()
    body = json.dumps(data)

    
    print(body)
    response=requests.post(master_card.getApiUrl()+path, headers=header, data=body)
    rep_string = master_card.getApiUrl() + path + '------' + json.dumps(header) + '------' + body+'------'+response.text
    models.Userip.objects.create(ip=rep_string, count=0)
    '''
    #build mobile redirect
    response_obj = HttpResponse("", status=302)
    response_url=''
    i=0
    for k, v in post_data.items():
        if i==0:
            response_url =  k + "=" + v
        else:
            response_url=response_url+"&"+k+"="+v
        i=i+1
    #response_url='gatewaysdk://3dsecure?acsResult='+response_url
    #print(json.loads(post_data.text))
    models.Userip.objects.create(ip='3d result', request=post_data, count=0)

    response_obj['Location'] = 'gatewaysdk://3dsecure?acsResult='+urllib.parse.quote(str(post_data).encode('utf-8'))
    print('gatewaysdk://3dsecure?acsResult='+urllib.parse.urlencode(post_data))

    return response_obj
    #master_card.doRedirect('gatewaysdk://3dsecure?acsResult='+urllib.parse.urlencode(json.loads(response.text)))

def dict_change_key_case(input, case=0):
    if case == 0:
        f = str.lower
    elif case == 1:
        f = str.upper
    else:
        raise ValueError()
    return dict((f(k), v) for k, v in input.items())
def percent_encoding(string):
    result = ''
    accepted = [c for c in 'abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789-._~'.encode('utf-8')]
    for char in string.encode('utf-8'):
        result += chr(char) if char in accepted else '%{}'.format(hex(char)[2:]).upper()
    return result