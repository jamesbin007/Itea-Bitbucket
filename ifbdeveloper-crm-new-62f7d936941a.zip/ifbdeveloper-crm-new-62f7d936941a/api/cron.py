from app01 import models
import datetime

from django.db.models import Count
from django.db import transaction
from django.db import connection
from .serializers import WalletBalanceSerializer
from invicode import utils
from .utils import check_server
import requests
def record_wallet_balance():

    with transaction.atomic():
        sql = "select sum(balance) from app01_wallet  "
        cursor = connection.cursor()
        cursor.execute(sql)
        row = cursor.fetchall()
        if row:
            if row[0][0] is not None:
                wallet_balance = row[0][0]
            else:
                wallet_balance = 0.0
        else:
            wallet_balance = 0.0
        sql = "select sum(balance) from app01_wallet where  member_id in (95,383,822,27,881,529,2749,102,1028,3458,621,952) "
        cursor = connection.cursor()
        cursor.execute(sql)
        row = cursor.fetchall()
        if row:
            if row[0][0] is not None:
                test_wallet_balance = row[0][0]
            else:
                test_wallet_balance = 0.0
        else:
            test_wallet_balance = 0.0
        serializer=WalletBalanceSerializer(data={'balance':wallet_balance,'test_balance':test_wallet_balance})
        if serializer.is_valid():
            #pass
            models.WalletBalance.objects.create(**serializer.validated_data)
        balance_record()

def balance_record():
    days = [21,20,19,18,17,16,15,14,13,12,11,10,9,8,7, 6, 5, 4, 3, 2, 1, 0]
    table = "<table border='1' cellspacing='0' style='text-align:center' ><tr><td colspan='13'  style='text-align:center' >Wallet Balance</td><td rowspan='2'>Test Account Balance</td></tr><tr><td>date</td><td>topup (GrabPay)</td><td>topup (CreditCard)</td><td>topup (outlet)</td><td>topup (all)</td><td>wallet payment</td><td>cash back</td><td>OrderCancel refund</td><td>OrderCancel(test) refund</td><td>Change Amount</td><td>Yesterday Balance</td><td>Today Balance</td><td>Differential Amount</td></tr>"
    line=""
    # wirecard
    for i in days:
            #sql = "select sum(money) from app01_RechargeRecord where type=0 and status=1 and (request_id is not null and \"grab_txID\" is null) and (money=10 or money=20 or money=50) and to_char(created,'yyyy-mm-dd')=to_char(current_date,'yyyy-mm-dd')"
            sql = "select sum(money) from app01_RechargeRecord where type=0 and status=1 and (request_id is not null and \"grab_txID\" is null)  and to_char(created+interval '8' hour,'yyyy-mm-dd')='"+getdate(i)+"'"
            cursor = connection.cursor()
            cursor.execute(sql)
            row = cursor.fetchall()
            if row:
                if row[0][0] is not None:
                    wirecard_topup_money = row[0][0]
                else:
                    wirecard_topup_money = 0.0
            else:
                wirecard_topup_money = 0.0
            print(str(wirecard_topup_money))
            # grabpay
            #sql = "select sum(money) from app01_RechargeRecord where type=0 and status=1 and (request_id is not null and \"grab_txID\" is not null) and (money=10 or money=20 or money=50) and to_char(created,'yyyy-mm-dd')=to_char(current_date,'yyyy-mm-dd')"
            sql = "select sum(money) from app01_RechargeRecord where type=0 and status=1 and (request_id is not null and \"grab_txID\" is not null)  and to_char(created+interval '8' hour,'yyyy-mm-dd')='"+getdate(i)+"'"
            cursor = connection.cursor()
            cursor.execute(sql)
            row = cursor.fetchall()
            if row:
                if row[0][0] is not None:
                    grabpay_topup_money = row[0][0]
                else:
                    grabpay_topup_money = 0.0
            else:
                grabpay_topup_money = 0.0
            print(str(grabpay_topup_money))
            # outlet
            sql = "select sum(money) from app01_topuprecord where to_char(created+interval '8' hour,'yyyy-mm-dd')='"+getdate(i)+"'"
            cursor = connection.cursor()
            cursor.execute(sql)
            row = cursor.fetchall()
            if row:
                if row[0][0] is not None:
                    outlet_topup_money = row[0][0]
                else:
                    outlet_topup_money = 0.0
            else:
                outlet_topup_money = 0.0
            sum_topup_money = wirecard_topup_money + grabpay_topup_money + outlet_topup_money

            # wallet sumAmount
            # sql="select  sum(app01_transaction.total_money)  from app01_transaction   where to_char(app01_transaction.payment_datetime,'yyyy-mm-dd')=to_char(current_date,'yyyy-mm-dd')  and app01_transaction.transaction_status in (4,5) and  payment_modes=8 "
            sql = "select sum(money) from app01_rechargerecord where type in (1) and to_char(created,'yyyy-mm-dd')='"+getdate(i)+"'"
            cursor = connection.cursor()
            cursor.execute(sql)
            row = cursor.fetchall()
            if row:
                if row[0][0] is not None:
                    sum_payment = row[0][0]
                else:
                    sum_payment = 0.0
            else:
                sum_payment = 0.0
            # cashback
            sql = "select sum(money) from app01_rechargerecord where type in (3) and to_char(created+interval '8' hour,'yyyy-mm-dd')='"+getdate(i)+"'"
            cursor = connection.cursor()
            cursor.execute(sql)
            row = cursor.fetchall()
            if row:
                if row[0][0] is not None:
                    cashback = row[0][0]
                else:
                    cashback = 0.0
            else:
                cashback = 0.0
            # cashback deduction
            sql = "select sum(money) from app01_rechargerecord where type in (4) and to_char(created+interval '8' hour,'yyyy-mm-dd')='"+getdate(i)+"'"
            cursor = connection.cursor()
            cursor.execute(sql)
            row = cursor.fetchall()
            if row:
                if row[0][0] is not None:
                    cashback_deduction = row[0][0]
                else:
                    cashback_deduction = 0.0
            else:
                cashback_deduction = 0.0
            cashback = cashback - cashback_deduction
            # refund
            sql = "select sum(money) from app01_rechargerecord where type in (2) and to_char(created+interval '8' hour,'yyyy-mm-dd')='"+getdate(i)+"'"
            cursor = connection.cursor()
            cursor.execute(sql)
            row = cursor.fetchall()
            if row:
                if row[0][0] is not None:
                    refund = row[0][0]
                else:
                    refund = 0.0
            else:
                refund = 0.0

            increase_decrease_value = sum_topup_money + cashback + refund - sum_payment

            #test refund
            sql = "select sum(money) from app01_rechargerecord where type in (2) and to_char(created+interval '8' hour,'yyyy-mm-dd')='" + getdate(
                i) + "' and wallet_id in ( select id from app01_wallet where member_id in (95,383,822,27,881,529,2749,102,1028,3458,621,952)) "
            cursor = connection.cursor()
            cursor.execute(sql)
            row = cursor.fetchall()
            if row:
                if row[0][0] is not None:
                    test_refund = row[0][0]
                else:
                    test_refund = 0.0
            else:
                test_refund = 0.0

            increase_decrease_value = sum_topup_money + cashback + refund - sum_payment

            # yesterday iPay wallet balance
            sql = "select balance from app01_walletbalance where to_char(record_date,'yyyy-mm-dd')=to_char(current_date-interval '"+str(i+1)+"' day ,'yyyy-mm-dd')"
            cursor = connection.cursor()
            cursor.execute(sql)
            row = cursor.fetchall()
            if row:
                if row[0][0] is not None:
                    yesterday_wallet_balance = row[0][0]
                else:
                    yesterday_wallet_balance = 0.0
            else:
                yesterday_wallet_balance = 0.0
            # iPay wallet  balance(test)
            #sql = "select test_balance from app01_walletbalance where to_char(record_date,'yyyy-mm-dd')=to_char(current_date-interval '"+str(i+1)+"' day ,'yyyy-mm-dd') member_id in (95,383,822,27,881,529,2749,102,1028,3458,621,952) "
            sql = "select test_balance from app01_walletbalance where to_char(record_date,'yyyy-mm-dd')=to_char(current_date-interval '" + str(i) + "' day ,'yyyy-mm-dd') "
            cursor = connection.cursor()
            cursor.execute(sql)
            row = cursor.fetchall()
            if row:
                if row[0][0] is not None:
                    wallet_test_balance = row[0][0]
                else:
                    wallet_test_balance = 0.0
            else:
                wallet_test_balance = 0.0

            # iPay wallet balance
            #sql = "select sum(balance) from app01_wallet "
            sql = "select balance from app01_walletbalance where to_char(record_date,'yyyy-mm-dd')=to_char(current_date-interval '" + str(i) + "' day ,'yyyy-mm-dd')"
            cursor = connection.cursor()
            cursor.execute(sql)
            row = cursor.fetchall()
            if row:
                if row[0][0] is not None:
                    wallet_balance = row[0][0]
                else:
                    wallet_balance = 0.0
            else:
                wallet_balance = 0.0
            add_redecue_balance = getFloat(increase_decrease_value)
            if (add_redecue_balance >= 0):
                incre_decre_value = '+' + str(add_redecue_balance)
            else:
                incre_decre_value = '' + str(add_redecue_balance)
            different_value = getFloat(wallet_balance - (yesterday_wallet_balance + add_redecue_balance))
            if different_value >= 0:
                str_different_value = '+' + str(different_value)
            else:
                str_different_value = '' + str(different_value)
            if yesterday_wallet_balance ==0:
                str_different_value='0.0'
            line =line+ "<tr><td>"+getdate(i)+"</td><td>" + str(
                getFloat(grabpay_topup_money)) + "</td><td>" + str(
                getFloat(wirecard_topup_money)) + "</td><td>" + str(
                getFloat(outlet_topup_money)) + "</td><td>" + str(
                getFloat(sum_topup_money)) + "</td><td>" + str(getFloat(sum_payment)) + "</td><td>" + str(
                getFloat(cashback)) + "</td><td>" + str(getFloat(refund)) + "</td><td>"+str(getFloat(test_refund))+"</td><td>" + incre_decre_value + "</td><td>" + str(
                getFloat(yesterday_wallet_balance)) + "</td><td>" + str(
                getFloat(wallet_balance)) + "</td><td><font color='red'>" + str_different_value + "</font></td><td>" + str(
                getFloat(wallet_test_balance)) + "</tr>"
    table=table+line+"</table>"
    utils.send_register_email(utils.RECEIVE_MAIL, table, send_type="balance", promotion='')


def getFloat(f):

    g = '%.2f' % f
    return float(g)
def getdate( beforeOfDay):
    today = datetime.datetime.now()
    # 计算偏移量
    offset = datetime.timedelta(days=-beforeOfDay)
    # 获取想要的日期的时间
    re_date = (today + offset).strftime('%Y-%m-%d')
    return re_date

def count_purchase():
    week_day = [13,12,11,10,9,8,7, 6, 5, 4, 3, 2, 1, 0]
    query_times = [1, 2, 3, 4, 5,6,7,8,9,10]
    table = "<table border='1' cellspacing='0' style='text-align:center' ><tr><td colspan='63'  style='text-align:center' >Purchase Times Count</td></tr>"
    thead = "<tr><td rowspan='2'>times</td>"
    cursor = connection.cursor()
    today_times_list=[]
    all_times_list=[]
    tfoot="<tr><td >total</td>"
    for day in week_day:
        sql_today = "select count(*) from app01_transaction where transaction_status in (4,5) and to_char(app01_transaction.payment_datetime,'yyyy-mm-dd')='"+ getdate(
                    day)+"'"
        cursor.execute(sql_today)
        row = cursor.fetchall()
        if row:
            if row[0][0] is not None:
                today_times = row[0][0]
                today_times_list.append({'date':getdate(day),'times':today_times})
            else:
                today_times = 0.0
                today_times_list.append({'date':getdate(day),'times':today_times})
        sql_count_all = "select count(temp.member_id) from (select count(*) as m_count,member_id from app01_transaction where  transaction_status in (4,5)  and to_char(app01_transaction.payment_datetime,'yyyy-mm-dd')<='"+getdate(day)+"'  group by member_id order by member_id asc) as temp"
        cursor.execute(sql_count_all)
        row = cursor.fetchall()
        if row:
            if row[0][0] is not None:
                all_count_times = row[0][0]
                all_times_list.append({'date': getdate(day), 'times': all_count_times})
            else:
                all_count_times = 0.0
                all_times_list.append({'date': getdate(day), 'times': all_count_times})
        tfoot = tfoot + "<td  ><span style='color:#159246'>" + str(today_times) + "</span></td><td></td><td><span style='color:#ff0000'>"+str(all_count_times)+"</span></td><td></td>"
        thead = thead + "<td colspan='4' >" + getdate(day) + "</td>"
    thead = thead + "</tr>"
    tfoot = tfoot+ "</tr>"
    table = table + thead
    t_today="<tr>"
    for day in week_day:
        t_today = t_today + "<td >today</td><td >today percent</td><td>all</td><td>all percent</td>"
    t_today = t_today + "</tr>"
    table = table + t_today
    for times in query_times:
        tbody = ""
        if times != 10:
            tbody = "<tr><td>" + str(times) + "</td>"
        else:
            tbody = "<tr><td>" + '>=' + str(times) + "</td>"
        for day in week_day:


            if times != 10:
                sql_all = "select count(temp.m_count) from (select count(*) as m_count,member_id from app01_transaction where  transaction_status in (4,5)  and to_char(app01_transaction.payment_datetime,'yyyy-mm-dd')<='" + getdate(day) + "'  group by member_id order by member_id asc) as temp where temp.m_count=" + str(times)
                sql = "select count(*) from app01_transaction where member_id in (select temp.member_id from (select count(*) as m_count,member_id from app01_transaction where  transaction_status in (4,5)    group by member_id order by member_id asc) as temp where temp.m_count=" +  str(
                    times) + ") and  transaction_status in (4,5) and to_char(app01_transaction.payment_datetime,'yyyy-mm-dd')='" + getdate(
                    day) + "' "
            else:
                sql="select count(*) from app01_transaction where member_id in (select temp.member_id from (select count(*) as m_count,member_id from app01_transaction where  transaction_status in (4,5)    group by member_id order by member_id asc) as temp where temp.m_count>="+ str(times)+") and transaction_status in (4,5) and to_char(app01_transaction.payment_datetime,'yyyy-mm-dd')='" + getdate(
                    day) + "' "
                sql_all = "select count(temp.m_count) from (select count(*) as m_count,member_id from app01_transaction where  transaction_status in (4,5)  and to_char(app01_transaction.payment_datetime,'yyyy-mm-dd')<='" + getdate(day) + "'  group by member_id order by member_id asc) as temp where temp.m_count>=" + str(times)


            cursor.execute(sql)
            row = cursor.fetchall()
            if row:
                if row[0][0] is not None:
                    p_times = row[0][0]
                else:
                    p_times = 0.0
            cursor.execute(sql_all)
            row = cursor.fetchall()
            if row:
                if row[0][0] is not None:
                    all_p_times = row[0][0]
                else:
                    all_p_times = 0.0
            for day_times in today_times_list:
                if getdate(day)==day_times.get('date'):
                    today_count_times=day_times.get('times')
                    break

            if today_count_times>0:
                times_percent='{:.2f}%'.format(p_times/today_count_times*100)
            for all_times in all_times_list:
                if getdate(day)==all_times.get('date'):
                    all_count_times=all_times.get('times')
                    break

            if all_count_times>0:
                all_times_percent='{:.2f}%'.format(all_p_times/all_count_times*100)
            tbody = tbody + "<td ><span style='color:#159246'>" + str(p_times) + "</span></td><td><span style='color:#154692'>"+times_percent+"</span></td><td ><span style='color:#ff0000'>"+str(all_p_times)+"</span></td><td><span style='color:#159292'>"+str(all_times_percent)+"</span></td>"
        tbody = tbody + "</tr>"

        table = table + tbody
    table = table + tfoot
    table = table + "</table>"
    # print(table)
    utils.send_register_email(utils.RECEIVE_MAIL, table, send_type="purchase", promotion='')

def erpGoodsCount():

    try:

        #response = requests.get("http://47.74.156.85:8008/api/v1/card/sendMessage/")
        checks = check_server('47.74.156.85', 8008, 'api/v1/card/sendMessage/')
        check_result_1 = checks.check()
        #response = requests.get("http://47.74.156.85:8008/api/v1/card/sendMessage/",headers={'Authorization':'Token fa3c5db850ada70422a02e4638984dc08822f010'})

        #return json.loads(response.text)
    except Exception as e:
        return {'msg': 'error'}




def erpOrderCount():

    try:

        #response = requests.get("http://47.74.156.85:8008/api/v1/card/getPos/")
        checks = check_server('47.74.156.85', 8008, 'api/v1/card/getPos/')
        check_result_1 = checks.check()
        #response = requests.get("http://47.74.156.85:8008/api/v1/card/getPos/",headers={'Authorization':'Token fa3c5db850ada70422a02e4638984dc08822f010'})

        #return json.loads(response.text)
    except Exception as e:
        return {'msg': 'error'}
def erpSalesComp():

    try:

        #response = requests.get("http://47.74.156.85:8008/api/v1/card/getPos/")
        checks = check_server('47.74.156.85', 8008, 'api/v1/card/getPosCompare/')
        check_result_1 = checks.check()
        #response = requests.get("http://47.74.156.85:8008/api/v1/card/getPosCompare/",headers={'Authorization':'Token fa3c5db850ada70422a02e4638984dc08822f010'})

        #return json.loads(response.text)
    except Exception as e:
        return {'msg': 'error'}
