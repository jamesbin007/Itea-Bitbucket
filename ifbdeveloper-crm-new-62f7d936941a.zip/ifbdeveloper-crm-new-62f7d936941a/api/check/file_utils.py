import threading
import os
import time
from optparse import OptionParser

import socket

import sys

import re

from io import StringIO
class FileHandler(object):
    _instance_lock = threading.Lock()
    def __init__(self,**exclude_path):
        self.exclude_path=exclude_path
    def list_all_files(self,rootdir):
        #with FileHandler._instance_lock:

            _files = []
            list = os.listdir(rootdir) #列出文件夹下所有的目录与文件
            for i in range(0,len(list)):
                   path = os.path.join(rootdir,list[i])
                   if os.path.isdir(path):
                      path_split_arr=path.split('\\')
                      if path_split_arr:
                           dir_name=path_split_arr[len(path_split_arr)-1]

                           if(dir_name==self.exclude_path['path_1'] or dir_name==self.exclude_path['path_2'] or dir_name==self.exclude_path['path_3'] or dir_name==self.exclude_path['path_4']or dir_name==self.exclude_path['path_5']):
                               pass
                           else:

                               _files.extend(self.list_all_files(path))
                   if os.path.isfile(path):
                      if os.path.splitext(path)[-1][1:] !='pyc':
                           _files.append(path)
            return _files
    def containsValue(self,pathName):
        contains=False
        if self.exclude_path:
            for k,v in self.exclude_path:
                if pathName==v:
                    contains=True
                    break
                else:
                    pass
            return contains
        return contains

#check server status
class check_server:


   def __init__(self,address,port,resource):
       self.address = address
       self.port = port
       self.resource = resource
   def check(self):
           """
       该方法也是该类的主要方法，包括构建请求资源，解析返回结果等
       """
           if not self.resource.startswith('/'):
               self.resource = '/' + self.resource
               request = "GET %s HTTP/1.1\r\nHost:%s\r\nAuthorization:%s\r\n\r\n" %(self.resource,self.address,'Token fa3c5db850ada70422a02e4638984dc08822f010')
               #建立一个socket连接
               s =socket.socket()
               # #设置连接超时时间
               s.settimeout(10)
               print("now connect to %s port %s ......" %(self.address,self.port))

               try:
                   s.connect((self.address,self.port))
                   print("connect %s port %s successfully" %(self.address,self.port))
                   s.send(request.encode('utf8'))
                   response = s.recv(100)
               except socket.error as e:
                    print("connect %s port %s fail ,reason:%s" %(self.address,self.port,e))
                    return {'result':"connect %s port %s fail ,reason:%s" %(self.address,self.port,e),'status':'fail'}
                    #return False
               finally:
                    print("close connection")
                    s.close()
               line = StringIO(response.decode()).readline()
               try:
                   (http_version,status,messages) = re.split(r'\s+',line,2)
               except ValueError:
                   print("split respone code fail")
                   return {'result': "server:%s port:%s split respone code fail"%(self.address,self.port),'status': 'fail'}
                   #return False
               print("return status code:%s" %(status))
               if status in ['200','301','302','304','404']:
                   print("server status is good")
                   return {'result': "server:%s port:%s resource:%s status is good"%(self.address,self.port,self.resource), 'status': 'success'}
               else:
                   print("Server Error")
                   server_status_msg="server:%s port:%s resource:%s   " %(self.address,self.port,self.resource)
                   return {'result': server_status_msg+status, 'status': 'fail'}
               '''
               if __name__ == '__main__':
               

                   parser =OptionParser()
                   parser.add_option("-a","--address",dest="address" ,default='localhost',help="host address or host name")
                   parser.add_option('-p','--port',dest="port",type=int,default=80,help="port")
                   parser.add_option('-r','--resource',dest="resource",default="/",help="resource")
                   (options,args) = parser.parse_args()
              
if __name__=='__main__':
    exclude_path={'path_1':'node_modules','path_2':'.idea','path_3':'migrations','path_4':'__pycache__'}
    fileHandler=FileHandler(**exclude_path)
    file_list=fileHandler.list_all_files("e:\\erp-workspace\\")
    for file in file_list:
        print(file.title()+'      create time:'+time.strftime('%Y-%m-%d %H:%M:%S', time.localtime(os.stat(file).st_mtime))+'      modify time:'+time.strftime('%Y-%m-%d %H:%M:%S', time.localtime(os.stat(file).st_ctime)))
        ##print(file.title()+'      modify time:'+time.strftime('%Y-%m-%d %H:%M:%S', time.localtime(os.stat(file).st_mtime)))
 '''