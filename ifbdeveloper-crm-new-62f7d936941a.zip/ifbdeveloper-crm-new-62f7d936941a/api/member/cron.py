from app01 import models
from datetime import datetime
from member.services import update_membership, update_points,deal_electric_sign
#from member.services import update_membership, update_points
from django.db.models import Count,Q
from django.db import transaction
from invicode.service import record_reward_member_invicode
from .services import update_member_points
from django.utils import timezone
def daily():
    """ Executed at 00:00:02 every day"""
    # 1.Check campaign state
    models.Campaign.objects.exclude(state__in=[models.Campaign.processing, models.Campaign.archived]).filter(
        effective_date__gte=datetime.now(), expiring_date__gte=datetime.now()).update(state=1)
    models.Campaign.objects.exclude(state__in=[models.Campaign.processing, models.Campaign.archived]).filter(
        effective_date__lte=datetime.now(), expiring_date__gte=datetime.now()).update(state=2)
    models.Campaign.objects.exclude(state__in=[models.Campaign.processing, models.Campaign.archived]).filter(
        effective_date__lte=datetime.now(), expiring_date__lte=datetime.now()).update(state=3)

    # 2.Check voucher state and Voucher_Member state
    models.Voucher.objects.filter(effective_date__gte=datetime.now().date(), expiring_date__gte=datetime.now().date()).update(state=1)
    models.Voucher.objects.filter(effective_date__lte=datetime.now().date(), expiring_date__gte=datetime.now().date()).update(state=2)
    #models.Voucher.objects.filter(effective_date__lte=datetime.now(), expiring_date__lte=datetime.now()).update(state=3)
    models.Voucher.objects.filter(effective_date__lte=datetime.now().date(), expiring_date__lt=datetime.now().date()).update(state=3)
    models.Voucher_Member.objects.filter(voucher__effective_date__lte=datetime.now(),
                                         voucher__expiring_date__lte=datetime.now()).update(status=2)

    # 3.Change in membership level cycle
    membership_members = models.Membership_Member.objects.filter(status=0, expiring_date__lte=datetime.now()).all()
    members = []
    # 3.1 will execute downgrade one level
    with transaction.atomic():
        for membership_member in membership_members:
            member = membership_member.member
            members.append(member)
            desc_memberships = models.Membership.objects.order_by('-start_points').all()
            for membership in desc_memberships:
                if member.total_points <= member.membership.renewal_points:
                    if 0 > member.membership.start_points < membership.start_points:
                        update_membership(member, membership)
                        break

    # 3.2 will automatic exchange of vouchers for one year and clear the points(points_bal and total_points)
    with transaction.atomic():
        reward_vouchers = []
        for member in members:
            total_num_products = models.Product.objects.all().count()
            # get Any one drink(M) voucher
            voucher = models.Voucher.objects.annotate(num=Count('redemption_products')).filter(state=2,
                                                                                               num=total_num_products)
            if voucher.exists():
                voucher = voucher.first()
            else:
                lastest_id = models.Voucher.objects.only('id').latest('id').pk
                voucher = models.Voucher.objects.create(
                    name='Any one drink(M)-%s' % (datetime.now().strftime('%Y-%m-%d %H:%M:%S')), type=0,
                    voucher_code='any_one_drink(M)-%05d' % (lastest_id + 1),
                    effective_date='2018-01-01', expiring_date='2099-01-01',
                    redemption_points=9999, product_size=[0], product_number=1,
                    state=2)
                voucher.redemption_products.set(models.Product.objects.all())
                #voucher.save()
            count_redeemed = int(member.points_bal // member.membership.complimentary_m_drink_points)
            update_points(member, -member.points_bal, 4)
            for i in range(count_redeemed):
                reward_vouchers.append(voucher)
            record_reward_member_invicode(member, reward_vouchers)


def monthly():
    """ Execute at 00:00:02 every month on the 1st"""
    # 1.Birthday voucher for the month of the month
    with transaction.atomic():
        if datetime.now().day == 1:
            members = models.Member.objects.filter(dob__month=datetime.now().month).all()
            for member in members:
                vouchers = member.membership.birthday_vouchers.all()
                record_reward_member_invicode(member, vouchers)

def member_birthday():
    import datetime
    with transaction.atomic():

            #members = models.Member.objects.filter(~Q(reward_birthday_voucher_date__year=datetime.now().year) | Q(reward_birthday_voucher_date__isnull=True)).filter(dob__month=datetime.now().month,dob__day=datetime.now().day).all()
            for i in range(7,8):
                members = models.Member.objects.filter(Q(reward_birthday_voucher_date__isnull=False,reward_birthday_voucher_date__year__lt=datetime.datetime.now().year) | Q(reward_birthday_voucher_date__isnull=True)).filter(dob__month=(datetime.datetime.now().date()+datetime.timedelta(days=i)).month,dob__day=(datetime.datetime.now().date()+datetime.timedelta(days=i)).day).all()
                if members:
                    for member in members:
                        dob=member.dob
                        if dob:

                            vouchers = member.membership.birthday_vouchers.all()
                            #member.reward_birthday_voucher_date=datetime.now().date()
                            member.reward_birthday_voucher_date = (datetime.datetime.now()+datetime.timedelta(days=i)).date()

                            member.save()
                            record_reward_member_invicode(member, vouchers,'birthday')

def auto_collect():
    import datetime
    with transaction.atomic():
        transas_list=models.Transaction.objects.filter(transaction_status=4,member_updated=True)
        if transas_list:
            for trans in transas_list:
                if trans.pick_up_type==0:
                    trans.transaction_status=5
                    dt=trans.delay_time+datetime.timedelta(minutes=5)
                    trans.collected_time=timezone.make_aware(dt, timezone=timezone.get_current_timezone())
                    trans.save()
                    '''
                    amount=trans.total_money
                    member=trans.member
                    deal_electric_sign(member, trans)
                    if amount>0:
                        if member:
                            update_member_points(member, amount, 1, None, None)
                    '''

