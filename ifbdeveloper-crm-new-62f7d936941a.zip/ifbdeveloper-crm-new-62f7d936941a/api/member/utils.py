from app01 import models
from transaction.utils import thread_send_mail
from django.db import transaction
import datetime
from invicode.serializers import generate_random_str
def dispatch_invicode(member):
    #member campaign bind voucher
    bind_member_campaign_voucher(member)

    if member:
        member_ship = member.membership
        member_campaign_list = models.Member_Campaign.objects.filter(status=True, member_ship__id=member_ship.id)
        if member_campaign_list:
            objs = []
            for item in member_campaign_list:
                
                    voucher_list = item.voucher.all()
                    if voucher_list:
                        for voucher_item in voucher_list:
                            with transaction.atomic():
                                #invicode = models.Invicode.objects.filter(member__id=member.id,voucher__id=voucher_item.id).first()
                                #if invicode:
                                if models.Invicode.objects.filter(member__id=member.id,voucher__id=voucher_item.id).first():
                                    pass
                                else:
                                    try:
                                        invicode_first = models.Invicode.objects.select_for_update(nowait=True).filter(
                                            voucher__id=voucher_item.id, status=0).first()
                                        if invicode_first:
                                            invicode_first.member = member
                                            invicode_first.invicode_user = member.mobile_no
                                            invicode_first.status = 1
                                            invicode_first.register_date = datetime.datetime.now()
                                            voucher = invicode_first.voucher
                                            if voucher:
                                                voucher_expire_date = voucher.expiring_date

                                                invicode_register_date = invicode_first.register_date
                                                valid_days = invicode_first.vaild_days
                                                voucher_expire_date_8 = voucher_expire_date
                                                # voucher_expire_zone_date=voucher_expire_date_8.replace(tzinfo=None)
                                                invicode_register_date_8 = invicode_register_date
                                                # invicode_register_zone_date = invicode_register_date_8.replace(tzinfo=None)
                                                if (valid_days and valid_days > 0):
                                                    v_days = valid_days - 1
                                                    invicode_exp_date = invicode_register_date_8 + datetime.timedelta(
                                                        days=v_days)
                                                    if invicode_exp_date.date() >= voucher_expire_date_8:

                                                        invicode_first.expire_date = voucher_expire_date_8
                                                    else:
                                                        invicode_first.expire_date = invicode_exp_date
                                                else:
                                                    invicode_first.expire_date = voucher_expire_date_8
                                            invicode_first.save()
                                        else:
                                            pass

                                    except Exception as e:
                                        pass

    bind_voucher_obj=models.Bind_Voucher.objects.all().first()
    if bind_voucher_obj:
        if bind_voucher_obj.activity_flag:
            voucher=bind_voucher_obj.voucher
            if voucher:
                voucher_id=voucher.id
                if voucher_id:
                    if member:
                        if hasattr(member,'id'):
                            with transaction.atomic():
                                member_id=member.id
                                invicode=models.Invicode.objects.filter(member__id=member_id,voucher__id=voucher_id).first()
                                if invicode:
                                    pass
                                else:
                                    invicode_first = models.Invicode.objects.select_for_update(nowait=True).filter(voucher__id=voucher_id,status=0).first()
                                    if invicode_first:
                                        invicode_first.member=member
                                        invicode_first.invicode_user=member.mobile_no
                                        invicode_first.status=1
                                        invicode_first.register_date=datetime.datetime.now()
                                        voucher = invicode_first.voucher
                                        if voucher:
                                            voucher_expire_date = voucher.expiring_date

                                            invicode_register_date = invicode_first.register_date
                                            valid_days = invicode_first.vaild_days
                                            voucher_expire_date_8 = voucher_expire_date
                                            # voucher_expire_zone_date=voucher_expire_date_8.replace(tzinfo=None)
                                            invicode_register_date_8 = invicode_register_date
                                            # invicode_register_zone_date = invicode_register_date_8.replace(tzinfo=None)
                                            if (valid_days and valid_days > 0):
                                                v_days = valid_days - 1
                                                invicode_exp_date = invicode_register_date_8 + datetime.timedelta(
                                                    days=v_days)
                                                if invicode_exp_date.date() >= voucher_expire_date_8:

                                                    invicode_first.expire_date = voucher_expire_date_8
                                                else:
                                                    invicode_first.expire_date = invicode_exp_date
                                            else:
                                                invicode_first.expire_date = voucher_expire_date_8
                                        invicode_first.save()
                                    else:
                                        pass
                                        #thread_send_mail('iPot voucher is all exchanged!','check')

    bind_second_voucher_obj = models.Bind_Second_Voucher.objects.all().first()
    if bind_second_voucher_obj:
        if bind_second_voucher_obj.activity_flag:
            voucher = bind_second_voucher_obj.voucher
            if voucher:
                voucher_id = voucher.id
                if voucher_id:
                    if member:
                        if hasattr(member, 'id'):
                            with transaction.atomic():
                                member_id = member.id
                                invicode = models.Invicode.objects.filter(member__id=member_id,
                                                                          voucher__id=voucher_id).first()
                                if invicode:
                                    pass
                                else:
                                    invicode_first = models.Invicode.objects.select_for_update(nowait=True).filter(
                                        voucher__id=voucher_id, status=0).first()
                                    if invicode_first:
                                        invicode_first.member = member
                                        invicode_first.invicode_user = member.mobile_no
                                        invicode_first.status = 1
                                        invicode_first.register_date = datetime.datetime.now()
                                        voucher = invicode_first.voucher
                                        if voucher:
                                            voucher_expire_date = voucher.expiring_date

                                            invicode_register_date = invicode_first.register_date
                                            valid_days = invicode_first.vaild_days
                                            voucher_expire_date_8 = voucher_expire_date
                                            # voucher_expire_zone_date=voucher_expire_date_8.replace(tzinfo=None)
                                            invicode_register_date_8 = invicode_register_date
                                            # invicode_register_zone_date = invicode_register_date_8.replace(tzinfo=None)
                                            if (valid_days and valid_days > 0):
                                                v_days = valid_days - 1
                                                invicode_exp_date = invicode_register_date_8 + datetime.timedelta(
                                                    days=v_days)
                                                if invicode_exp_date.date() >= voucher_expire_date_8:

                                                    invicode_first.expire_date = voucher_expire_date_8
                                                else:
                                                    invicode_first.expire_date = invicode_exp_date
                                            else:
                                                invicode_first.expire_date = voucher_expire_date_8
                                        invicode_first.save()
                                    else:
                                        pass

    bind_third_voucher_obj = models.Bind_Third_Voucher.objects.all().first()
    if bind_third_voucher_obj:
        if bind_third_voucher_obj.activity_flag:
            voucher = bind_third_voucher_obj.voucher
            if voucher:
                voucher_id = voucher.id
                if voucher_id:
                    if member:
                        if hasattr(member, 'id'):
                            with transaction.atomic():
                                member_id = member.id
                                invicode = models.Invicode.objects.filter(member__id=member_id,
                                                                          voucher__id=voucher_id).first()
                                if invicode:
                                    pass
                                else:
                                    invicode_first = models.Invicode.objects.select_for_update(nowait=True).filter(
                                        voucher__id=voucher_id, status=0).first()
                                    if invicode_first:
                                        invicode_first.member = member
                                        invicode_first.invicode_user = member.mobile_no
                                        invicode_first.status = 1
                                        invicode_first.register_date = datetime.datetime.now()
                                        voucher = invicode_first.voucher
                                        if voucher:
                                            voucher_expire_date = voucher.expiring_date

                                            invicode_register_date = invicode_first.register_date
                                            valid_days = invicode_first.vaild_days
                                            voucher_expire_date_8 = voucher_expire_date
                                            # voucher_expire_zone_date=voucher_expire_date_8.replace(tzinfo=None)
                                            invicode_register_date_8 = invicode_register_date
                                            # invicode_register_zone_date = invicode_register_date_8.replace(tzinfo=None)
                                            if (valid_days and valid_days > 0):
                                                v_days = valid_days - 1
                                                invicode_exp_date = invicode_register_date_8 + datetime.timedelta(
                                                    days=v_days)
                                                if invicode_exp_date.date() >= voucher_expire_date_8:

                                                    invicode_first.expire_date = voucher_expire_date_8
                                                else:
                                                    invicode_first.expire_date = invicode_exp_date
                                            else:
                                                invicode_first.expire_date = voucher_expire_date_8
                                        invicode_first.save()
                                    else:
                                        pass
def bind_member_campaign_voucher(member):
    pass





