from rest_framework import serializers
from django.db import transaction
from django.utils import timezone
from app01 import models
from utils.utils import except_validation_error
from rest_framework.response import Response
from rest_framework import status
from .services import supplement_info, bind_email, update_membership, create_member, encrypted_or_reset_password
from django.core.exceptions import ObjectDoesNotExist
from membership.services import get_initial_membership_level
from utils.utils import transaction_wrapper
from membership.serializers import MembershipSerializer
from django.db.models import Q,Sum,Count
import datetime
from django.contrib.auth.hashers import make_password,check_password
@transaction_wrapper
def set_interest(interest_group_datas, member):
    """Set a member's interest groups"""
    for interest_group_data in interest_group_datas:
        if models.InterestGroup.objects.filter(name=interest_group_data.get('name')).exists():
            interest_group = models.InterestGroup.objects.get(name=interest_group_data.get('name'))
        else:
            serializer = InterestGroupSerializer(data=interest_group_data)
            serializer.is_valid(raise_exception=True)
            interest_group = serializer.save()
        member.interestGroups.add(interest_group)
    member.save()


@transaction_wrapper
def reset_interest(interest_group_datas, member):
    """Reset a member's interest groups"""
    member.interestGroups.clear()
    set_interest(interest_group_datas, member)


class InterestGroupSerializer(serializers.ModelSerializer):
    class Meta:
        model = models.InterestGroup
        fields = '__all__'

class MemberMobileSerializer(serializers.ModelSerializer):
    membership_name=serializers.SerializerMethodField()
    next_update_points=serializers.SerializerMethodField()
    next_membership_name=serializers.SerializerMethodField()
    recent_membership_points=serializers.SerializerMethodField()
    wallet_balance=serializers.SerializerMethodField()
    enable_invicode_count=serializers.SerializerMethodField()
    class Meta:
        model = models.Member
        fields = ('id','mobile_no','wallet_balance','enable_invicode_count', 'is_active', 'name','membership_name','email','total_points','points_bal','invite_code','dob','next_update_points','next_membership_name','recent_membership_points')
    def get_wallet_balance(self, obj):
        ret = models.Wallet.objects.get(member__id=obj.id)
        if (ret is not None):
            return ret.balance
        else:
            return 0
    def get_enable_invicode_count(self, obj):
        ret = models.Invicode.objects.filter    (member__id=obj.id,status=1,expire_date__gte=datetime.datetime.now().date()).count()
        return ret
    def get_membership_name(self, obj):
        ret = models.Membership.objects.get(id=obj.membership.id)
        if (ret is not None):
            return ret.name
        else:
            return ''
    def get_next_update_points(self, obj):

        top_membership_obj=models.Membership.objects.order_by('-start_points').first()
        next_update_points = -1
        if top_membership_obj:

            top_membership_id=top_membership_obj.id
            if obj.membership.id!=top_membership_id:


                membership_list = models.Membership.objects.order_by('start_points')
                if membership_list:
                    index=0
                    next_grade_index=index+1
                    for item in membership_list:
                        if item.id==obj.membership.id:
                            next_grade_index=index+1
                            break
                        index+=1
                    if next_grade_index<len(membership_list) :
                        next_membership_obj=membership_list[next_grade_index]
                        #next_update_points= float('%.2f' % (next_membership_obj.start_points-obj.total_points))
                        next_update_points = next_membership_obj.start_points - obj.total_points

        return next_update_points
    def get_next_membership_name(self, obj):

        top_membership_obj=models.Membership.objects.order_by('-start_points').first()
        next_membership_name = ''
        if top_membership_obj:

            top_membership_id=top_membership_obj.id
            if obj.membership.id!=top_membership_id:


                membership_list = models.Membership.objects.order_by('start_points')
                if membership_list:
                    index=0
                    next_grade_index=index+1
                    for item in membership_list:
                        if item.id==obj.membership.id:
                            next_grade_index=index+1
                            break
                        index+=1
                    if next_grade_index<len(membership_list) :
                        next_membership_obj=membership_list[next_grade_index]
                        next_membership_name= next_membership_obj.name

        return next_membership_name

    def get_recent_membership_points(self, obj):
        if obj:
            return obj.membership.renewal_points
class Member_CampaignTypeSerializer(serializers.ModelSerializer):
    class Meta:
        model = models.Member_CampaignType
        exclude = ('id',)


class Voucher_MemberSerializer(serializers.ModelSerializer):
    class Meta:
        model = models.Invicode
        exclude = ('id',)


class Points_MemberSerializer(serializers.ModelSerializer):
    class Meta:
        model = models.Points_Member
        exclude = ('id','campaigntype','member')
        depth=1
class Payment_CodeSerializer(serializers.ModelSerializer):
    class Meta:
        model = models.Payment_Code
        fields = '__all__'


class Member_RewardSerializer(serializers.ModelSerializer):
    class Meta:
        model = models.Member_Reward
        exclude = ('id',)

class SignedOrderRecordSerializer(serializers.ModelSerializer):
    class Meta:
        model = models.SignedOrderRecord
        fields = '__all__'

class MembershipMemberSerializer(serializers.ModelSerializer):
    class Meta:
        model = models.Membership_Member
        exclude = ('id',)
class SignedOrderRecordSerializer(serializers.ModelSerializer):
    class Meta:
        model = models.SignedOrderRecord
        fields = '__all__'
class PuzzleImageLogSerializer(serializers.ModelSerializer):
    class Meta:
        model = models.PuzzleImageLog
        fields = '__all__'
class New_User_RewardsSerializer(serializers.ModelSerializer):

    class Meta:
        model = models.New_User_Rewards
        fields = '__all__'
        depth = 1
class SignedGlobalIndexSerializer(serializers.ModelSerializer):
    signed_item = serializers.SerializerMethodField()
    class Meta:
        model = models.SignedGlobalIndex
        fields = '__all__'

    def get_signed_item (self, obj):
        obj_list=models.SignedOrderRecord.objects.filter(signed_global_index__id=obj.id).order_by('circle_index')
        erase_times = 0
        member=obj.member
        if obj_list is not None:
            temp_obj_list=[]

            for i in range(12):
                j=i+1
                if j==4 or j==9:

                    obj = models.SignedOrderRecord(id=0, electronic_signed=False, signed_type=2,null_image_url='', prize_image_url='http://erp.itea.sg:8000/signed/upsize.gif',fake=False)
                elif j==12:
                    obj = models.SignedOrderRecord(id=0, electronic_signed=False, signed_type=2, null_image_url='',prize_image_url='http://erp.itea.sg:8000/signed/free_drink.gif',fake=False)
                else:

                    obj=models.SignedOrderRecord(id=0,electronic_signed=False,signed_type=0,null_image_url='http://erp.itea.sg:8000/signed/null.gif',prize_image_url='',fake=False)
                temp_obj_list.append(obj)
            if len(obj_list)<12:
                #check pending order exists
                if member:


                    trans_list = models.Transaction.objects.filter(member__id=member.id,
                                                                   transaction_status__in=(2, 4),pick_up_type=0,
                                                                   inserted_signed_record=False)
                    trans_id_list = []
                    if trans_list:
                        for item in trans_list:
                            # if trans use free up size or free drink voucher,then erase 1 times
                            redeem_invicode = item.redeem_invicode
                            if redeem_invicode != 0:
                                invicode_obj = models.Invicode.objects.filter(id=redeem_invicode).first()
                                if invicode_obj:
                                    voucher_obj = invicode_obj.voucher
                                    if voucher_obj:
                                        if voucher_obj.id == 292 or voucher_obj.id == 295:
                                            pass
                                            #erase_times = erase_times + 1
                            trans_id_list.append(item.id)
                    transDetails_count_obj = models.TransactDetails.objects.filter(
                        transaction__id__in=tuple(trans_id_list)).aggregate(sum=Sum('quantity'))
                    if transDetails_count_obj:
                        quantity_num = transDetails_count_obj['sum']
                        if quantity_num:
                            quantity_num = quantity_num - erase_times
                    obj_list_count = len(obj_list)
                    pending_index_list = []

                    if quantity_num:
                        for l in range(quantity_num):

                            temp_index = obj_list_count + l
                            if temp_index > 11:
                                break

                            pending_index_list.append(temp_index)
                        t_index=0
                        for t_obj in temp_obj_list:
                            if t_index in pending_index_list:
                                t_obj.fake=True
                            t_index=t_index+1

                temp_return_obj_list = [SignedOrderRecordSerializer(i).data for i in obj_list]
                for k in range(12-len(obj_list)):
                    temp_return_obj_list.append(SignedOrderRecordSerializer(temp_obj_list[len(obj_list)+k]).data)

                return temp_return_obj_list
            else:
                return [SignedOrderRecordSerializer(i).data for i in obj_list]
        else:
            return []
class FakeSignedGlobalIndexSerializer(serializers.ModelSerializer):
    signed_item = serializers.SerializerMethodField()
    class Meta:
        model = models.SignedGlobalIndex
        fields = '__all__'

    def get_signed_item (self, obj):

        obj_list=models.SignedOrderRecord.objects.filter(signed_global_index__id=obj.id).order_by('circle_index')

        if obj_list:
            erase_times = 0
            #caculate order quantity
            first_obj=obj_list[0]
            member=first_obj.member
            if member:
                #transaction_status==2
                trans_list=models.Transaction.objects.filter(member__id=member.id,transaction_status__in=(2,4),pick_up_type=0,inserted_signed_record=False)
                #trans_list = models.Transaction.objects.filter(member__id=member.id, transaction_status=2)
                trans_id_list=[]
                if trans_list:
                    for item in trans_list:
                        # if trans use free up size or free drink voucher,then erase 1 times
                        redeem_invicode = item.redeem_invicode
                        if redeem_invicode != 0:
                            invicode_obj = models.Invicode.objects.filter(id=redeem_invicode).first()
                            if invicode_obj:
                                voucher_obj = invicode_obj.voucher
                                if voucher_obj:
                                    if voucher_obj.id == 292 or voucher_obj.id == 295:
                                        pass
                                        #erase_times = erase_times + 1
                        trans_id_list.append(item.id)
                transDetails_count_obj=models.TransactDetails.objects.filter(transaction__id__in=tuple(trans_id_list)).aggregate(sum=Sum('quantity'))
                if transDetails_count_obj:
                    quantity_num=transDetails_count_obj['sum']
                    if quantity_num:
                        quantity_num = quantity_num - erase_times
            temp_obj_list=[]
            obj_list_count=len(obj_list)
            fake_index_list=[]
            if quantity_num:
                for l in range(quantity_num):

                    temp_index=obj_list_count+l
                    if temp_index>11:
                        break
                        '''
                        remain_num=temp_index % 12
                        if remain_num==0:
                            temp_index=12
                        else:
                            temp_index=remain_num
                        '''
                    fake_index_list.append(temp_index)
            for i in range(12):
                j=i+1
                if j==4 or j==9:

                    obj = models.SignedOrderRecord(id=0, electronic_signed=False,fake=False, signed_type=2,null_image_url='http://erp.itea.sg:8000/signed/upsize.gif', prize_image_url='http://47.74.156.85:8000/signed/upsize.png',signed_prize_image_url='http://47.74.156.85:8000/signed/signed_upsize.png',fake_image_url='http://47.74.156.85:8000/signed/fake_up_size.png')
                elif j==12:
                    obj = models.SignedOrderRecord(id=0, electronic_signed=False,fake=False, signed_type=2, null_image_url='http://erp.itea.sg:8000/signed/free_drink.gif',prize_image_url='http://47.74.156.85:8000/signed/free_drink.png',signed_prize_image_url='http://47.74.156.85:8000/signed/signed_free_drink.png',fake_image_url='http://47.74.156.85:8000/signed/fake_free_drink.png')
                else:

                    obj=models.SignedOrderRecord(id=0,electronic_signed=False,fake=False,signed_type=0,null_image_url='http://erp.itea.sg:8000/signed/null.gif',prize_image_url='',signed_null_image_url ='http://47.74.156.85:8000/signed/signed_null.png',fake_image_url='http://47.74.156.85:8000/signed/fake_null.png')
                if fake_index_list and i in fake_index_list:
                    obj.fake=True
                temp_obj_list.append(obj)
            if len(obj_list)<12:
                temp_return_obj_list = [SignedOrderRecordSerializer(i).data for i in obj_list]
                for k in range(12-len(obj_list)):
                    temp_return_obj_list.append(SignedOrderRecordSerializer(temp_obj_list[len(obj_list)+k]).data)

                return temp_return_obj_list
            else:
                return [SignedOrderRecordSerializer(i).data for i in obj_list]
        else:
            return []
class FullMemberCUSerializer(serializers.ModelSerializer):
    class Meta:
        model = models.Member
        exclude = ('role', 'interestGroups', 'vouchers')

    @except_validation_error
    def create(self, validated_data):
        role = models.Role.objects.get(name=2)
        validated_data['role'] = role
        instance = super(FullMemberCUSerializer, self).create(validated_data)
        # Some passive business logic will be triggered by the creation of new members
        create_member(instance)
        # Set this member's interest groups
        if self.initial_data.get('interestGroups'):
            set_interest(self.initial_data.get('interestGroups'), instance)
        # Create a record of membership level periodic table
        update_membership(instance, instance.membership)
        return instance

    @except_validation_error
    def update(self, instance, validated_data):
        instance = super(FullMemberCUSerializer, self).update(instance, validated_data)
        # Reset password
        encrypted_or_reset_password(instance, instance.password)
        # Reset this member's interest groups
        if self.initial_data.get('interestGroups'):
            reset_interest(self.initial_data.get('interestGroups'), instance)
        # Update a record of membership level periodic table
        if validated_data.get('membership'):
            update_membership(instance, instance.membership)
        return instance


class FullMemberReadSerializer(serializers.ModelSerializer):
    membership_members = MembershipMemberSerializer(many=True, read_only=True)
    member_campaigntypes = Member_CampaignTypeSerializer(many=True, read_only=True)
    invicode_members = Voucher_MemberSerializer(many=True, read_only=True)
    points = Points_MemberSerializer(many=True, read_only=True)
    membership = MembershipSerializer(read_only=True)

    class Meta:
        model = models.Member
        exclude = ('vouchers', 'campaigntypes')
        depth = 2


class BasicMemberUSerializer(serializers.ModelSerializer):
    class Meta:
        model = models.Member
        exclude = ('last_login', 'mobile_no', 'username', 'password', 'registration_date', 'role', 'interestGroups',
                   'vouchers', 'dob')

    @except_validation_error
    def update(self, instance, validated_data):
        instance = super(BasicMemberUSerializer, self).update(instance, validated_data)
        # Member can get bonus points by binding emails
        #bind_email(validated_data, instance)
        # Member's supplementary information can get bonus points
        #supplement_info(validated_data, instance)
        # Reset this member's interest groups
        reset_interest(self.initial_data, instance)
        return instance

class DeletionMemberUSerializer(serializers.ModelSerializer):
    class Meta:
        model = models.Member
        exclude = ('last_login', 'mobile_no', 'username', 'password', 'registration_date', 'role', 'interestGroups',
                   'vouchers', 'dob','membership','campaigntypes','device_token')
class BasicMemberReadSerializer(serializers.ModelSerializer):
    membership_members = MembershipMemberSerializer(many=True, read_only=True)
    member_campaigntypes = Member_CampaignTypeSerializer(many=True, read_only=True)
    invicode_members = Voucher_MemberSerializer(many=True, read_only=True)
    points = Points_MemberSerializer(many=True, read_only=True)
    membership = MembershipSerializer(read_only=True)

    class Meta:
        model = models.Member
        exclude = ('password', 'vouchers', 'campaigntypes')
        depth = 2


class LoginVerifyCodeSerializer(serializers.Serializer):

    username = serializers.CharField(required=False)


    def __init__(self, *args, **kwargs):
        super(LoginVerifyCodeSerializer, self).__init__(*args, **kwargs)
        self.fields[models.Member.USERNAME_FIELD] = serializers.CharField(
            required=False
        )

    def create(self, validated_data):
        try:
            if validated_data.get('username'):
                user = models.Member.objects.get(username=validated_data.get('username'))
            else:
                if validated_data.get('mobile_no'):
                    user = models.Member.objects.get(mobile_no=validated_data.get('mobile_no'))
                else:
                    user=None
            #ret = user.check_password(validated_data.get('password'))
        except ObjectDoesNotExist as e:
            return models.Token.objects.none()
        if user:
            user.last_login = timezone.now()
            token, _ = models.Token.objects.get_or_create(user=user)
        else:
            token = models.Token()
        return token

class LoginSerializer(serializers.Serializer):
    password = serializers.CharField(
        required=True, style={'input_type': 'password'}
    )
    username = serializers.CharField(required=False)

    def __init__(self, *args, **kwargs):
        super(LoginSerializer, self).__init__(*args, **kwargs)
        self.fields[models.Member.USERNAME_FIELD] = serializers.CharField(
            required=False
        )

    def create(self, validated_data):
        try:
            if validated_data.get('username'):
                user = models.Member.objects.get(username=validated_data.get('username'))
            else:
                user = models.Member.objects.get(mobile_no=validated_data.get('mobile_no'))
            ret = user.check_password(validated_data.get('password'))
        except ObjectDoesNotExist as e:
            return models.Token.objects.none()
        if ret:
            user.last_login = timezone.now()
            token, _ = models.Token.objects.get_or_create(user=user)
        else:
            token = models.Token()
        return token


class LoginSerializer1(serializers.Serializer):
    password = serializers.CharField(
        required=True, style={'input_type': 'password'}
    )
    username = serializers.CharField(required=False)

    def __init__(self, *args, **kwargs):
        super(LoginSerializer, self).__init__(*args, **kwargs)
        self.fields[models.Member.USERNAME_FIELD] = serializers.CharField(
            required=False
        )

    def create(self, validated_data):
        try:
            if validated_data.get('email'):
                user = models.Member.objects.get(email=validated_data.get('email'))
            # else:
                # user = models.Member.objects.get(mobile_no=validated_data.get('mobile_no'))
            ret = user.check_password(validated_data.get('password'))
        except ObjectDoesNotExist as e:
            return models.Token.objects.none()
        if ret:
            user.last_login = timezone.now()
            token, _ = models.Token.objects.get_or_create(user=user)
        else:
            token = models.Token()
        return token


class RegisterSerializer(serializers.ModelSerializer):
    class Meta:
        model = models.Member
        fields = ('username', 'password',  'register_code')

    def create(self, validated_data):
        with transaction.atomic():
            #validated_data['username'] = validated_data.get('mobile_no')
            init_membership = get_initial_membership_level()
            if init_membership:
                validated_data['membership'] = init_membership
                role = models.Role.objects.get(name=2)
                validated_data['role'] = role
                instance = super(RegisterSerializer, self).create(validated_data)
                create_member(instance)
                return instance


class RegisterSerializer1(serializers.ModelSerializer):
    class Meta:
        model = models.Member
        fields = ('email', 'password', 'dob', 'mobile_no', "nick_name")

    def create(self, validated_data):
        with transaction.atomic():
            validated_data['username'] = validated_data.get('email')
            init_membership = get_initial_membership_level()
            if init_membership:
                validated_data['membership'] = init_membership
                role = models.Role.objects.get(name=2)
                validated_data['role'] = role
                instance = super(RegisterSerializer1, self).create(validated_data)
                create_member(instance)
                return instance
class GuestLoginSerializer(serializers.ModelSerializer):
    class Meta:
        model = models.Member
        fields = ('username', 'password',  'mobile_no', "nick_name","is_active",'is_guest','role','membership')
    '''
    def create(self, validated_data):
        with transaction.atomic():




                instance = super(GuestLoginSerializer, self).create(validated_data)
                #create_member(instance)
                return instance
    '''