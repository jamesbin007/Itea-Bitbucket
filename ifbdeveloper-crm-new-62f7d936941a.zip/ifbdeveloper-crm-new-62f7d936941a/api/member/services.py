from app01 import models
from django.conf import settings
from utils.utils import transaction_wrapper
from invicode.service import record_reward_member_invicode
from utils.message_manage import send_message_to_token
import datetime
import math
from django.db.models import Sum, Count,Q
from invicode.serializers import generate_random_str
from django.utils import timezone
@transaction_wrapper
def encrypted_or_reset_password(member, new_passwd):
    """encrypted password or reset password"""
    member.set_password(new_passwd)
    member.save()


@transaction_wrapper
def create_member(member):
    """Some passive business logic will be triggered by the creation of new members"""
    # 1.Encrypted password
    encrypted_or_reset_password(member, member.password)
    # 2.Free vouchers for this member membership level
    #TODO
    # free_vouchers = member.membership.complimentary_vouchers.all()
    # if free_vouchers:
    #     record_reward_member_voucher(member, free_vouchers)

@transaction_wrapper
def update_member_points(member, points_change, method, campaigntype=None, campaigntype_id=None):
    """Changes triggered by points change"""
    # 1.Record Points_Member
    '''
    if campaigntype:
        points_member = models.Points_Member.objects.create(member=member, points_number=points_change, method=method,
                                                            campaigntype=campaigntype)
    elif campaigntype_id:
        points_member = models.Points_Member.objects.create(member=member, points_number=points_change, method=method,
                                                            campaigntype_id=campaigntype_id)
    else:
        points_member = models.Points_Member.objects.create(member=member, points_number=points_change, method=method)
    '''
    points_member = models.Points_Member.objects.create(member=member, points_number=math.ceil(float(points_change)*100), method=method)
    # 2.Update member's points balance and total_points
    #member.points_bal += float(points_change)
    member.points_bal += math.ceil(float(points_change)*100)
    if points_member.method in (0, 1, 2):
        #member.total_points += float(points_change)
        member.total_points += math.ceil(float(points_change)*100)

    member.save()
    # 3.Upgrade membership
    desc_memberships = models.Membership.objects.order_by('-start_points').all()
    for membership in desc_memberships:
        if member.membership.start_points < membership.start_points <= member.total_points:
            update_membership(member, membership)
            break

@transaction_wrapper
def update_points(member, points_change, method, campaigntype=None, campaigntype_id=None):
    """Changes triggered by points change"""
    # 1.Record Points_Member
    pass
    '''
    if campaigntype:
        points_member = models.Points_Member.objects.create(member=member, points_number=points_change, method=method,
                                                            campaigntype=campaigntype)
    elif campaigntype_id:
        points_member = models.Points_Member.objects.create(member=member, points_number=points_change, method=method,
                                                            campaigntype_id=campaigntype_id)
    else:
        points_member = models.Points_Member.objects.create(member=member, points_number=points_change, method=method)
    # 2.Update member's points balance and total_points
    member.points_bal += points_change
    if points_member.method in (0, 1, 2):
        member.total_points += points_change
    elif points_member.method == 4:
        member.total_points = 0
    member.save()
    # 3.Upgrade membership
    desc_memberships = models.Membership.objects.order_by('-start_points').all()
    for membership in desc_memberships:
        if member.membership.start_points < membership.start_points <= member.total_points:
            update_membership(member, membership)
            break
    '''

@transaction_wrapper
def update_membership(member, new_membership):
    """Changes triggered by a member's membership level change"""
    # 1.Record and update Membership_Member
    member.membership_members.update(status=1)
    models.Membership_Member.objects.create(member=member, membership=new_membership, status=0)
    member.membership = new_membership
    member.save()
    if member.device_token:
        #pass
        send_message_to_token(member.device_token, 'Congratulations to upgrade', "You've upgraded to iTEA "+new_membership.name+'')
    # 2.Free vouchers for new membership level
    #free_vouchers = member.membership.complimentary_vouchers.all()
    free_vouchers = member.membership.reward_vouchers.all()
    if free_vouchers:
        record_reward_member_invicode(member, free_vouchers)


@transaction_wrapper
def bind_email(validated_data, member):
    """Member can get bonus points by binding emails"""
    if validated_data.get('email') and not models.Points_Member.objects.filter(member=member, method=1).exists():
        reward_points = settings.BINDING_EMAIL.get('reward_points')
        if reward_points:
            update_points(member, reward_points, 1)


@transaction_wrapper
def supplement_info(validated_data, member):
    """Member's supplementary information can get bonus points"""
    if not models.Points_Member.objects.filter(member=member, method=0).exists():
        reward_points = settings.SUPPLEMENT_INFO.get('reward_points')
        if reward_points:
            update_points(member, reward_points, 0)


@transaction_wrapper
def update_member_last_purchase_date(member, date):
    member.last_purchase_date = date
    member.save()

@transaction_wrapper
def deal_electric_sign(member, transObj):
    #signed prize list
    signed_prize_list=models.SignedPrize.objects.all().order_by('id')


    now_index=0
    global_index=0
    transDetails_top=models.SignedGlobalIndex.objects.filter(member__id=member.id,circle_status=False).order_by('-id').first()

    index_obj = models.SignedGlobalIndex.objects.filter(member=member, circle_status=False).order_by('-id').first()
    if transDetails_top:
            now_global_index=transDetails_top.id
            top_index_signed_obj=models.SignedOrderRecord.objects.filter(signed_global_index__id=now_global_index).order_by('-circle_index').first()
            if top_index_signed_obj:

                now_index=top_index_signed_obj.circle_index

    if index_obj:
        global_index=index_obj.id
    if transObj:
        transObj.inserted_signed_record=True
        transObj.save()
        #if trans use free up size or free drink voucher,then erase 1 times
        isCancelVoucher=False
        redeem_invicode = transObj.redeem_invicode
        if redeem_invicode!=0:
            invicode_obj=models.Invicode.objects.filter(id=redeem_invicode).first()
            if invicode_obj:
                voucher_obj=invicode_obj.voucher
                if voucher_obj:
                    if voucher_obj.id==292 or voucher_obj.id==295:
                        pass
                        #isCancelVoucher=True

        transDetails_list=models.TransactDetails.objects.filter(transaction__id=transObj.id).order_by('id')
        if isCancelVoucher:
            if transDetails_list and len(transDetails_list)>0:
                first_obj=transDetails_list.first()
                if first_obj:
                    first_obj.quantity=first_obj.quantity-1

        now_trans_item_count=0
        if transDetails_list:
            for detailsItem in transDetails_list:
                if detailsItem.transactDetails_type==0:
                    now_trans_item_count=now_trans_item_count+detailsItem.quantity
                    for i in range(detailsItem.quantity):
                        electronic_signed=False
                        circle_status = False
                        puzzle_image=None
                        signed_prize=None
                        prize_image_url=None
                        signed_prize_image_url=None
                        puzzle_image_url=None
                        signed_type=None
                        if now_index<12:
                            now_index+=1
                            if now_index==1:
                               index_obj= models.SignedGlobalIndex.objects.create(member=member,circle_status=False)
                               if index_obj:
                                   global_index=index_obj.id


                        else:
                            models.SignedGlobalIndex.objects.filter(id=global_index).update(circle_status=True)
                            models.SignedOrderRecord.objects.filter(signed_global_index__id=global_index).update(circle_status=True)
                            index_obj = models.SignedGlobalIndex.objects.create(member=member, circle_status=False)
                            if index_obj:
                                global_index = index_obj.id
                            now_index=1
                        circle_index = now_index
                        signed_prize_enable=False
                        if signed_prize_list:
                            for signed_prize_item in signed_prize_list:
                                if signed_prize_item:
                                    if now_index==signed_prize_item.index:
                                        signed_type=2
                                        signed_prize=signed_prize_item
                                        prize_image_url=signed_prize.img_url
                                        signed_prize_image_url=signed_prize.signed_img_url
                                        signed_prize_enable =True
                                        break

                        if not signed_prize_enable:
                            puzzle_times = getPuzzleTimes()
                            puzzle_probability = models.PuzzleProbability.objects.filter(rand_number=puzzle_times).first()
                            if puzzle_probability:
                                puzzle_item_count=0
                                puzzle_item = puzzle_probability.puzzle_image
                                puzzle_count=models.PuzzleImageLog.objects.filter(puzzle_image__id=puzzle_item.id).aggregate(count=Count('id'))
                                if puzzle_count:
                                    puzzle_item_count=puzzle_count['count']
                                #limit max puzzle quantity
                                if puzzle_item.max_quantity>puzzle_item_count:
                                    signed_type = 1
                                    puzzle_image = puzzle_item
                                    puzzle_image_url=puzzle_item.img_url

                                else:
                                    signed_type = 0
                                    #set puzzle item status
                                    models.PuzzleImage.objects.filter(id=puzzle_item.id).update(status=False)
                                    #delete puzzle probability item
                                    models.PuzzleProbability.objects.filter(puzzle_image__id=puzzle_item.id).delete()
                            else:
                                signed_type = 0
                        signed_record_obj=models.SignedOrderRecord.objects.create(signed_global_index_id=global_index,member=member,transaction=transObj,electronic_signed=electronic_signed,signed_type=signed_type,puzzle_image=puzzle_image,signed_prize=signed_prize,prize_image_url=prize_image_url,circle_status=circle_status,circle_index=now_index,signed_prize_image_url=signed_prize_image_url,puzzle_image_url=puzzle_image_url)
                        if signed_type == 1:
                            models.PuzzleImageLog.objects.create(member=member, puzzle_image=puzzle_image,puzzle_image_url=puzzle_image_url,signed_order_record_id=signed_record_obj.id)
        if member:
            auto_signed(member.id)
            if member.device_token:
                #pass
                #if member.id==881:
                if now_trans_item_count>0:
                    pass
                    #send_message_to_token(member.device_token, 'iTea electronic stamp', 'Order confirmed,stamp signed' )
@transaction_wrapper
def auto_signed(member_id):
    obj_list = models.SignedOrderRecord.objects.filter(member__id=member_id, electronic_signed=False)

    if obj_list:
        transaction_id_list = []
        for obj in obj_list:
            if obj:
                transaction_id_list.append(obj.transaction.id)
                obj.electronic_signed = True
                obj.save()
                # modify global index status
                signed_item_count_dict = models.SignedOrderRecord.objects.filter(member__id=member_id,
                                                                                 electronic_signed=True,
                                                                                 signed_global_index__id=obj.signed_global_index.id).aggregate(
                    count=Count('id'))
                if signed_item_count_dict:
                    signed_item_count = signed_item_count_dict['count']
                    if signed_item_count == 12:
                        models.SignedGlobalIndex.objects.filter(id=obj.signed_global_index.id).update(
                            all_signed=True)
                if obj.signed_type == 1:
                    models.PuzzleImageLog.objects.filter(signed_order_record__id=obj.id).update(status=True)
                if obj.signed_type == 2:
                    signed_prize = obj.signed_prize
                    if signed_prize:
                        models.Invicode.objects.create(
                            **{'voucher': signed_prize.voucher, 'code': generate_random_str(), 'status': 1,
                               'member_id': member_id, 'register_date': timezone.make_aware(datetime.datetime.now(), timezone=timezone.get_current_timezone()), 'vaild_days': 360,
                               'expire_date':  datetime.datetime.now().date() + datetime.timedelta(days=360)  })
        # modify transaction signed flag
        if transaction_id_list:
            temp_list = list(set(transaction_id_list))
            if temp_list:
                models.Transaction.objects.filter(member__id=member_id, transaction_status__in=(4, 5),
                                                  id__in=tuple(temp_list)).update(signed=True)
@transaction_wrapper
def getPuzzleTimes():
    recent_times = 1
    puzzle_times_cache = models.PuzzleTimesCache.objects.first()
    if puzzle_times_cache:
        now_date = puzzle_times_cache.now_date
        if now_date:
            if now_date == datetime.datetime.now().date():
                recent_times = puzzle_times_cache.puzzle_times + 1
                puzzle_times_cache.puzzle_times = recent_times


                puzzle_times_cache.save()
            else:
                recent_times = 1
                puzzle_times_cache.now_date = datetime.datetime.now().date()
                puzzle_times_cache.puzzle_times = 1

                puzzle_times_cache.save()
        else:
            recent_times = 1
            puzzle_times_cache.now_date = datetime.datetime.now().date()
            puzzle_times_cache.puzzle_times = 1

            puzzle_times_cache.save()


    else:

        recent_times = 1

        models.PuzzleTimesCache.objects.create(puzzle_times=recent_times, now_date=datetime.datetime.now().date())

    mod_100 = recent_times % 100
    # exact query puzzle times
    query_rand_number = 0
    if mod_100 == 0:
        query_rand_number = 100
    else:
        query_rand_number = mod_100
    return  query_rand_number