from django.urls import path, include, re_path
from rest_framework.routers import DefaultRouter
from . import views
from django.conf.urls import url
from rest_framework_simplejwt.views import token_obtain_pair,token_refresh #jwt token
#test


member_router = DefaultRouter()
member_router.register('signed_record', views.SignedOrderRecordViewSet, base_name='signed_record')
member_router.register('member_points', views.PointsMemberViewSet, base_name='member_points')
member_router.register('member_reward', views.MemberRewardViewSet, base_name='member_reward')
member_router.register('member_signed', views.SignedOrderRecordViewSet, base_name='member_signed')
member_router.register('member_signed_list', views.SignedGlobalIndexViewSet, base_name='member_signed_list')
member_router.register('new_user_rewards', views.New_User_RewardsViewSet, base_name='new_user_rewards')
member_router.register('member_fake_signed_list', views.FakeSignedGlobalIndexViewSet, base_name='member_fake_signed_list')

#member_router.register('delete_account', views.DeletionViewSet, base_name='delete_account')
member_router.register('', views.MemberViewSet)

urlpatterns = [
    path('otp/', views.otp, name='otp'),
    path('obtaintoken/', views.MyTokenObtainPairView.as_view(), name='login_token'),
    #path('obtaintoken/', token_obtain_pair, name='login_token'),
    path('refreshtoken/', token_refresh, name='refresh_token'),
    path('login_verify_code/', views.LoginView_verify_code.as_view(), name="login_verify_code"),
    path('payment_code/', views.PaymentCodeViewSet.as_view(), name="payment_code"),
    path('guest_login/', views.GuestLoginView.as_view(), name="guest_login"),
    path('login/', views.LoginView.as_view(), name="login"),
    path('addDevice_token/', views.addDevice_token, name="addDevice_token"),
    path('send_message/', views.send_message, name="send_message"),
    path('crm_login/', views.LoginView_CRM.as_view(), name="crm_login"),
    path('register/', views.NewRegisterView.as_view(), name="register"),
    path('profile/', views.MemberMobileViewSet.as_view({'get': 'list'}), name="profile"),
    #path('modpass/', views.ModifyPassView.as_view(), name="modpass"),
    path('modpass/', views.modPass, name="modpass"),
    path('send_push_message/', views.sendPushMessage, name="send_push_message"),
    path('modUserinfo/', views.modUserinfo, name="modUserinfo"),
    path('update_payment_code/', views.update_payment_code, name="update_payment_code"),
    path('reset_payment_code/', views.reset_payment_code, name="reset_payment_code"),
    path('check_payment_code/', views.check_payment_code, name="check_payment_code"),
    path('set_secure_payment/', views.set_secure_payment, name="set_secure_payment"),
    path('visit/', views.visit, name="visit"),
    path('check/', views.CheckRegisterView.as_view(), name="check_reg"),
    path('check_invite_code/', views.check_invite_code, name="check_invite_code"),
    path('get_member_count/', views.get_member_count, name="get_member_count"),
    path('get_pass/', views.get_pass, name="get_pass"),
    path('mod_post_code/', views.mod_post_code, name="mod_post_code"),
    path('memberExisted/', views.memberExisted, name="memberExisted"),
    path('invitation_reward/', views.invitation_reward, name="invitation_reward"),
    path('signed_order/', views.signed_order, name="signed_order"),
    path('puzzle/', views.puzzle, name="puzzle"),
    path('new_member_fake_signed_list/', views.new_member_fake_signed_list, name="new_member_fake_signed_list"),
    path('change_mobile_to_new_mobile/', views.change_mobile_to_new_mobile, name="change_mobile_to_new_mobile"),
    path('delete_account/', views.delete_account, name="delete_account"),
    path('send_mail_code/', views.send_mail_code, name="send_mail_code"),
    path('login_by_password/', views.LoginView_by_password.as_view(), name="login_by_password"),
    path('login_by_code/', views.LoginView_by_code.as_view(), name="login_by_code"),
    path('reset_password/', views.reset_password, name="reset_password"),
    path('new_otp/', views.new_otp, name='new_otp'),
    path('check_by_otp/', views.LoginView_by_otp.as_view(), name="check_by_otp"),
    path('check_by_email_otp/', views.LoginView_by_email_otp.as_view(), name="check_by_email_otp"),
    re_path('card/', include('card.urls')),


    path('', include(member_router.urls)),
]
