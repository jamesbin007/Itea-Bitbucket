from rest_framework import viewsets
from rest_framework import generics
from rest_framework import status
from rest_framework.permissions import AllowAny
from rest_framework.response import Response
from app01 import models
from . import serializers
from utils.pagination import DefaultPagination
from .permissions import MemberViewSetPermission
from rest_framework.filters import SearchFilter, OrderingFilter
from django_filters.rest_framework import DjangoFilterBackend
from django_filters import rest_framework as filters
from django_filters import Filter
from django_filters.fields import Lookup
from django.db import connection
from invicode.service import record_reward_member_invicode
from django.contrib.auth.hashers import make_password,check_password
from rest_framework.mixins import UpdateModelMixin
from rest_framework.mixins import ListModelMixin
from rest_framework.decorators import api_view,authentication_classes,permission_classes
from invicode import utils
from django.db import transaction
import time
from django.db.models import Q
import datetime
from django.utils import timezone
from utils.message_manage import send_message_to_token
from wallet.serializers import WalletSimpleSerializer,RechargeRecordCreateSerializer
from .services import   update_member_points
from api.settings import SUPPLEMENT_INFO
import copy
from invicode.serializers import generate_random_str
from django.db.models import Sum, Count,Q
from django.http import HttpResponseRedirect
from .serializers import PuzzleImageLogSerializer
from aliyunsdkcore.client import AcsClient
from aliyunsdkcore.request import CommonRequest
import json
import random
from rest_framework_simplejwt.serializers import TokenObtainPairSerializer
from rest_framework_simplejwt.views import TokenObtainPairView
import requests
from api.settings import TOKEN_EXPIRE_TIME
from utils.auth import CustomAuthentication
import threading
class IntegerListFilter(Filter):
    def filter(self,qs,value):
     if value not in (None,''):
      integers = [int(v) for v in value.split(',')]
      return qs.filter(**{'%s__%s'%(self.field_name, self.lookup_expr):integers})
class ListFilter(Filter):
    def filter(self, qs, value):
        if value not in (None,''):
            value_list = value.split(u',')
            return super(ListFilter, self).filter(qs, Lookup(value_list, 'in'))
        else:
            return qs
class SignedOrderRecordFilter(filters.FilterSet):
    member = filters.CharFilter(field_name="member", lookup_expr='exact')
    electronic_signed = filters.CharFilter(field_name='electronic_signed',lookup_expr='exact')
    circle_status= filters.CharFilter(field_name='circle_status',lookup_expr='exact')
    class Meta:
        model = models.SignedOrderRecord
        fields = (
            'member', 'electronic_signed','circle_status', )

class PointsFilter(filters.FilterSet):
    member = filters.CharFilter(field_name="member", lookup_expr='exact')
    method = IntegerListFilter(field_name='method',lookup_expr='in')
    class Meta:
        model = models.Points_Member
        fields = (
            'member', 'method', )
class RewardsFilter(filters.FilterSet):
    points = filters.CharFilter(field_name="points", lookup_expr='gte')
    status=filters.CharFilter(field_name="status", lookup_expr='exact')
    class Meta:
        model = models.Member_Reward
        fields = (
            'points','status',  )
class SignedOrderRecordFilter(filters.FilterSet):
    member = filters.CharFilter(field_name="member", lookup_expr='exact')
    signed_type = filters.CharFilter(field_name="signed_type", lookup_expr='exact')
    electronic_signed = filters.CharFilter(field_name="electronic_signed", lookup_expr='exact')
    circle_status= filters.CharFilter(field_name="circle_status", lookup_expr='exact')
    class Meta:
        model = models.SignedOrderRecord
        fields = (
            'member', 'signed_type', 'electronic_signed', 'circle_status', )
class SignedGlobalIndexFilter(filters.FilterSet):
    member = filters.CharFilter(field_name="member", lookup_expr='exact')

    all_signed = filters.CharFilter(field_name="all_signed", lookup_expr='exact')
    circle_status= filters.CharFilter(field_name="circle_status", lookup_expr='exact')
    class Meta:
        model = models.SignedGlobalIndex
        fields = (
            'member',  'all_signed', 'circle_status', )

class MemberFilter(filters.FilterSet):
    member_id=filters.CharFilter(field_name="id", lookup_expr='exact')
    race = ListFilter(field_name="race", lookup_expr='icontains')
    race_exclude = ListFilter(field_name="race", lookup_expr='icontains', exclude=True)
    membership_name = ListFilter(field_name="membership__name", lookup_expr='icontains')
    membership_name_exclude = ListFilter(field_name="membership__name", lookup_expr='icontains', exclude=True)
    min_registration_date = filters.DateTimeFilter(field_name="registration_date", lookup_expr='gte')
    max_registration_date = filters.DateTimeFilter(field_name="registration_date", lookup_expr='lte')
    min_last_purchase_date = filters.DateTimeFilter(field_name="last_purchase_date", lookup_expr='gte')
    max_last_purchase_date = filters.DateTimeFilter(field_name="last_purchase_date", lookup_expr='lte')

    class Meta:
        model = models.Member
        fields = ('member_id',
            'mobile_no', 'race', 'race_exclude', 'membership_name', 'membership_name_exclude', 'min_registration_date',
            'max_registration_date',
            'min_last_purchase_date',
            'max_last_purchase_date')


class MemberMobileViewSet(viewsets.ModelViewSet):
    permission_classes = (MemberViewSetPermission,)
    queryset = models.Member.objects.all()
    serializer_class = serializers.MemberMobileSerializer
    pagination_class = DefaultPagination
    filter_backends = (
        DjangoFilterBackend,
        SearchFilter,
        OrderingFilter,
    )
    filter_class = MemberFilter
    search_fields = ('mobile_no',)

    def get_queryset(self):

        if self.request.user.role.name not in (0, 1):
            self.queryset = self.queryset.filter(pk=self.request.user.pk)
        return super(MemberMobileViewSet, self).get_queryset()
@api_view(['GET', 'POST'])
@authentication_classes([CustomAuthentication,])
@permission_classes((AllowAny,))
def delete_account(request, *args, **kwargs):
    member_id = request.GET.get('member_id')
    #verify_code = request.GET.get('verify_code')
    pk = request.user.pk
    member=models.Member.objects.filter(id=pk).first()
    if not member:
        return Response({
            'msg': 'member is not exits'
        }, status=status.HTTP_200_OK)
    '''
    if verify_code and verify_code != "":
        if verify_code and not checkOtp('65' + str(member.mobile_no), verify_code):
            return Response({
                'msg': 'verify code error'
            }, status=status.HTTP_200_OK)
    else:

            return Response({
                'msg': 'verify code is null'
            }, status=status.HTTP_200_OK)
    '''
    if str(pk) == member_id:
        member = models.Member.objects.filter(pk=pk).first()
        if member:
            member.status = 1
            member.delete_time = datetime.datetime.now()
            member.save()
    else:
        return Response({
            'msg': 'Only the accounts of authenticated users can be deleted'
        }, status=status.HTTP_200_OK)
    return Response({
        'msg': 'success'
    }, status=status.HTTP_200_OK)
@api_view(['GET', 'POST'])
@authentication_classes([])
@permission_classes((AllowAny,))
def change_mobile_to_new_mobile(request, *args, **kwargs):

    return Response({
        'msg': 'ok'
    }, status=status.HTTP_200_OK)

    new_mobile = request.data.get('new_mobile')
    old_mobile = request.data.get('old_mobile')
    if new_mobile and old_mobile:
        old_member=models.Member.objects.filter(mobile_no=old_mobile).first()
        new_member=models.Member.objects.filter(mobile_no=new_mobile).first()
        with transaction.atomic():
            if old_member and new_member:
                points_bal=old_member.points_bal
                total_points=old_member.total_points
                membership_id=old_member.membership.id
                new_member.points_bal=new_member.points_bal+points_bal
                new_member.total_points=new_member.total_points+total_points
                new_member.membership_id=membership_id
                new_member.save()
                old_member.points_bal=0
                old_member.total_points=0
                old_member.membership_id=1
                old_member.save()
                old_wallet=models.Wallet.objects.filter(member__id=old_member.id).first()
                new_wallet=models.Wallet.objects.filter(member__id=new_member.id).first()
                new_wallet.balance=new_wallet.balance+old_wallet.balance
                new_wallet.save()
                old_wallet.balance=0
                old_wallet.save()
                models.SignedGlobalIndex.objects.filter(member__id=old_member.id).update(member_id=new_member.id)
                models.SignedOrderRecord.objects.filter(member__id=old_member.id).update(member_id=new_member.id)
                models.Invicode.objects.filter(member__id=old_member.id,status=1).update(member_id=new_member.id)
                return Response({
                    'msg': 'ok'
                }, status=status.HTTP_200_OK)
    return Response({
        'msg': 'error'
    }, status=status.HTTP_200_OK)
@api_view(['GET', 'POST'])
@authentication_classes([])
@permission_classes((AllowAny,))
def modUserinfo(request, *args, **kwargs):
    id=request.data.get('member_id')
    username = request.data.get('username')
    gender=request.data.get('gender')
    mail=request.data.get('mail')
    dob = request.data.get('dob')
    new_mobile = request.data.get('new_mobile')
    print(new_mobile)
    member=models.Member.objects.get(id=id)
    verify_code = request.data.get('verify_code')
    if verify_code and verify_code != "":
        if mail and mail!="":

            if verify_code and not checkOtp(str(mail), verify_code):
                return Response({
                    'msg': 'verify code error'
                }, status=status.HTTP_200_OK)
        elif  new_mobile and new_mobile!="":
            if verify_code and not checkOtp('65'+ str(new_mobile), verify_code):
                return Response({
                    'msg': 'verify code error'
                }, status=status.HTTP_200_OK)
    temp_member=None
    if(member):
        with transaction.atomic():

            if(username and username!=''):
                member.name=username
            if (gender and gender!='-1'):
                member.is_active = gender

            if (mail and mail!=''):
                member.email = mail
                member.username =mail
                member_new = models.Member.objects.filter(Q(username=mail) | Q(email=mail)).first()
                if member_new:
                    return Response({
                        'id': member.id,
                        'mobile_no': member.mobile_no,
                        'is_active': member.is_active,
                        'name': member.name,
                        'email': member.email,
                        'dob': member.dob,
                        'status': 'mail already exists',
                    }, status=status.HTTP_201_CREATED)
            if (dob and dob!=''):
                if (member.dob and member.dob!=''):
                    return Response({
                        'id': member.id,
                        'mobile_no': member.mobile_no,
                        'is_active': member.is_active,
                        'name': member.name,
                        'email': member.email,
                        'dob': member.dob,
                        'status': 'Date of birthday only modify once',
                    }, status=status.HTTP_201_CREATED)
                #reward points
                if  not models.Points_Member.objects.filter(member=member, method=0).exists():
                    update_member_points(member, SUPPLEMENT_INFO['reward_points'], 0, campaigntype=None, campaigntype_id=None)
                member.dob = dob
                # birthday voucher
                dob_date = datetime.datetime.strptime(dob, "%Y-%m-%d")
                if dob_date:
                    #if dob_date.month==datetime.datetime.now().month and dob_date.day==datetime.datetime.now().day:
                    for i in range(8):
                        if dob_date.month==(datetime.datetime.now()+datetime.timedelta(days=i)).month and dob_date.day==(datetime.datetime.now()+datetime.timedelta(days=i)).day:


                            vouchers = member.membership.birthday_vouchers.all()
                            #member.reward_birthday_voucher_date = datetime.datetime.now().date()
                            member.reward_birthday_voucher_date = (datetime.datetime.now()+datetime.timedelta(days=i)).date()

                            record_reward_member_invicode(member, vouchers, 'birthday')
                            break
            if (new_mobile and new_mobile!=''):
                member_new = models.Member.objects.filter(mobile_no=new_mobile).first()
                if member_new:
                    return Response({
                        'id': member.id,
                        'mobile_no': member.mobile_no,
                        'is_active': member.is_active,
                        'name': member.name,
                        'email': member.email,
                        'dob': member.dob,
                        'status': 'mobile number already exists',
                    }, status=status.HTTP_201_CREATED)
                #temp_member = copy.copy(member)
                member.last_phone_number=member.mobile_no
                member.mobile_no=new_mobile
                if member.username and member.username.isdigit():
                    member.username=new_mobile



            member.save()
            if temp_member:
                invite_code_obj = models.Invite_Code.objects.filter(activate_status=False).first()
                if invite_code_obj:
                    temp_member.invite_code = invite_code_obj.invite_code

                    invite_code_obj.activate_status = True
                    invite_code_obj.save()
                member_ship_obj=models.Membership.objects.all().order_by('id').first()
                nick_name = random_pass(20)
                password = make_password(member.nick_name)

                backup_member_obj=models.Member.objects.create(mobile_no=temp_member.mobile_no,username=temp_member.username,membership=member_ship_obj,role_id=3,points_bal=0,total_points=0,invite_code=temp_member.invite_code,reward_birthday_voucher_date=temp_member.reward_birthday_voucher_date,is_active = 1,nick_name=nick_name,password=password)
                serializer1 = WalletSimpleSerializer(
                    data={'balance': 0, 'member': backup_member_obj.id})
                if serializer1.is_valid():
                     models.Wallet.objects.create(**serializer1.validated_data)
        return  Response({
                    'id': member.id,
                    'mobile_no': member.mobile_no,
                    'is_active': member.is_active,
                    'name': member.name,
                    'email': member.email,
                    'dob': member.dob,
                    'status': 'ok',
                }, status=status.HTTP_201_CREATED)

class SignedOrderRecordViewSet(viewsets.ModelViewSet):
    permission_classes = (MemberViewSetPermission,)
    queryset = models.SignedOrderRecord.objects.all().order_by('circle_index')
    serializer_class = serializers.SignedOrderRecordSerializer
    pagination_class = DefaultPagination
    filter_backends = (
        DjangoFilterBackend,
        SearchFilter,
        OrderingFilter,
    )
    filter_class = SignedOrderRecordFilter


    def get_queryset(self):

        return super(SignedOrderRecordViewSet, self).get_queryset()


class MemberViewSet(viewsets.ModelViewSet):
    permission_classes = (MemberViewSetPermission,)
    queryset = models.Member.objects.all()
    serializer_class = serializers.FullMemberCUSerializer
    pagination_class = DefaultPagination
    filter_backends = (
        DjangoFilterBackend,
        SearchFilter,
        OrderingFilter,
    )
    filter_class = MemberFilter
    search_fields = ('mobile_no',)

    def get_queryset(self):
        self.queryset = self.queryset.prefetch_related(
            'role',
            'membership',
            #'points',
            #'invicode_members',
            #'membership_members',
            #'membership__complimentary_vouchers',
            #'membership__birthday_vouchers',
            #'member_campaigntypes',
            #'interestGroups',
        )
        if self.request.user.role.name not in (0, 1):
            self.queryset = self.queryset.filter(pk=self.request.user.pk)
        return super(MemberViewSet, self).get_queryset()

    def get_serializer_class(self):
        if self.request.method == 'GET':
            if self.request.user.role.name in (0, 1):
                return serializers.FullMemberReadSerializer
            else:
                return serializers.BasicMemberReadSerializer
        else:
            if self.request.user.role.name in (0, 1):
                return super(MemberViewSet, self).get_serializer_class()
            else:
                return serializers.BasicMemberUSerializer

class DeletionViewSet(viewsets.ModelViewSet):
    permission_classes = (MemberViewSetPermission,)
    queryset = models.Member.objects.all()
    serializer_class = serializers.DeletionMemberUSerializer
    pagination_class = DefaultPagination
    filter_backends = (
        DjangoFilterBackend,
        SearchFilter,
        OrderingFilter,
    )
    filter_class = MemberFilter
    search_fields = ('mobile_no',)

    def get_queryset(self):

        if self.request.user.role.name not in (0, 1):
            pk = self.request.user.pk

            member_id=self.request.GET.get('member_id')

            if str(pk)==member_id:
                member=models.Member.objects.filter(pk=pk).first()
                if member:

                    member.status=1
                    member.delete_time=datetime.datetime.now()
                    member.save()

                self.queryset = self.queryset.filter(pk=pk)
            else:
                self.queryset = self.queryset.filter(pk=-1)
        else:
            self.queryset = self.queryset.filter(pk=-1)
        return super(DeletionViewSet, self).get_queryset()




class LoginView(generics.GenericAPIView):
    authentication_classes = ()
    permission_classes = (AllowAny,)
    serializer_class = serializers.LoginSerializer

    def post(self, request, *args, **kwargs):
        serializer = self.get_serializer(data=request.data)
        serializer.is_valid(raise_exception=True)
        token = serializer.save()
        mobile_no = request.data.get("username")
        # 修改，返回wallet_id
        member = models.Member.objects.filter(mobile_no__contains=mobile_no)
        wallet_id = 0
        if member:
            device_token=member[0].device_token
            member_id = member[0].id
            wallet = models.Wallet.objects.filter(member_id=member[0].id)
            if wallet:
                wallet_id = wallet[0].id


        #content = 'User Mobile:' + request.data.get('mobile_no') + '\n register time:' + str(time.strftime("%Y-%m-%d %H:%M:%S", time.localtime()))
        #print(content)
        #utils.send_register_email("ziyiw2019@gmail.com", content, send_type="register")
        if not token:
            return Response({'msg': 'username is not exist'}, status=status.HTTP_401_UNAUTHORIZED)
        if not token.pk:
            return Response({'msg': 'wrong user name or password'}, status=status.HTTP_401_UNAUTHORIZED)
        else:
            response = Response({'token': token.key, 'wallet_id': wallet_id,'member_id':member_id,'device_token':device_token})
            #response = Response({'token': token.key})
            # response.setdefault('Authorization', 'Token {auth_token}'.format(auth_token=token.key))
            # response.set_cookie(
            #     'Authorization',
            #     value='Token {auth_token}'.format(auth_token=token.key),
            #     httponly=True
            # )
            return response

class GuestLoginView(generics.GenericAPIView):
    authentication_classes = ()
    permission_classes = (AllowAny,)
    serializer_class = serializers.GuestLoginSerializer

    def post(self, request, *args, **kwargs):


            mobile_no = request.data.get("username")
            if not mobile_no:
                mobile_no=creat_guest_username()


            # 修改，返回wallet_id
            member = models.Member.objects.filter(username__iexact=mobile_no)
            wallet_id = 0
            if member:
                device_token=member[0].device_token

                member_id = member[0].id
                member_username=member[0].username
                member_mobile=member[0].mobile_no
                wallet = models.Wallet.objects.filter(member_id=member[0].id)
                if wallet:
                    wallet_id = wallet[0].id
            else:
                with transaction.atomic():
                    role=models.Role(3)
                    membership=models.Membership(1)
                    n_password=random_pass(20)
                    password=make_password(n_password)
                    member_obj={'mobile_no':mobile_no,'username':mobile_no,'nick_name':n_password,'password':password,'role':role,'membership':membership,'is_active':1,'is_guest':1}

                    member = models.Member(**member_obj)
                    member.save()









                if member:

                    r_response = requests.post('http://localhost:8018/api/v1/member/obtaintoken/', headers={}, data={'username':member.username,'password':member.nick_name})

                    return Response(json.loads(r_response.text))



            if  member:

                r_response = requests.post('http://localhost:8018/api/v1/member/obtaintoken/', headers={},data={'username': member[0].username, 'password': member[0].nick_name})

                response=Response(json.loads(r_response.text))

                return response


class LoginView_verify_code(generics.GenericAPIView):
    authentication_classes = ()
    permission_classes = (AllowAny,)
    serializer_class = serializers.LoginVerifyCodeSerializer
    def get_serializer_class(self):
        mobile_no = self.request.data.get("username")
        if not mobile_no:
            mobile_no = self.request.data.get("mobile_no")
        # 修改，返回wallet_id
        member = models.Member.objects.filter(mobile_no__contains=mobile_no)
        if member:
            return super(LoginView_verify_code, self).get_serializer_class()
        else:
            return   serializers.RegisterSerializer
    def post(self, request, *args, **kwargs):
        #with transaction.atomic():
            #serializer = self.get_serializer(data=request.data)
            #serializer.is_valid(raise_exception=True)
            #token = serializer.save()

            mobile_no = request.data.get("username")
            if not mobile_no:
                mobile_no=request.data.get("mobile_no")
            #check otp
            verify_code = request.data.get("verify_code")
            #test account for android app update
            if mobile_no=='88888888':
                pass
            else:
                if verify_code and  not checkOtp('65'+mobile_no,verify_code):
                    return Response({
                        'msg': 'verify code error'
                    }, status=status.HTTP_200_OK)

            # 修改，返回wallet_id
            member = models.Member.objects.filter(mobile_no__contains=mobile_no)
            wallet_id = 0
            if member:
                device_token=member[0].device_token
                #print(member[0].device_token)
                member_id = member[0].id
                member_username=member[0].username
                member_mobile=member[0].mobile_no
                wallet = models.Wallet.objects.filter(member_id=member[0].id)
                if wallet:
                    wallet_id = wallet[0].id
            else:
                with transaction.atomic():
                    if (request.data.get('register_code')):
                        memberList = models.Member.objects.filter(invite_code=request.data.get('register_code'))
                        if memberList:
                            member1=memberList[0]
                            # print(member)
                            if member1:
                                #bind invitation_code voucher

                                pass
                            else:
                                return Response({
                                    'msg': 'invite code error'
                                }, status=status.HTTP_200_OK)
                        else:
                            return Response({
                                'msg': 'invite code error'
                            }, status=status.HTTP_200_OK)
                    post_data = dict(request.POST.lists())
                    if  'mobile_no' in post_data.keys():
                        serializer = self.get_serializer(data=request.data)
                    else:
                         member_obj={'mobile_no':mobile_no,'username':mobile_no,'password':'!ijdkfdfeke','register_code':request.data.get('register_code')}
                         serializer = self.get_serializer(data=member_obj)
                    #serializer = self.get_serializer(data=request.data)

                    serializer.is_valid(raise_exception=True)
                    member = serializer.save()
                    #tempory password from jwt token
                    member.nick_name=random_pass(20)
                    member.password=make_password(member.nick_name)
                    member.is_active=1
                    member.save()
                    if request.data.get('register_code')=='':
                        register_use_invitation='none'
                    else:
                        register_use_invitation=request.data.get('register_code')
                    content = 'User Mobile:' + request.data.get('username') + '\n register time:' + str(
                        time.strftime("%Y-%m-%d %H:%M:%S", time.localtime()))+'\n invitation code:'+register_use_invitation
                    #print(content)
                    #utils.send_register_email(utils.RECEIVE_MAIL, content, send_type="register")


                    if member:
                        campaign_register = models.Campaign_Register.objects.first()

                        if campaign_register and campaign_register.activity_status:
                            member_wallet = models.Wallet.objects.get(member__id=member.id)
                            if member_wallet is None:
                                serializer = WalletSimpleSerializer(data={'balance': 0, 'member': member.id})
                                if serializer.is_valid():
                                    member_wallet1 = models.Wallet.objects.create(**serializer.validated_data)
                                    if campaign_register.register_cash_back > 0:
                                        member_wallet1.balance += campaign_register.register_cash_back
                                        member_wallet1.save()
                                        serializer2 = RechargeRecordCreateSerializer(
                                            data={'money': campaign_register.register_cash_back,
                                                  'wallet': member_wallet1.id, 'type': 3})
                                        if serializer2.is_valid():
                                            models.RechargeRecord.objects.create(**serializer2.validated_data)
                            else:
                                if campaign_register.register_cash_back > 0:
                                    member_wallet.balance += campaign_register.register_cash_back
                                    member_wallet.save()
                                    serializer2 = RechargeRecordCreateSerializer(
                                        data={'money': campaign_register.register_cash_back,
                                              'wallet': member_wallet.id, 'type': 3})
                                    if serializer2.is_valid():
                                        models.RechargeRecord.objects.create(**serializer2.validated_data)
                                else:
                                    reg_voucherObj = campaign_register.voucher
                                    if reg_voucherObj:
                                        cursor = connection.cursor()
                                        cursor.execute(
                                            "select * from app01_invicode where voucher_id = %s and  status=0 limit 1" % reg_voucherObj.id)
                                        row2 = cursor.fetchall()
                                        if row2:
                                            invicode_id = row2[0][0]
                                            #invicode
                                            invicode_obj=models.Invicode.objects.filter(id=invicode_id).first()
                                            invicode_expire_date=reg_voucherObj.expiring_date
                                            if invicode_obj:

                                                if invicode_obj.vaild_days and invicode_obj.vaild_days > 0:
                                                    v_days = invicode_obj.vaild_days - 1
                                                    now_expire_date =datetime.datetime.now().date()+ datetime.timedelta(days=v_days)
                                                    if now_expire_date >= reg_voucherObj.expiring_date:

                                                        invicode_expire_date = reg_voucherObj.expiring_date
                                                    else:
                                                        invicode_expire_date = now_expire_date

                                                else:
                                                    invicode_expire_date =reg_voucherObj.expiring_date


                                            sql = "update app01_invicode set status=1 ,member_id=%s,register_date='%s',expire_date='%s' where id=%s" % (
                                            member.id, datetime.datetime.now(),invicode_expire_date, invicode_id)
                                            #print(sql)

                                            cursor.execute(sql)

                        invite_code_obj = models.Invite_Code.objects.filter(activate_status=False).first()
                        if invite_code_obj:
                            member.invite_code = invite_code_obj.invite_code
                            member.save()
                            invite_code_obj.activate_status = True
                            invite_code_obj.save()
                            # post_data = dict(request.POST.lists())
                            # print(request.data.get('mobile_no'))
                            # print(post_data.keys())

                            # if 'register_code' in post_data.keys() and request.data.get('register_code') is not None and request.data.get('register_code')!='':
                            if request.data.get('register_code') is not None and request.data.get('register_code') != '':
                                invite_member_f = models.Member.objects.filter(invite_code=request.data.get('register_code'))
                                if invite_member_f:
                                    invite_member=invite_member_f[0]
                                    if invite_member.invite_count is not None:
                                        invite_member.invite_count = invite_member.invite_count + 1
                                    else:
                                        invite_member.invite_count = 1
                                    invite_member.save()
                                    # invitation campaign
                                    campaign_invitation = models.Campaign_Invitation_Code.objects.first()
                                    if campaign_invitation and campaign_invitation.activity_status:
                                        invitation_times = campaign_invitation.invitation_times
                                        if invitation_times and invite_member.invite_count >= invitation_times:
                                            # register cash back
                                            # voucher
                                            voucherObj = campaign_invitation.voucher
                                            if voucherObj:
                                                cursor = connection.cursor()
                                                cursor.execute("select * from app01_invicode where voucher_id = %s and  status=0 limit 1" % voucherObj.id)
                                                row2 = cursor.fetchall()
                                                if row2:
                                                    invicode_id=row2[0][0]
                                                    #add expire date
                                                    invicode_obj = models.Invicode.objects.filter(id=invicode_id).first()
                                                    invicode_expire_date = voucherObj.expiring_date
                                                    if invicode_obj:

                                                        if invicode_obj.vaild_days and invicode_obj.vaild_days > 0:
                                                            v_days = invicode_obj.vaild_days - 1
                                                            now_expire_date = datetime.datetime.now().date() + datetime.timedelta(
                                                                days=v_days)
                                                            if now_expire_date >= voucherObj.expiring_date:

                                                                invicode_expire_date = voucherObj.expiring_date
                                                            else:
                                                                invicode_expire_date = now_expire_date

                                                        else:
                                                            invicode_expire_date = voucherObj.expiring_date
                                                    sql="update app01_invicode set status=1 ,member_id=%s,register_date='%s',expire_date='%s' where id=%s" % (member.id,datetime.datetime.now(),invicode_expire_date,invicode_id)
                                                    print(sql)
                                                    cursor.execute(sql)
                                                #invicodeOjb = models.Invicode.objects.filter(voucher__id=voucherObj.id,status=0).first()
                                                #if invicodeOjb:
                                                 #   invicodeOjb.status = 1
                                                  #  invicodeOjb.member =member
                                                   # invicodeOjb.register_date=datetime.datetime.now()
                                                    #invicodeOjb.save()
                                            member_wallet = models.Wallet.objects.get(member__id=member.id)

                                            if member_wallet is None:
                                                serializer = WalletSimpleSerializer(data={'balance': 0, 'member': member.id})
                                                if serializer.is_valid():
                                                    member_wallet1 = models.Wallet.objects.create(**serializer.validated_data)
                                                    if campaign_invitation.register_cash_back > 0:
                                                        member_wallet1.balance += campaign_invitation.register_cash_back
                                                        member_wallet1.save()
                                                        serializer2 = RechargeRecordCreateSerializer(
                                                            data={'money': campaign_invitation.register_cash_back,
                                                                  'wallet': member_wallet1.id, 'type': 3})
                                                        if serializer2.is_valid():
                                                            models.RechargeRecord.objects.create(**serializer2.validated_data)
                                            else:
                                                if campaign_invitation.register_cash_back > 0:
                                                    member_wallet.balance += campaign_invitation.register_cash_back
                                                    member_wallet.save()
                                                    serializer2 = RechargeRecordCreateSerializer(
                                                        data={'money': campaign_invitation.register_cash_back,
                                                              'wallet': member_wallet.id, 'type': 3})
                                                    if serializer2.is_valid():
                                                        models.RechargeRecord.objects.create(**serializer2.validated_data)
                                            # invitation cash back
                                            inviter_wallet = models.Wallet.objects.get(member__id=invite_member.id)
                                            if inviter_wallet:
                                                # inviter voucher
                                                voucherObj = campaign_invitation.voucher
                                                if voucherObj:
                                                    cursor = connection.cursor()
                                                    cursor.execute(
                                                        "select * from app01_invicode where voucher_id = %s and  status=0 limit 1" % voucherObj.id)
                                                    row2 = cursor.fetchall()
                                                    if row2:
                                                        invicode_id = row2[0][0]
                                                        # add expire date
                                                        invicode_obj = models.Invicode.objects.filter(
                                                            id=invicode_id).first()
                                                        invicode_expire_date = voucherObj.expiring_date
                                                        if invicode_obj:

                                                            if invicode_obj.vaild_days and invicode_obj.vaild_days > 0:
                                                                v_days = invicode_obj.vaild_days - 1
                                                                now_expire_date = datetime.datetime.now().date() + datetime.timedelta(
                                                                    days=v_days)
                                                                if now_expire_date >= voucherObj.expiring_date:

                                                                    invicode_expire_date = voucherObj.expiring_date
                                                                else:
                                                                    invicode_expire_date = now_expire_date

                                                            else:
                                                                invicode_expire_date = voucherObj.expiring_date
                                                        sql = "update app01_invicode set status=1 ,member_id=%s,register_date='%s',expire_date='%s' where id=%s" % (
                                                        invite_member.id, datetime.datetime.now(),invicode_expire_date, invicode_id)
                                                        print(sql)
                                                        cursor.execute(sql)

                                                if campaign_invitation.inviter_cash_back>0:
                                                    inviter_wallet.balance += campaign_invitation.inviter_cash_back
                                                    inviter_wallet.save()
                                                    serializer2 = RechargeRecordCreateSerializer(
                                                        data={'money': campaign_invitation.inviter_cash_back,
                                                              'wallet': inviter_wallet.id, 'type': 3})
                                                    if serializer2.is_valid():
                                                        models.RechargeRecord.objects.create(**serializer2.validated_data)
                                            else:
                                                serializer1 = WalletSimpleSerializer(
                                                    data={'balance': 0, 'member': invite_member.id})
                                                if serializer1.is_valid():
                                                    inviter_wallet1 = models.Wallet.objects.create(**serializer1.validated_data)
                                                    # inviter voucher
                                                    voucherObj = campaign_invitation.voucher
                                                    if voucherObj:
                                                        cursor = connection.cursor()
                                                        cursor.execute(
                                                            "select * from app01_invicode where voucher_id = %s and  status=0 limit 1" % voucherObj.id)
                                                        row2 = cursor.fetchall()
                                                        if row2:
                                                            invicode_id = row2[0][0]
                                                            # add expire date
                                                            invicode_obj = models.Invicode.objects.filter(
                                                                id=invicode_id).first()
                                                            invicode_expire_date = voucherObj.expiring_date
                                                            if invicode_obj:

                                                                if invicode_obj.vaild_days and invicode_obj.vaild_days > 0:
                                                                    v_days = invicode_obj.vaild_days - 1
                                                                    now_expire_date = datetime.datetime.now().date() + datetime.timedelta(
                                                                        days=v_days)
                                                                    if now_expire_date >= voucherObj.expiring_date:

                                                                        invicode_expire_date = voucherObj.expiring_date
                                                                    else:
                                                                        invicode_expire_date = now_expire_date

                                                                else:
                                                                    invicode_expire_date = voucherObj.expiring_date
                                                            sql = "update app01_invicode set status=1 ,member_id=%s,register_date='%s',expire_date='%s' where id=%s" % (
                                                                invite_member.id, datetime.datetime.now(),invicode_expire_date, invicode_id)
                                                            print(sql)
                                                            cursor.execute(sql)
                                                    if  campaign_invitation.inviter_cash_back>0:
                                                        inviter_wallet1.balance += campaign_invitation.inviter_cash_back
                                                        inviter_wallet1.save()
                                                        serializer2 = RechargeRecordCreateSerializer(
                                                            data={'money': campaign_invitation.inviter_cash_back,
                                                                  'wallet': inviter_wallet1.id, 'type': 3})
                                                        if serializer2.is_valid():
                                                            models.RechargeRecord.objects.create(**serializer2.validated_data)
                if member:
                    #params = eval(request.body.decode(encoding="utf-8"))

                    #params["username"] = member.username
                    #params["password"] = member.member.nick_name
                    # 重新构造请求体, 进行编码后, 重新赋值给 request._body
                    # 注意是 request._body, 因为 request.body 是不可修改的, 但是 body 属性继承自 _body 属性, 所以直接修改 _body 属性
                    #request._body = json.dumps(params).encode(encoding="utf-8")
                    #return HttpResponseRedirect(request.META.get('HTTP_REFERER','/api/v1/member/obtaintoken/'))
                    #transaction.commit()
                    r_response = requests.post('http://localhost:8018/api/v1/member/obtaintoken/', headers={}, data={'username':member.username,'password':member.nick_name})
                    #print(response.text)
                    return Response(json.loads(r_response.text))
                    '''
                    return Response({
                        'id': member.id,
                        'username': member.username,
                        'wallet':member.wallet.id,
                        'mobile_no': member.mobile_no,
                        'dob': member.dob,
                        'invicode': member.invicode,
                         'device_token':-member.device_token,
                        'rand_code':member.nick_name

                    }, status=status.HTTP_201_CREATED)
                    '''

            #content = 'User Mobile:' + request.data.get('mobile_no') + '\n register time:' + str(time.strftime("%Y-%m-%d %H:%M:%S", time.localtime()))
            #print(content)
            #utils.send_register_email("ziyiw2019@gmail.com", content, send_type="register")
            if  member:
                #r_params = {'username':member[0].username,'password':member[0].nick_name}

                #r_params["username"] = member.username
                #r_params["password"] = member.member.nick_name
                # 重新构造请求体, 进行编码后, 重新赋值给 request._body
                # 注意是 request._body, 因为 request.body 是不可修改的, 但是 body 属性继承自 _body 属性, 所以直接修改 _body 属性
                r_response = requests.post('http://localhost:8018/api/v1/member/obtaintoken/', headers={},data={'username': member[0].username, 'password': member[0].nick_name})
                #print(r_response.text)
                response=Response(json.loads(r_response.text))
                #response = Response({'id': member_id, 'wallet': wallet_id,'username': member_username,'mobile_no': member_mobile,'device_token':device_token})
                #response = Response({'token': token.key})
                # response.setdefault('Authorization', 'Token {auth_token}'.format(auth_token=token.key))
                # response.set_cookie(
                #     'Authorization',
                #     value='Token {auth_token}'.format(auth_token=token.key),
                #     httponly=True
                # )
                return response

class LoginView_CRM(generics.GenericAPIView):
    authentication_classes = ()
    permission_classes = (AllowAny,)
    serializer_class = serializers.LoginSerializer

    def post(self, request, *args, **kwargs):
        serializer = self.get_serializer(data=request.data)
        serializer.is_valid(raise_exception=True)
        token = serializer.save()
        mobile_no = request.data.get("username")
        if( mobile_no!="root"):
            return Response({'msg': 'username have no permission'}, status=status.HTTP_401_UNAUTHORIZED)

        member = models.Member.objects.filter(mobile_no__contains=mobile_no)
        wallet_id = 0
        if member:
            member_id = member[0].id
            wallet = models.Wallet.objects.filter(member_id=member[0].id)
            if wallet:
                wallet_id = wallet[0].id


        #content = 'User Mobile:' + request.data.get('mobile_no') + '\n register time:' + str(time.strftime("%Y-%m-%d %H:%M:%S", time.localtime()))
        #print(content)
        #utils.send_register_email("ziyiw2019@gmail.com", content, send_type="register")
        if not token:
            return Response({'msg': 'username is not exist'}, status=status.HTTP_401_UNAUTHORIZED)
        if not token.pk:
            return Response({'msg': 'wrong user name or password'}, status=status.HTTP_401_UNAUTHORIZED)
        else:
            response = Response({'token': token.key, 'wallet_id': wallet_id,'member_id':member_id})
            #response = Response({'token': token.key})
            # response.setdefault('Authorization', 'Token {auth_token}'.format(auth_token=token.key))
            # response.set_cookie(
            #     'Authorization',
            #     value='Token {auth_token}'.format(auth_token=token.key),
            #     httponly=True
            # )
            return response


class LoginView1(generics.GenericAPIView):
    authentication_classes = ()
    permission_classes = (AllowAny,)
    serializer_class = serializers.LoginSerializer1

    def post(self, request, *args, **kwargs):

        serializer = self.get_serializer(data=request.data)
        serializer.is_valid(raise_exception=True)
        token = serializer.save()
        if not token:
            return Response({'msg': 'username is not exist'}, status=status.HTTP_401_UNAUTHORIZED)
        if not token.pk:
            return Response({'msg': 'wrong user name or password'}, status=status.HTTP_401_UNAUTHORIZED)
        else:
            response = Response({'token': token.key})
            # response.setdefault('Authorization', 'Token {auth_token}'.format(auth_token=token.key))
            # response.set_cookie(
            #     'Authorization',
            #     value='Token {auth_token}'.format(auth_token=token.key),
            #     httponly=True
            # )
            return response
#修改密码
#class ModifyPassView(generics.GenericViewSet):
@api_view(['GET', 'POST'])
@authentication_classes([])
@permission_classes((AllowAny,))
def modPass(request, *args, **kwargs):
    #authentication_classes = ()
    #permission_classes = (AllowAny,)
    #serializer_class = serializers.RegisterSerializer

    #def post(self, request, *args, **kwargs):
    if request.method == 'POST':
        cursor = connection.cursor()
        cursor.execute("select * from app01_member where mobile_no = '%s'" % (request.data.get('mobile_no')))
        row2 = cursor.fetchall()
        if row2:
           n= cursor.execute("update app01_member set password = '%s' where mobile_no = '%s'" % (make_password(request.data.get('password')), request.data.get('mobile_no')))
           if (n!=0) :
               
               return Response({
               'msg':'ok',
                   'mobile_no':request.data.get('mobile_no'),
                   'member_id':row2[0][0],
               }, status=status.HTTP_201_CREATED)
           else :
               return Response({
                'msg':'error'
               }, status=status.HTTP_402_UNAUTHORIZED) 
       






class RegisterView(generics.GenericAPIView):
    authentication_classes = ()
    permission_classes = (AllowAny,)
    serializer_class = serializers.RegisterSerializer

    def post(self, request, *args, **kwargs):
        if(request.data.get('register_code')):
            member = models.Member.objects.filter(invite_code=request.data.get('register_code'))
            #print(member)
            if member:
                pass
            else:
                return Response({
                    'msg': 'invite code error'
                }, status=status.HTTP_200_OK)
        cursor = connection.cursor()
        cursor.execute("select * from app01_member where mobile_no = '%s'" % (request.data.get('mobile_no')))
        row2 = cursor.fetchall()
        if row2:
            return Response({
                'msg':'User exist'
            }, status=status.HTTP_401_UNAUTHORIZED)
        cursor.execute("select * from app01_invicode where code = '%s'" % (request.data.get('invicode')))
        row = cursor.fetchall()
        serializer = self.get_serializer(data=request.data)
        serializer.is_valid(raise_exception=True)
        member = serializer.save()
        content = 'User Mobile:' + request.data.get('mobile_no') + '\n register time:' + str(
            time.strftime("%Y-%m-%d %H:%M:%S", time.localtime()))
        print(content)
        #utils.send_register_email(utils.RECEIVE_MAIL, content, send_type="register")

        if row and row[0][1] == 0:
            free_vouchers = member.membership.invitation_vouchers.get(pk=int(row[0][3]))
            print('ATTENTION!!!')
            if free_vouchers:
                record_reward_member_invicode(member, free_vouchers)
                cursor.execute("update app01_invicode set status = 1 where code = '%s'" % (member.invicode))
                cursor.execute("update app01_invicode set invicode_user = '%s' where code = '%s'" % (member.mobile_no, member.invicode))
        if member:
            campaign_register = models.Campaign_Register.objects.first()


            if campaign_register and campaign_register.activity_status:
                member_wallet = models.Wallet.objects.get(member__id=member.id)
                if member_wallet is None:
                    serializer = WalletSimpleSerializer(data={'balance': 0, 'member': member.id})
                    if serializer.is_valid():
                        member_wallet1 = models.Wallet.objects.create(**serializer.validated_data)
                        if campaign_register.register_cash_back > 0:
                            member_wallet1.balance += campaign_register.register_cash_back
                            member_wallet1.save()
                            serializer2 = RechargeRecordCreateSerializer(
                                data={'money': campaign_register.register_cash_back,
                                      'wallet': member_wallet1.id, 'type': 3})
                            if serializer2.is_valid():
                                models.RechargeRecord.objects.create(**serializer2.validated_data)
                else:
                    if campaign_register.register_cash_back > 0:
                        member_wallet.balance += campaign_register.register_cash_back
                        member_wallet.save()
                        serializer2 = RechargeRecordCreateSerializer(
                            data={'money': campaign_register.register_cash_back,
                                  'wallet': member_wallet.id, 'type': 3})
                        if serializer2.is_valid():
                            models.RechargeRecord.objects.create(**serializer2.validated_data)
            invite_code_obj=models.Invite_Code.objects.filter(activate_status=False).first()
            if invite_code_obj:
                member.invite_code=invite_code_obj.invite_code
                member.save()
                invite_code_obj.activate_status=True
                invite_code_obj.save()
                #post_data = dict(request.POST.lists())
                #print(request.data.get('mobile_no'))
                #print(post_data.keys())

                #if 'register_code' in post_data.keys() and request.data.get('register_code') is not None and request.data.get('register_code')!='':
                if  request.data.get('register_code') is not None and request.data.get('register_code') != '':
                     invite_member=models.Member.objects.get(invite_code=request.data.get('register_code'))
                     if invite_member:
                         if invite_member.invite_count is not None:
                             invite_member.invite_count=invite_member.invite_count+1
                         else:
                             invite_member.invite_count=1
                         invite_member.save()
                         #invitation campaign
                         campaign_invitation=models.Campaign_Invitation_Code.objects.first()
                         if  campaign_invitation and campaign_invitation.activity_status:
                                 invitation_times=campaign_invitation.invitation_times
                                 if invitation_times and invite_member.invite_count>=invitation_times:
                                     #register cash back
                                     member_wallet=models.Wallet.objects.get(member__id=member.id)
                                     if member_wallet is None:
                                        serializer=WalletSimpleSerializer(data={'balance':0,'member':member.id})
                                        if serializer.is_valid():
                                            member_wallet1=models.Wallet.objects.create(**serializer.validated_data)
                                            if campaign_invitation.register_cash_back>0:
                                                member_wallet1.balance+=campaign_invitation.register_cash_back
                                                member_wallet1.save()
                                                serializer2 = RechargeRecordCreateSerializer(
                                                    data={'money': campaign_invitation.register_cash_back,
                                                          'wallet': member_wallet1.id, 'type': 3})
                                                if serializer2.is_valid():
                                                    models.RechargeRecord.objects.create(**serializer2.validated_data)
                                     else:
                                         if campaign_invitation.register_cash_back > 0:
                                             member_wallet.balance += campaign_invitation.register_cash_back
                                             member_wallet.save()
                                             serializer2 = RechargeRecordCreateSerializer(
                                                 data={'money': campaign_invitation.register_cash_back,
                                                       'wallet': member_wallet.id, 'type': 3})
                                             if serializer2.is_valid():
                                                 models.RechargeRecord.objects.create(**serializer2.validated_data)
                                     #invitation cash back
                                     inviter_wallet=models.Wallet.objects.get(member__id=invite_member.id)
                                     if inviter_wallet:
                                         inviter_wallet.balance += campaign_invitation.inviter_cash_back
                                         inviter_wallet.save()
                                         serializer2 = RechargeRecordCreateSerializer(
                                             data={'money': campaign_invitation.inviter_cash_back,
                                                   'wallet': inviter_wallet.id, 'type': 3})
                                         if serializer2.is_valid():
                                             models.RechargeRecord.objects.create(**serializer2.validated_data)
                                     else:
                                         serializer1 = WalletSimpleSerializer(data={'balance': 0, 'member': invite_member.id})
                                         if serializer1.is_valid():
                                             inviter_wallet1 = models.Wallet.objects.create(**serializer1.validated_data)
                                             inviter_wallet1.balance += campaign_invitation.inviter_cash_back
                                             inviter_wallet1.save()
                                             serializer2 = RechargeRecordCreateSerializer(
                                                 data={'money': campaign_invitation.inviter_cash_back,
                                                       'wallet': inviter_wallet1.id, 'type': 3})
                                             if serializer2.is_valid():
                                                 models.RechargeRecord.objects.create(**serializer2.validated_data)









        return Response({
            'id': member.pk,
            'username': member.username,
            'mobile_no': member.mobile_no,
            'dob': member.dob,
            'invicode': member.invicode,
        }, status=status.HTTP_201_CREATED)


class CheckRegisterView(generics.GenericAPIView):
    authentication_classes = ()
    permission_classes = (AllowAny,)
    serializer_class = serializers.RegisterSerializer

    def post(self, request, *args, **kwargs):
        cursor = connection.cursor()
        cursor.execute("select * from app01_member where mobile_no = '%s'" % (request.data.get('mobile_no')))
        row2 = cursor.fetchall()
        if row2:
            return Response({
                'msg':'User exist'
            }, status=status.HTTP_401_UNAUTHORIZED)
        return Response({
            'msg':'OK'
        }, status=status.HTTP_201_CREATED)


class RegisterByEmailView(generics.GenericAPIView):
    authentication_classes = ()
    permission_classes = (AllowAny,)
    serializer_class = serializers.RegisterSerializer1

    def post(self, request, *args, **kwargs):
        serializer = self.get_serializer(data=request.data)
        serializer.is_valid(raise_exception=True)
        member = serializer.save()
        return Response({
            'id': member.pk,
            'username': member.username,
            'email': member.email,
            "mobile_no": member.mobile_no,
            'dob': member.dob,
            "nick_name": member.nick_name
        }, status=status.HTTP_201_CREATED)


# add mobile device token for message push

@api_view(['GET', 'POST'])
@authentication_classes([])
@permission_classes((AllowAny,))
def addDevice_token(request, *args, **kwargs):

    if request.method == 'POST':
        member_id=request.data.get('member_id')
        device_token = request.data.get('device_token')
        terminal = request.data.get('terminal')
        if member_id:
            member = models.Member.objects.get(id=member_id)

            if member:
                member.device_token=device_token
                member.terminal = terminal
                member.save()
                return Response({
                    'msg': 'ok',
                    'device_token':device_token,

                }, status=status.HTTP_201_CREATED)
            else:
                return Response({
                    'msg': 'error'
                }, status=status.HTTP_201_CREATED)

# add mobile device token for message push

@api_view(['GET', 'POST'])
@authentication_classes([])
@permission_classes((AllowAny,))
def send_message(request, *args, **kwargs):

    if request.method == 'POST':
        #test send message
        send_message_to_token(
            'dD5E2ynClNM:APA91bGwf8UCz2E1CLMYJsyDAgUUGWd0p2NKL9mMjT5G1HSH8qrP2qG_sUMtaU96872KjmVmWUHB7AdPG5SMpcqPyFy-IgeLQDJ6BnsP0l2V4N9K1Jb5uksIJK9GJtLbBZ1hn6Adx6YD',
            'Itea order notify', 'Your order has been confirmed.\nPick up time is 15:30')
        return Response({
            'msg': 'ok',


        }, status=status.HTTP_201_CREATED)
# marketing send push message
@api_view(['GET', 'POST'])
@authentication_classes([])
@permission_classes((AllowAny,))
def sendPushMessage(request, *args, **kwargs):

    if request.method == 'POST':
        # send message
        message_title = request.data.get('message_title')
        voucher = request.data.get('voucher')
        message_description = request.data.get('message_description')
        select_purchase_date = request.data.get('select_purchase_date')
        select_count = request.data.get('select_count')
        search_dict = dict()
        search_dict["voucher__id"]=voucher
        search_dict["status"] = 0
        invicode=models.Invicode.objects.filter(**search_dict)
        if invicode:
            invicode_count=invicode.count()
            if(invicode_count>=select_count):
                search_member_dict={}
                search_member_dict["last_purchase_date__lte"] = datetime.datetime.strptime(select_purchase_date, "%Y-%m-%d")
                search_member_dict["device_token__isnull"] =False
                #get member set
                member_set=models.Member.objects.filter(**search_member_dict)
                print(member_set.count())
                if  member_set:
                    for member in member_set:
                        send_message_to_token(
                            member.device_token,
                            message_title, message_description)
            else:
                return Response({
                    'message': 'Voucher available invicode less than ' + str(select_count),

                }, status=status.HTTP_201_CREATED)

            #print(invicode_count)
        else:
            return Response({
                'message': 'Voucher available invicode less than '+str(select_count),

            }, status=status.HTTP_201_CREATED)



        return Response({
            'message': 'Push message successfully',


        }, status=status.HTTP_201_CREATED)

@api_view(['GET', 'POST'])
@authentication_classes([])
@permission_classes((AllowAny,))
def visit(request, *args, **kwargs):
    # authentication_classes = ()
    # permission_classes = (AllowAny,)
    # serializer_class = serializers.RegisterSerializer

    # def post(self, request, *args, **kwargs):
    change_info(request)
    visitAllArr=models.VisitNumber.objects.all()
    visitAll=visitAllArr.first().count
    visitDayArr=models.DayNumber.objects.order_by('-id')[0]
    visitDay=visitDayArr.count
    if request.method == 'GET':

            if (visitAll != 0):

                return Response({
                    'visitAll': visitAll,
                    'visitDay':visitDay
                }, status=status.HTTP_201_CREATED)
            else:
                return Response({
                    'msg': 'error'
                }, status=status.HTTP_402_UNAUTHORIZED)

@api_view([ 'POST'])
@authentication_classes([])
@permission_classes((AllowAny,))
def update_payment_code(request, *args, **kwargs):

    member_id=request.data.get('member_id')
    payment_code=request.data.get('payment_code').strip()
    new_payment_code=request.data.get('new_payment_code').strip()
    if member_id:
        payment_code_obj=models.Payment_Code.objects.filter(member__id=member_id).first()
        if payment_code:
            if check_password(payment_code,payment_code_obj.payment_code):
                if new_payment_code:
                     payment_code_obj.payment_code=make_password(new_payment_code)
                     payment_code_obj.save()
                     return Response({
                         'msg': 'success'
                     }, status=status.HTTP_200_OK)
                else:
                    return Response({
                        'msg': 'New payment code must not null'
                    }, status=status.HTTP_200_OK)
            else:
                return Response({
                    'msg': 'payment code not match'
                }, status=status.HTTP_200_OK)
    return Response({
        'msg': 'member_id or payment code is null'
    }, status=status.HTTP_200_OK)
@api_view([ 'POST'])
#@authentication_classes([])
@permission_classes((AllowAny,))
def set_secure_payment(request, *args, **kwargs):

    member_id=request.data.get('member_id')
    is_secure_payment=request.data.get('is_secure_payment')
    if is_secure_payment!='0' and is_secure_payment!='1':
        return Response({
            'msg': 'is_secure_payment value is 0 or 1'
        }, status=status.HTTP_200_OK)
    if member_id:
        member=models.Member.objects.filter(id=member_id).first()
        if member:
            member.is_secure_payment=is_secure_payment
            member.save()
            return Response({
                'msg': 'success'
            }, status=status.HTTP_200_OK)

    return Response({
        'msg': 'member not exits'
    }, status=status.HTTP_200_OK)
@api_view([ 'POST'])
@authentication_classes([])
@permission_classes((AllowAny,))
def reset_payment_code(request, *args, **kwargs):

    member_id=request.data.get('member_id')
    payment_code=request.data.get('payment_code').strip()
    #new_payment_code=request.data.get('new_payment_code').strip()
    # check otp
    verify_code = request.data.get("verify_code")
    # test account for android app update
    member=None
    if member_id:
        member=models.Member.objects.filter(id=member_id).first()
        if member:
            username=member.username

            if verify_code and not checkOtp(username, verify_code):
                return Response({
                    'msg': 'verify code error', 'msg_cn': "验证码错误"
                }, status=status.HTTP_200_OK)
    else:
        return Response({
            'msg': 'member id not exits', 'msg_cn': "会员ID不存在"
        }, status=status.HTTP_200_OK)
    if member_id:
        payment_code_obj=models.Payment_Code.objects.filter(member__id=member_id).first()

        if payment_code:
            if payment_code_obj:
                     payment_code_obj.payment_code=make_password(payment_code)
                     payment_code_obj.save()
                     return Response({
                         'msg': 'success'
                     }, status=status.HTTP_200_OK)
            else:
                    models.Payment_Code.objects.create(member=member,payment_code=make_password(payment_code))
                    return Response({
                        'msg': 'success'
                    }, status=status.HTTP_200_OK)
        else:
            return Response({
                'msg': 'payment code must not null', 'msg_cn': "支付密码必须非空"
            }, status=status.HTTP_200_OK)
    return Response({
        'msg': 'member_id or payment code is null'
    }, status=status.HTTP_200_OK)
@api_view([ 'POST'])
@authentication_classes([])
@permission_classes((AllowAny,))
def check_payment_code(request, *args, **kwargs):

    member_id=request.data.get('member_id')
    payment_code=request.data.get('payment_code').strip()

    if member_id:
        payment_code_obj=models.Payment_Code.objects.filter(member__id=member_id).first()
        if payment_code:
            if payment_code_obj:
                p_pass=make_password(payment_code)
                if check_password(payment_code,payment_code_obj.payment_code):

                     return Response({
                         'msg': 'success'
                     }, status=status.HTTP_200_OK)

                else:
                    return Response({
                        'msg': 'payment code not match'
                    }, status=status.HTTP_200_OK)
            else:
                return Response({
                    'msg': 'payment code not exists'
                }, status=status.HTTP_200_OK)
    return Response({
        'msg': 'member_id or payment code is null'
    }, status=status.HTTP_200_OK)
def change_info(request):

    count_nums = models.VisitNumber.objects.filter(id=1)
    if count_nums:
        count_nums = count_nums[0]
        count_nums.count += 1
    else:
        count_nums = models.VisitNumber()
        count_nums.count = 1
    count_nums.save()


    if 'HTTP_X_FORWARDED_FOR' in request.META:
        client_ip = request.META['HTTP_X_FORWARDED_FOR']
        client_ip = client_ip.split(",")[0]
    else:
        client_ip = request.META['REMOTE_ADDR']
    # print(client_ip)

    ip_exist = models.Userip.objects.filter(ip=str(client_ip))
    if ip_exist:
        uobj = ip_exist[0]
        uobj.count += 1
    else:
        uobj = models.Userip()
        uobj.ip = client_ip
        uobj.count = 1
    uobj.save()


    date = timezone.now().date()
    today = models.DayNumber.objects.filter(day=date)
    if today:
        temp = today[0]
        temp.count += 1
    else:
        temp = models.DayNumber()
        temp.dayTime = date
        temp.count = 1
    temp.save()

@api_view(['GET', 'POST'])
@authentication_classes([])
@permission_classes((AllowAny,))
def check_invite_code(request, *args, **kwargs):

    if request.method == 'GET':
            register_code=request.query_params.get('register_code')
            if (register_code):
                member=models.Member.objects.filter(invite_code=register_code)
                if member:
                    return Response({
                        'msg': 'ok',

                    }, status=status.HTTP_200_OK)

                else:
                    return Response({
                        'msg': 'error'
                    }, status=status.HTTP_200_OK)

    return Response({
        'msg': 'error'
    }, status=status.HTTP_200_OK)

@api_view(['GET', 'POST'])
@authentication_classes([])
@permission_classes((AllowAny,))
def get_member_count(request, *args, **kwargs):

    if request.method == 'GET':
            promotionCount=getRegisterCount()
            countTable = "<table border='1' cellspacing='0' style='text-align:center' ><tr ><td colspan='4'>Register Count</td></tr><tr><td>Today Registered(invitation)</td><td>Today Registered</td><td>Registered(invitation)</td><td>Registered</td></tr><tr><td>" + \
                         promotionCount['reg_code_today_count'] + "</td><td>" + promotionCount['reg_today_count'] + "</td><td>" + \
                         promotionCount['reg_code_count'] + "</td><td>" + promotionCount['sum_count'] + "</td></tr></table>"

            utils.send_register_email(utils.RECEIVE_MAIL, countTable, send_type="registered_count", promotion='')
    return Response(promotionCount, status=status.HTTP_200_OK)
def getRegisterCount():

    sum_count=0
    reg_code_count=0
    reg_today_count=0
    reg_code_today_count=0

    sum_count=models.Member.objects.all().count()
    print(sum_count)

    reg_code_count = models.Member.objects.filter(register_code__isnull=False).filter(~Q(register_code='')).count()
    print(reg_code_count)

    reg_sql="select count(*) from app01_member where to_char(app01_member.registration_date,'yyyy-mm-dd')=to_char(current_date,'yyyy-mm-dd') "
    reg_code_sql="select count(*) from app01_member where to_char(app01_member.registration_date,'yyyy-mm-dd')=to_char(current_date,'yyyy-mm-dd') and app01_member.register_code is not null and app01_member.register_code!=''"
    cursor = connection.cursor()
    cursor.execute(reg_sql)
    reg_today_count = cursor.fetchall()[0][0]
    print(reg_today_count)
    cursor.execute(reg_code_sql)
    reg_code_today_count = cursor.fetchall()[0][0]
    print(reg_code_today_count)
    return {'sum_count':str(sum_count),'reg_code_count':str(reg_code_count),'reg_today_count':str(reg_today_count),'reg_code_today_count':str(reg_code_today_count)}


# 修改密码
# class ModifyPassView(generics.GenericViewSet):
@api_view(['GET', 'POST'])
@authentication_classes([])
@permission_classes((AllowAny,))
def get_pass(request, *args, **kwargs):
    #password=random_pass(8)
    #print(password)
    #print(make_password('!ifb,itea,12'))
    #print(make_password('!ijdkfdfeke'))
    #print(make_password('!itea,factory,123'))
    print(make_password('123456'))
    print(check_password('123456','pbkdf2_sha256$120000$ijLcQMsqGZB4$ERdUSeLxfiqn00ED2wCxXexp+bMclXoIP4ufbLVQdBQ='))
    return Response({'msg': 'ok',}, status=status.HTTP_200_OK)

@api_view(['GET', 'POST'])
@authentication_classes([])
@permission_classes((AllowAny,))
def mod_post_code(request, *args, **kwargs):
    #print(make_password('!ifb,itea,12'))
    if request.method == 'POST':
        member_id = request.data.get('member_id')
        delivery_address = request.data.get('delivery_address')
        post_code = request.data.get('post_code')
        if member_id:
            member=models.Member.objects.filter(id=member_id).first()
            if member:
                member.delivery_address=delivery_address
                member.post_code=post_code
                member.save()
                return Response({'msg': 'ok',}, status=status.HTTP_200_OK)
    return  Response({'msg': 'error',}, status=status.HTTP_200_OK)

class PointsMemberViewSet(viewsets.ModelViewSet):
    permission_classes = (AllowAny,)
    queryset = models.Points_Member.objects.all().order_by('-id')
    serializer_class = serializers.Points_MemberSerializer
    pagination_class = DefaultPagination
    filter_backends = (
        DjangoFilterBackend,
        SearchFilter,
    )
    filter_class = PointsFilter
    search_fields = ('method',)

    def get_queryset(self):
        return super(PointsMemberViewSet, self).get_queryset()


class PaymentCodeViewSet(generics.GenericAPIView):
    permission_classes = (MemberViewSetPermission,)
    queryset = models.Payment_Code.objects.all().order_by('-id')
    serializer_class = serializers.Payment_CodeSerializer
    pagination_class = DefaultPagination
    filter_backends = (
        DjangoFilterBackend,
        SearchFilter,
    )

    search_fields = ('id',)

    def get_queryset(self):
        return super(PaymentCodeViewSet, self).get_queryset()
    def post(self, request, *args, **kwargs):
        #with transaction.atomic():

            member = request.data.get("member")
            payment_code = request.data.get("payment_code").strip()
            if member:
                payment_code_obj=models.Payment_Code.objects.filter(member__id=member).first()
                if payment_code_obj:
                    return Response({
                        'msg': 'payment code already exits'
                    }, status=status.HTTP_200_OK)
                else:
                    member_obj=models.Member.objects.filter(id=member).first()
                    if  member_obj:
                        if payment_code:
                            serializer = self.get_serializer(data=request.data)
                            serializer.is_valid(raise_exception=True)
                            paymentCode = serializer.save()
                            paymentCode.payment_code=make_password(payment_code)
                            paymentCode.save()
                        else:
                            return Response({
                                'msg': 'payment code must not null'
                            }, status=status.HTTP_200_OK)
                    else:
                        return Response({
                            'msg': 'member not exits'
                        }, status=status.HTTP_200_OK)
            else:
                return Response({
                    'msg': 'member must not null'
                }, status=status.HTTP_200_OK)
            return Response({
                'msg': 'success'
            }, status=status.HTTP_200_OK)



class MemberRewardViewSet(viewsets.ModelViewSet):
    permission_classes = (AllowAny,)
    queryset = models.Member_Reward.objects.all().order_by('id')
    serializer_class = serializers.Member_RewardSerializer
    pagination_class = DefaultPagination
    filter_backends = (
        DjangoFilterBackend,
        SearchFilter,
    )
    filter_class = RewardsFilter


    def get_queryset(self):
        return super(MemberRewardViewSet, self).get_queryset()
class SignedOrderRecordViewSet(viewsets.ModelViewSet):
    permission_classes = (AllowAny,)
    queryset = models.SignedOrderRecord.objects.all().order_by('id')
    serializer_class = serializers.SignedOrderRecordSerializer
    pagination_class = DefaultPagination
    filter_backends = (
        DjangoFilterBackend,
        SearchFilter,
    )
    filter_class = SignedOrderRecordFilter
    search_fields = ('member',)

    def get_queryset(self):
        return super(SignedOrderRecordViewSet, self).get_queryset()
class SignedGlobalIndexViewSet(viewsets.ModelViewSet):
    permission_classes = (AllowAny,)
    queryset = models.SignedGlobalIndex.objects.all().order_by('-id')
    serializer_class = serializers.SignedGlobalIndexSerializer
    pagination_class = DefaultPagination
    filter_backends = (
        DjangoFilterBackend,
        SearchFilter,
    )
    filter_class = SignedGlobalIndexFilter
    search_fields = ('member',)

    def get_queryset(self):
        return super(SignedGlobalIndexViewSet, self).get_queryset()

class New_User_RewardsViewSet(viewsets.ModelViewSet):
    permission_classes = (AllowAny,)
    queryset = models.New_User_Rewards.objects.filter(status=True).order_by('id')
    serializer_class = serializers.New_User_RewardsSerializer
    pagination_class = DefaultPagination
    filter_backends = (
        DjangoFilterBackend,
        SearchFilter,
    )

    search_fields = ('id',)

    def get_queryset(self):
        return super(New_User_RewardsViewSet, self).get_queryset()
class FakeSignedGlobalIndexViewSet(viewsets.ModelViewSet):
    permission_classes = (AllowAny,)
    authentication_classes=[]
    queryset = models.SignedGlobalIndex.objects.all().order_by('-id')
    serializer_class = serializers.FakeSignedGlobalIndexSerializer
    pagination_class = DefaultPagination
    filter_backends = (
        DjangoFilterBackend,
        SearchFilter,
    )
    filter_class = SignedGlobalIndexFilter
    search_fields = ('member',)

    def get_queryset(self):
        return super(FakeSignedGlobalIndexViewSet, self).get_queryset()
        '''
        member_id=member_id=self.request.query_params.get('member')
        if member_id:
            member=models.Member.objects.filter(id=member_id).first()
            if member:
                obj_list = models.SignedGlobalIndex.objects.filter(member__id=member.id).first()
                have_obj = models.SignedGlobalIndex.objects.filter(member__id=member.id,circle_status=False).order_by('-id').first()
                temp_fake_isnull_flag=False
                if have_obj:
                    temp_signed_count= models.SignedOrderRecord.objects.filter(signed_global_index__id=have_obj.id).count()
                    if temp_signed_count==12:
                        temp_fake_isnull_flag=True
                    else:
                        temp_fake_isnull_flag = True

                else:
                    temp_fake_isnull_flag = True



                if not obj_list  or temp_fake_isnull_flag :
                    trans_list = models.Transaction.objects.filter(member__id=member.id, transaction_status=2)
                    trans_id_list = []
                    if trans_list:
                        for item in trans_list:
                            trans_id_list.append(item.id)
                    transDetails_count_obj = models.TransactDetails.objects.filter(
                        transaction__id__in=tuple(trans_id_list)).aggregate(sum=Sum('quantity'))
                    if transDetails_count_obj:
                        quantity_num = transDetails_count_obj['sum']
                    temp_obj_list = []
                    obj_list_count = 0
                    fake_index_list = []
                    quantity_num=1
                    if quantity_num:
                        for l in range(quantity_num):

                            temp_index = obj_list_count + l
                            if temp_index > 11:
                                break
                                
                            fake_index_list.append(temp_index)
                        for i in range(12):
                            j = i + 1
                            if j == 4 or j == 9:

                                obj = models.SignedOrderRecord(id=0, electronic_signed=False, fake=False,
                                                               signed_type=2, null_image_url='',
                                                               prize_image_url='http://47.74.156.85:8000/signed/upsize.gif')
                            elif j == 12:
                                obj = models.SignedOrderRecord(id=0, electronic_signed=False, fake=False,
                                                               signed_type=2, null_image_url='',
                                                               prize_image_url='http://47.74.156.85:8000/signed/free_drink.gif')
                            else:

                                obj = models.SignedOrderRecord(id=0, electronic_signed=False, fake=False,
                                                               signed_type=0,
                                                               null_image_url='http://47.74.156.85:8000/signed/null.gif',
                                                               prize_image_url='')
                            if fake_index_list and i in fake_index_list:
                                obj.fake = True
                            temp_obj_list.append(obj)
                        return [serializers.SignedOrderRecordSerializer(i).data for i in temp_obj_list]
                        #return temp_obj_list
       '''




@api_view(['GET', 'POST'])
@authentication_classes([])
@permission_classes((AllowAny,))
def memberExisted(request, *args, **kwargs):
    mobile_no = request.GET.get("username")
    if not mobile_no:
        mobile_no = request.GET.get("mobile_no")
    # 修改，返回wallet_id
    member = models.Member.objects.filter(mobile_no=mobile_no)
    if member:
        return Response({"status":'ok'},status=status.HTTP_200_OK)
    else:
        return Response({"status":'error'},status=status.HTTP_201_CREATED)

@api_view(['GET', 'POST'])
@authentication_classes([])
@permission_classes((AllowAny,))
def invitation_reward(request, *args, **kwargs):
    member_id = request.GET.get("member_id")
    promotion= request.GET.get("promotion")
    if member_id:

        return Response({"msg":'ok','reward_amount':0},status=status.HTTP_200_OK)
    else:
        return Response({"status":'error'},status=status.HTTP_201_CREATED)
@api_view(['GET', 'POST'])
@authentication_classes([])
@permission_classes((AllowAny,))
def signed_order(request, *args, **kwargs):
    member_id = request.GET.get("member_id")
    signed_id= request.GET.get("signed_id")
    signed_id_list = request.GET.get("signed_id_list")

    if member_id:
        with transaction.atomic():
            if signed_id:
                if signed_id!="0":
                    obj=models.SignedOrderRecord.objects.filter(member__id=member_id,id=signed_id,electronic_signed=False).first()
                    if obj:
                        obj.electronic_signed=True
                        obj.save()
                        # modify transaction signed flag
                        transObj=obj.transaction
                        if transObj:
                            trans_signed=models.SignedOrderRecord.objects.filter(member__id=member_id,electronic_signed=False,transaction__id=transObj.id).first()
                            if not trans_signed:
                                transObj.signed = True
                                transObj.save()
                        #modify global index status
                        signed_item_count_dict=models.SignedOrderRecord.objects.filter(member__id=member_id,  electronic_signed=True,signed_global_index__id=obj.signed_global_index.id).aggregate(count=Count('id'))
                        if signed_item_count_dict:
                            signed_item_count=signed_item_count_dict['count']
                            if signed_item_count==12:
                                models.SignedGlobalIndex.objects.filter(id=obj.signed_global_index.id).update(all_signed=True)
                        if obj.signed_type == 1:
                            models.PuzzleImageLog.objects.filter(signed_order_record__id=obj.id).update(status=True)
                        if obj.signed_type==2:
                            signed_prize=obj.signed_prize
                            if signed_prize:
                                models.Invicode.objects.create(**{'voucher': signed_prize.voucher, 'code': generate_random_str(), 'status': 1,'member_id': member_id, 'register_date': datetime.datetime.now(), 'vaild_days': 14,'expire_date': datetime.datetime.now().date() + datetime.timedelta(days=14)})

                else:
                    obj_list=models.SignedOrderRecord.objects.filter(member__id=member_id,electronic_signed=False)

                    if obj_list:
                        transaction_id_list=[]
                        for obj in obj_list:
                            if obj:
                                transaction_id_list.append(obj.transaction.id)
                                obj.electronic_signed = True
                                obj.save()
                                # modify global index status
                                signed_item_count_dict = models.SignedOrderRecord.objects.filter(member__id=member_id, electronic_signed=True,signed_global_index__id=obj.signed_global_index.id).aggregate(
                                    count=Count('id'))
                                if signed_item_count_dict:
                                    signed_item_count = signed_item_count_dict['count']
                                    if signed_item_count == 12:
                                        models.SignedGlobalIndex.objects.filter(id=obj.signed_global_index.id).update(
                                            all_signed=True)
                                if obj.signed_type == 1:
                                    models.PuzzleImageLog.objects.filter(signed_order_record__id=obj.id).update(status=True)
                                if obj.signed_type == 2:
                                    signed_prize = obj.signed_prize
                                    if signed_prize:
                                        models.Invicode.objects.create(**{'voucher': signed_prize.voucher, 'code': generate_random_str(), 'status': 1,'member_id': member_id, 'register_date': datetime.datetime.now(), 'vaild_days': 14,'expire_date': datetime.datetime.now().date() + datetime.timedelta(days=14)})
                        #modify transaction signed flag
                        if transaction_id_list:
                            temp_list=list(set(transaction_id_list))
                            if temp_list:
                                models.Transaction.objects.filter(member__id=member_id, transaction_status__in=(4,5),id__in=tuple(temp_list)).update(signed=True)
            return Response({"msg":'ok'},status=status.HTTP_200_OK)

    else:
        return Response({"msg":'error'},status=status.HTTP_201_CREATED)

@api_view(['GET', 'POST'])
@authentication_classes([])
@permission_classes((AllowAny,))
def new_member_fake_signed_list(request, *args, **kwargs):
    member_id = request.GET.get("member")
    if member_id:
        member=models.Member.objects.filter(id=member_id).first()
        if member:
            obj_list = models.SignedGlobalIndex.objects.filter(member__id=member.id).first()
            have_obj = models.SignedGlobalIndex.objects.filter(member__id=member.id, circle_status=False).order_by(
                '-id').first()
            temp_fake_isnull_flag = False
            if have_obj:
                temp_signed_count = models.SignedOrderRecord.objects.filter(signed_global_index__id=have_obj.id).count()
                if temp_signed_count == 12:
                    temp_fake_isnull_flag = True
                else:
                    temp_fake_isnull_flag = False

            else:
                temp_fake_isnull_flag = True

            if not obj_list or temp_fake_isnull_flag:
                trans_list = models.Transaction.objects.filter(member__id=member.id,pick_up_type=0, transaction_status__in=(2,4),inserted_signed_record=False)
                trans_id_list = []
                erase_times=0
                if trans_list:
                    for item in trans_list:
                        # if trans use free up size or free drink voucher,then erase 1 times
                        redeem_invicode = item.redeem_invicode
                        if redeem_invicode != 0:
                            invicode_obj = models.Invicode.objects.filter(id=redeem_invicode).first()
                            if invicode_obj:
                                voucher_obj = invicode_obj.voucher
                                if voucher_obj:
                                    if voucher_obj.id == 292 or voucher_obj.id == 295:
                                        pass
                                        #erase_times=erase_times+1
                        trans_id_list.append(item.id)
                transDetails_count_obj = models.TransactDetails.objects.filter(
                    transaction__id__in=tuple(trans_id_list)).aggregate(sum=Sum('quantity'))
                if transDetails_count_obj:
                    quantity_num = transDetails_count_obj['sum']
                    if quantity_num:
                        quantity_num=quantity_num-erase_times
                temp_obj_list = []
                obj_list_count = 0
                fake_index_list = []

                if quantity_num:
                    for l in range(quantity_num):

                        temp_index = obj_list_count + l
                        if temp_index > 11:
                            break

                        fake_index_list.append(temp_index)
                    for i in range(12):
                        j = i + 1
                        if j == 4 or j == 9:

                            obj = models.SignedOrderRecord(id=0, electronic_signed=False, fake=False,
                                                           signed_type=2, null_image_url='',
                                                           prize_image_url='http://erp.itea.sg:8000/signed/upsize.gif',

                                                           fake_image_url='http://erp.itea.sg:8000/signed/fake_up_size.png'
                                                           )
                        elif j == 12:
                            obj = models.SignedOrderRecord(id=0, electronic_signed=False, fake=False,
                                                           signed_type=2, null_image_url='',
                                                           prize_image_url='http://erp.itea.sg:8000/signed/free_drink.gif',
                                                           fake_image_url='http://erp.itea.sg:8000/signed/fake_free_drink.png'
                                                           )
                        else:

                            obj = models.SignedOrderRecord(id=0, electronic_signed=False, fake=False,
                                                           signed_type=0,
                                                           null_image_url='https://crm.itea.sg/tea_imgs2/signed/null.gif',
                                                           prize_image_url='',
                                                           fake_image_url='https://crm.itea.sg/tea_imgs2/signed/fake_null.png'
                                                           )
                        if fake_index_list and i in fake_index_list:
                            obj.fake = True
                        temp_obj_list.append(obj)
                    return Response({'count':1,'next':None,'previous':None,'results':[{ 'signed_item': [serializers.SignedOrderRecordSerializer(i).data for i in temp_obj_list],"circle_status": False,"all_signed": False,"member": member_id } ] })
                else:
                    temp_null_list=[]
                    for i in range(12):
                        j = i + 1
                        if j == 4 or j == 9:

                            obj = models.SignedOrderRecord(id=0, electronic_signed=False, fake=False,
                                                           signed_type=2, null_image_url='',
                                                           prize_image_url='https://crm.itea.sg/tea_imgs2/signed/upsize.gif',

                                                           fake_image_url='https://crm.itea.sg/tea_imgs2/signed/fake_up_size.png'
                                                           )
                        elif j == 12:
                            obj = models.SignedOrderRecord(id=0, electronic_signed=False, fake=False,
                                                           signed_type=2, null_image_url='',
                                                           prize_image_url='https://crm.itea.sg/tea_imgs2/signed/free_drink.gif',
                                                           fake_image_url='https://crm.itea.sg/tea_imgs2/signed/fake_free_drink.png'
                                                           )
                        else:

                            obj = models.SignedOrderRecord(id=0, electronic_signed=False, fake=False,
                                                           signed_type=0,
                                                           null_image_url='https://crm.itea.sg/tea_imgs2/signed/null.gif',
                                                           prize_image_url='',
                                                           fake_image_url='https://crm.itea.sg/tea_imgs2/signed/fake_null.png'
                                                           )

                        temp_null_list.append(obj)
                    return Response({'count': 1, 'next': None, 'previous': None, 'results': [{'signed_item': [serializers.SignedOrderRecordSerializer(i).data for i in temp_null_list],"circle_status": False, "all_signed": False, "member": member_id}]})
                    #return Response({'count': 0, 'next': None, 'previous': None, 'results': []})
            else:

                path=request.get_full_path()
                url=request.get_raw_uri()
                a_url=url.replace(path,'')
                
                r_response = requests.get('http://localhost:8018/api/v1/member/member_fake_signed_list/?member='+member_id+'&all_signed=False&page_size=1&page=1')
                return Response(json.loads(r_response.text))


@api_view(['GET', 'POST'])
@authentication_classes([])
@permission_classes((AllowAny,))
def puzzle(request, *args, **kwargs):
    member_id = request.GET.get("member")
    list=models.PuzzleImageLog.objects.filter(member__id=member_id,status=True).values('puzzle_image','puzzle_image__sort_index','puzzle_image_url').annotate(Count('id'))
    return Response({"puzzle_list": list}, status=status.HTTP_200_OK)
@api_view(['GET', 'POST'])
@authentication_classes([])
@permission_classes((AllowAny,))
def otp(request, *args, **kwargs):
    #return Response({'responseCode':'OK','responseDescription':''})
    mobile_no=request.GET.get("mobile_no")
    member=models.Member.objects.filter(mobile_no=mobile_no[2:],status=1).first()
    if member:
        return Response({'responseCode': 'Prompt Error',
                         'responseDescription': 'Your account has been deleted','responseCode_cn':'错误提示','responseDescription_cn': '该账户已经被删除'})
    #mobile_no='65'+mobile_no
    otp_set=models.OtpSet.objects.first()
    if otp_set:
        expire_minute=otp_set.expire_minute
        max_times_per_minute=otp_set.max_times_per_minute
        max_times_per_day=otp_set.max_times_per_day
    today_otp_count=models.LoginOtp.objects.filter(mobile_no=mobile_no,send_date=datetime.datetime.now().date()).count()
    if today_otp_count>=max_times_per_day:
        #pass
        return Response({'responseCode':'Prompt Error','responseDescription':'Account daily sending limit has been reached','responseCode_cn':'错误提示','responseDescription_cn':'已达到帐户每日发送限制' })
    one_minute_otp_count = models.LoginOtp.objects.filter(mobile_no=mobile_no,send_date=datetime.datetime.now().date(),send_time__gt=datetime.datetime.now()-datetime.timedelta(minutes=1)).count()
    #print('kkk'+str(max_times_per_minute)+'   '+str(one_minute_otp_count))
    if one_minute_otp_count>=max_times_per_minute:
        return Response({'responseCode': 'Prompt Error','responseDescription': 'Max 2 times otp per 1 minute','responseCode_cn': '错误提示','responseDescription_cn': '每分钟最多发送2次OTP'})
    number_list=[0,1,2,3,4,5,6,7,8,9]
    generate_number=6
    rand_list=random.sample(number_list, generate_number)
    rand_number=''
    for i in rand_list:
        rand_number=rand_number+str(i)

    client = AcsClient('LTAI4GHhAjCxfuFFpbBbp3z9', 'NUhyLwKPURI2ANRGpbwSdnoXoVnVU1', 'ap-southeast-1')

    request = CommonRequest()
    request.set_accept_format('json')
    request.set_domain('dysmsapi.ap-southeast-1.aliyuncs.com')
    request.set_method('POST')
    request.set_protocol_type('https')  # https | http
    request.set_version('2018-05-01')
    request.set_action_name('SendMessageToGlobe')

    request.add_query_param('RegionId', "ap-southeast-1")
    request.add_query_param('To', mobile_no)
    request.add_query_param('Message', "Your iTEA verify code is "+rand_number+',expire after '+str(expire_minute)+' minutes')
    request.add_query_param('From', "iTEA")
    response = json.loads(str(client.do_action(request), encoding="utf-8"))

    # python2:  print(response)
    response_json={}
    if 'ResponseCode' in response.keys():
        response_json['responseCode']=response['ResponseCode']
        if response_json['responseCode']=='OK':
            models.LoginOtp.objects.create(mobile_no=mobile_no, send_date=datetime.datetime.now().date(),expire_time=datetime.datetime.now() + datetime.timedelta(minutes=expire_minute), verify_code=rand_number)
    if 'ResponseDescription' in response.keys():
        response_json['responseDescription']=response['ResponseDescription']
    return Response(response_json)
@api_view(['GET', 'POST'])
@authentication_classes([])
@permission_classes((AllowAny,))
def new_otp(request, *args, **kwargs):
    #return Response({'responseCode':'OK','responseDescription':''})
    mobile_no=request.GET.get("mobile_no")
    if len(str(mobile_no))==10:
        member=models.Member.objects.filter(mobile_no=mobile_no[2:]).first()
        if not member:
            return Response({'status': 'failure',
                             'msg': 'Mobile no. not exits','msg_cn': '手机号不存在'})
    else:
        member = models.Member.objects.filter(mobile_no=mobile_no).first()
        if not member:
            return Response({'status': 'failure',
                             'msg': 'Mobile no. not exits',"msg_cn":"手机号不存在"})
    if member and member.status==1:
        return Response({'responseCode': 'ALERT_LIMIT_DAY','responseDescription': 'Your account has been deleted','responseCode_cn': '错误提示','responseDescription_cn': '你已删除这个账号'})

    if member and member.username :
          if not member.username.isdigit():
                 return Response({'is_new_user': 'true',
                         'msg': 'Please use password login','msg_cn': '请用密码登录'})
    if len(str(mobile_no)) == 10:
        pass
    else:
        mobile_no='65'+mobile_no
    number_list = [0, 1, 2, 3, 4, 5, 6, 7, 8, 9]
    generate_number = 6
    rand_list = random.sample(number_list, generate_number)
    rand_number = ''
    for i in rand_list:
        rand_number = rand_number + str(i)
    if mobile_no=='6588888888':
        models.LoginOtp.objects.create(mobile_no=mobile_no, send_date=datetime.datetime.now().date(),
                                       expire_time=datetime.datetime.now() + datetime.timedelta(minutes=10),
                                       verify_code=rand_number)
        return Response({
                        "responseCode": "OK",
                        "is_new_user": "false",
                        "responseDescription": "OK"
                    })
    otp_set=models.OtpSet.objects.first()
    if otp_set:
        expire_minute=otp_set.expire_minute
        max_times_per_minute=otp_set.max_times_per_minute
        max_times_per_day=otp_set.max_times_per_day
    today_otp_count=models.LoginOtp.objects.filter(mobile_no=mobile_no,send_date=datetime.datetime.now().date()).count()
    if today_otp_count >= max_times_per_day:
        # pass
        return Response(
            {'responseCode': 'Prompt Error', 'responseDescription': 'Account daily sending limit has been reached',
             'responseCode_cn': '错误提示', 'responseDescription_cn': '已达到帐户每日发送限制'})
    one_minute_otp_count = models.LoginOtp.objects.filter(mobile_no=mobile_no, send_date=datetime.datetime.now().date(),
                                                          send_time__gt=datetime.datetime.now() - datetime.timedelta(
                                                              minutes=1)).count()
    # print('kkk'+str(max_times_per_minute)+'   '+str(one_minute_otp_count))
    if one_minute_otp_count >= max_times_per_minute:
        return Response({'responseCode': 'Prompt Error', 'responseDescription': 'Max 2 times otp per 1 minute',
                         'responseCode_cn': '错误提示', 'responseDescription_cn': '每分钟最多发送2次OTP'})


    client = AcsClient('LTAI4GHhAjCxfuFFpbBbp3z9', 'NUhyLwKPURI2ANRGpbwSdnoXoVnVU1', 'ap-southeast-1')

    request = CommonRequest()
    request.set_accept_format('json')
    request.set_domain('dysmsapi.ap-southeast-1.aliyuncs.com')
    request.set_method('POST')
    request.set_protocol_type('https')  # https | http
    request.set_version('2018-05-01')
    request.set_action_name('SendMessageToGlobe')

    request.add_query_param('RegionId', "ap-southeast-1")
    request.add_query_param('To', mobile_no)
    request.add_query_param('Message', "Your iTEA verify code is "+rand_number+',expire after '+str(expire_minute)+' minutes')
    request.add_query_param('From', "iTEA")
    response = json.loads(str(client.do_action(request), encoding="utf-8"))

    # python2:  print(response)
    response_json={}
    if 'ResponseCode' in response.keys():
        response_json['responseCode']=response['ResponseCode']
        if response_json['responseCode']=='OK':
            response_json['is_new_user']="false"

            models.LoginOtp.objects.create(mobile_no=mobile_no, send_date=datetime.datetime.now().date(),expire_time=datetime.datetime.now() + datetime.timedelta(minutes=expire_minute), verify_code=rand_number)
    if 'ResponseDescription' in response.keys():
        response_json['responseDescription']=response['ResponseDescription']

    return Response(response_json)
class NewRegisterView(generics.GenericAPIView):
    authentication_classes = ()
    permission_classes = (AllowAny,)
    serializer_class = serializers.LoginVerifyCodeSerializer
    def get_serializer_class(self):
        username = self.request.data.get("username")
        mobile_no = self.request.data.get("mobile_no")
        if  username:
            member = models.Member.objects.filter(username__iexact=username)
        else:
            if not mobile_no:
                member = models.Member.objects.filter(mobile_no__contains=mobile_no)
            else:
                member=None
        # 修改，返回wallet_id
        #member = models.Member.objects.filter(mobile_no__contains=mobile_no)
        if member:
            return super(NewRegisterView, self).get_serializer_class()
        else:
            return   serializers.RegisterSerializer
    def post(self, request, *args, **kwargs):
        #with transaction.atomic():
            #serializer = self.get_serializer(data=request.data)
            #serializer.is_valid(raise_exception=True)
            #token = serializer.save()
            username = request.data.get("username")

            mobile_no = request.data.get("mobile_no")

            #password = request.data.get("password")
            password=random_pass(20)
            register_code=request.data.get('register_code')
            #check otp
            verify_code = request.data.get("verify_code")
            #test account for android app update
            '''
            if verify_code and  not checkOtp('65'+mobile_no,verify_code):
                return Response({
                    'msg': 'verify code error'
                }, status=status.HTTP_200_OK)
            '''

            if verify_code and not checkOtp(username, verify_code):
                return Response({
                    'msg': 'verify code error','msg_cn':"验证码错误"
                }, status=status.HTTP_200_OK)
            # 修改，返回wallet_id
            if mobile_no:
                m_member=models.Member.objects.filter(mobile_no__iexact=mobile_no)
                if m_member:
                    return Response({
                        'msg': 'Mobile alread registered','msg_cn':"手机号已经注册"
                    }, status=status.HTTP_200_OK)
            member = models.Member.objects.filter(username__iexact=username).first()
            wallet_id = 0
            if member:
                if member.status==0:
                    return Response({
                        'msg': 'Email  alread registered',"msg_cn":"邮箱已经注册"
                    }, status=status.HTTP_200_OK)
                else:
                    r_response = requests.post('http://localhost:8018/api/v1/member/obtaintoken/', headers={},
                                               data={'username': member.username, 'password': member.nick_name})
                    # print(response.text)
                    return Response(json.loads(r_response.text))

            else:
                with transaction.atomic():
                    if (request.data.get('register_code')):
                        memberList = models.Member.objects.filter(invite_code=request.data.get('register_code'))
                        if memberList:
                            member1=memberList[0]
                            # print(member)
                            if member1:
                                #bind invitation_code voucher

                                pass
                            else:
                                return Response({
                                    'msg': 'invite code error','msg_cn':'邀请码错误'
                                }, status=status.HTTP_200_OK)
                        else:
                            return Response({
                                'msg': 'invite code error','msg_cn':'邀请码错误'
                            }, status=status.HTTP_200_OK)
                    post_data = dict(request.POST.lists())
                    if  'mobile_no' in post_data.keys():
                        serializer = self.get_serializer(data=request.data)
                    else:
                         member_obj={'mobile_no':mobile_no,'username':username,'password':password,'register_code':request.data.get('register_code')}
                         serializer = self.get_serializer(data=member_obj)
                    #serializer = self.get_serializer(data=request.data)

                    serializer.is_valid(raise_exception=True)
                    member = serializer.save()
                    #tempory password from jwt token
                    member.nick_name=password
                    if mobile_no:
                        member.mobile_no=mobile_no
                    if register_code:
                        member.register_code=register_code
                    member.email=username
                    member.password=make_password(password)
                    member.is_active=1
                    member.save()

                    w_serializer = WalletSimpleSerializer(data={'balance': 0, 'member': member.id})
                    if w_serializer.is_valid():
                         models.Wallet.objects.create(**w_serializer.validated_data)


                    if member:
                        #new user reward voucher
                        v_list=models.New_User_Rewards.objects.filter(status=True)
                        if v_list:
                             for v in v_list:
                                 invicode_register_date = datetime.datetime.now().date()
                                 voucher_expire_date=invicode_register_date+datetime.timedelta(days=30)
                                 for i in range(v.quantity):
                                     models.Invicode.objects.create(
                                         **{'voucher': v.voucher, 'code': generate_random_str(),
                                            'status': 1,
                                            'member': member,
                                            'register_date': datetime.datetime.now(),
                                            'vaild_days': 30,
                                            'expire_date': voucher_expire_date})
                        '''
                        campaign_register = models.Campaign_Register.objects.first()

                        if campaign_register and campaign_register.activity_status:
                            member_wallet = models.Wallet.objects.get(member__id=member.id)
                            if member_wallet is None:
                                serializer = WalletSimpleSerializer(data={'balance': 0, 'member': member.id})
                                if serializer.is_valid():
                                    member_wallet1 = models.Wallet.objects.create(**serializer.validated_data)
                                    if campaign_register.register_cash_back > 0:
                                        member_wallet1.balance += campaign_register.register_cash_back
                                        member_wallet1.save()
                                        serializer2 = RechargeRecordCreateSerializer(
                                            data={'money': campaign_register.register_cash_back,
                                                  'wallet': member_wallet1.id, 'type': 3})
                                        if serializer2.is_valid():
                                            models.RechargeRecord.objects.create(**serializer2.validated_data)
                            else:
                                
                                if campaign_register.register_cash_back > 0:
                                    member_wallet.balance += campaign_register.register_cash_back
                                    member_wallet.save()
                                    serializer2 = RechargeRecordCreateSerializer(
                                        data={'money': campaign_register.register_cash_back,
                                              'wallet': member_wallet.id, 'type': 3})
                                    if serializer2.is_valid():
                                        models.RechargeRecord.objects.create(**serializer2.validated_data)
                                else:
                                    reg_voucherObj = campaign_register.voucher
                                    if reg_voucherObj:
                                        cursor = connection.cursor()
                                        cursor.execute(
                                            "select * from app01_invicode where voucher_id = %s and  status=0 limit 1" % reg_voucherObj.id)
                                        row2 = cursor.fetchall()
                                        if row2:
                                            invicode_id = row2[0][0]
                                            #invicode
                                            invicode_obj=models.Invicode.objects.filter(id=invicode_id).first()
                                            invicode_expire_date=reg_voucherObj.expiring_date
                                            if invicode_obj:

                                                if invicode_obj.vaild_days and invicode_obj.vaild_days > 0:
                                                    v_days = invicode_obj.vaild_days - 1
                                                    now_expire_date =datetime.datetime.now().date()+ datetime.timedelta(days=v_days)
                                                    if now_expire_date >= reg_voucherObj.expiring_date:

                                                        invicode_expire_date = reg_voucherObj.expiring_date
                                                    else:
                                                        invicode_expire_date = now_expire_date

                                                else:
                                                    invicode_expire_date =reg_voucherObj.expiring_date


                                            sql = "update app01_invicode set status=1 ,member_id=%s,register_date='%s',expire_date='%s' where id=%s" % (
                                            member.id, datetime.datetime.now(),invicode_expire_date, invicode_id)
                                            #print(sql)

                                            cursor.execute(sql)
                        '''
                        invite_code_obj = models.Invite_Code.objects.filter(activate_status=False).first()
                        if invite_code_obj:
                            member.invite_code = invite_code_obj.invite_code
                            member.save()
                            invite_code_obj.activate_status = True
                            invite_code_obj.save()
                            # post_data = dict(request.POST.lists())
                            # print(request.data.get('mobile_no'))
                            # print(post_data.keys())

                            # if 'register_code' in post_data.keys() and request.data.get('register_code') is not None and request.data.get('register_code')!='':
                            if request.data.get('register_code') is not None and request.data.get('register_code') != '':
                                invite_member_f = models.Member.objects.filter(invite_code=request.data.get('register_code'))
                                if invite_member_f:
                                    invite_member=invite_member_f[0]
                                    if invite_member.invite_count is not None:
                                        invite_member.invite_count = invite_member.invite_count + 1
                                    else:
                                        invite_member.invite_count = 1
                                    invite_member.save()
                                    # invitation campaign
                                    campaign_invitation = models.Campaign_Invitation_Code.objects.first()
                                    if campaign_invitation and campaign_invitation.activity_status:
                                        invitation_times = campaign_invitation.invitation_times
                                        if invitation_times and invite_member.invite_count >= invitation_times:
                                            # register cash back
                                            # voucher
                                            voucherObj = campaign_invitation.voucher
                                            if voucherObj:
                                                cursor = connection.cursor()
                                                cursor.execute("select * from app01_invicode where voucher_id = %s and  status=0 limit 1" % voucherObj.id)
                                                row2 = cursor.fetchall()
                                                if row2:
                                                    invicode_id=row2[0][0]
                                                    #add expire date
                                                    invicode_obj = models.Invicode.objects.filter(id=invicode_id).first()
                                                    invicode_expire_date = voucherObj.expiring_date
                                                    if invicode_obj:

                                                        if invicode_obj.vaild_days and invicode_obj.vaild_days > 0:
                                                            v_days = invicode_obj.vaild_days - 1
                                                            now_expire_date = datetime.datetime.now().date() + datetime.timedelta(
                                                                days=v_days)
                                                            if now_expire_date >= voucherObj.expiring_date:

                                                                invicode_expire_date = voucherObj.expiring_date
                                                            else:
                                                                invicode_expire_date = now_expire_date

                                                        else:
                                                            invicode_expire_date = voucherObj.expiring_date
                                                    sql="update app01_invicode set status=1 ,member_id=%s,register_date='%s',expire_date='%s' where id=%s" % (member.id,datetime.datetime.now(),invicode_expire_date,invicode_id)
                                                    print(sql)
                                                    cursor.execute(sql)
                                                #invicodeOjb = models.Invicode.objects.filter(voucher__id=voucherObj.id,status=0).first()
                                                #if invicodeOjb:
                                                 #   invicodeOjb.status = 1
                                                  #  invicodeOjb.member =member
                                                   # invicodeOjb.register_date=datetime.datetime.now()
                                                    #invicodeOjb.save()
                                            member_wallet = models.Wallet.objects.get(member__id=member.id)

                                            if member_wallet is None:
                                                serializer = WalletSimpleSerializer(data={'balance': 0, 'member': member.id})
                                                if serializer.is_valid():
                                                    member_wallet1 = models.Wallet.objects.create(**serializer.validated_data)
                                                    if campaign_invitation.register_cash_back > 0:
                                                        member_wallet1.balance += campaign_invitation.register_cash_back
                                                        member_wallet1.save()
                                                        serializer2 = RechargeRecordCreateSerializer(
                                                            data={'money': campaign_invitation.register_cash_back,
                                                                  'wallet': member_wallet1.id, 'type': 3})
                                                        if serializer2.is_valid():
                                                            models.RechargeRecord.objects.create(**serializer2.validated_data)
                                            else:
                                                if campaign_invitation.register_cash_back > 0:
                                                    member_wallet.balance += campaign_invitation.register_cash_back
                                                    member_wallet.save()
                                                    serializer2 = RechargeRecordCreateSerializer(
                                                        data={'money': campaign_invitation.register_cash_back,
                                                              'wallet': member_wallet.id, 'type': 3})
                                                    if serializer2.is_valid():
                                                        models.RechargeRecord.objects.create(**serializer2.validated_data)
                                            # invitation cash back
                                            inviter_wallet = models.Wallet.objects.get(member__id=invite_member.id)
                                            if inviter_wallet:
                                                # inviter voucher
                                                voucherObj = campaign_invitation.voucher
                                                if voucherObj:
                                                    cursor = connection.cursor()
                                                    cursor.execute(
                                                        "select * from app01_invicode where voucher_id = %s and  status=0 limit 1" % voucherObj.id)
                                                    row2 = cursor.fetchall()
                                                    if row2:
                                                        invicode_id = row2[0][0]
                                                        # add expire date
                                                        invicode_obj = models.Invicode.objects.filter(
                                                            id=invicode_id).first()
                                                        invicode_expire_date = voucherObj.expiring_date
                                                        if invicode_obj:

                                                            if invicode_obj.vaild_days and invicode_obj.vaild_days > 0:
                                                                v_days = invicode_obj.vaild_days - 1
                                                                now_expire_date = datetime.datetime.now().date() + datetime.timedelta(
                                                                    days=v_days)
                                                                if now_expire_date >= voucherObj.expiring_date:

                                                                    invicode_expire_date = voucherObj.expiring_date
                                                                else:
                                                                    invicode_expire_date = now_expire_date

                                                            else:
                                                                invicode_expire_date = voucherObj.expiring_date
                                                        sql = "update app01_invicode set status=1 ,member_id=%s,register_date='%s',expire_date='%s' where id=%s" % (
                                                        invite_member.id, datetime.datetime.now(),invicode_expire_date, invicode_id)
                                                        print(sql)
                                                        cursor.execute(sql)

                                                if campaign_invitation.inviter_cash_back>0:
                                                    inviter_wallet.balance += campaign_invitation.inviter_cash_back
                                                    inviter_wallet.save()
                                                    serializer2 = RechargeRecordCreateSerializer(
                                                        data={'money': campaign_invitation.inviter_cash_back,
                                                              'wallet': inviter_wallet.id, 'type': 3})
                                                    if serializer2.is_valid():
                                                        models.RechargeRecord.objects.create(**serializer2.validated_data)
                                            else:
                                                serializer1 = WalletSimpleSerializer(
                                                    data={'balance': 0, 'member': invite_member.id})
                                                if serializer1.is_valid():
                                                    inviter_wallet1 = models.Wallet.objects.create(**serializer1.validated_data)
                                                    # inviter voucher
                                                    voucherObj = campaign_invitation.voucher
                                                    if voucherObj:
                                                        cursor = connection.cursor()
                                                        cursor.execute(
                                                            "select * from app01_invicode where voucher_id = %s and  status=0 limit 1" % voucherObj.id)
                                                        row2 = cursor.fetchall()
                                                        if row2:
                                                            invicode_id = row2[0][0]
                                                            # add expire date
                                                            invicode_obj = models.Invicode.objects.filter(
                                                                id=invicode_id).first()
                                                            invicode_expire_date = voucherObj.expiring_date
                                                            if invicode_obj:

                                                                if invicode_obj.vaild_days and invicode_obj.vaild_days > 0:
                                                                    v_days = invicode_obj.vaild_days - 1
                                                                    now_expire_date = datetime.datetime.now().date() + datetime.timedelta(
                                                                        days=v_days)
                                                                    if now_expire_date >= voucherObj.expiring_date:

                                                                        invicode_expire_date = voucherObj.expiring_date
                                                                    else:
                                                                        invicode_expire_date = now_expire_date

                                                                else:
                                                                    invicode_expire_date = voucherObj.expiring_date
                                                            sql = "update app01_invicode set status=1 ,member_id=%s,register_date='%s',expire_date='%s' where id=%s" % (
                                                                invite_member.id, datetime.datetime.now(),invicode_expire_date, invicode_id)
                                                            print(sql)
                                                            cursor.execute(sql)
                                                    if  campaign_invitation.inviter_cash_back>0:
                                                        inviter_wallet1.balance += campaign_invitation.inviter_cash_back
                                                        inviter_wallet1.save()
                                                        serializer2 = RechargeRecordCreateSerializer(
                                                            data={'money': campaign_invitation.inviter_cash_back,
                                                                  'wallet': inviter_wallet1.id, 'type': 3})
                                                        if serializer2.is_valid():
                                                            models.RechargeRecord.objects.create(**serializer2.validated_data)
                if member:
                    #params = eval(request.body.decode(encoding="utf-8"))

                    #params["username"] = member.username
                    #params["password"] = member.member.nick_name
                    # 重新构造请求体, 进行编码后, 重新赋值给 request._body
                    # 注意是 request._body, 因为 request.body 是不可修改的, 但是 body 属性继承自 _body 属性, 所以直接修改 _body 属性
                    #request._body = json.dumps(params).encode(encoding="utf-8")
                    #return HttpResponseRedirect(request.META.get('HTTP_REFERER','/api/v1/member/obtaintoken/'))
                    #transaction.commit()
                    r_response = requests.post('http://localhost:8018/api/v1/member/obtaintoken/', headers={}, data={'username':member.username,'password':member.nick_name})
                    #print(response.text)
                    return Response(json.loads(r_response.text))
                    '''
                    return Response({
                        'id': member.id,
                        'username': member.username,
                        'wallet':member.wallet.id,
                        'mobile_no': member.mobile_no,
                        'dob': member.dob,
                        'invicode': member.invicode,
                         'device_token':-member.device_token,
                        'rand_code':member.nick_name

                    }, status=status.HTTP_201_CREATED)
                    '''

            #content = 'User Mobile:' + request.data.get('mobile_no') + '\n register time:' + str(time.strftime("%Y-%m-%d %H:%M:%S", time.localtime()))
            #print(content)
            #utils.send_register_email("ziyiw2019@gmail.com", content, send_type="register")
            if  member:
                #r_params = {'username':member[0].username,'password':member[0].nick_name}

                #r_params["username"] = member.username
                #r_params["password"] = member.member.nick_name
                # 重新构造请求体, 进行编码后, 重新赋值给 request._body
                # 注意是 request._body, 因为 request.body 是不可修改的, 但是 body 属性继承自 _body 属性, 所以直接修改 _body 属性
                r_response = requests.post('http://localhost:8018/api/v1/member/obtaintoken/', headers={},data={'username': member[0].username, 'password': member[0].nick_name})
                #print(r_response.text)
                response=Response(json.loads(r_response.text))
                #response = Response({'id': member_id, 'wallet': wallet_id,'username': member_username,'mobile_no': member_mobile,'device_token':device_token})
                #response = Response({'token': token.key})
                # response.setdefault('Authorization', 'Token {auth_token}'.format(auth_token=token.key))
                # response.set_cookie(
                #     'Authorization',
                #     value='Token {auth_token}'.format(auth_token=token.key),
                #     httponly=True
                # )
                return response

class LoginView_by_otp(generics.GenericAPIView):
    authentication_classes = ()
    permission_classes = (AllowAny,)
    serializer_class = serializers.LoginVerifyCodeSerializer

    def post(self, request, *args, **kwargs):
        member=None
        username = self.request.data.get("mobile_no")

        verify_code = self.request.data.get("verify_code")


        if username.isdigit():
            if len(str(username)) == 10:
                username=username[2:]
            member = models.Member.objects.filter(mobile_no__iexact=username).first()
            if not member:

                return Response({"msg": 'Mobile no. not exists',"msg_cn":"手机号不存在"}, status=status.HTTP_200_OK)
            else:
                if len(str(username))==8:
                    username='65'+username
                if verify_code and not checkOtp(username, verify_code):
                    return Response({
                        'status':'failed',
                        'msg': 'verify code error','msg_cn':'验证码错误'
                    }, status=status.HTTP_200_OK)
        else:
            return Response({
                'msg': 'mobile no. must number ','msg_cn':'手机号必须为数字'

            }, status=status.HTTP_200_OK)
        if member:
            return Response({
                'status': 'success',
                'msg': 'verify code is right'
            }, status=status.HTTP_200_OK)


class LoginView_by_email_otp(generics.GenericAPIView):
    authentication_classes = ()
    permission_classes = (AllowAny,)
    serializer_class = serializers.LoginVerifyCodeSerializer

    def post(self, request, *args, **kwargs):
        member=None
        username = self.request.data.get("email")

        verify_code = self.request.data.get("verify_code")



        member = models.Member.objects.filter(username__iexact=username).first()
        if not member:

            return Response({"msg": 'Email not exists',"msg_cn":"邮箱不存在"}, status=status.HTTP_200_OK)
        else:

            if verify_code and not checkEmailOtp(username, verify_code):
                return Response({
                    'status':'failed',
                    'msg': 'verify code error','msg_cn':'验证码错误'
                }, status=status.HTTP_200_OK)

        if member:
            return Response({
                'status': 'success',
                'msg': 'verify code is right'
            }, status=status.HTTP_200_OK)
class LoginView_by_password(generics.GenericAPIView):
    authentication_classes = ()
    permission_classes = (AllowAny,)
    serializer_class = serializers.LoginVerifyCodeSerializer
    def get_serializer_class(self):
        username = self.request.data.get("username")
        mobile_no = self.request.data.get("mobile_no")
        if not username:
            member = models.Member.objects.filter(username__iexact=username)
        else:
            if not mobile_no:
                member = models.Member.objects.filter(mobile_no__contains=mobile_no)
            else:
                member = None
        # 修改，返回wallet_id
        # member = models.Member.objects.filter(mobile_no__contains=mobile_no)
        if member:
            return super(NewRegisterView, self).get_serializer_class()
        else:
            return serializers.RegisterSerializer
    def post(self, request, *args, **kwargs):
        username = self.request.data.get("username")

        password = self.request.data.get("password")
        if username.isdigit():
            member = models.Member.objects.filter(mobile_no__iexact=username).first()
            if not member:

                return Response({"msg": 'Mobile no. not exists',"msg_cn":"手机号不存在"}, status=status.HTTP_200_OK)
            else:
                m=models.Member.objects.filter(mobile_no__iexact=username, nick_name=password).first()
                if not m:
                    return Response({"msg": 'Password error',"msg_cn":"密码错误"}, status=status.HTTP_200_OK)
        else:
            member = models.Member.objects.filter((Q(username__iexact=username) | Q(email__iexact=username))).first()
            if not member:
                return Response({"msg": 'Email not exists',"msg_cn":"邮箱不存在"}, status=status.HTTP_200_OK)
            else:
                m=member = models.Member.objects.filter((Q(username__iexact=username) | Q(email__iexact=username)), nick_name=password).first()
                if not m:
                    return Response({"msg": 'Password error',"msg_cn":"密码错误"}, status=status.HTTP_200_OK)
        if member:
            r_response = requests.post('http://localhost:8018/api/v1/member/obtaintoken/', headers={},
                                       data={'username': member.username, 'password': member.nick_name})

            response = Response(json.loads(r_response.text))

            return response
class LoginView_by_code(generics.GenericAPIView):
    authentication_classes = ()
    permission_classes = (AllowAny,)
    serializer_class = serializers.LoginVerifyCodeSerializer
    def get_serializer_class(self):
        username = self.request.data.get("username")
        mobile_no = self.request.data.get("mobile_no")
        if not username:
            member = models.Member.objects.filter(username__iexact=username)
        else:
            if not mobile_no:
                member = models.Member.objects.filter(mobile_no__contains=mobile_no)
            else:
                member = None
        # 修改，返回wallet_id
        # member = models.Member.objects.filter(mobile_no__contains=mobile_no)
        if member:
            return super(NewRegisterView, self).get_serializer_class()
        else:
            return serializers.RegisterSerializer
    def post(self, request, *args, **kwargs):
        username = self.request.data.get("username")

        #password = self.request.data.get("password")
        verify_code=self.request.data.get("verify_code")
        if verify_code and not checkOtp(username, verify_code):
            return Response({
                'status': 'failed',
                'msg': 'verify code error', 'msg_cn': '验证码错误'
            }, status=status.HTTP_200_OK)
        if username.isdigit():
            member = models.Member.objects.filter(mobile_no__iexact=username).first()
            if not member:

                return Response({"msg": 'Mobile no. not exists',"msg_cn":"手机号不存在"}, status=status.HTTP_200_OK)
            else:
                pass
                '''
                m=models.Member.objects.filter(mobile_no__iexact=username, nick_name=password).first()
                if not m:
                    return Response({"msg": 'Password error',"msg_cn":"密码错误"}, status=status.HTTP_200_OK)
                '''
        else:
            member = models.Member.objects.filter((Q(username__iexact=username) | Q(email__iexact=username))).first()
            if not member:
                return Response({"msg": 'Email not exists',"msg_cn":"邮箱不存在"}, status=status.HTTP_200_OK)
            else:
                pass
                '''
                m=member = models.Member.objects.filter((Q(username__iexact=username) | Q(email__iexact=username)), nick_name=password).first()
                if not m:
                    return Response({"msg": 'Password error',"msg_cn":"密码错误"}, status=status.HTTP_200_OK)
                '''
        if member:
            r_response = requests.post('http://localhost:8018/api/v1/member/obtaintoken/', headers={},
                                       data={'username': member.username, 'password': member.nick_name})

            response = Response(json.loads(r_response.text))

            return response
@api_view(['GET', 'POST'])
@authentication_classes([])
@permission_classes((AllowAny,))
def reset_password(request, *args, **kwargs):
    username = request.data.get("username")

    mobile_no=request.data.get("mobile_no")

    password = request.data.get("password")

    # check otp
    verify_code = request.data.get("verify_code")
    # test account for android app update


    if verify_code and not checkOtp(username, verify_code):
        return Response({
            'msg': 'verify code error','msg_cn':'验证码错误'
        }, status=status.HTTP_200_OK)
    if len(str(mobile_no))==10:
         mobile_no=mobile_no[2:]
    if not mobile_no:
        ret=models.Member.objects.filter(username__iexact=username).update(nick_name=password,password=make_password(password))
        if ret:
            member=models.Member.objects.filter(username__iexact=username).first()
            if member:
                r_response = requests.post('http://localhost:8018/api/v1/member/obtaintoken/', headers={},
                                           data={'username': member.username, 'password': member.nick_name})

                response = Response(json.loads(r_response.text))
                return response
    else:
        m=models.Member.objects.filter(username__iexact=username).first()
        if m and str(m.mobile_no)!=str(mobile_no):
            return Response({"msg": 'This email already registered',"msg_cn":"邮箱已经被注册"}, status=status.HTTP_200_OK)

        ret = models.Member.objects.filter(mobile_no__iexact=mobile_no).update(username=username,email=username,nick_name=password,
                                                                             password=make_password(password))
        if ret:
            member = models.Member.objects.filter(username__iexact=username).first()
            if member:
                r_response = requests.post('http://localhost:8018/api/v1/member/obtaintoken/', headers={},
                                           data={'username': username, 'password': member.nick_name})

                response = Response(json.loads(r_response.text))
                return response
    return Response({"msg": 'reset password failed',"msg_cn":"重置密码失败"}, status=status.HTTP_200_OK)
@api_view(['GET', 'POST'])
@authentication_classes([])
@permission_classes((AllowAny,))
def send_mail_code(request, *args, **kwargs):
  mail = request.GET.get("mail").lower()
  otp_set = models.OtpSet.objects.first()
  if otp_set:
    expire_minute = otp_set.expire_minute


  number_list = [0, 1, 2, 3, 4, 5, 6, 7, 8, 9]
  generate_number = 6
  rand_list = random.sample(number_list, generate_number)
  rand_number = ''
  for i in rand_list:
    rand_number = rand_number + str(i)


  models.LoginOtp.objects.create(mobile_no=mail, send_date=datetime.datetime.now().date(),
                                 expire_time=datetime.datetime.now() + datetime.timedelta(minutes=expire_minute),
                                 verify_code=rand_number)
  table='<h3>iTea member email verification code is:'+str(rand_number)+',it will be expired in 10 minusts.</h3>'
  m_thread = MessThread()
  m_thread.mail = mail
  m_thread.title = 'iTea email verification code'
  m_thread.message = table
  m_thread.start()
  #utils.send_register_email(mail, table, send_type="", promotion='DUOZOULU email verification code')
  return Response({"msg": 'ok'}, status=status.HTTP_200_OK)
def checkOtp(mobile_no,verify_code):
    now=datetime.datetime.now()
    verify_code_count=models.LoginOtp.objects.filter(mobile_no__iexact=mobile_no,expire_time__gt=now,verify_code=verify_code).count()
    if verify_code_count>0:
        return True
    return False
def checkEmailOtp(mobile_no,verify_code):
    now=datetime.datetime.now()
    verify_code_count=models.LoginOtp.objects.filter(mobile_no__iexact=mobile_no,expire_time__gt=now,verify_code=verify_code).count()
    if verify_code_count>0:
        return True
    return False
class MessThread(threading.Thread):
  mail=''
  title = ''
  message = ''

  def run(self):
    utils.send_register_email(self.mail, self.message, send_type="", promotion=self.title)
def random_pass(generate_number):
    pass_str = 'abcdefghijklmnopqrstuvwxyz0123456789ABCDEFGHIJKLMNOPQRSTUVWXYZ!@#$%^&*()'
    number_list = []
    for i in range(len(pass_str)):
        number_list.append(i )




    recent_list = random.sample(number_list, generate_number)
    password=''
    for pos in recent_list:
        password=password+pass_str[pos]
    return password
def random_number(generate_number):
    pass_str = '0123456789'
    number_list = []
    for i in range(len(pass_str)):
        number_list.append(i )




    recent_list = random.sample(number_list, generate_number)
    password=''
    for pos in recent_list:
        password=password+pass_str[pos]
    return password
def creat_guest_username():
    name='Guest'
    timestamp = int(datetime.datetime.now().timestamp())
    name=name+str(random_number(3))+str(timestamp)
    return name
class MyTokenObtainPairSerializer(TokenObtainPairSerializer):
    def validate(self, attrs):
        data = super().validate(attrs)
        refresh = self.get_token(self.user)
        data['refresh'] = str(refresh)
        data['access'] = str(refresh.access_token)

        # Add extra responses here
        data['id'] = self.user.id
        data['username'] = self.user.username
        data['mobile_no']=self.user.mobile_no
        data['wallet']=self.user.wallet.id
        data['dob']=self.user.dob

        data['device_token']=self.user.device_token
        data['rand_code']=self.user.nick_name
        data['expires_in']=TOKEN_EXPIRE_TIME
        data['is_guest'] = self.user.is_guest
        payment_code=models.Payment_Code.objects.filter(member__id=self.user.id).first()
        if payment_code:
            data['have_payment_code']=1
        else:
            data['have_payment_code'] = 0
        data['is_secure_payment'] = self.user.is_secure_payment
        return data


class MyTokenObtainPairView(TokenObtainPairView):
    serializer_class = MyTokenObtainPairSerializer


