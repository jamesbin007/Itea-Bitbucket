from django.test import TestCase

# Create your tests here.
'''
def get_pass(request, *args, **kwargs):
    print(make_password('!ifb,itea,12'))
    return Response({'msg': 'ok',}, status=status.HTTP_200_OK)
'''