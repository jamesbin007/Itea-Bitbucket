from app01 import models
import datetime

from django.db.models import Count,Sum
from django.db import transaction
from django.db import connection
from .serializers import WalletBalanceSerializer
from invicode import utils
from .utils import check_server
import requests
def check_long_sold_product():
    table = "<table  border='1' cellspacing='0' style='text-align:center;width:100%;font-size:0.4rem' ><tr><td colspan='4'  style='text-align:center' >Mobile Order long sold out count("+getdate(0)+")</td></tr><tr><td >S/N</td><td>outlet</td><td>topping</td><td>tea</td></tr>"
    line = ""
    list=[]
    sql='select id,outlet_name from app01_outlet where visiable=true and closed=false order by outlet_name asc'
    cursor = connection.cursor()
    cursor.execute(sql)
    row = cursor.fetchall()
    if row:
        for item in row:
            cell={}
            cell['id']=item[0]
            cell['name']=item[1]
            cell['topping']=''
            cell['product']=''
            list.append(cell)
    for item in list:

        sql="select name, long_sold_out from app01_product where id in (select product_id from app01_category_product where category_id in (select category_id from app01_outlet_category where outlet_id="+str(item['id'])+")) and long_sold_out = true and product_status=false and group_name='Product'"
        cursor = connection.cursor()
        cursor.execute(sql)
        row = cursor.fetchall()
        p_table=''
        if row:
            p_table=""
            p_index=0
            for i in row:
                if p_index==0:
                    p_table=p_table+""+i[0]+""
                else:
                    p_table = p_table + " ; " + i[0] + ""
                p_index=p_index+1
            p_table=p_table+""
        item['product']=p_table
        sql="select description ,product_status from app01_product where name in ( select relation_name from app01_toppings where toppings_type=0 and topping_status=true) and group_name='Topping' and product_status=false and outlet_id="+str(item['id'])
        cursor = connection.cursor()
        cursor.execute(sql)
        row = cursor.fetchall()
        t_table=''
        if row:
            t_table = ""
            t_index=0
            for i in row:
                if t_index==0:
                    t_table=t_table+""+i[0]+""
                else:
                    t_table = t_table + " ; " + i[0] + ""
                t_index=t_index+1
            t_table=t_table+""
        item['topping']=t_table
    index=1
    for item in list:
        if item['topping']!='' or item['product']!='':
            line=line+"<tr><td>"+str(index)+"</td><td >"+item['name']+"</td><td style='text-align:left;' >"+item['topping']+"</td><td style='text-align:left;' >"+item['product']+"</td></tr>"
            index=index+1
    table=table+line+"</table>"
    utils.send_register_email(utils.RECEIVE_MAIL, table, send_type="", promotion='Itea mobile order sold out count')
    #utils.send_register_email('ziyiw2019@gmail.com', table, send_type="", promotion='Itea mobile order sold out count')
    sql = "select * from app01_regional_manager"
    cursor = connection.cursor()
    cursor.execute(sql)
    row = cursor.fetchall()

    if row:
        for i in row:
            utils.send_register_email(i[2], table, send_type="",promotion='Itea mobile order sold out count')


def record_wallet_balance():

    with transaction.atomic():
        sql = "select sum(balance) from app01_wallet  "
        cursor = connection.cursor()
        cursor.execute(sql)
        row = cursor.fetchall()
        if row:
            if row[0][0] is not None:
                wallet_balance = row[0][0]
            else:
                wallet_balance = 0.0
        else:
            wallet_balance = 0.0
        sql = "select sum(balance) from app01_wallet where  member_id in (95,383,822,27,881,529,2749,102,1028,3458,621,952) "
        cursor = connection.cursor()
        cursor.execute(sql)
        row = cursor.fetchall()
        if row:
            if row[0][0] is not None:
                test_wallet_balance = row[0][0]
            else:
                test_wallet_balance = 0.0
        else:
            test_wallet_balance = 0.0
        serializer=WalletBalanceSerializer(data={'balance':wallet_balance,'test_balance':test_wallet_balance})
        if serializer.is_valid():
            #pass
            models.WalletBalance.objects.create(**serializer.validated_data)
        balance_record()

def balance_record():
    days = [21,20,19,18,17,16,15,14,13,12,11,10,9,8,7, 6, 5, 4, 3, 2, 1, 0]
    table = "<table border='1' cellspacing='0' style='text-align:center' ><tr><td colspan='13'  style='text-align:center' >Wallet Balance</td><td rowspan='2'>Test Account Balance</td></tr><tr><td>date</td><td>topup (GrabPay)</td><td>topup (CreditCard)</td><td>topup (outlet)</td><td>topup (all)</td><td>wallet payment</td><td>cash back</td><td>OrderCancel refund</td><td>OrderCancel(test) refund</td><td>Change Amount</td><td>Yesterday Balance</td><td>Today Balance</td><td>Differential Amount</td></tr>"
    line=""
    # wirecard
    for i in days:
            #sql = "select sum(money) from app01_RechargeRecord where type=0 and status=1 and (request_id is not null and \"grab_txID\" is null) and (money=10 or money=20 or money=50) and to_char(created,'yyyy-mm-dd')=to_char(current_date,'yyyy-mm-dd')"
            sql = "select sum(money) from app01_RechargeRecord where type=0 and status=1 and (request_id is not null and \"grab_txID\" is null)  and to_char(created+interval '8' hour,'yyyy-mm-dd')='"+getdate(i)+"'"
            cursor = connection.cursor()
            cursor.execute(sql)
            row = cursor.fetchall()
            if row:
                if row[0][0] is not None:
                    wirecard_topup_money = row[0][0]
                else:
                    wirecard_topup_money = 0.0
            else:
                wirecard_topup_money = 0.0
            print(str(wirecard_topup_money))
            # grabpay
            #sql = "select sum(money) from app01_RechargeRecord where type=0 and status=1 and (request_id is not null and \"grab_txID\" is not null) and (money=10 or money=20 or money=50) and to_char(created,'yyyy-mm-dd')=to_char(current_date,'yyyy-mm-dd')"
            sql = "select sum(money) from app01_RechargeRecord where type=0 and status=1 and (request_id is not null and \"grab_txID\" is not null)  and to_char(created+interval '8' hour,'yyyy-mm-dd')='"+getdate(i)+"'"
            cursor = connection.cursor()
            cursor.execute(sql)
            row = cursor.fetchall()
            if row:
                if row[0][0] is not None:
                    grabpay_topup_money = row[0][0]
                else:
                    grabpay_topup_money = 0.0
            else:
                grabpay_topup_money = 0.0
            print(str(grabpay_topup_money))
            # outlet
            sql = "select sum(money) from app01_topuprecord where to_char(created+interval '8' hour,'yyyy-mm-dd')='"+getdate(i)+"'"
            cursor = connection.cursor()
            cursor.execute(sql)
            row = cursor.fetchall()
            if row:
                if row[0][0] is not None:
                    outlet_topup_money = row[0][0]
                else:
                    outlet_topup_money = 0.0
            else:
                outlet_topup_money = 0.0
            sum_topup_money = wirecard_topup_money + grabpay_topup_money + outlet_topup_money

            # wallet sumAmount
            # sql="select  sum(app01_transaction.total_money)  from app01_transaction   where to_char(app01_transaction.payment_datetime,'yyyy-mm-dd')=to_char(current_date,'yyyy-mm-dd')  and app01_transaction.transaction_status in (4,5) and  payment_modes=8 "
            sql = "select sum(money) from app01_rechargerecord where type in (1,7) and to_char(created,'yyyy-mm-dd')='"+getdate(i)+"'"
            cursor = connection.cursor()
            cursor.execute(sql)
            row = cursor.fetchall()
            if row:
                if row[0][0] is not None:
                    sum_payment = row[0][0]
                else:
                    sum_payment = 0.0
            else:
                sum_payment = 0.0
            # cashback
            sql = "select sum(money) from app01_rechargerecord where type in (3) and to_char(created+interval '8' hour,'yyyy-mm-dd')='"+getdate(i)+"'"
            cursor = connection.cursor()
            cursor.execute(sql)
            row = cursor.fetchall()
            if row:
                if row[0][0] is not None:
                    cashback = row[0][0]
                else:
                    cashback = 0.0
            else:
                cashback = 0.0
            # cashback deduction
            sql = "select sum(money) from app01_rechargerecord where type in (4) and to_char(created+interval '8' hour,'yyyy-mm-dd')='"+getdate(i)+"'"
            cursor = connection.cursor()
            cursor.execute(sql)
            row = cursor.fetchall()
            if row:
                if row[0][0] is not None:
                    cashback_deduction = row[0][0]
                else:
                    cashback_deduction = 0.0
            else:
                cashback_deduction = 0.0
            cashback = cashback - cashback_deduction
            # refund
            sql = "select sum(money) from app01_rechargerecord where type in (2) and to_char(created+interval '8' hour,'yyyy-mm-dd')='"+getdate(i)+"'"
            cursor = connection.cursor()
            cursor.execute(sql)
            row = cursor.fetchall()
            if row:
                if row[0][0] is not None:
                    refund = row[0][0]
                else:
                    refund = 0.0
            else:
                refund = 0.0

            increase_decrease_value = sum_topup_money + cashback + refund - sum_payment

            #test refund
            sql = "select sum(money) from app01_rechargerecord where type in (2) and to_char(created+interval '8' hour,'yyyy-mm-dd')='" + getdate(
                i) + "' and wallet_id in ( select id from app01_wallet where member_id in (95,383,822,27,881,529,2749,102,1028,3458,621,952)) "
            cursor = connection.cursor()
            cursor.execute(sql)
            row = cursor.fetchall()
            if row:
                if row[0][0] is not None:
                    test_refund = row[0][0]
                else:
                    test_refund = 0.0
            else:
                test_refund = 0.0

            increase_decrease_value = sum_topup_money + cashback + refund - sum_payment

            # yesterday iPay wallet balance
            sql = "select balance from app01_walletbalance where to_char(record_date,'yyyy-mm-dd')=to_char(current_date-interval '"+str(i+1)+"' day ,'yyyy-mm-dd')"
            cursor = connection.cursor()
            cursor.execute(sql)
            row = cursor.fetchall()
            if row:
                if row[0][0] is not None:
                    yesterday_wallet_balance = row[0][0]
                else:
                    yesterday_wallet_balance = 0.0
            else:
                yesterday_wallet_balance = 0.0
            # iPay wallet  balance(test)
            #sql = "select test_balance from app01_walletbalance where to_char(record_date,'yyyy-mm-dd')=to_char(current_date-interval '"+str(i+1)+"' day ,'yyyy-mm-dd') member_id in (95,383,822,27,881,529,2749,102,1028,3458,621,952) "
            sql = "select test_balance from app01_walletbalance where to_char(record_date,'yyyy-mm-dd')=to_char(current_date-interval '" + str(i) + "' day ,'yyyy-mm-dd') "
            cursor = connection.cursor()
            cursor.execute(sql)
            row = cursor.fetchall()
            if row:
                if row[0][0] is not None:
                    wallet_test_balance = row[0][0]
                else:
                    wallet_test_balance = 0.0
            else:
                wallet_test_balance = 0.0

            # iPay wallet balance
            #sql = "select sum(balance) from app01_wallet "
            sql = "select balance from app01_walletbalance where to_char(record_date,'yyyy-mm-dd')=to_char(current_date-interval '" + str(i) + "' day ,'yyyy-mm-dd')"
            cursor = connection.cursor()
            cursor.execute(sql)
            row = cursor.fetchall()
            if row:
                if row[0][0] is not None:
                    wallet_balance = row[0][0]
                else:
                    wallet_balance = 0.0
            else:
                wallet_balance = 0.0
            add_redecue_balance = getFloat(increase_decrease_value)
            if (add_redecue_balance >= 0):
                incre_decre_value = '+' + str(add_redecue_balance)
            else:
                incre_decre_value = '' + str(add_redecue_balance)
            different_value = getFloat(wallet_balance - (yesterday_wallet_balance + add_redecue_balance))
            if different_value >= 0:
                str_different_value = '+' + str(different_value)
            else:
                str_different_value = '' + str(different_value)
            if yesterday_wallet_balance ==0:
                str_different_value='0.0'
            line =line+ "<tr><td>"+getdate(i)+"</td><td>" + str(
                getFloat(grabpay_topup_money)) + "</td><td>" + str(
                getFloat(wirecard_topup_money)) + "</td><td>" + str(
                getFloat(outlet_topup_money)) + "</td><td>" + str(
                getFloat(sum_topup_money)) + "</td><td>" + str(getFloat(sum_payment)) + "</td><td>" + str(
                getFloat(cashback)) + "</td><td>" + str(getFloat(refund)) + "</td><td>"+str(getFloat(test_refund))+"</td><td>" + incre_decre_value + "</td><td>" + str(
                getFloat(yesterday_wallet_balance)) + "</td><td>" + str(
                getFloat(wallet_balance)) + "</td><td><font color='red'>" + str_different_value + "</font></td><td>" + str(
                getFloat(wallet_test_balance)) + "</tr>"
    table=table+line+"</table>"
    utils.send_register_email(utils.RECEIVE_MAIL, table, send_type="balance", promotion='')


def getFloat(f):

    g = '%.2f' % f
    return float(g)
def getdate( beforeOfDay):
    today = datetime.datetime.now()
    # 计算偏移量
    offset = datetime.timedelta(days=-beforeOfDay)
    # 获取想要的日期的时间
    re_date = (today + offset).strftime('%Y-%m-%d')
    return re_date

def count_purchase():
    week_day = [13,12,11,10,9,8,7, 6, 5, 4, 3, 2, 1, 0]
    query_times = [1, 2, 3, 4, 5,6,7,8,9,10]
    table = "<table border='1' cellspacing='0' style='text-align:center' ><tr><td colspan='63'  style='text-align:center' >Purchase Times Count</td></tr>"
    thead = "<tr><td rowspan='2'>times</td>"
    cursor = connection.cursor()
    today_times_list=[]
    all_times_list=[]
    tfoot="<tr><td >total</td>"
    for day in week_day:
        sql_today = "select count(*) from app01_transaction where transaction_status in (4,5) and to_char(app01_transaction.payment_datetime,'yyyy-mm-dd')='"+ getdate(
                    day)+"'"
        cursor.execute(sql_today)
        row = cursor.fetchall()
        if row:
            if row[0][0] is not None:
                today_times = row[0][0]
                today_times_list.append({'date':getdate(day),'times':today_times})
            else:
                today_times = 0.0
                today_times_list.append({'date':getdate(day),'times':today_times})
        sql_count_all = "select count(temp.member_id) from (select count(*) as m_count,member_id from app01_transaction where  transaction_status in (4,5)  and to_char(app01_transaction.payment_datetime,'yyyy-mm-dd')<='"+getdate(day)+"'  group by member_id order by member_id asc) as temp"
        cursor.execute(sql_count_all)
        row = cursor.fetchall()
        if row:
            if row[0][0] is not None:
                all_count_times = row[0][0]
                all_times_list.append({'date': getdate(day), 'times': all_count_times})
            else:
                all_count_times = 0.0
                all_times_list.append({'date': getdate(day), 'times': all_count_times})
        tfoot = tfoot + "<td  ><span style='color:#159246'>" + str(today_times) + "</span></td><td></td><td><span style='color:#ff0000'>"+str(all_count_times)+"</span></td><td></td>"
        thead = thead + "<td colspan='4' >" + getdate(day) + "</td>"
    thead = thead + "</tr>"
    tfoot = tfoot+ "</tr>"
    table = table + thead
    t_today="<tr>"
    for day in week_day:
        t_today = t_today + "<td >today</td><td >today percent</td><td>all</td><td>all percent</td>"
    t_today = t_today + "</tr>"
    table = table + t_today
    for times in query_times:
        tbody = ""
        if times != 10:
            tbody = "<tr><td>" + str(times) + "</td>"
        else:
            tbody = "<tr><td>" + '>=' + str(times) + "</td>"
        for day in week_day:


            if times != 10:
                sql_all = "select count(temp.m_count) from (select count(*) as m_count,member_id from app01_transaction where  transaction_status in (4,5)  and to_char(app01_transaction.payment_datetime,'yyyy-mm-dd')<='" + getdate(day) + "'  group by member_id order by member_id asc) as temp where temp.m_count=" + str(times)
                sql = "select count(*) from app01_transaction where member_id in (select temp.member_id from (select count(*) as m_count,member_id from app01_transaction where  transaction_status in (4,5)    group by member_id order by member_id asc) as temp where temp.m_count=" +  str(
                    times) + ") and  transaction_status in (4,5) and to_char(app01_transaction.payment_datetime,'yyyy-mm-dd')='" + getdate(
                    day) + "' "
            else:
                sql="select count(*) from app01_transaction where member_id in (select temp.member_id from (select count(*) as m_count,member_id from app01_transaction where  transaction_status in (4,5)    group by member_id order by member_id asc) as temp where temp.m_count>="+ str(times)+") and transaction_status in (4,5) and to_char(app01_transaction.payment_datetime,'yyyy-mm-dd')='" + getdate(
                    day) + "' "
                sql_all = "select count(temp.m_count) from (select count(*) as m_count,member_id from app01_transaction where  transaction_status in (4,5)  and to_char(app01_transaction.payment_datetime,'yyyy-mm-dd')<='" + getdate(day) + "'  group by member_id order by member_id asc) as temp where temp.m_count>=" + str(times)


            cursor.execute(sql)
            row = cursor.fetchall()
            if row:
                if row[0][0] is not None:
                    p_times = row[0][0]
                else:
                    p_times = 0.0
            cursor.execute(sql_all)
            row = cursor.fetchall()
            if row:
                if row[0][0] is not None:
                    all_p_times = row[0][0]
                else:
                    all_p_times = 0.0
            for day_times in today_times_list:
                if getdate(day)==day_times.get('date'):
                    today_count_times=day_times.get('times')
                    break

            if today_count_times>0:
                times_percent='{:.2f}%'.format(p_times/today_count_times*100)
            for all_times in all_times_list:
                if getdate(day)==all_times.get('date'):
                    all_count_times=all_times.get('times')
                    break

            if all_count_times>0:
                all_times_percent='{:.2f}%'.format(all_p_times/all_count_times*100)
            tbody = tbody + "<td ><span style='color:#159246'>" + str(p_times) + "</span></td><td><span style='color:#154692'>"+times_percent+"</span></td><td ><span style='color:#ff0000'>"+str(all_p_times)+"</span></td><td><span style='color:#159292'>"+str(all_times_percent)+"</span></td>"
        tbody = tbody + "</tr>"

        table = table + tbody
    table = table + tfoot
    table = table + "</table>"
    # print(table)
    utils.send_register_email(utils.RECEIVE_MAIL, table, send_type="purchase", promotion='')

def erpGoodsCount():

    try:

        #response = requests.get("http://47.74.156.85:8008/api/v1/card/sendMessage/")
        checks = check_server('47.74.156.85', 8008, 'api/v1/card/sendMessage/')
        check_result_1 = checks.check()
        #response = requests.get("http://47.74.156.85:8008/api/v1/card/sendMessage/",headers={'Authorization':'Token fa3c5db850ada70422a02e4638984dc08822f010'})

        #return json.loads(response.text)
    except Exception as e:
        return {'msg': 'error'}

def erpStockAlert():

    try:

        #response = requests.get("http://47.74.156.85:8008/api/v1/card/sendMessage/")
        checks = check_server('47.74.156.85', 8008, 'api/v1/card/getStockAlert/')
        check_result_1 = checks.check()
        #response = requests.get("http://47.74.156.85:8008/api/v1/card/sendMessage/",headers={'Authorization':'Token fa3c5db850ada70422a02e4638984dc08822f010'})

        #return json.loads(response.text)
    except Exception as e:
        return {'msg': 'error'}
def productStockLog():

    try:

        #response = requests.get("http://47.74.156.85:8008/api/v1/card/sendMessage/")
        checks = check_server('47.74.156.85', 8008, 'api/v1/card/productStockLog/')
        check_result_1 = checks.check()
        #response = requests.get("http://47.74.156.85:8008/api/v1/card/sendMessage/",headers={'Authorization':'Token fa3c5db850ada70422a02e4638984dc08822f010'})

        #return json.loads(response.text)
    except Exception as e:
        return {'msg': 'error'}
def getStockDetails():

    try:

        #response = requests.get("http://47.74.156.85:8008/api/v1/card/sendMessage/")
        checks = check_server('47.74.156.85', 8008, 'api/v1/card/getStockDetails/')
        check_result_1 = checks.check()
        #response = requests.get("http://47.74.156.85:8008/api/v1/card/sendMessage/",headers={'Authorization':'Token fa3c5db850ada70422a02e4638984dc08822f010'})

        #return json.loads(response.text)
    except Exception as e:
        return {'msg': 'error'}

def getOutletWorkHours():

    try:

        #response = requests.get("http://47.74.156.85:8008/api/v1/card/sendMessage/")
        checks = check_server('47.74.156.85', 8010, 'api/v1/card/getOutletWorkHours/')
        check_result_1 = checks.check()
        #response = requests.get("http://47.74.156.85:8008/api/v1/card/sendMessage/",headers={'Authorization':'Token fa3c5db850ada70422a02e4638984dc08822f010'})

        #return json.loads(response.text)
    except Exception as e:
        return {'msg': 'error'}
def schedule_count():

    try:

        #response = requests.get("http://47.74.156.85:8008/api/v1/card/sendMessage/")
        checks = check_server('47.74.156.85', 8010, 'api/v1/invicode/schedule_count/')
        check_result_1 = checks.check()
        #response = requests.get("http://47.74.156.85:8008/api/v1/card/sendMessage/",headers={'Authorization':'Token fa3c5db850ada70422a02e4638984dc08822f010'})

        #return json.loads(response.text)
    except Exception as e:
        return {'msg': 'error'}

def duozoulu_prize_count():

    try:

        # response = requests.get("http://47.74.156.85:8008/api/v1/card/sendMessage/")
        checks = check_server('47.74.208.48', 8100, 'api/v1/card/testConfirm/')
        check_result_1 = checks.check()
        # response = requests.get("http://47.74.156.85:8008/api/v1/card/sendMessage/",headers={'Authorization':'Token fa3c5db850ada70422a02e4638984dc08822f010'})

        # return json.loads(response.text)
    except Exception as e:
        return {'msg': 'error'}


def AveragePricePerCupMail():
    try:

        # response = requests.get("http://47.74.156.85:8008/api/v1/card/sendMessage/")
        checks = check_server('47.74.156.85', 8080, 'iTeaMS/AveragePricePerCupMail')
        check_result_1 = checks.check()
        # response = requests.get("http://47.74.156.85:8008/api/v1/card/sendMessage/",headers={'Authorization':'Token fa3c5db850ada70422a02e4638984dc08822f010'})

        # return json.loads(response.text)
    except Exception as e:
        return {'msg': 'error'}
def AllOutletSalesMail():
    try:

        # response = requests.get("http://47.74.156.85:8008/api/v1/card/sendMessage/")
        checks = check_server('47.74.156.85', 8080, 'iTeaMS/AllOutletSalesMail')
        check_result_1 = checks.check()
        # response = requests.get("http://47.74.156.85:8008/api/v1/card/sendMessage/",headers={'Authorization':'Token fa3c5db850ada70422a02e4638984dc08822f010'})

        # return json.loads(response.text)
    except Exception as e:
        return {'msg': 'error'}

def MonthBonusMail():
    try:

        # response = requests.get("http://47.74.156.85:8008/api/v1/card/sendMessage/")
        checks = check_server('47.74.156.85', 8080, 'iTeaMS/MonthBonusMail')
        check_result_1 = checks.check()
        # response = requests.get("http://47.74.156.85:8008/api/v1/card/sendMessage/",headers={'Authorization':'Token fa3c5db850ada70422a02e4638984dc08822f010'})

        # return json.loads(response.text)
    except Exception as e:
        return {'msg': 'error'}
def getSalesAndWorkHours():
    try:

        # response = requests.get("http://47.74.156.85:8008/api/v1/card/sendMessage/")
        checks = check_server('47.74.156.85', 8010, 'api/v1/campaign/getSalesAndWorkHours/')
        check_result_1 = checks.check()
        # response = requests.get("http://47.74.156.85:8008/api/v1/card/sendMessage/",headers={'Authorization':'Token fa3c5db850ada70422a02e4638984dc08822f010'})

        # return json.loads(response.text)
    except Exception as e:
        return {'msg': 'error'}
def timing_modify_category_time():
    try:

        # response = requests.get("http://47.74.156.85:8008/api/v1/card/sendMessage/")
        checks = check_server('47.74.156.85', 8068, 'api/v1/outlet/timing_modify_category_time/')
        check_result_1 = checks.check()
        # response = requests.get("http://47.74.156.85:8008/api/v1/card/sendMessage/",headers={'Authorization':'Token fa3c5db850ada70422a02e4638984dc08822f010'})

        # return json.loads(response.text)
    except Exception as e:
        return {'msg': 'error'}
def getYesterdaySalesAndWorkHours():
    try:

        # response = requests.get("http://47.74.156.85:8008/api/v1/card/sendMessage/")
        checks = check_server('47.74.156.85', 8010, 'api/v1/campaign/getYesterdaySalesAndWorkHours/')
        check_result_1 = checks.check()
        # response = requests.get("http://47.74.156.85:8008/api/v1/card/sendMessage/",headers={'Authorization':'Token fa3c5db850ada70422a02e4638984dc08822f010'})

        # return json.loads(response.text)
    except Exception as e:
        return {'msg': 'error'}
def getOutletEmployeeWorkHours():
    try:

        # response = requests.get("http://47.74.156.85:8008/api/v1/card/sendMessage/")
        checks = check_server('47.74.156.85', 8069, 'api/v1/card/getOutletEmployeeWorkHours/')
        check_result_1 = checks.check()
        # response = requests.get("http://47.74.156.85:8008/api/v1/card/sendMessage/",headers={'Authorization':'Token fa3c5db850ada70422a02e4638984dc08822f010'})

        # return json.loads(response.text)
    except Exception as e:
        return {'msg': 'error'}
def getOutletEmployeeWorkHoursAndByEmployee():
    try:

        # response = requests.get("http://47.74.156.85:8008/api/v1/card/sendMessage/")
        checks = check_server('47.74.156.85', 8069, 'api/v1/card/getOutletEmployeeWorkHoursAndByEmployee/')
        check_result_1 = checks.check()
        # response = requests.get("http://47.74.156.85:8008/api/v1/card/sendMessage/",headers={'Authorization':'Token fa3c5db850ada70422a02e4638984dc08822f010'})

        # return json.loads(response.text)
    except Exception as e:
        return {'msg': 'error'}
def getBreadFreshAlert():

    try:

        #response = requests.get("http://47.74.156.85:8008/api/v1/card/sendMessage/")
        checks = check_server('47.74.156.85', 8808, 'api/v1/card/getBreadFreshAlert/')
        check_result_1 = checks.check()
        #response = requests.get("http://47.74.156.85:8008/api/v1/card/sendMessage/",headers={'Authorization':'Token fa3c5db850ada70422a02e4638984dc08822f010'})

        #return json.loads(response.text)
    except Exception as e:
        return {'msg': 'error'}
def getPosCompare_month_count():

    try:

        #response = requests.get("http://47.74.156.85:8008/api/v1/card/sendMessage/")
        checks = check_server('47.74.156.85', 8808, 'api/v1/campaign/getPosCompare_month_count/')
        check_result_1 = checks.check()
        #response = requests.get("http://47.74.156.85:8008/api/v1/card/sendMessage/",headers={'Authorization':'Token fa3c5db850ada70422a02e4638984dc08822f010'})

        #return json.loads(response.text)
    except Exception as e:
        return {'msg': 'error'}
def posTransactionBackup():

    try:

        # response = requests.get("http://47.74.156.85:8008/api/v1/card/sendMessage/")
        checks = check_server('47.74.156.85', 8808, 'api/v1/invicode/backup_yesterday_data/')
        check_result_1 = checks.check()
        # response = requests.get("http://47.74.156.85:8008/api/v1/card/sendMessage/",headers={'Authorization':'Token fa3c5db850ada70422a02e4638984dc08822f010'})

        # return json.loads(response.text)
    except Exception as e:
        return {'msg': 'error'}

def getDurableGoods():
    try:

        #response = requests.get("http://47.74.156.85:8008/api/v1/card/getPos/")
        checks = check_server('47.74.156.85', 8008, 'api/v1/card/getDurableGoods/')
        check_result_1 = checks.check()
        #response = requests.get("http://47.74.156.85:8008/api/v1/card/getPos/",headers={'Authorization':'Token fa3c5db850ada70422a02e4638984dc08822f010'})

        #return json.loads(response.text)
    except Exception as e:
        return {'msg': 'error'}
def erpOrderCount():

    try:

        #response = requests.get("http://47.74.156.85:8008/api/v1/card/getPos/")
        checks = check_server('47.74.156.85', 8008, 'api/v1/card/getPos/')
        check_result_1 = checks.check()
        #response = requests.get("http://47.74.156.85:8008/api/v1/card/getPos/",headers={'Authorization':'Token fa3c5db850ada70422a02e4638984dc08822f010'})

        #return json.loads(response.text)
    except Exception as e:
        return {'msg': 'error'}
def erpSalesComp():

    try:

        #response = requests.get("http://47.74.156.85:8008/api/v1/card/getPos/")
        checks = check_server('47.74.156.85', 8808, 'api/v1/card/getPosCompare_new/')
        check_result_1 = checks.check()
        #response = requests.get("http://47.74.156.85:8008/api/v1/card/getPosCompare/",headers={'Authorization':'Token fa3c5db850ada70422a02e4638984dc08822f010'})

        #return json.loads(response.text)
    except Exception as e:
        return {'msg': 'error'}
def shoesSalesComp():

    try:

        #response = requests.get("http://47.74.156.85:8008/api/v1/card/getPos/")
        checks = check_server('47.74.156.85', 8118, 'api/v1/card/getPosCompare_new/')
        checks1 = check_server('47.74.156.85', 8038, 'api/v1/card/getPosCompare_new/')

        checks2 = check_server('47.74.156.85', 8178, 'api/v1/card/getPosCompare_new/')
        #checks3 = check_server('47.74.156.85', 8048, 'api/v1/card/getPosCompare_new/')
        check_result_1 = checks.check()
        check_result_2 = checks1.check()
        check_result_3 = checks2.check()
        #check_result_4 = checks3.check()
        #response = requests.get("http://47.74.156.85:8008/api/v1/card/getPosCompare/",headers={'Authorization':'Token fa3c5db850ada70422a02e4638984dc08822f010'})

        #return json.loads(response.text)
    except Exception as e:
        return {'msg': 'error'}
def shoesSalesComp_indonisia():

    try:

        #response = requests.get("http://47.74.156.85:8008/api/v1/card/getPos/")

        checks3 = check_server('47.74.156.85', 8048, 'api/v1/card/getPosCompare_new/')

        check_result_4 = checks3.check()
        #response = requests.get("http://47.74.156.85:8008/api/v1/card/getPosCompare/",headers={'Authorization':'Token fa3c5db850ada70422a02e4638984dc08822f010'})

        #return json.loads(response.text)
    except Exception as e:
        return {'msg': 'error'}
def getVivaiaEmployeeSalesData():

    try:

        #response = requests.get("http://47.74.156.85:8008/api/v1/card/getPos/")
        checks = check_server('47.74.156.85', 8118, 'api/v1/card/getEmployeeSalesData/')
        check_result_1 = checks.check()
        checks1 = check_server('47.74.156.85', 8178, 'api/v1/card/getEmployeeSalesData/')
        check_result_2 = checks1.check()
        #response = requests.get("http://47.74.156.85:8008/api/v1/card/getPosCompare/",headers={'Authorization':'Token fa3c5db850ada70422a02e4638984dc08822f010'})

        #return json.loads(response.text)
    except Exception as e:
        return {'msg': 'error'}
def getDuozouluEmployeeSalesData():

    try:

        #response = requests.get("http://47.74.156.85:8008/api/v1/card/getPos/")
        checks = check_server('47.74.156.85', 8128, 'api/v1/card/getEmployeeSalesData/')
        check_result_1 = checks.check()
        #response = requests.get("http://47.74.156.85:8008/api/v1/card/getPosCompare/",headers={'Authorization':'Token fa3c5db850ada70422a02e4638984dc08822f010'})

        #return json.loads(response.text)
    except Exception as e:
        return {'msg': 'error'}
def shoesSalesComp_1():

    try:

        #response = requests.get("http://47.74.156.85:8008/api/v1/card/getPos/")
        checks = check_server('47.74.156.85', 8118, 'api/v1/card/getPosCompare_new_1hour/')
        checks = check_server('47.74.156.85', 8178, 'api/v1/card/getPosCompare_new_1hour/')
        check_result_1 = checks.check()
        #response = requests.get("http://47.74.156.85:8008/api/v1/card/getPosCompare/",headers={'Authorization':'Token fa3c5db850ada70422a02e4638984dc08822f010'})

        #return json.loads(response.text)
    except Exception as e:
        return {'msg': 'error'}
def countDuozouluItemQuantity():

    try:

        #response = requests.get("http://47.74.156.85:8008/api/v1/card/getPos/")
        checks = check_server('47.74.156.85', 8128, 'api/v1/card/getDuoProductSalesData/')
        check_result_1 = checks.check()
        #response = requests.get("http://47.74.156.85:8008/api/v1/card/getPosCompare/",headers={'Authorization':'Token fa3c5db850ada70422a02e4638984dc08822f010'})

        #return json.loads(response.text)
    except Exception as e:
        return {'msg': 'error'}
def DuozouluChinaOrder():

    try:

        #response = requests.get("http://47.74.156.85:8008/api/v1/card/getPos/")
        checks = check_server('47.74.156.85', 8128, 'api/v1/card/getReplenishment/')
        check_result_1 = checks.check()
        #response = requests.get("http://47.74.156.85:8008/api/v1/card/getPosCompare/",headers={'Authorization':'Token fa3c5db850ada70422a02e4638984dc08822f010'})

        #return json.loads(response.text)
    except Exception as e:
        return {'msg': 'error'}
def DuozouluOutletDispatch():

    try:

        #response = requests.get("http://47.74.156.85:8008/api/v1/card/getPos/")
        checks = check_server('47.74.156.85', 8128, 'api/v1/card/getOutletDispatch/')
        check_result_1 = checks.check()
        #response = requests.get("http://47.74.156.85:8008/api/v1/card/getPosCompare/",headers={'Authorization':'Token fa3c5db850ada70422a02e4638984dc08822f010'})

        #return json.loads(response.text)
    except Exception as e:
        return {'msg': 'error'}
def DuozouluBackupStock():

    try:

        #response = requests.get("http://47.74.156.85:8008/api/v1/card/getPos/")
        checks = check_server('47.74.156.85', 8128, 'api/v1/card/backupStock/')
        check_result_1 = checks.check()
        #response = requests.get("http://47.74.156.85:8008/api/v1/card/getPosCompare/",headers={'Authorization':'Token fa3c5db850ada70422a02e4638984dc08822f010'})

        #return json.loads(response.text)
    except Exception as e:
        return {'msg': 'error'}
def countVivaiaItemQuantity():

    try:

        #response = requests.get("http://47.74.156.85:8008/api/v1/card/getPos/")
        checks = check_server('47.74.156.85', 8118, 'api/v1/card/getDuoProductSalesData/')
        check_result_1 = checks.check()
        checks1 = check_server('47.74.156.85', 8038, 'api/v1/card/getDuoProductSalesData/')
        check_result_2 = checks1.check()
        checks2 = check_server('47.74.156.85', 8178, 'api/v1/card/getDuoProductSalesData/')
        check_result_3 = checks2.check()
        checks3 = check_server('47.74.156.85', 8128, 'api/v1/card/getDuoProductSalesData/')
        check_result_4 = checks3.check()
        checks4 = check_server('47.74.156.85', 8048, 'api/v1/card/getDuoProductSalesData/')
        check_result_5 = checks4.check()
        #response = requests.get("http://47.74.156.85:8008/api/v1/card/getPosCompare/",headers={'Authorization':'Token fa3c5db850ada70422a02e4638984dc08822f010'})

        #return json.loads(response.text)
    except Exception as e:
        return {'msg': 'error'}
def VivaiaChinaOrder():

    try:

        #response = requests.get("http://47.74.156.85:8008/api/v1/card/getPos/")
        checks = check_server('47.74.156.85', 8118, 'api/v1/card/getReplenishment/')
        check_result_1 = checks.check()
        checks1 = check_server('47.74.156.85', 8038, 'api/v1/card/getReplenishment/')
        check_result_2 = checks1.check()
        checks2 = check_server('47.74.156.85', 8178, 'api/v1/card/getReplenishment/')
        check_result_3 = checks2.check()
        checks3 = check_server('47.74.156.85', 8048, 'api/v1/card/getReplenishment/')
        check_result_4 = checks3.check()
        #response = requests.get("http://47.74.156.85:8008/api/v1/card/getPosCompare/",headers={'Authorization':'Token fa3c5db850ada70422a02e4638984dc08822f010'})

        #return json.loads(response.text)
    except Exception as e:
        return {'msg': 'error'}
def deal_promotion_price():

    try:

        #response = requests.get("http://47.74.156.85:8008/api/v1/card/getPos/")
        checks = check_server('47.74.156.85', 8118, 'api/v1/product/deal_promotion_price/')
        check_result_1 = checks.check()
        checks1 = check_server('47.74.156.85', 8038, 'api/v1/product/deal_promotion_price/')
        check_result_2 = checks1.check()
        checks2 = check_server('47.74.156.85', 8038, 'api/v1/delivery/upload_pos_sales/')
        check_result_3 = checks2.check()
        checks5 = check_server('47.74.156.85', 8048, 'api/v1/product/deal_promotion_price/')
        check_result_5 = checks5.check()
        checks6 = check_server('47.74.156.85', 8178, 'api/v1/product/deal_promotion_price/')
        check_result_6 = checks6.check()
        #response = requests.get("http://47.74.156.85:8008/api/v1/card/getPosCompare/",headers={'Authorization':'Token fa3c5db850ada70422a02e4638984dc08822f010'})

        #return json.loads(response.text)
    except Exception as e:
        return {'msg': 'error'}
def VivaiaOutletDispatch():

    try:

        #response = requests.get("http://47.74.156.85:8008/api/v1/card/getPos/")
        checks = check_server('47.74.156.85', 8118, 'api/v1/card/getOutletDispatch/')
        check_result_1 = checks.check()
        #response = requests.get("http://47.74.156.85:8008/api/v1/card/getPosCompare/",headers={'Authorization':'Token fa3c5db850ada70422a02e4638984dc08822f010'})

        #return json.loads(response.text)
    except Exception as e:
        return {'msg': 'error'}
def update_restaunant_status():

    try:

        #response = requests.get("http://47.74.156.85:8008/api/v1/card/getPos/")
        checks = check_server('47.74.156.85', 8068, 'api/v1/card/update_status/')
        check_result_1 = checks.check()
        #response = requests.get("http://47.74.156.85:8008/api/v1/card/getPosCompare/",headers={'Authorization':'Token fa3c5db850ada70422a02e4638984dc08822f010'})

        #return json.loads(response.text)
    except Exception as e:
        return {'msg': 'error'}
def VivaiaBackupStock():

    try:

        #response = requests.get("http://47.74.156.85:8008/api/v1/card/getPos/")
        checks = check_server('47.74.156.85', 8118, 'api/v1/card/backupStock/')
        check_result_1 = checks.check()
        checks1 = check_server('47.74.156.85', 8038, 'api/v1/card/backupStock/')
        check_result_2 = checks1.check()
        checks2 = check_server('47.74.156.85', 8178, 'api/v1/card/backupStock/')
        check_result_3 = checks2.check()
        checks3 = check_server('47.74.156.85', 8048, 'api/v1/card/backupStock/')
        check_result_4 = checks3.check()
        #response = requests.get("http://47.74.156.85:8008/api/v1/card/getPosCompare/",headers={'Authorization':'Token fa3c5db850ada70422a02e4638984dc08822f010'})

        #return json.loads(response.text)
    except Exception as e:
        return {'msg': 'error'}
def IndonisiaVivaiaBackupStock():

    try:


        checks3 = check_server('47.74.156.85', 8048, 'api/v1/card/backupStock/')
        check_result_4 = checks3.check()
        checks4 = check_server('47.74.156.85', 8048, 'api/v1/card/getShoesWarehouseStockDetails/')
        check_result_5 = checks4.check()
        #response = requests.get("http://47.74.156.85:8008/api/v1/card/getPosCompare/",headers={'Authorization':'Token fa3c5db850ada70422a02e4638984dc08822f010'})

        #return json.loads(response.text)
    except Exception as e:
        return {'msg': 'error'}
def china_duozoulu_email():
  try:

    # response = requests.get("http://47.74.156.85:8008/api/v1/card/getPos/")
    checks = check_server('47.74.156.85', 8128, 'api/v1/card/china_duozoulu_email/')
    check_result_1 = checks.check()
    # response = requests.get("http://47.74.156.85:8008/api/v1/card/getPosCompare/",headers={'Authorization':'Token fa3c5db850ada70422a02e4638984dc08822f010'})

    # return json.loads(response.text)
  except Exception as e:
    return {'msg': 'error'}
def countBeneunderItemQuantity():

    try:

        #response = requests.get("http://47.74.156.85:8008/api/v1/card/getPos/")
        checks = check_server('47.74.156.85', 8158, 'api/v1/card/getDuoProductSalesData/')
        check_result_1 = checks.check()
        #response = requests.get("http://47.74.156.85:8008/api/v1/card/getPosCompare/",headers={'Authorization':'Token fa3c5db850ada70422a02e4638984dc08822f010'})

        #return json.loads(response.text)
    except Exception as e:
        return {'msg': 'error'}
def BeneunderChinaOrder():

    try:

        #response = requests.get("http://47.74.156.85:8008/api/v1/card/getPos/")
        checks = check_server('47.74.156.85', 8158, 'api/v1/card/getReplenishment/')
        check_result_1 = checks.check()
        #response = requests.get("http://47.74.156.85:8008/api/v1/card/getPosCompare/",headers={'Authorization':'Token fa3c5db850ada70422a02e4638984dc08822f010'})

        #return json.loads(response.text)
    except Exception as e:
        return {'msg': 'error'}
def BeneunderOutletDispatch():

    try:

        #response = requests.get("http://47.74.156.85:8008/api/v1/card/getPos/")
        checks = check_server('47.74.156.85', 8158, 'api/v1/card/getOutletDispatch/')
        check_result_1 = checks.check()
        #response = requests.get("http://47.74.156.85:8008/api/v1/card/getPosCompare/",headers={'Authorization':'Token fa3c5db850ada70422a02e4638984dc08822f010'})

        #return json.loads(response.text)
    except Exception as e:
        return {'msg': 'error'}
def BeneunderBackupStock():

    try:

        #response = requests.get("http://47.74.156.85:8008/api/v1/card/getPos/")
        checks = check_server('47.74.156.85', 8158, 'api/v1/card/backupStock/')
        check_result_1 = checks.check()
        #response = requests.get("http://47.74.156.85:8008/api/v1/card/getPosCompare/",headers={'Authorization':'Token fa3c5db850ada70422a02e4638984dc08822f010'})

        #return json.loads(response.text)
    except Exception as e:
        return {'msg': 'error'}
def breadFreshSalesComp():

    try:

        #response = requests.get("http://47.74.156.85:8008/api/v1/card/getPos/")
        checks = check_server('47.74.156.85', 8808, 'api/v1/card/getPosCompare_bread_include_year_goods/')
        check_result_1 = checks.check()
        #response = requests.get("http://47.74.156.85:8008/api/v1/card/getPosCompare/",headers={'Authorization':'Token fa3c5db850ada70422a02e4638984dc08822f010'})

        #return json.loads(response.text)
    except Exception as e:
        return {'msg': 'error'}
def getTastyChinaWeeklySales():

    try:

        #response = requests.get("http://47.74.156.85:8008/api/v1/card/getPos/")
        checks = check_server('47.74.156.85', 8808, 'api/v1/card/getTastyChinaWeeklySales/')
        check_result_1 = checks.check()
        #response = requests.get("http://47.74.156.85:8008/api/v1/card/getPosCompare/",headers={'Authorization':'Token fa3c5db850ada70422a02e4638984dc08822f010'})

        #return json.loads(response.text)
    except Exception as e:
        return {'msg': 'error'}
def erpOutletClockin():

    try:

        #response = requests.get("http://47.74.156.85:8008/api/v1/card/getPos/")
        checks = check_server('47.74.156.85', 8008, 'api/v1/card/getOutletClockIn/')
        check_result_1 = checks.check()
        #response = requests.get("http://47.74.156.85:8008/api/v1/card/getPosCompare/",headers={'Authorization':'Token fa3c5db850ada70422a02e4638984dc08822f010'})

        #return json.loads(response.text)
    except Exception as e:
        return {'msg': 'error'}
def erp_modify_opening_time():
    try:

        #response = requests.get("http://47.74.156.85:8008/api/v1/card/getPos/")
        checks = check_server('47.74.156.85', 8010, 'api/v1/outletInformation/update_outlet_working_time/')
        check_result_1 = checks.check()
        #malaysia upload pos
        checks1 = check_server('47.74.156.85', 8038, 'api/v1/delivery/upload_pos_sales/')
        check_result_2 = checks1.check()
        #response = requests.get("http://47.74.156.85:8008/api/v1/card/getPosCompare/",headers={'Authorization':'Token fa3c5db850ada70422a02e4638984dc08822f010'})

        #return json.loads(response.text)
    except Exception as e:
        return {'msg': 'error'}
def getMonitorClockIn():
    try:

        #response = requests.get("http://47.74.156.85:8008/api/v1/card/getPos/")
        checks = check_server('47.74.156.85', 8008, 'api/v1/card/getMonitorClockIn/')
        check_result_1 = checks.check()
        #response = requests.get("http://47.74.156.85:8008/api/v1/card/getPosCompare/",headers={'Authorization':'Token fa3c5db850ada70422a02e4638984dc08822f010'})

        #return json.loads(response.text)
    except Exception as e:
        return {'msg': 'error'}

def all_count():
    login_times=0
    lucky_draw_times=0
    order_sum_quantity=0
    order_sum_amount=0
    card_topup_amount=0
    grab_topup_amount=0
    outlet_topup_amount=0
    bronze_count=0
    silver_count=0
    gold_count=0
    diamond_count=0
    register_count=0
    wallet_amount=0
    grab_amount=0
    card_amount=0
    ipay_amount=0

    #login_times
    member_login_count_dict = models.Member.objects.filter(last_login_date=datetime.datetime.now().date()).aggregate(
        count=Count('id'))

    if member_login_count_dict:
        login_times = member_login_count_dict['count']


    # today prize times
    today_lucky_draw_times_aggre_count=models.PrizeMemberLog.objects.filter(prize_date=datetime.datetime.now().date()).aggregate(today_times_count=Sum('used_prize_times'))
    if today_lucky_draw_times_aggre_count:
        lucky_draw_times = today_lucky_draw_times_aggre_count['today_times_count']

    #order_sum_quantity
    today_order_sum_count=models.Transaction.objects.filter(payment_datetime__date=datetime.datetime.now().date(),transaction_status__in = (4,5)).aggregate(today_order_count=Count('id'))
    if today_order_sum_count:
        order_sum_quantity=today_order_sum_count['today_order_count']

    #order_sum_amount
    today_order_sum_amount = models.Transaction.objects.filter(payment_datetime__date=datetime.datetime.now().date(),
                                                              transaction_status__in=(4, 5)).aggregate(
        today_order_amount=Sum('total_money'))
    if today_order_sum_amount:
        order_sum_amount = today_order_sum_amount['today_order_amount']

    #card_topup_amount
    # wirecard
    sql = "select sum(money) from app01_RechargeRecord where type=0 and status=1 and (request_id is not null and \"grab_txID\" is null) and (money=10 or money=20 or money=50) and to_char(created+interval '8' hour,'yyyy-mm-dd')=to_char(current_date,'yyyy-mm-dd')"
    cursor = connection.cursor()
    cursor.execute(sql)
    row = cursor.fetchall()
    if row:
        if row[0][0] is not None:
            card_topup_amount = row[0][0]
        else:
            card_topup_amount = 0.0
    else:
        card_topup_amount = 0.0

    # grab_topup_amount
    sql = "select sum(money) from app01_RechargeRecord where type=0 and status=1 and (request_id is not null and \"grab_txID\" is not null) and (money=10 or money=20 or money=50) and to_char(created+interval '8' hour,'yyyy-mm-dd')=to_char(current_date,'yyyy-mm-dd')"
    cursor = connection.cursor()
    cursor.execute(sql)
    row = cursor.fetchall()
    if row:
        if row[0][0] is not None:
            grab_topup_amount = row[0][0]
        else:
            grab_topup_amount = 0.0
    else:
        grab_topup_amount = 0.0

    #outlet_topup_amount

    sql = "select sum(money) from app01_topuprecord where to_char(created+interval '8' hour,'yyyy-mm-dd')=to_char(current_date,'yyyy-mm-dd')"
    cursor = connection.cursor()
    cursor.execute(sql)
    row = cursor.fetchall()
    if row:
        if row[0][0] is not None:
            outlet_topup_amount = row[0][0]
        else:
            outlet_topup_amount = 0.0
    else:
        outlet_topup_amount = 0.0

    #bronze_count
    bronze_sum_amount = models.Member.objects.filter(membership__id=1).aggregate(
        bronze_count=Count('id'))
    if bronze_sum_amount:
        bronze_count = bronze_sum_amount['bronze_count']
    # silver_count
    silver_sum_amount = models.Member.objects.filter(membership__id=3).aggregate(
        silver_count=Count('id'))
    if silver_sum_amount:
        silver_count = silver_sum_amount['silver_count']
    # gold_count
    gold_sum_amount = models.Member.objects.filter(membership__id=5).aggregate(
        gold_count=Count('id'))
    if gold_sum_amount:
        gold_count = gold_sum_amount['gold_count']
    # diamond_count
    diamond_sum_amount = models.Member.objects.filter(membership__id=8).aggregate(
        diamond_count=Count('id'))
    if diamond_sum_amount:
        diamond_count = diamond_sum_amount['diamond_count']
    # register_count
    register_sum_amount = models.Member.objects.filter(registration_date__date=datetime.datetime.now().date()).aggregate(
        register_count=Count('id'))
    if register_sum_amount:
        register_count = register_sum_amount['register_count']

    # walletAmount
    sql = "select  sum(app01_transaction.total_money)  from app01_transaction   where to_char(app01_transaction.payment_datetime,'yyyy-mm-dd')=to_char(current_date,'yyyy-mm-dd')  and app01_transaction.transaction_status in (4,5) and  payment_modes=8  "
    cursor = connection.cursor()
    cursor.execute(sql)
    row = cursor.fetchall()
    if row:
        if row[0][0] is not None:
            wallet_amount = row[0][0]
        else:
            wallet_amount = 0.0
    else:
        wallet_amount = 0.0

    # grabPayAmount
    sql = "select  sum(app01_transaction.total_money)  from app01_transaction   where to_char(app01_transaction.payment_datetime,'yyyy-mm-dd')=to_char(current_date,'yyyy-mm-dd')  and app01_transaction.transaction_status in (4,5) and  payment_modes=12  "
    cursor = connection.cursor()
    cursor.execute(sql)
    row = cursor.fetchall()
    if row:
        if row[0][0] is not None:
            grab_amount = row[0][0]
        else:
            grab_amount = 0.0
    else:
        grab_amount = 0.0

    # creditCardAmount
    sql = "select  sum(app01_transaction.total_money)  from app01_transaction   where to_char(app01_transaction.payment_datetime,'yyyy-mm-dd')=to_char(current_date,'yyyy-mm-dd')  and app01_transaction.transaction_status in (4,5) and  payment_modes=9  "
    cursor = connection.cursor()
    cursor.execute(sql)
    row = cursor.fetchall()
    if row:
        if row[0][0] is not None:
            card_amount = row[0][0]
        else:
            card_amount = 0.0
    else:
        card_amount = 0.0
    # iPayAmount
    sql = "select  sum(money) from  app01_ipayrecord where created_date=current_date  "
    cursor = connection.cursor()
    cursor.execute(sql)
    row = cursor.fetchall()
    if row:
        if row[0][0] is not None:
            ipay_amount = row[0][0]
        else:
            ipay_amount = 0.0
    else:
        ipay_amount = 0.0
    sql="select * from app01_yesterday_count_data where to_char(created+interval '8' hour,'yyyy-mm-dd')=to_char(current_date,'yyyy-mm-dd')"
    cursor = connection.cursor()
    cursor.execute(sql)
    row = cursor.fetchall()
    if row:
        sql='delete from app01_yesterday_count_data where created=current_date'
        cursor = connection.cursor()
        cursor.execute(sql)

    sql = 'INSERT INTO app01_yesterday_count_data(login_times, lucky_draw_times, order_sum_quantity, order_sum_amount, card_topup_amount, grab_topup_amount, outlet_topup_amount, bronze_count, silver_count, gold_count, diamond_count, register_count, created,wallet_amount,grab_amount,card_amount,ipay_amount) VALUES ( '+ str(login_times)+', ' +str(lucky_draw_times) +', ' + str(order_sum_quantity)+', ' +str(order_sum_amount) +', ' +str(card_topup_amount) +', ' +str(grab_topup_amount) +', ' +str(outlet_topup_amount) +', ' +str(bronze_count) +', ' + str(silver_count)+', ' +str(gold_count )+', ' + str(diamond_count)+', ' + str(register_count)+', current_date,'+str(wallet_amount)+','+str(grab_amount)+','+str(card_amount)+','+str(ipay_amount)+')'
    cursor = connection.cursor()
    cursor.execute(sql)

    sql='select login_times, lucky_draw_times, order_sum_quantity, order_sum_amount, card_topup_amount, grab_topup_amount, outlet_topup_amount, bronze_count, silver_count, gold_count, diamond_count, register_count, created,wallet_amount,grab_amount,card_amount,ipay_amount from app01_yesterday_count_data where to_char(created,\'yyyy-mm-dd\')=to_char(current_date-interval \'1\' day,\'yyyy-mm-dd\')'
    cursor = connection.cursor()
    cursor.execute(sql)
    row = cursor.fetchall()
    if row:
        y_login_times=row[0][0]
        y_lucky_draw_times=row[0][1]
        y_order_sum_quantity=row[0][2]
        y_order_sum_amount=row[0][3]
        y_card_topup_amount=row[0][4]
        y_grab_topup_amount=row[0][5]
        y_outlet_topup_amount=row[0][6]
        y_bronze_count=row[0][7]
        y_silver_count=row[0][8]
        y_gold_count=row[0][9]
        y_diamond_count=row[0][10]
        y_register_count=row[0][11]
        y_created=row[0][12]
        y_wallet_amount=row[0][13]
        y_grab_amount = row[0][14]
        y_card_amount = row[0][15]
        y_ipay_amount = row[0][16]
        table = "<table border='1' cellspacing='0' style='text-align:center' ><tr><td colspan='3'  style='text-align:center' >Mobile Ordering Count</td></tr>"
        thead='<tr><td>Item</td><td>Today</td><td>Yesterday</td></tr>'
        thead = thead+"<tr><td >login times</td><td>"+str(login_times)+"</td>"+str(y_login_times)+"</td></tr>"
        thead = thead + "<tr><td >lucky draw times</td><td>"+str(lucky_draw_times)+"</td>"+str(y_lucky_draw_times)+"</td></tr>"
        thead = thead + "<tr><td >order sum quantity</td><td>"+str(order_sum_quantity)+"</td>"+str(y_order_sum_quantity)+"</td></tr>"
        thead = thead + "<tr><td >order sum amount</td><td>"+str(order_sum_amount)+"</td>"+str(y_order_sum_amount)+"</td></tr>"
        thead = thead + "<tr><td >wallet payment amount</td><td>" + str(wallet_amount) + "</td>" + str(y_wallet_amount) + "</td></tr>"
        thead = thead + "<tr><td >grab payment amount</td><td>" + str(grab_amount) + "</td>" + str(y_grab_amount) + "</td></tr>"
        thead = thead + "<tr><td >card payment amount</td><td>" + str(card_amount) + "</td>" + str(y_card_amount) + "</td></tr>"
        thead = thead + "<tr><td >iPay payment amount</td><td>" + str(ipay_amount) + "</td>" + str(y_ipay_amount) + "</td></tr>"
        thead = thead + "<tr><td >card topup amount</td><td>"+str(card_topup_amount)+"</td>"+str(y_card_topup_amount)+"</td></tr>"
        thead = thead + "<tr><td >grab topup amount</td><td>"+str(grab_topup_amount)+"</td>"+str(y_grab_topup_amount)+"</td></tr>"
        thead = thead + "<tr><td >outlet topup amount</td><td>"+str(outlet_topup_amount)+"</td>"+str(y_outlet_topup_amount)+"</td></tr>"
        thead = thead + "<tr><td >bronze count</td><td>"+str(bronze_count)+"</td>"+str(y_bronze_count)+"</td></tr>"
        thead = thead + "<tr><td >silver count</td><td>"+str(silver_count)+"</td>"+str(y_silver_count)+"</td></tr>"
        thead = thead + "<tr><td >gold count</td><td>"+str(gold_count)+"</td>"+str(y_gold_count)+"</td></tr>"
        thead = thead + "<tr><td >diamond count</td><td>"+str(diamond_count)+"</td>"+str(y_diamond_count)+"</td></tr>"
        thead = thead + "<tr><td >register count</td><td>"+str(register_count)+"</td>"+str(y_register_count)+"</td></tr>"

        table =table+thead+"</table>"
        #utils.send_register_email(utils.RECEIVE_MAIL, table, send_type="count", promotion='')
        utils.send_register_email('ziyiw2019@gmail.com', table, send_type="count", promotion='')
    return {'msg': 'ok'}