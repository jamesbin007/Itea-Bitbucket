from rest_framework import viewsets
from app01 import models
from . import serializers
from utils.pagination import DefaultPagination
from django_filters.rest_framework import DjangoFilterBackend
from rest_framework.filters import SearchFilter, OrderingFilter
from .permissions import CardViewSetPermission
from django.conf import settings # new
from django.views.generic.base import TemplateView
import stripe # new
from django.shortcuts import render # new
from rest_framework.permissions import AllowAny
from rest_framework.decorators import api_view,authentication_classes,permission_classes
from rest_framework.response import Response
from django.http import HttpResponse
import json
import time
from app01 import models
from .utils import check_server
from .cron import erpSalesComp,all_count,getMonitorClockIn
import requests
import threading
from django.db import connection
import datetime
from invicode.cron import send_payment
from django.db import transaction
from outlet.cron import prize_random_activity,prize_random,puzzle_random,auto_confirm
from member.services import update_member_points
stripe.api_key = settings.STRIPE_SECRET_KEY # new
from invicode.serializers import generate_random_str
#import xlwt
from check import file_utils
from invicode import utils
from invicode.cron import countPrize
from outlet.cron import prize_random
from utils.message_manage import send_message_to_token,send_message_to_token_android_tablet
import os
from member.utils import dispatch_invicode,bind_member_campaign_voucher
from .cron import count_purchase,record_wallet_balance,check_long_sold_product
from outlet.cron import auto_confirm,modify_opening_time
from django.db.models import Q,Sum,Count
import random
from transaction.utils import thread_send_mail
from member.cron import member_birthday,auto_collect
from invicode.service import record_reward_member_invicode
from member.services import deal_electric_sign
from member.views import random_pass
from transaction.cron import daily
from django.contrib.auth.hashers import make_password
from product.serializers import  ProductCUDSerializer
from card.cron import  shoesSalesComp
class CardViewSet(viewsets.ModelViewSet):
    permission_classes = (CardViewSetPermission,)
    queryset = models.Card.objects.all()
    serializer_class = serializers.CardSerializer
    pagination_class = DefaultPagination
    filter_backends = (
        DjangoFilterBackend,
        SearchFilter,
        OrderingFilter,
    )
    filter_fields = ('card_no', 'member')
    search_fields = ('card_no', 'member')
    ordering_fields = ('card_no', 'member')

    def get_queryset(self):
        ret = super(CardViewSet, self).get_queryset()
        if self.request.user.role.name in (0, 1):
            return ret
        else:
            return ret.filter(member=self.request.user)


@api_view(['GET'])
@authentication_classes([])
@permission_classes((AllowAny,))

def check(request, *args, **kwargs):
    #check server status
    checks_1 = file_utils.check_server('47.74.208.48', 3000,'login')
    #checks_1 = file_utils.check_server('47.74.156.85', 3000, 'login')
    checks_2 = file_utils.check_server('47.74.208.48', 8000, 'api/v1/outlet/')
    #checks_3 = file_utils.check_server('47.74.156.85', 7000, 'api/getcode//')

    check_result_3=None
    check_result_1=checks_1.check()
    check_result_2 = checks_2.check()
    #check_result_3 = checks_3.check()


    #check project file valid
    exclude_path = {'path_1': 'node_modules', 'path_2': '.idea', 'path_3': 'migrations', 'path_4': '__pycache__','path_5':'.git'}
    fileHandler = file_utils.FileHandler(**exclude_path)
    #file_list = fileHandler.list_all_files(os.path.abspath(os.path.dirname(settings.BASE_DIR)))
    file_list = fileHandler.list_all_files(os.path.abspath(os.path.dirname(os.path.dirname(os.path.dirname(__file__)))))
    print(os.path.abspath(os.path.dirname(os.path.dirname(os.path.dirname(os.path.dirname(__file__))))))
    #file_list = fileHandler.list_all_files(settings.BASE_DIR)
    now = datetime.datetime.now()
    file_modify_dict={}
    file_modify_arr=[]
    for file in file_list:
        modify_time_str=time.strftime('%Y-%m-%d %H:%M:%S',time.localtime(os.stat(file).st_ctime))
        modify_time=datetime.datetime.strptime(modify_time_str, '%Y-%m-%d %H:%M:%S')
        previous_day_time=now-datetime.timedelta(hours=24)
        #print(modify_time)
        #print(previous_day_time)
        if (modify_time>previous_day_time and previous_day_time<now):
            file_modify_arr.append({'file':file.title(),'modify_time':time.strftime('%Y-%m-%d %H:%M:%S',time.localtime(os.stat(file).st_ctime))})

        #print(file.title()  + '      modify time:' + time.strftime('%Y-%m-%d %H:%M:%S',time.localtime(os.stat(file).st_ctime)))
    content=''
    if check_result_1:
        content='<p>'+check_result_1['result']+'</p>'
    if check_result_2:
        content=content+'<p>'+check_result_2['result']+'</p>'
    if check_result_3:
        content=content+'<p>'+check_result_3['result']+'</p>'
    if  file_modify_arr:
        for i in file_modify_arr:
            content=content+'<p>'+i['file']+'  modify:'+i['modify_time']+'</p>'
    utils.send_register_email(utils.RECEIVE_MAIL, content, send_type="check")


    #request server 47.74.156.85
    try:

        response = requests.get("http://47.74.156.85:8008/api/v1/payments/check/")

        #return json.loads(response.text)
    except Exception as e:
        return {'msg': 'error'}

    return HttpResponse(json.dumps({'Status': 'Ok'}))

@api_view(['GET','POST'])
@authentication_classes([])
@permission_classes((AllowAny,))
def sendMessage_sql(request, *args, **kwargs):
    title = request.data.get('title')
    message = request.data.get('message')
    type = request.data.get('type')
    mobile = request.data.get('mobile_no')
    sql=''
    if type == '0':
        member = models.Member.objects.all().filter(mobile_no=mobile).first()
        if member:
            if member.device_token is not None:
                send_message_to_token(member.device_token, title, message)
    if type == '1':
        member_list = models.Member.objects.all().filter(id__gt=0).order_by('id')
        if member_list:
            messThread = MessThread()
            messThread.member_list = member_list
            messThread.title = title
            messThread.message = message
            messThread.start()

    return HttpResponse(json.dumps({'Status': 'Ok'}))


@api_view(['GET','POST'])
@authentication_classes([])
@permission_classes((AllowAny,))
def sendMessage(request, *args, **kwargs):
      title=request.data.get('title')
      message=request.data.get('message')
      type=request.data.get('type')
      mobile = request.data.get('mobile_no')
      if type=='0':
          member=models.Member.objects.all().filter(mobile_no=mobile).first()
          if member:
              if member.device_token is not None:
                        send_message_to_token(member.device_token, title, message)
                        #send_message_to_token_android_tablet('ejFKXDJ9F2k:APA91bH5pgGj3fSCPJE6nJvzXwSCLhKwJJcX9I59ZeGavYlcKGoh1IkedAWGj5phrBpXY4U74zcHEFSgNJ2yIk9VdkpQQrZRsMDUUGMxT5oqiKEUNcjJu5CVmaAjtazq2J6n-6O9-Iau', title, message)
      if type=='1':

          '''
          invite_member_list=[]
          member_list = models.Member.objects.all().filter(registration_date__gte=datetime.datetime.now() + datetime.timedelta(hours=-45)).order_by('id')

          if member_list:
              for member in member_list:
                  if member.register_code is not None and member.register_code!='' :
                      invite_member=models.Member.objects.all().filter(invite_code=member.register_code).first()
                      if invite_member:
                          invite_member_list.append(invite_member)
          
          member_list=invite_member_list
         
          member_list_tp=[]
          sql = "select member_id from (select member_id, sum(total_money) as sum_money from app01_transaction where transaction_status in (4,5) group by member_id order by member_id) as temp_sum where sum_money>=100"
          cursor = connection.cursor()
          cursor.execute(sql)
          result_list = cursor.fetchall()
          if result_list:
              for row in result_list:
                  member_list_tp.append(row[0])
          member_list = models.Member.objects.all().filter(id__in=tuple(member_list_tp)).order_by('id')
          #print(member_list)
          '''
          member_list = models.Member.objects.all().filter(id__gt=0).order_by('id') #5950

          if member_list:
              messThread = MessThread()
              messThread.member_list=member_list
              messThread.title=title
              messThread.message=message
              messThread.start()


      return HttpResponse(json.dumps({'Status': 'Ok'}))
class MessThread(threading.Thread):
    member_list=[]
    title=''
    message=''

    def run(self):
        if self.member_list:
            i = 0

            for member in self.member_list:
                '''
                send_message_to_token(
                    'cWi1yYd_Lfk:APA91bH_qqfdC07TyRN5g9anVYhNt7P27ZHTbg13APKHQUkt2_rNUJMUCPdSenQUvCdztmYIyLMyEK8F1jm6RSJD85Bj8KNnSsrqOK-fk6jvXfQyq0uDjNNr05kFdbf2Yb8jReIuXJYH',
                   title,
                    message)
                return Response({'message':'ok'})
                '''
                if member.device_token is not None:

                    send_message_to_token(member.device_token, self.title,self.message)
                    # send_message_to_token('d_UghULZIzc:APA91bGRDDvRNnz0SVW61crRauippT2gB7rAiy3VCEWBVSC-_1hQ6IDt-uwGMfG9vnm1ejQze6L-8NIUk5JIrv4bY6JX5UhBGv1xmI7gKAx4P5aE7R4YP4_RJgNoseK5gmBS_XxSCMtF', 'Taro Bobo Promotion',"30% off for all Taro Bobo products for APP ordering, during 19/2-25/2.Don't miss it.")
                    time.sleep(0.15)
                    i = i + 1
                    print(member.mobile_no + '    id:' + str(member.id) + '    count:' + str(i))


@api_view(['GET','POST'])
@authentication_classes([])
@permission_classes((AllowAny,))

def balance(request, *args, **kwargs):
    record_wallet_balance()
    return HttpResponse(json.dumps({'Status': 'Ok'}))

@api_view(['GET','POST'])
@authentication_classes([])
@permission_classes((AllowAny,))

def balance_record(request, *args, **kwargs):
    record_wallet_balance()
    '''
    # wirecard
    sql = "select sum(money) from app01_RechargeRecord where type=0 and status=1 and (request_id is not null and \"grab_txID\" is null) and (money=10 or money=20 or money=50) and to_char(created,'yyyy-mm-dd')=to_char(current_date,'yyyy-mm-dd')"
    cursor = connection.cursor()
    cursor.execute(sql)
    row = cursor.fetchall()
    if row:
        if row[0][0] is not None:
            wirecard_topup_money = row[0][0]
        else:
            wirecard_topup_money = 0.0
    else:
        wirecard_topup_money = 0.0

    # grabpay
    sql = "select sum(money) from app01_RechargeRecord where type=0 and status=1 and (request_id is not null and \"grab_txID\" is not null) and (money=10 or money=20 or money=50) and to_char(created,'yyyy-mm-dd')=to_char(current_date,'yyyy-mm-dd')"
    cursor = connection.cursor()
    cursor.execute(sql)
    row = cursor.fetchall()
    if row:
        if row[0][0] is not None:
            grabpay_topup_money = row[0][0]
        else:
            grabpay_topup_money = 0.0
    else:
        grabpay_topup_money = 0.0

    # outlet
    sql = "select sum(money) from app01_topuprecord where to_char(created_date,'yyyy-mm-dd')=to_char(current_date,'yyyy-mm-dd')"
    cursor = connection.cursor()
    cursor.execute(sql)
    row = cursor.fetchall()
    if row:
        if row[0][0] is not None:
            outlet_topup_money = row[0][0]
        else:
            outlet_topup_money = 0.0
    else:
        outlet_topup_money = 0.0
    sum_topup_money = wirecard_topup_money + grabpay_topup_money + outlet_topup_money

    # wallet sumAmount
    #sql="select  sum(app01_transaction.total_money)  from app01_transaction   where to_char(app01_transaction.payment_datetime,'yyyy-mm-dd')=to_char(current_date,'yyyy-mm-dd')  and app01_transaction.transaction_status in (4,5) and  payment_modes=8 "
    sql = "select sum(money) from app01_rechargerecord where type in (1) and to_char(created,'yyyy-mm-dd')=to_char(current_date ,'yyyy-mm-dd') "
    cursor = connection.cursor()
    cursor.execute(sql)
    row = cursor.fetchall()
    if row:
        if row[0][0] is not None:
            sum_payment = row[0][0]
        else:
            sum_payment = 0.0
    else:
        sum_payment = 0.0
    # cashback
    sql = "select sum(money) from app01_rechargerecord where type in (3) and to_char(created,'yyyy-mm-dd')=to_char(current_date ,'yyyy-mm-dd') "
    cursor = connection.cursor()
    cursor.execute(sql)
    row = cursor.fetchall()
    if row:
        if row[0][0] is not None:
            cashback = row[0][0]
        else:
            cashback = 0.0
    else:
        cashback = 0.0
    # cashback deduction
    sql = "select sum(money) from app01_rechargerecord where type in (4) and to_char(created,'yyyy-mm-dd')=to_char(current_date ,'yyyy-mm-dd') "
    cursor = connection.cursor()
    cursor.execute(sql)
    row = cursor.fetchall()
    if row:
        if row[0][0] is not None:
            cashback_deduction = row[0][0]
        else:
            cashback_deduction = 0.0
    else:
        cashback_deduction = 0.0
    cashback=cashback-cashback_deduction
    # refund
    sql = "select sum(money) from app01_rechargerecord where type in (2) and to_char(created,'yyyy-mm-dd')=to_char(current_date ,'yyyy-mm-dd') "
    cursor = connection.cursor()
    cursor.execute(sql)
    row = cursor.fetchall()
    if row:
        if row[0][0] is not None:
            refund = row[0][0]
        else:
            refund = 0.0
    else:
        refund = 0.0

    increase_decrease_value = sum_topup_money + cashback+refund - sum_payment

    # yesterday iPay wallet balance
    sql = "select balance from app01_walletbalance where to_char(record_date,'yyyy-mm-dd')=to_char(current_date-interval '1' day ,'yyyy-mm-dd')"
    cursor = connection.cursor()
    cursor.execute(sql)
    row = cursor.fetchall()
    if row:
        if row[0][0] is not None:
            yesterday_wallet_balance = row[0][0]
        else:
            yesterday_wallet_balance = 0.0
    else:
        yesterday_wallet_balance = 0.0
    # iPay wallet  balance(test)
    sql = "select sum(balance) from app01_wallet where member_id in (95,383,822,27,881,529,2749,102,1028,3458,621,952) "
    cursor = connection.cursor()
    cursor.execute(sql)
    row = cursor.fetchall()
    if row:
        if row[0][0] is not None:
            wallet_test_balance = row[0][0]
        else:
            wallet_test_balance = 0.0
    else:
        wallet_test_balance = 0.0

    # iPay wallet balance
    sql = "select sum(balance) from app01_wallet "
    cursor = connection.cursor()
    cursor.execute(sql)
    row = cursor.fetchall()
    if row:
        if row[0][0] is not None:
            wallet_balance = row[0][0]
        else:
            wallet_balance = 0.0
    else:
        wallet_balance = 0.0
    add_redecue_balance = getFloat(increase_decrease_value)
    if (add_redecue_balance > 0):
        incre_decre_value = '+' + str(add_redecue_balance)
    else:
        incre_decre_value = '' + str(add_redecue_balance)
    different_value=getFloat(wallet_balance - (yesterday_wallet_balance + add_redecue_balance))
    if different_value>0:
        str_different_value='+'+str(different_value)
    else:
        str_different_value = '' + str(different_value)
    table = "<table border='1' cellspacing='0' style='text-align:center' ><tr><td colspan='11'  style='text-align:center' >Wallet Balance</td><td rowspan='2'>Test Account Balance</td></tr><tr><td>topup (GrabPay)</td><td>topup (CreditCard)</td><td>topup (outlet)</td><td>topup (all)</td><td>wallet payment</td><td>cash back</td><td>refund</td><td>Change Amount</td><td>Yesterday Balance</td><td>Today Balance</td><td>Differential Amount</td></tr>" + "<tr><td>" + str(
        getFloat(grabpay_topup_money)) + "</td><td>" + str(
        getFloat(wirecard_topup_money)) + "</td><td>" + str(
        getFloat(outlet_topup_money)) + "</td><td>" + str(
        getFloat(sum_topup_money)) + "</td><td>" + str(getFloat(sum_payment)) + "</td><td>" + str(
        getFloat(cashback)) + "</td><td>"+str(getFloat(refund))+"</td><td>" + incre_decre_value + "</td><td>" + str(
        getFloat(yesterday_wallet_balance)) + "</td><td>" + str(getFloat(wallet_balance)) + "</td><td><font color='red'>" + str_different_value + "</font></td><td>" + str(
        getFloat(wallet_test_balance)) + "</tr></table>"
    utils.send_register_email(utils.RECEIVE_MAIL, table, send_type="balance", promotion='')
'''
    return HttpResponse(json.dumps({'Status': 'Ok'}))

def getFloat(f):

    g = '%.2f' % f
    return float(g)

def getdate( beforeOfDay):
    today = datetime.datetime.now()
    # 计算偏移量
    offset = datetime.timedelta(days=-beforeOfDay)
    # 获取想要的日期的时间
    re_date = (today + offset).strftime('%Y-%m-%d')
    return re_date


@api_view(['GET','POST'])
@authentication_classes([])
@permission_classes((AllowAny,))

def count_purchase_1(request, *args, **kwargs):
    count_purchase()
    '''
    week_day=[7,6,5,4,3,2,1,0]
    query_times=[1,2,3,4,5]
    table="<table border='1' cellspacing='0' style='text-align:center' ><tr><td colspan='9'  style='text-align:center' >Purchase Times Count</td></tr>"
    thead="<tr><td>times</td>"
    for day in week_day:
        thead=thead+"<td>"+getdate(day)+"</td>"
    thead=thead+"</tr>"
    table=table+thead

    for times in query_times:
         tbody = ""
         if times!=5:
             tbody = "<tr><td>"+str(times)+"</td>"
         else:
             tbody = "<tr><td>" + '>='+str(times) + "</td>"
         for day in week_day:
             if times!=5:
                 sql = "select count(temp.m_count) from (select count(*) as m_count,member_id from app01_transaction where  transaction_status in (4,5)  and to_char(app01_transaction.payment_datetime,'yyyy-mm-dd')<='"+getdate(day)+"'  group by member_id order by member_id asc) as temp where temp.m_count="+str(times)
             else:
                 sql = "select count(temp.m_count) from (select count(*) as m_count,member_id from app01_transaction where  transaction_status in (4,5)  and to_char(app01_transaction.payment_datetime,'yyyy-mm-dd')<='"+getdate(day)+"'  group by member_id order by member_id asc) as temp where temp.m_count>="+str(times)

             cursor = connection.cursor()
             cursor.execute(sql)
             row = cursor.fetchall()
             if row:
                 if row[0][0] is not None:
                     p_times = row[0][0]
                 else:
                     p_times = 0.0
             tbody=tbody+"<td>"+str(p_times)+"</td>"
         tbody=tbody+"</tr>"
         table =table+tbody
    table=table+"</table>"
    #print(table)
    utils.send_register_email(utils.RECEIVE_MAIL, table, send_type="purchase", promotion='')
'''
    return HttpResponse(json.dumps({'Status': 'Ok'}))

@api_view(['GET','POST'])
@authentication_classes([])
@permission_classes((AllowAny,))

def bind_voucher(request, *args, **kwargs):
    member_id=request.query_params.get('member_id')
    if member_id:
        member=models.Member.objects.filter(id=member_id).first()
        if member:
            dispatch_invicode(member)

    return HttpResponse(json.dumps({'Status': 'Ok'}))

@api_view(['GET','POST'])
@authentication_classes([])
@permission_classes((AllowAny,))

def erpGoodsCount(request, *args, **kwargs):

    try:

        #response = requests.get("http://47.74.156.85:8008/api/v1/card/sendMessage/")
        response = requests.get("http://127.0.0.1:8008/api/v1/card/sendMessage/",headers={'Authorization':'Token fa3c5db850ada70422a02e4638984dc08822f010'})

        #return json.loads(response.text)
    except Exception as e:
        return {'msg': 'error'}
    return HttpResponse(json.dumps({'Status': 'Ok'}))

@api_view(['GET','POST'])
@authentication_classes([])
@permission_classes((AllowAny,))

def erpOrderCount(request, *args, **kwargs):

    try:

        #response = requests.get("http://47.74.156.85:8008/api/v1/card/getPos/")
        checks = check_server('47.74.156.85', 8008, 'api/v1/card/getPosCompare/')
        check_result_1 = checks.check()
        #response = requests.get("http://127.0.0.1:8008/api/v1/card/getPos/",headers={'Authorization':'Token fa3c5db850ada70422a02e4638984dc08822f010'})

        #return json.loads(response.text)
    except Exception as e:
        return {'msg': 'error'}
    return HttpResponse(json.dumps({'Status': 'Ok'}))

@api_view(['GET','POST'])
@authentication_classes([])
@permission_classes((AllowAny,))

def testConfirm(request, *args, **kwargs):
    t='100'
    if t[0:3]=='100':
        print(t[0:3])
    elif t[0:2]=='20':
        print(t[0:2])
    elif t[0:2]=='50':
        print(t[0:2])
    elif t[0:2]=='10':
        print(t[0:2])

    #shoesSalesComp()
    #countPrize()
    #prize_random()
    #check_long_sold_product()
    '''
    postBody = request.body
    postBodyStr = postBody.decode('utf-8')
    json_result = json.dumps(postBodyStr)
    print(json_result)
    cursor = connection.cursor()
    cursor.execute("insert into app01_pos_test (order_id,\"remoteCode\") values(0,'" + json_result + "' ) ")
    '''
    #member_birthday()
    #member=models.Member.objects.filter(id=881).first()
    #trans=models.Transaction.objects.filter(id=303118).first()
    #deal_electric_sign(member,trans)
    #models.LoginOtp.objects.filter(expire_time__lt=datetime.datetime.now()).delete()
    return HttpResponse(json.dumps({'Status': 'Ok'}))
@api_view(['GET','POST'])
@authentication_classes([])
@permission_classes((AllowAny,))
def checkStock(request, *args, **kwargs):
    order_id = request.GET.get('order_id')
    if order_id:
        product_list=[]
        size_list=[]
        topping_list=[]
        transaction = models.Transaction.objects.filter(id=order_id).first()

        if transaction:
            outlet=transaction.outlet
            if outlet:
                size_topping_list=models.Product.objects.filter((Q(group_name='Size') | Q(group_name='Topping')),outlet__id=outlet.id)
            transact_list=models.TransactDetails.objects.filter(transaction__id=transaction.id)
            if transact_list:
                for item in transact_list:
                    if item.transactDetails_type==0:
                        product=item.product
                        if product:
                            if product.tea_base is not None and product.tea_base!='':
                                pass
                            else:
                                size_list.append(item.size)
                                sel_topping_list=item.toppings.all()
                                if sel_topping_list:
                                    for sel_topping in sel_topping_list:
                                         topping_list.append(sel_topping)
                            product_list.append(product)
            size_list=list(set(size_list))
            topping_list=list(set(topping_list))
            if product_list:
                for p_item in product_list:
                    if p_item.product_status==False:
                        return HttpResponse(json.dumps({'msg': p_item.name+' sold out!'}))
            if size_topping_list:
                if size_list:
                    for size in size_list:
                        if size==0:
                            size_name='size_medium'
                        elif size==1:
                            size_name='size_large'
                        elif size==2:
                            size_name = 'size_tall'
                        else:
                            size_name=''
                        if size_name!='':
                            for size_product in size_topping_list:
                                if size_product.name==size_name:
                                    if size_product.product_status==False:
                                        return HttpResponse(json.dumps({'msg': 'Size '+size_product.description + ' sold out!'}))
                if topping_list:
                    topping_relation_list=[]
                    for topping_item in topping_list:
                        topping_relation_list.append(topping_item.relation_name)
                    if topping_relation_list:
                        for relation_name in topping_relation_list:
                            for topping_product in size_topping_list:
                                if relation_name==topping_product.name:
                                    if topping_product.product_status==False:
                                        return HttpResponse(
                                            json.dumps({'msg': 'Topping ' + topping_product.description + ' sold out!'}))






    return HttpResponse(json.dumps({'msg': 'ok'}))



@api_view(['GET','POST'])
@authentication_classes([])
@permission_classes((AllowAny,))
def countPrize_t(request, *args, **kwargs):
    #prize_random()
    countPrize()
    '''

    prize_class_set_count=models.PrizeClassSet.objects.filter(id__gte=0).count()

    if prize_class_set_count:
        #prize probability
        table = "<table border='1' cellspacing='0' style='text-align:center' ><tr><td colspan='"+str(prize_class_set_count+1)+"'  style='text-align:center' >Prize Probability</td></tr>"
        prize_class_set_list=models.PrizeClassSet.objects.all().order_by('id')

        if prize_class_set_list:
            prize_class_name_line=""
            prize_class_probability_line=""
            sum_prize_probability=0
            for item in prize_class_set_list:
                prize_class_name_line = prize_class_name_line+ "<td>" + item.prize_name + "</td>"
                prize_class_probability_line=prize_class_probability_line+"<td>" +str(('{:.1f}%'.format(item.probability*100) ))+ "</td>"
                sum_prize_probability=sum_prize_probability+item.probability

            prize_class_name_line = "<tr>" + prize_class_name_line + "<td>total probability</td></tr>"
            prize_class_probability_line = "<tr>" +  prize_class_probability_line +"<td>"+str(('{:.1f}%'.format(sum_prize_probability*100) )) + "</td></tr>"
            table=table+prize_class_name_line+prize_class_probability_line+"</table>"

        #count prize times
        count_table = "<table border='1' cellspacing='0' style='text-align:center' ><tr><td colspan='" + str(
            (prize_class_set_count+2)*2 + 1) + "'  style='text-align:center' >Prize Count</td></tr>"

        today_lucky_draw_times=0
        all_lucky_draw_times = 0
        today_prize_times=0
        all_prize_times=0
        # today lucky draw times
        today_lucky_draw_times_aggre_count=models.PrizeMemberLog.objects.filter(prize_date=datetime.datetime.now().date()).aggregate(today_times_count=Sum('used_prize_times'))
        if today_lucky_draw_times_aggre_count:
            today_lucky_draw_times=today_lucky_draw_times_aggre_count['today_times_count']

        # all lucky draw times

        all_lucky_draw_times_aggre_count = models.PrizeMemberLog.objects.filter(id__gte=1).aggregate(all_times_count=Sum('all_used_prize_times'))
        if all_lucky_draw_times_aggre_count:
            all_lucky_draw_times = all_lucky_draw_times_aggre_count['all_times_count']
        # today prize times
        today_prize_times_aggre_count = models.PrizeLog.objects.filter(
            created__date=datetime.datetime.now().date()).aggregate(today_prize_times_count=Count('id'))
        if today_prize_times_aggre_count:
            today_prize_times = today_prize_times_aggre_count['today_prize_times_count']

        # all prize times

        all_prize_times_aggre_count = models.PrizeLog.objects.filter(id__gte=1).aggregate(
            all_prize_times_count=Count('id'))
        if all_prize_times_aggre_count:
            all_prize_times = all_prize_times_aggre_count['all_prize_times_count']

        #today thank you
        today_thank_times=today_lucky_draw_times-today_prize_times
        all_thank_times=all_lucky_draw_times-all_prize_times

        today_thank_times_precent='0.0%'
        if today_lucky_draw_times>0:
            today_thank_times_precent ='{:.1f}%'.format((today_thank_times/today_lucky_draw_times)*100)
        all_thank_times_precent = '0.0%'
        if all_lucky_draw_times > 0:
            all_thank_times_precent = '{:.1f}%'.format((all_thank_times / all_lucky_draw_times)*100)


        #class set prize_count
        today_class_prize_dict={}
        today_class_prize_dict['today_thank_times']=today_thank_times
        today_class_prize_dict['today_thank_times_precent'] = today_thank_times_precent
        all_class_prize_dict = {}
        all_class_prize_dict['all_thank_times'] = all_thank_times
        all_class_prize_dict['all_thank_times_precent'] = all_thank_times_precent

        prize_class_set_list = models.PrizeClassSet.objects.all().order_by('id')

        if prize_class_set_list:
            count_table_line_1 = '<tr><td rowspan=2 >Time</td>'
            count_table_line_2 = '<tr>'
            for item in prize_class_set_list:
                prize_list=item.prize.all()
                today_prize_class_times=0
                all_prize_class_times = 0
                prize_class_name=item.prize_name
                count_table_line_1=count_table_line_1+'<td colspan=2 >'+prize_class_name+'</td>'
                count_table_line_2=count_table_line_2+'<td >times</td><td>percent</td>'
                if prize_list:
                    prize_id_list=[]
                    for prize in prize_list:
                        prize_id_list.append(prize.id)
                    prize_id_tuple=tuple(prize_id_list)
                    if prize_id_tuple:
                        sql = 'select count(*) from app01_PrizeLog   where to_char(created,\'yyyy-mm-dd\')=to_char(current_date,\'yyyy-mm-dd\') and prize_id in ('+','.join([str(i) for i in prize_id_list])+')'
                        cursor = connection.cursor()
                        cursor.execute(sql)
                        row = cursor.fetchall()
                        if row:
                            if row[0][0] is not None:
                                today_prize_class_times = row[0][0]
                            else:
                                today_prize_class_times = 0
                        else:
                            today_prize_class_times = 0

                        sql = 'select count(*) from app01_PrizeLog   where  prize_id in ('+','.join([str(i) for i in prize_id_list])+')'
                        cursor = connection.cursor()
                        cursor.execute(sql)
                        row = cursor.fetchall()
                        if row:
                            if row[0][0] is not None:
                                all_prize_class_times = row[0][0]
                            else:
                                all_prize_class_times = 0
                        else:
                            all_prize_class_times = 0

                        today_prize_class_precent = '0.0%'
                        if today_lucky_draw_times > 0:
                            today_prize_class_precent = '{:.1f}%'.format((today_prize_class_times / today_lucky_draw_times)*100)
                        all_prize_class_precent = '0.0%'
                        if all_lucky_draw_times > 0:
                            all_prize_class_precent = '{:.1f}%'.format((all_prize_class_times / all_lucky_draw_times)*100)
                today_class_prize_dict[prize_class_name]=today_prize_class_times
                today_class_prize_dict[prize_class_name+'_percent'] = today_prize_class_precent
                all_class_prize_dict[prize_class_name]=all_prize_class_times
                all_class_prize_dict[prize_class_name + '_percent'] = all_prize_class_precent
            count_table_line_1=count_table_line_1+'<td colspan=2>thank you</td><td rowspan=2>total</td></tr>'
            count_table_line_2 = count_table_line_2 + '<td>times</td><td>percent</td></tr>'
            count_table=count_table+count_table_line_1+count_table_line_2

            line_1='<tr><td>today</td>'
            line_2='<tr><td>all</td>'
            for i in range(2):
                for item in prize_class_set_list:
                    if i==0:
                        line_1=line_1+'<td>'+str(today_class_prize_dict[item.prize_name])+'</td>'+'<td>'+today_class_prize_dict[item.prize_name+'_percent']+'</td>'
                    elif i==1:
                        line_2 = line_2 + '<td>' + str(all_class_prize_dict[item.prize_name]) + '</td>' + '<td>' + all_class_prize_dict[item.prize_name + '_percent'] + '</td>'
            line_1=line_1+'<td>'+str(today_thank_times)+'</td>'+'<td>'+today_thank_times_precent+'</td><td>'+str(today_lucky_draw_times)+'</td></tr>'
            line_2 = line_2 + '<td>' + str(all_thank_times) + '</td>' + '<td>' + all_thank_times_precent + '</td><td>' + str(all_lucky_draw_times )+ '</td></tr>'
            count_table=count_table+line_1+line_2
        count_table=count_table+"</table>"
        table=table+count_table
        thread_send_mail(count_table, "prize")
        '''




    return HttpResponse(json.dumps({'msg': 'ok'}))


def one_year_later():
    now = datetime.datetime.now()
    return now + datetime.timedelta(days=365)


@api_view(['GET','POST'])
@authentication_classes([])
@permission_classes((AllowAny,))
def testVoucher(request, *args, **kwargs):
    return
    #$5  310   $10   415
    mobile_no=request.data.get('mobile_no')
    v_number=request.data.get('v_number')
    voucher_id=request.data.get('voucher_id')
    member=models.Member.objects.filter(mobile_no=mobile_no).first()
    if member:
        voucher=models.Voucher.objects.filter(id=voucher_id).first()
        if voucher:
            for i in range(int(v_number)):
                models.Invicode.objects.create(
                    **{'voucher': voucher, 'code': generate_random_str(), 'status': 1, 'member': member,
                       'register_date': datetime.datetime.now(), 'vaild_days': 90,
                       'expire_date': datetime.datetime.now().date() + datetime.timedelta(days=90)})
    else:
        return HttpResponse(json.dumps({'Message': 'Mobile not found'}))
    return HttpResponse(json.dumps({'Message': 'ok'}))
@api_view(['GET','POST'])
@authentication_classes([])
@permission_classes((AllowAny,))
def dispatchVoucher(request, *args, **kwargs):
    #return
    #$5  310   $10   415
    mobile_no=request.data.get('mobile_no')
    v_number=request.data.get('v_number')
    voucher_id=request.data.get('voucher_id')
    member=models.Member.objects.filter(mobile_no=mobile_no).first()
    if member:
        voucher=models.Voucher.objects.filter(id=voucher_id).first()
        if voucher:
            for i in range(int(v_number)):
                models.Invicode.objects.create(
                    **{'voucher': voucher, 'code': generate_random_str(), 'status': 1, 'member': member,
                       'register_date': datetime.datetime.now(), 'vaild_days': 90,
                       'expire_date': datetime.datetime.now().date() + datetime.timedelta(days=90)})
    else:
        return HttpResponse(json.dumps({'Message': 'Mobile not found'}))
    return HttpResponse(json.dumps({'Message': 'ok'}))
@api_view(['GET','POST'])
@authentication_classes([])
@permission_classes((AllowAny,))
def dealMember(request, *args, **kwargs):
    daily()
    '''
    now=datetime.datetime.now()
    member_list=models.Member.objects.filter(id__lt=45000,id__gt=39999).order_by('id')
    if member_list:
        for member in member_list:
            total_amount=0
            app_purchase_amount = models.Transaction.objects.filter(member__id=member.id, transaction_status__in=(4, 5)
                                                        ).aggregate(
                sum=Sum('total_money'))
            ipay_amount = models.IpayRecord.objects.filter(member__id=member.id).aggregate(
                sum=Sum('money'))
            if app_purchase_amount['sum'] is not None:
                total_amount = total_amount + app_purchase_amount['sum']
            if ipay_amount['sum'] is not None:
                total_amount = total_amount + ipay_amount['sum']
            if(total_amount>0):
                update_member_points(member,total_amount,1,None,None)
                print(member.id)
    '''


@api_view(['GET','POST'])
@authentication_classes([])
@permission_classes((AllowAny,))
def getGrabMonthData(request, *args, **kwargs):
    month=request.GET.get('month')
    #wbk = xlwt.Workbook()
    #sheet = wbk.add_sheet('GrabPay count', cell_overwrite_ok=True)
    table = "<table  border='1' cellspacing='0' style='text-align:center;width:100%;font-size:0.4rem' ><tr><td colspan='3'  style='text-align:center' >GrabPay ("+month+")</td></tr><tr><td >Outlet</td><td>amount</td><td>time</td></tr>"
    sql = "select origin_outlet_name,total_money as amount,to_char(payment_datetime,'YYYY-MM-DD HH:MM') from app01_transaction where payment_modes = 12 and transaction_status >=4 and to_char(payment_datetime,'YYYY-MM')='"+month+"'  order by payment_datetime"
    cursor = connection.cursor()
    cursor.execute(sql)
    rows = cursor.fetchall()
    line=''
    if rows:
        for i in rows:
              line=line+"<tr><td>"+i[0]+"</td><td>"+str(i[1])+"</td><td>"+i[2]+"</td></tr>"
    table=table+line+"</table>"
    utils.send_register_email('ziyiw2019@gmail.com',table,'','GrabPay('+month+")")
    utils.send_register_email('account@itea.sg', table, '', 'GrabPay(' + month + ")")
    return HttpResponse(json.dumps({'Status': 'Ok'}))
def send_mooncake_payment(transactObj):
    if transactObj:
        amount=0
        quantity=0
        transactDetails_list = models.TransactDetails.objects.filter(transaction__id=transactObj.id)
        if transactDetails_list:
            for transactDetails in transactDetails_list:
                product=transactDetails.product
                if product:
                    product_name =product.name.lower()
                    if 'mooncake' in product_name:
                        quantity=quantity+transactDetails.quantity
        return quantity

@api_view(['GET', 'POST'])
@authentication_classes([])
@permission_classes((AllowAny,))
def modeMemberPass(request, *args, **kwargs):

    member_list = models.Member.objects.all().filter(~Q(name='root'),is_active=0).order_by('id')  # 5950

    if member_list:
        messThread = MessThread()
        messThread.member_list = member_list

        messThread.start()

    return HttpResponse(json.dumps({'Status': 'Ok'}))

class MessThread(threading.Thread):
    member_list = []


    def run(self):
        if self.member_list:
            i = 0

            for member in self.member_list:

                i = i + 1
                member.nick_name = random_pass(20)
                member.password = make_password(member.nick_name)
                member.is_active = 1
                member.save()
                print(member.mobile_no + '    id:' + str(member.id)+ '    password:' + str(member.nick_name) + '    count:' + str(i))

@api_view(['GET', 'POST'])
@authentication_classes([])
@permission_classes((AllowAny,))
def addTopping(request, *args, **kwargs):
       #http://47.74.156.85:8000/Toppings/mango_popping_boba.jpeg
       #Mango Popping Boba ITEATP21047  topping_mango_popping_boba
       return
       with transaction.atomic():
           topping_mango_popping_boba=models.Toppings.objects.filter(relation_name='topping_mango_popping_boba').first()
           if topping_mango_popping_boba:
               product_white_pearl_list=models.Product.objects.filter(name='topping_white_pearl').order_by('id')
               if product_white_pearl_list:
                     for item in product_white_pearl_list:
                        scheme=item.scheme
                        outlet=item.outlet
                        new_topping_mango_popping_boba=item
                        new_topping_mango_popping_boba.id=None
                        new_topping_mango_popping_boba.scheme=scheme
                        new_topping_mango_popping_boba.outlet = outlet
                        new_topping_mango_popping_boba.item_code=topping_mango_popping_boba.item_code
                        new_topping_mango_popping_boba.name=topping_mango_popping_boba.relation_name
                        new_topping_mango_popping_boba.description=topping_mango_popping_boba.name
                        new_topping_mango_popping_boba.chinese_name='芒果爆爆珠'
                        new_topping_mango_popping_boba.thumb_image_path='http://47.74.156.85:8000/Toppings/mango_popping_boba.jpeg'
                        new_topping_mango_popping_boba.save()

           return HttpResponse(json.dumps({'Status': 'Ok'}))
@api_view(['GET', 'POST'])
@authentication_classes([])
@permission_classes((AllowAny,))
def addProduct(request, *args, **kwargs):
    return
    with transaction.atomic():

            model_product_list = models.Product.objects.filter(name='Black Tea Macchiato',id__gt=2770).order_by('id')
            if model_product_list:
                for item in model_product_list:
                     #item.pk=None
                     #item.chinese_name='夏日柠冰爽'
                     #item.save()
                     new_mango_popping_boba_tea=item
                     i_id=item.id

                     new_mango_popping_boba_tea.id=None
                     new_mango_popping_boba_tea.name='Uji Kyoto Matcha Ice'
                     new_mango_popping_boba_tea.description = 'Uji Kyoto Matcha Ice'
                     new_mango_popping_boba_tea.chinese_name = 'Uji Kyoto Matcha Ice'
                     new_mango_popping_boba_tea.thumb_image_path='http://erp.itea.sg:8000/Macchiato_latte/UjiKyoto_small.jpeg'
                     new_mango_popping_boba_tea.image_path = 'http://erp.itea.sg:8000/Macchiato_latte/UjiKyoto_big.jpeg'
                     new_mango_popping_boba_tea.item_code='ITEA030615'
                     new_mango_popping_boba_tea.show_ice_level=0
                     new_mango_popping_boba_tea.long_sold_out=False
                     new_mango_popping_boba_tea.price = 4.7
                     new_mango_popping_boba_tea.save()
                     if new_mango_popping_boba_tea and new_mango_popping_boba_tea.id:
                         sql = "select * from app01_category_product where product_id="+str(i_id)
                         cursor = connection.cursor()
                         cursor.execute(sql)
                         list = cursor.fetchall()
                         if list:
                              for row in list:
                                   category_id=row[1]
                                   cursor.execute('insert into app01_category_product (category_id,product_id) values ('+str(category_id)+","+str(new_mango_popping_boba_tea.id)+")")

            return HttpResponse(json.dumps({'Status': 'Ok'}))

@api_view(['GET', 'POST'])
@authentication_classes([])
@permission_classes((AllowAny,))
def addProductGroup(request, *args, **kwargs):
    with transaction.atomic():
            old_group_id=15
            group_id=17
            model_product_list = models.Product.objects.filter(name='MANGO POMELO').order_by('id')
            if model_product_list:
                for item in model_product_list:


                    cursor = connection.cursor()
                    cursor.execute("update app01_product_group set group_id="+str(group_id) +" where product_id=" + str(item.id) +" and group_id="+str(old_group_id))


@api_view(['GET', 'POST'])
@authentication_classes([])
@permission_classes((AllowAny,))
def addNewProduct(request, *args, **kwargs):

    with transaction.atomic():
            outlet_list=models.Outlet.objects.filter(id=43).order_by('id') #~Q(id=40)
            if outlet_list:
                for outlet in outlet_list:
                    product_list = models.Product.objects.filter(id__in=(14800,14801)).order_by('id')
                    if product_list:
                        for model_product in product_list:
                                new_item = model_product
                                new_item.pk=None
                                new_item.outlet_id=outlet.id
                                new_item.save()
                                p_id=new_item.id
                                cursor = connection.cursor()
                                cursor.execute('insert into app01_product_group (product_id,group_id) values (' + str(p_id) + ",18)")
                                cursor.execute('insert into app01_product_group (product_id,group_id) values (' + str(p_id) + ",19)")
                                cursor.execute('insert into app01_voucher_unparticipated_products (voucher_id,product_id) values (380,' + str(p_id) + ")")
                                sql = "select c.id from app01_outlet_category as oc,app01_category as c where c.name in ('Best Seller','Juice/Yakult') and oc.category_id=c.id and oc.outlet_id=" + str(outlet.id)


                                cursor.execute(sql)
                                list = cursor.fetchall()
                                if list:
                                     for i in list:
                                         category_id = i[0]
                                         cursor.execute('insert into app01_category_product (category_id,product_id) values (' + str(category_id) + "," + str(p_id) + ")")


            return HttpResponse(json.dumps({'Status': 'Ok'}))