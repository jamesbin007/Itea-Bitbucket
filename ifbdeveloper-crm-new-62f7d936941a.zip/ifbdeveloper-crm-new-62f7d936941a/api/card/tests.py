from django.test import TestCase
from django.contrib.auth.hashers import make_password, check_password
# Create your tests here.
def make_pass():
    print(make_password("cobra_itea.1234"))

make_pass()
