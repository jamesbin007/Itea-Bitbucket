from django.urls import path, include
from rest_framework.routers import DefaultRouter
from . import views






card_router = DefaultRouter()
card_router.register('', views.CardViewSet)

urlpatterns = [
    path('check/', views.check, name='check'),
    path('sendMessage/', views.sendMessage, name='sendMessage'),
    path('checkBalance/', views.balance, name='checkBalance'),
    path('checkBalanceRecord/', views.balance_record, name='checkBalanceRecord'),
    path('countPurchase/', views.count_purchase_1, name='countPurchase'),
    path('bindVoucher/', views.bind_voucher, name='bindVoucher'),
    path('erpGoodsCount/', views.erpGoodsCount, name='erpGoodsCount'),
    path('erpOrderCount/', views.erpOrderCount, name='erpOrderCount'),
    path('testConfirm/', views.testConfirm, name='testConfirm'),
    path('checkStock/', views.checkStock, name='checkStock'),
    path('countPrize/<outlet_id>', views.countPrize_t, name='countPrize'),
    path('dealMember/', views.dealMember, name='dealMember'),
    path('getGrabMonthData/', views.getGrabMonthData, name='getGrabMonthData'),
    path('modeMemberPass/', views.modeMemberPass, name='modeMemberPass'),
    path('dispatchShoeVoucher/', views.dispatchVoucher, name='dispatchShoeVoucher'),
    path('testVoucher/', views.testVoucher, name='testVoucher'),
    path('addTopping/', views.addTopping, name='addTopping'),
    path('addProduct/', views.addProduct, name='addProduct'),
    path('addProductGroup/', views.addProductGroup, name='addProductGroup'),
    path('addNewProduct/', views.addNewProduct, name='addNewProduct'),
    path('', include(card_router.urls)),

]
