from rest_framework import serializers
from app01 import models


class CardSerializer(serializers.ModelSerializer):
    class Meta:
        model = models.Card
        fields = '__all__'

class WalletBalanceSerializer(serializers.ModelSerializer):
    class Meta:
        model = models.WalletBalance
        fields = '__all__'
