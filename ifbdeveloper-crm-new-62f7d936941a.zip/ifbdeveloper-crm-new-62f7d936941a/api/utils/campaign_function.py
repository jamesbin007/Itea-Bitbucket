from app01 import models

def campaign_return(member,amount):
    campaignPurchase=models.CampaignPurchase.objects.first()

    return_amount=0
    if campaignPurchase:
        activity_flag=campaignPurchase.activity_flag
        times_limit_flag=campaignPurchase.times_limit_flag
        limit_times=campaignPurchase.limit_times
        max_return_wallet_amount=campaignPurchase.max_return_wallet_amount
        if member:
            non_wallet_pay_times= 0 if member.non_wallet_pay_times is None else member.non_wallet_pay_times
            if activity_flag:
                if times_limit_flag:
                      if limit_times>non_wallet_pay_times:
                          purchase_return_wallet_percent= 0 if campaignPurchase.purchase_return_wallet_percent is None else campaignPurchase.purchase_return_wallet_percent
                          #print(purchase_return_wallet_percent)
                          #print(amount)
                          return_amount=float(amount)*purchase_return_wallet_percent
                          if return_amount>max_return_wallet_amount:
                              return_amount=max_return_wallet_amount

                else:
                    purchase_return_wallet_percent= 0 if campaignPurchase.purchase_return_wallet_percent is None else campaignPurchase.purchase_return_wallet_percent
                    return_amount = float(amount) * purchase_return_wallet_percent
                    if return_amount > max_return_wallet_amount:
                        return_amount = max_return_wallet_amount




    return return_amount