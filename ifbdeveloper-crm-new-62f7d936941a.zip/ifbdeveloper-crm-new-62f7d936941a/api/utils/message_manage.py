# Copyright 2018 Google Inc. All Rights Reserved.
#
# Licensed under the Apache License, Version 2.0 (the "License");
# you may not use this file except in compliance with the License.
# You may obtain a copy of the License at
#
#      http://www.apache.org/licenses/LICENSE-2.0
#
# Unless required by applicable law or agreed to in writing, software
# distributed under the License is distributed on an "AS IS" BASIS,
# WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
# See the License for the specific language governing permissions and
# limitations under the License.

from __future__ import print_function

import datetime
import os
import time

from django.http import HttpResponse
from firebase_admin import messaging
import firebase_admin
from firebase_admin import credentials
import threading

from rest_framework.utils import json


class MessageHandler(object):
    _instance_lock = threading.Lock()

    def __init__(self):
        if not hasattr(self, 'app'):
            #print('firebase init')
            with MessageHandler._instance_lock:
                if not hasattr(self, 'app'):
                    #print (os.path.dirname(__file__)+'99999')
                    #exit(0)
                    if '[DEFAULT]' not in firebase_admin._apps:
                        self.cred = credentials.Certificate(os.path.dirname(__file__)+'//qualified-cacao-245606-firebase-adminsdk-zgev2-ea91a79d69.json')
                        self.default_app = firebase_admin.initialize_app(self.cred)
                        #self.other_app = firebase_admin.initialize_app(self.cred, name='iTEA')
                        #print(self.default_app.name)  # "[DEFAULT]"
                        #print(self.other_app.name)

                        self.app = self.default_app
                    else:
                        self.cred = credentials.Certificate(os.path.dirname(
                            __file__) + '//qualified-cacao-245606-firebase-adminsdk-zgev2-ea91a79d69.json')
                        self.default_app = firebase_admin.initialize_app(self.cred,name='mobile')
                        # self.other_app = firebase_admin.initialize_app(self.cred, name='iTEA')
                        # print(self.default_app.name)  # "[DEFAULT]"
                        # print(self.other_app.name)

                        self.app = self.default_app


    def __new__(cls, *args, **kwargs):
        if not hasattr(MessageHandler, "_instance"):
            with MessageHandler._instance_lock:
                if not hasattr(MessageHandler, "_instance"):
                    MessageHandler._instance = object.__new__(cls)
        return MessageHandler._instance

    def get_app(self):
        return self.app

class MessageHandler_New(object):
    _instance_lock = threading.Lock()

    def __init__(self):
        if not hasattr(self, 'app'):
            #print('firebase init')
            with MessageHandler_New._instance_lock:
                if not hasattr(self, 'app'):
                    #print (os.path.dirname(__file__)+'99999')
                    #exit(0)
                    if '[DEFAULT]' not in firebase_admin._apps:
                        self.cred = credentials.Certificate(os.path.dirname(__file__)+'//ipay-push-message-001-firebase-adminsdk-9z5dc-c436713ea1.json')
                        self.default_app = firebase_admin.initialize_app(self.cred)

                        #print(self.default_app.name)  # "[DEFAULT]"
                        #print(self.other_app.name)

                        self.app =self.default_app
                    else:
                        self.cred = credentials.Certificate(os.path.dirname(
                            __file__) + '//ipay-push-message-001-firebase-adminsdk-9z5dc-c436713ea1.json')
                        self.default_app = firebase_admin.initialize_app(self.cred,name='ipay')

                        # print(self.default_app.name)  # "[DEFAULT]"
                        # print(self.other_app.name)

                        self.app = self.default_app


    def __new__(cls, *args, **kwargs):
        if not hasattr(MessageHandler_New, "_instance"):
            with MessageHandler_New._instance_lock:
                if not hasattr(MessageHandler_New, "_instance"):
                    MessageHandler_New._instance = object.__new__(cls)
        return MessageHandler_New._instance

    def get_app(self):
        return self.app

#_message_handler = MessageHandler()
def send_message_to_token_ios(reg_token,message_title,message_body):
    _message_handler = MessageHandler()
    app = _message_handler.get_app()

    message = messaging.Message(
        apns=messaging.APNSConfig(payload=messaging.APNSPayload(
            aps=messaging.Aps(
                alert=messaging.ApsAlert(
                    title=message_title,
                    body=message_body
                )
            )
        )),
        token=reg_token,
    )
    try:
        messaging.send(message,False,app)

    except messaging.ApiCallError as e:
        return HttpResponse(json.dumps({
            'message': "The Message send error."
        }))
    '''
        except Exception as e:
            pass
        '''
def send_message_to_token_android_tablet(reg_token,message_title,message_body):

    _message_handler = MessageHandler_New()

    app=_message_handler.get_app()


    message = messaging.Message(
        android=messaging.AndroidConfig(
            restricted_package_name='com.itea.outlet',
            ttl=datetime.timedelta(seconds=3600),
            priority='high',
            notification=messaging.AndroidNotification(
                title=message_title,
                body=message_body,
                # icon='stock_ticker_update',
                color='#f45342'
            ),),
        token=reg_token,
        )
    try:
        messaging.send(message, False, app)

    except Exception as e:
        pass
    '''
        except messaging.ApiCallError as e:
            return HttpResponse(json.dumps({
                'message': "The Message send error."
            }))
        '''
def send_message_to_token_android(reg_token,message_title,message_body):
    _message_handler = MessageHandler()
    app = _message_handler.get_app()
    messaging._get_messaging_service(app)
    message = messaging.Message(
        android=messaging.AndroidConfig(
            restricted_package_name='com.zack.shop',
            ttl=datetime.timedelta(seconds=3600),
            priority='high',
            notification=messaging.AndroidNotification(
                title=message_title,
                body=message_body,
                # icon='stock_ticker_update',
                color='#f45342'
            ),),
        token=reg_token,
        )
    try:
        messaging.send(message, False, app)

    except Exception as e:
        pass
    '''
        except messaging.ApiCallError as e:
            return HttpResponse(json.dumps({
                'message': "The Message send error."
            }))
        '''


    def send_to_token():
        # [START send_to_token]
        # This registration token comes from the client FCM SDKs.

        registration_token = 'dyP-7Ejml0A:APA91bFVor5umtjqXVB1VlqXcXzQiTCUXPOBAlBa3uicYeNAj14Q6D_1IjSraR_-D1qvBUyBqF9IKt7KxRjHFACVZDJE56gbZbCx0DmuNPrW4meq2lG2WYUcM_X3zBBvv0Kh0hhyL-Ut'
        registration_token1 ='e6Qvh_DVKec:APA91bFgO4HZNN3FzRrfuMf7SpJW7XSX69B0qhDY7KmoYP4BGs1u2FNFOViSfq2EDp6M3G14vLPykT2Kh8i_sEt1t9nUIsqxZo9iOfamOa6E3NkNHUlxDk9C_WLFWFpdqFGYTGn63IlR'
        token_arr=[registration_token,registration_token1]
        # See documentation on defining a message payload.
        '''
    message = messaging.Message(
        data={
            'score': '850',
            'time': '2:45',
        },
        token=registration_token,
    )
   

    message = messaging.Message(
        android=messaging.AndroidConfig(
            ttl=datetime.timedelta(seconds=3600),
            priority='normal',
            notification=messaging.AndroidNotification(
                title='Itea campaign',
                body='1 Free Voucher for Milk Tea.',
                # icon='stock_ticker_update',
                color='#f45342'
            ),
        ),
        token=registration_token,
    )
    '''
    # Send a message to the device corresponding to the provided
    # registration token.android_message()
    #response = messaging.send(android_message())
'''
    for num in (0,len(token_arr)-1):
        #print(token_arr[num])
        #exit(0)
        message=messaging.Message(
            android=messaging.AndroidConfig(
                ttl=datetime.timedelta(seconds=3600),
                priority='normal',
                notification=messaging.AndroidNotification(
                    title='Itea campaign',
                    body='1 Free Voucher for Milk Tea.',
                    # icon='stock_ticker_update',
                    color='#f45342'
                ),
            ),
            token=token_arr[num],
        )
        response = messaging.send(message)

        print('Successfully sent message:', response)
        time.sleep(1)

    #response = messaging.send(message)
    # Response is a message ID string.
    #print('Successfully sent message:', response)
    # [END send_to_token]
'''

def send_to_topic():
    # [START send_to_topic]
    # The topic name can be optionally prefixed with "/topics/".
    topic = 'weather'

    # See documentation on defining a message payload.
    message = messaging.Message(
        data={
            'score': '850',
            'time': '2:45',
        },
        topic=topic,
    )

    # Send a message to the devices subscribed to the provided topic.
    response = messaging.send(message)
    # Response is a message ID string.
    print('Successfully sent message:', response)
    # [END send_to_topic]


def send_to_condition():
    # [START send_to_condition]
    # Define a condition which will send to devices which are subscribed
    # to either the Google stock or the tech industry topics.
    condition = "'stock-GOOG' in topics || 'industry-tech' in topics"

    # See documentation on defining a message payload.
    message = messaging.Message(
        notification=messaging.Notification(
            title='$GOOG up 1.43% on the day',
            body='$GOOG gained 11.80 points to close at 835.67, up 1.43% on the day.',
        ),
        condition=condition,
    )

    # Send a message to devices subscribed to the combination of topics
    # specified by the provided condition.
    response = messaging.send(message)
    # Response is a message ID string.
    print('Successfully sent message:', response)
    # [END send_to_condition]


def send_dry_run():
    message = messaging.Message(
        data={
            'score': '850',
            'time': '2:45',
        },
        token='token',
    )

    # [START send_dry_run]
    # Send a message in the dry run mode.
    response = messaging.send(message, dry_run=True)
    # Response is a message ID string.
    print('Dry run successful:', response)
    # [END send_dry_run]


def android_message():
    # [START android_message]
    registration_token = 'dyP-7Ejml0A:APA91bFVor5umtjqXVB1VlqXcXzQiTCUXPOBAlBa3uicYeNAj14Q6D_1IjSraR_-D1qvBUyBqF9IKt7KxRjHFACVZDJE56gbZbCx0DmuNPrW4meq2lG2WYUcM_X3zBBvv0Kh0hhyL-Ut'
    message = messaging.Message(
        android=messaging.AndroidConfig(
            ttl=datetime.timedelta(seconds=3600),
            priority='normal',
            notification=messaging.AndroidNotification(
                title='Itea campaign',
                body='1 Free Voucher for Milk Tea.',
                #icon='stock_ticker_update',
                color='#f45342'
            ),
        ),
        #topic='weather',
        token=registration_token,
    )
    # [END android_message]
    return message


def apns_message():
    # [START apns_message]
    message = messaging.Message(
        apns=messaging.APNSConfig(
            headers={'apns-priority': '10'},
            payload=messaging.APNSPayload(
                aps=messaging.Aps(
                    alert=messaging.ApsAlert(
                        title='$GOOG up 1.43% on the day',
                        body='$GOOG gained 11.80 points to close at 835.67, up 1.43% on the day.',
                    ),
                    badge=42,
                ),
            ),
        ),
        topic='industry-tech',
    )
    # [END apns_message]
    return message


def webpush_message():
    # [START webpush_message]
    message = messaging.Message(
        webpush=messaging.WebpushConfig(
            notification=messaging.WebpushNotification(
                title='$GOOG up 1.43% on the day',
                body='$GOOG gained 11.80 points to close at 835.67, up 1.43% on the day.',
                icon='https://my-server/icon.png',
            ),
        ),
        topic='industry-tech',
    )
    # [END webpush_message]
    return message


def all_platforms_message():
    # [START multi_platforms_message]
    message = messaging.Message(
        notification=messaging.Notification(
            title='$GOOG up 1.43% on the day',
            body='$GOOG gained 11.80 points to close at 835.67, up 1.43% on the day.',
        ),
        android=messaging.AndroidConfig(
            ttl=datetime.timedelta(seconds=3600),
            priority='normal',
            notification=messaging.AndroidNotification(
                icon='stock_ticker_update',
                color='#f45342'
            ),
        ),
        apns=messaging.APNSConfig(
            payload=messaging.APNSPayload(
                aps=messaging.Aps(badge=42),
            ),
        ),
        topic='industry-tech',
    )
    # [END multi_platforms_message]
    return message


def subscribe_to_topic():
    topic = 'highScores'
    # [START subscribe]
    # These registration tokens come from the client FCM SDKs.
    registration_tokens = [
        'YOUR_REGISTRATION_TOKEN_1',
        # ...
        'YOUR_REGISTRATION_TOKEN_n',
    ]

    # Subscribe the devices corresponding to the registration tokens to the
    # topic.
    response = messaging.subscribe_to_topic(registration_tokens, topic)
    # See the TopicManagementResponse reference documentation
    # for the contents of response.
    print(response.success_count, 'tokens were subscribed successfully')
    # [END subscribe]


def unsubscribe_from_topic():
    topic = 'highScores'
    # [START unsubscribe]
    # These registration tokens come from the client FCM SDKs.
    registration_tokens = [
        'YOUR_REGISTRATION_TOKEN_1',
        # ...
        'YOUR_REGISTRATION_TOKEN_n',
    ]

    # Unubscribe the devices corresponding to the registration tokens from the
    # topic.
    response = messaging.unsubscribe_from_topic(registration_tokens, topic)
    # See the TopicManagementResponse reference documentation
    # for the contents of response.
    print(response.success_count, 'tokens were unsubscribed successfully')
    # [END unsubscribe]
def send_message_to_token(reg_token, message_title, message_body):
        send_message_to_token_android(reg_token, message_title, message_body)
        send_message_to_token_ios(reg_token, message_title, message_body)
if __name__=='__main__':
    send_message_to_token_ios('ff8liszrtlc:APA91bFK7AYfATe4jMnzrKkrVJdIsqSwM4ygnov9dlYU7qs0CxZVxnJR4eFEyp5fJXarvQBTjugoBXJ7bukrg4_cqHg7PR2AR1LLQj4CzOaregr4gZZ--CfDSNZ-Ygn87RKJn8qaXtyg','Itea order notify','Your order has been confirmed.\nPick up time is 15:30')
    send_message_to_token('ddMijW17DEw:APA91bGzeeuPvWCFZ7sYMELDXhywE5iFX4dwrhPIIEm4L69GF9a-d0i_oaX4B3V5DVpSLKm6ZnFdwZIm8JSfXSineGGONFjPY7qhR-Vx_ADopZ8KCHcVy28OC2rlzpMyYcn4taLBGTsj','Itea order notify', 'Your order has been confirmed.\nPick up time is 15:30')