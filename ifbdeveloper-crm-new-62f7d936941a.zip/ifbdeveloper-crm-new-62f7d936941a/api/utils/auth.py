from rest_framework import authentication
from app01 import models
from django.utils.six import text_type
from rest_framework import HTTP_HEADER_ENCODING, exceptions
from django.utils.translation import ugettext_lazy as _
from rest_framework_simplejwt import tokens
from rest_framework_simplejwt.exceptions import TokenBackendError


class CustomAuthentication(authentication.TokenAuthentication):
    model = models.Token

    def authenticate(self, request):
        auth = request.META.get('HTTP_AUTHORIZATION', b'')
        #add auth Token ,from rest_framework_swagger
        # auth='Token fa3c5db850ada70422a02e4638984dc08822f010'
        if isinstance(auth, text_type):
            # Work around django test client oddness
            auth = auth.encode(HTTP_HEADER_ENCODING)
        auth = auth.split()
        if not auth or auth[0].lower() != self.keyword.lower().encode():
            msg = _(
                "Invalid token header. Clients should authenticate by passing the token key in the 'Authorization' HTTP header, prepended with the string 'Token '.")
            raise exceptions.AuthenticationFailed(msg)

        if len(auth) == 1:
            msg = _('Invalid token header. No credentials provided.')
            raise exceptions.AuthenticationFailed(msg)
        elif len(auth) > 2:
            msg = _('Invalid token header. Token string should not contain spaces.')
            raise exceptions.AuthenticationFailed(msg)

        try:
            token = auth[1].decode()
        except UnicodeError:
            msg = _('Invalid token header. Token string should not contain invalid characters.')
            raise exceptions.AuthenticationFailed(msg)
        return self.authenticate_credentials(token)

    def authenticate_credentials(self, key):
        model = self.get_model()
        token=None
        try:
            token = model.objects.select_related('user').get(key=key)
        except model.DoesNotExist:

            try:
              jwt_token=  tokens.AccessToken(key,True)
              if jwt_token:
                  member_id=jwt_token.payload['member_id']
                  return (models.Member.objects.filter(id=member_id).first(),jwt_token.token)
            except Exception:
                raise exceptions.AuthenticationFailed('Token is invalid or expired')
            #raise exceptions.AuthenticationFailed('Invalid token.')
        if token is not None:
            return (token.user, token)
            #return (token.user, token)

