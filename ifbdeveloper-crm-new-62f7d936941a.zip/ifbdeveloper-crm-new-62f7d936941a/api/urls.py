from django.urls import path, include
from rest_framework.routers import DefaultRouter
from . import views






card_router = DefaultRouter()
card_router.register('', views.CardViewSet)

urlpatterns = [
    path('check/', views.check, name='check'),
    path('sendMessage/', views.sendMessage, name='sendMessage'),
    path('checkBalance/', views.balance, name='checkBalance'),
    path('checkBalanceRecord/', views.balance_record, name='checkBalanceRecord'),
    path('countPurchase/', views.count_purchase_1, name='countPurchase'),
    path('bindVoucher/', views.bind_voucher, name='bindVoucher'),
    path('erpGoodsCount/', views.erpGoodsCount, name='erpGoodsCount'),
    path('erpOrderCount/', views.erpOrderCount, name='erpOrderCount'),
    path('testConfirm/', views.testConfirm, name='testConfirm'),
    path('', include(card_router.urls)),

]
