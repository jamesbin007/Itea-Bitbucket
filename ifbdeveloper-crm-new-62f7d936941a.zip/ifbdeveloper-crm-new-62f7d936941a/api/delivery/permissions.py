from rest_framework.permissions import BasePermission


class DriverViewSetPermission(BasePermission):
    def has_permission(self, request, view):
        if request.method == 'POST':
            return True
            #return request.user.role.name in (1, 4)
        else:
            return True


class DeliveryViewSetPermission(BasePermission):
    def has_permission(self, request, view):
        if request.method in ('POST', 'DELETE', 'PUT', 'PATCH'):
            return True
            # print(request.user.role.name)
            # return request.user.role.name in (0, 1, 4)
        else:
            return True
