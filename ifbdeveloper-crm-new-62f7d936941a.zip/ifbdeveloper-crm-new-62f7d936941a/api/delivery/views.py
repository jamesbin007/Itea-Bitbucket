import stripe
from rest_framework import viewsets, mixins
from rest_framework.response import Response
from utils.pagination import DefaultPagination
from app01 import models
from . import serializers
from rest_framework.decorators import api_view
from django_filters.rest_framework import DjangoFilterBackend
from rest_framework.filters import SearchFilter, OrderingFilter
from utils.permissions import IsAdmin, IsApp
from .permissions import DriverViewSetPermission, DeliveryViewSetPermission
from django.db.models import Q, Sum
from rest_framework import status
from django_filters import rest_framework as filters
from django.db.models.functions import Coalesce
from rest_framework.decorators import action
from django.db import transaction
from django_filters import Filter,FilterSet
import  datetime
from rest_framework.permissions import AllowAny
from rest_framework.decorators import api_view,authentication_classes,permission_classes
class IntegerListFilter(Filter):
    def filter(self,qs,value):
     if value not in (None,''):
          integers = [int(v) for v in value.split(',')]
          return qs.filter(**{'%s__%s'%(self.field_name, self.lookup_expr):integers})
     return qs
class DriverFilter(filters.FilterSet):
    mobile_no = filters.CharFilter(field_name="mobile_no", lookup_expr='exact')
    password = filters.CharFilter(field_name="password", lookup_expr='exact')
    status = IntegerListFilter(field_name="status", lookup_expr='in')
    class Meta:
        model = models.Driver
        fields = ('mobile_no','password','status', )


class DeliveryFilter(filters.FilterSet):
    mobile_no = filters.CharFilter(field_name="driver", lookup_expr='exact')
    status = IntegerListFilter(field_name="delivery_status", lookup_expr='in')
    class Meta:
        model = models.DeliveryOrder
        fields = ('driver','status' ,)

class DriverViewSet(viewsets.ModelViewSet):
    permission_classes = (DriverViewSetPermission,)
    queryset = models.Driver.objects.all()
    serializer_class = serializers.DriverSerializer
    pagination_class = DefaultPagination
    filter_backends = (
        DjangoFilterBackend,
        SearchFilter,
        OrderingFilter,
    )

    search_fields = ('id',)
    filter_class = DriverFilter
class DeliveryOrderViewSet(viewsets.ModelViewSet):
    permission_classes = (DeliveryViewSetPermission,)
    queryset = models.DeliveryOrder.objects.all()
    serializer_class = serializers.DeliveryOrderSerializer
    pagination_class = DefaultPagination
    filter_backends = (
        DjangoFilterBackend,
        SearchFilter,
        OrderingFilter,
    )

    search_fields = ('id',)

class CreateDeliveryOrderViewSet(viewsets.ModelViewSet):
    permission_classes = (DeliveryViewSetPermission,)
    queryset = models.DeliveryOrder.objects.all()
    serializer_class = serializers.DeliveryOrderSerializer
    pagination_class = DefaultPagination
    filter_backends = (
        DjangoFilterBackend,
        SearchFilter,
        OrderingFilter,
    )
    filter_fields = ('id',)
    search_fields = ('id',)
    ordering_fields = ('delivery_time',)
    filter_class = DeliveryFilter
    def get_queryset(self):

        return super(CreateDeliveryOrderViewSet, self).get_queryset()
    def create(self, request, *args, **kwargs):

        with transaction.atomic():
            serializer = self.get_serializer(data=request.data)
            serializer.is_valid(raise_exception=True)


            self.perform_create(serializer)
            headers = self.get_success_headers(serializer.data)
            order_id=serializer.data['id']
            delivery_order=models.DeliveryOrder.objects.filter(id=order_id).first()
            transactionObj=models.Transaction.objects.filter(id=request.data.get('transaction')).first()
            driverObj = models.Driver.objects.filter(id=request.data.get('driver')).first()
            if transactionObj:
                member=transactionObj.member
                if member:
                    delivery_order.member_mobile=member.mobile_no
                delivery_order.delivery_address=transactionObj.delivery_address
                delivery_order.delivery_time=transactionObj.delivery_time
                delivery_order.transaction_status=transactionObj.transaction_status
                delivery_order.delivery_remark = transactionObj.delivery_remark
            if driverObj:
                delivery_order.driver_mobile=driverObj.mobile_no

            delivery_order.save()
            return Response(serializers.DeliveryOrderSerializer(delivery_order).data, status=status.HTTP_201_CREATED, headers=headers)

@api_view(['GET','POST'])
@authentication_classes([])
@permission_classes((AllowAny,))
def update_delivery(request, *args, **kwargs):
    order_id=request.GET['order_id']
    status = request.GET['status']
    print(order_id)
    print(status)
    if order_id:
        if int(status)==1:
            models.DeliveryOrder.objects.filter(id=order_id).update(delivery_status=1)
        elif int(status)==2:
            models.DeliveryOrder.objects.filter(id=order_id).update(delivery_status=2,finish_time=datetime.datetime.now())
        return Response({'msg':'ok'})


@api_view(['GET','POST'])
@authentication_classes([])
@permission_classes((AllowAny,))
def update_location(request, *args, **kwargs):
    driver_id=request.GET['driver_id']
    latitude = request.GET['latitude']
    longitude = request.GET['longitude']
    print(driver_id)

    if driver_id:

            models.Driver.objects.filter(id=driver_id).update(location_latitude=latitude,location_longitude=longitude,location_update_time=datetime.datetime.now())
            return Response({'msg':'ok'})