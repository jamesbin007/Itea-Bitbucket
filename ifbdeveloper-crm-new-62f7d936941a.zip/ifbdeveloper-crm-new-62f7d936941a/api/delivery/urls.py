from django.urls import path, include
from rest_framework.routers import DefaultRouter
from . import views



router = DefaultRouter()

router.register('driver', views.DriverViewSet, base_name='driver')
#android url prevent android decompile
router.register('delivery_order', views.CreateDeliveryOrderViewSet, base_name='delivery_order')

router.register('', views.DeliveryOrderViewSet)

urlpatterns = [
    path('update_delivery/', views.update_delivery, name='update_delivery'),
    path('update_location/', views.update_location, name='update_location'),
    path('', include(router.urls)),

]
