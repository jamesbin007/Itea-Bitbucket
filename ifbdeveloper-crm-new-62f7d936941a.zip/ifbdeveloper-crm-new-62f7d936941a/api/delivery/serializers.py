from rest_framework import serializers
from app01 import models
from utils.utils import except_validation_error



class DriverSerializer(serializers.ModelSerializer):


    class Meta:
        model = models.Driver
        fields = '__all__'

class DeliveryOrderSerializer(serializers.ModelSerializer):

    class Meta:
        model = models.DeliveryOrder
        fields = '__all__'


