from django.urls import path, include
from rest_framework.routers import DefaultRouter
from . import views



router = DefaultRouter()

router.register('recharge-record', views.RechargeRecordViewSet, base_name='recharge_record')
#android url prevent android decompile
router.register('show_class', views.RechargeRecordSimpleViewSet, base_name='consume_record')
router.register('wallet-amt-dis', views.WalletAmtDisView, base_name='wallet_amt_dis')
router.register('campaign_topup', views.CampaignTopupViewSet, base_name='campaign-topup')
router.register('', views.WalletViewSet)

urlpatterns = [
    path('', include(router.urls)),
    path('charge-test', views.checkStripe, name='charge-test')
]
