from django.urls import path, include
from rest_framework.routers import DefaultRouter
from . import views


router = DefaultRouter()
router.register('toppings', views.ToppingsViewSet, base_name='toppings')
router.register('mobile_size_toppings', views.SizesToppingsViewSet, base_name='mobile_size_toppings')
router.register('category', views.CategoryViewSet, base_name='category')
router.register('scheme', views.ProductSchemeViewSet, base_name='scheme')
router.register('mobile', views.ProductViewSetForMobile, base_name='scheme')
router.register('mobile_stock', views.ProductViewSetForStock, base_name='scheme')

router.register('product_group', views.ProductGroupViewSet, base_name='scheme')
router.register('template', views.TemplateViewSet, base_name='scheme')
router.register('tea-base', views.ProductTeaBaseViewSet, base_name='tea_base')
router.register('toppings', views.ToppingsViewSet, base_name='toppings')
router.register('advertising', views.AdvertisingViewSet, base_name='advertising')
router.register('getTopupImgs', views.TopupImgsViewSet, base_name='getTopupImgs')
router.register('open_adv', views.OpenAdvertisingViewSet, base_name='open_adv')
router.register('toppings_stock', views.StockToppingsViewSet, base_name='toppings_stock')
router.register('', views.ProductViewSet)

urlpatterns = [
    path('update_status/', views.update_status, name="update"),
    path('update_topping_status/', views.update_topping_status, name="topping_update"),
    path('update_status_new/', views.update_status_new, name="update_new"),
    path('product_sold_out/', views.product_sold_out, name="product_sold_out"),
    path('outlet_toppings/', views.outlet_toppings, name="outlet_toppings"),
    path('', include(router.urls)),
]
