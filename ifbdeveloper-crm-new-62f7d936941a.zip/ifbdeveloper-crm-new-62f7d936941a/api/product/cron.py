from app01 import models
from django.db import transaction


def update_goods():
    """ Executed at 12:00:00 every day"""
    with transaction.atomic():
        #models.Product.objects.all().filter(product_status=False).update(product_status=True)
        pass

def check_mooncake_order_quantity(delivery_times,outlet_id):
    trans_id_list=[]
    trans_id_tupple=()
    product_sum=0
    order_delivery_times=''
    max_limit_quantity=0
    product_limit_quantity=models.Product_Limit_Quantity.objects.all().first()
    if product_limit_quantity:
        max_limit_quantity=product_limit_quantity.max_quantity
    if delivery_times:
        delivery_times_arr=delivery_times.split(' ')
        if delivery_times_arr:
            if len(delivery_times_arr)>1:
                order_delivery_times=delivery_times_arr[len(delivery_times_arr)-1]
    if order_delivery_times!='':
        transaction_list=models.Transaction.objects.filter(delivery_times__contains=delivery_times,transaction_status__in =(4,5),outlet__id=outlet_id)
        if transaction_list:
            for item in transaction_list:
                trans_id_list.append(item.id)
                trans_id_tupple=tuple(trans_id_list)
            transactDetails_list=models.TransactDetails.objects.filter(transaction__id__in=trans_id_tupple)
            if transactDetails_list:
                for transDetails in transactDetails_list:
                    product_sum=product_sum+transDetails.quantity
            if product_sum:
                if product_sum>max_limit_quantity:
                    return True
    return False

