from rest_framework import viewsets
from app01 import models

from . import serializers
from django_filters.rest_framework import DjangoFilterBackend
from rest_framework.filters import SearchFilter, OrderingFilter
from .permissions import ProductViewSetPermission, ToppingsViewSetPermission, CategoryViewSetPermission, ProductSchemeViewSetPermission
from django_filters import rest_framework as filters
from django_filters import Filter,FilterSet
from django.db.models import Sum, Count, Avg,F,Q
from django.db.models.expressions import RawSQL
from django.db.models.functions import Coalesce
from rest_framework.decorators import api_view,authentication_classes,permission_classes
from rest_framework.permissions import AllowAny
from rest_framework.response import Response
from rest_framework import status
from django.db import connection
class IntegerListFilter(Filter):
    def filter(self,qs,value):
         if value not in (None,''):
              integers = [int(v) for v in value.split(',')]
              return qs.filter(**{'%s__%s'%(self.field_name, self.lookup_expr):integers})
         return qs

class GroupFilter(FilterSet):
    group_name = filters.CharFilter(field_name="group_name", lookup_expr='exact')
    group_id = IntegerListFilter(field_name='id', lookup_expr='in')

    class Meta:
        model = models.Group
        fields = ('group_name', 'group_id',)
class ProductFilter(filters.FilterSet):
    category_name = filters.CharFilter(field_name="category__name", lookup_expr='icontains')
    product_id = IntegerListFilter(field_name='id', lookup_expr='in')
    tea_base = filters.CharFilter(field_name="tea_base", lookup_expr='icontains')

    class Meta:
        model = models.Product

        fields = ['category__name' ,'product_id','tea_base',]

class CategoryFilter(filters.FilterSet):
    category_type = filters.CharFilter(field_name="category_type", lookup_expr='exact')



    class Meta:
        model = models.Category

        fields = ['category_type' ,]


class AdvFilter(filters.FilterSet):
    outlet = filters.CharFilter(field_name="outlet__id", lookup_expr='exact')



    class Meta:
        model = models.Advertising

        fields = ['outlet' ,]

class ProductFilterForMobile(filters.FilterSet):
    category_name = filters.CharFilter(field_name="category__name", lookup_expr='icontains')
    category_id = filters.CharFilter(field_name="category", lookup_expr='exact')
    outlet_id = filters.CharFilter(field_name="outlet", lookup_expr='exact')
    group_name=filters.CharFilter(field_name="group_name", lookup_expr='exact')
    product_id = IntegerListFilter(field_name='id', lookup_expr='in')

    class Meta:
        model = models.Product

        fields = ['category__name','category' ,'outlet','group_name','product_id',]


class ProductViewSetForStock(viewsets.ModelViewSet):
    permission_classes = (ProductViewSetPermission,)
    queryset = models.Product.objects.all()
    serializer_class = serializers.ProductCUDSerializer
    filter_backends = (
        DjangoFilterBackend,
        SearchFilter,
        OrderingFilter,
    )
    filter_class = ProductFilterForMobile
    search_fields = ('name',)
    ordering_fields = ('category',)

    def get_serializer_class(self):
        if self.request.method == "GET":
            return serializers.ProductMobileSerializer
        else:
            return super(ProductViewSet, self).get_serializer_class()

class ProductViewSetForMobile(viewsets.ModelViewSet):
    permission_classes = (ProductViewSetPermission,)
    authentication_classes = []
    #queryset = models.Product.objects.all().filter(product_status=True)
    queryset = models.Product.objects.all()

    serializer_class = serializers.ProductCUDSerializer
    filter_backends = (
        DjangoFilterBackend,
        SearchFilter,
        OrderingFilter,
    )
    filter_class = ProductFilterForMobile
    search_fields = ('name',)
    ordering_fields = ('category',)

    def get_serializer_class(self):
        if self.request.method == "GET":
            return serializers.ProductMobileSerializer
        else:
            return super(ProductViewSet, self).get_serializer_class()


class TemplateFilter(filters.FilterSet):
    plu_code = filters.CharFilter(field_name="plu_code", lookup_expr='exact')
    group_name = filters.CharFilter(field_name="group_name", lookup_expr='exact')

    class Meta:
        model = models.Template

        fields = ['plu_code','group_name',]

class ToppingsFilter(filters.FilterSet):
    name = filters.CharFilter(field_name="name", lookup_expr='exact')
    toppings_type= filters.CharFilter(field_name="toppings_type", lookup_expr='exact')
    key_word= filters.CharFilter(field_name="key_word", lookup_expr='exact')

    class Meta:
        model = models.Toppings

        fields = ['name','toppings_type','key_word',]
class TemplateViewSet(viewsets.ModelViewSet):
    permission_classes = (ProductViewSetPermission,)
    authentication_classes = []
    queryset = models.Template.objects.all()
    serializer_class = serializers.TemplateSerializer
    filter_backends = (
        DjangoFilterBackend,
        SearchFilter,
        OrderingFilter,
    )
    filter_class = TemplateFilter
    search_fields = ('name',)
    ordering_fields = ('id',)

class ToppingsViewSet(viewsets.ModelViewSet):
    permission_classes = (ProductViewSetPermission,)
    authentication_classes = []
    queryset = models.Toppings.objects.filter(topping_status=True)
    serializer_class = serializers.ToppingsSerializer
    filter_backends = (
        DjangoFilterBackend,
        SearchFilter,
        OrderingFilter,
    )
    filter_class = ToppingsFilter
    search_fields = ('name',)
    ordering_fields = ('id',)
    def get_queryset(self):

            if self.request.GET.get('toppings_type','')!='':
                #if self.request.GET.get('outlet_id','')!='' or self.request.GET.get('outlet','')!='':
                    if self.request.GET.get('toppings_type', '')=='1':
                        if self.request.GET.get('outlet_id', '') != '':
                            self.queryset = models.Toppings.objects.filter(toppings_type=1,topping_status=True,outlet__id=self.request.GET.get('outlet_id',0))
                        if self.request.GET.get('outlet','')!='':
                            self.queryset = models.Toppings.objects.filter(toppings_type=1,topping_status=True,
                                                                           outlet__id=self.request.GET.get('outlet',
                                                                                                           0))
                         #self.queryset=models.Toppings.objects.filter(name__in=RawSQL("select app01_toppings.name from app01_toppings join app01_product on app01_toppings.name=app01_product.name where app01_product.group_name='SpicyPot' and app01_product.outlet_id="+self.request.GET.get('outlet_id','')+" and app01_product.product_status=%s",[True,]))
                    else:
                        self.queryset = models.Toppings.objects.filter(toppings_type=0,topping_status=True)

            else:
                self.queryset = models.Toppings.objects.filter(toppings_type=0,topping_status=True)

            return super(ToppingsViewSet, self).get_queryset()

class SizesToppingsViewSet(viewsets.ModelViewSet):
    permission_classes = (ProductViewSetPermission,)
    queryset = models.Product.objects.all()
    serializer_class = serializers.ProductItemSerializer
    filter_backends = (
        DjangoFilterBackend,
        SearchFilter,
        OrderingFilter,
    )
    filter_class = ProductFilter
    search_fields = ('name',)
    ordering_fields = ('id',)
    def get_queryset(self):
            outlet_id=self.request.GET.get('outlet_id','')

            if outlet_id:
                self.queryset = models.Product.objects.filter(outlet__id=outlet_id).filter(Q(group_name='Size') | Q(group_name='Topping'))



            return super(SizesToppingsViewSet, self).get_queryset()


class StockToppingsViewSet(viewsets.ModelViewSet):
    permission_classes = (ProductViewSetPermission,)
    authentication_classes = []
    queryset = models.Toppings.objects.all()
    serializer_class = serializers.ToppingsSerializer
    filter_backends = (
        DjangoFilterBackend,
        SearchFilter,
        OrderingFilter,
    )
    filter_class = ToppingsFilter
    search_fields = ('name',)
    ordering_fields = ('id',)
    def get_queryset(self):

            if self.request.GET.get('toppings_type','')!='':
                #if self.request.GET.get('outlet_id','')!='' or self.request.GET.get('outlet','')!='':
                    if self.request.GET.get('toppings_type', '')=='1':
                        if self.request.GET.get('outlet_id', '') != '':
                            self.queryset = models.Toppings.objects.filter(toppings_type=1,outlet__id=self.request.GET.get('outlet_id',0))
                        if self.request.GET.get('outlet','')!='':
                            self.queryset = models.Toppings.objects.filter(toppings_type=1,
                                                                           outlet__id=self.request.GET.get('outlet',
                                                                                                           0))
                         #self.queryset=models.Toppings.objects.filter(name__in=RawSQL("select app01_toppings.name from app01_toppings join app01_product on app01_toppings.name=app01_product.name where app01_product.group_name='SpicyPot' and app01_product.outlet_id="+self.request.GET.get('outlet_id','')+" and app01_product.product_status=%s",[True,]))
                    else:
                        self.queryset = models.Toppings.objects.filter(toppings_type=0)

            else:
                self.queryset = models.Toppings.objects.filter(toppings_type=0)

            return super(StockToppingsViewSet, self).get_queryset()
class AdvertisingViewSet(viewsets.ModelViewSet):
    permission_classes = (ProductViewSetPermission,)
    authentication_classes = []
    queryset = models.Advertising.objects.all()
    serializer_class = serializers.AdvertisingSerializer
    filter_backends = (
        DjangoFilterBackend,
        SearchFilter,
        OrderingFilter,
    )
    #filter_class = AdvFilter

    search_fields = ('title',)
    ordering_fields = ('id',)
class ProductGroupViewSet(viewsets.ModelViewSet):
    permission_classes = (ProductViewSetPermission,)
    authentication_classes = []
    queryset = models.Group.objects.all()
    serializer_class = serializers.GroupSerializer
    filter_backends = (
        DjangoFilterBackend,
        SearchFilter,
        OrderingFilter,
    )
    filter_class = GroupFilter

    search_fields = ('name',)
    ordering_fields = ('id',)

class TopupImgsViewSet(viewsets.ModelViewSet):
    permission_classes = (ProductViewSetPermission,)
    queryset = models.TopupImgs.objects.all()
    serializer_class = serializers.TopupImgsSerializer
    filter_backends = (
        DjangoFilterBackend,
        SearchFilter,
        OrderingFilter,
    )
    #filter_class = AdvFilter

    search_fields = ('title',)
    ordering_fields = ('id',)


class OpenAdvertisingViewSet(viewsets.ModelViewSet):
    permission_classes = (ProductViewSetPermission,)
    authentication_classes = []
    queryset = models.OpenAdvertising.objects.filter(status=True)
    serializer_class = serializers.OpenAdvertisingSerializer
    filter_backends = (
        DjangoFilterBackend,
        SearchFilter,
        OrderingFilter,
    )
    # filter_class = AdvFilter

    search_fields = ('title',)




class ProductViewSet(viewsets.ModelViewSet):
    permission_classes = (ProductViewSetPermission,)
    queryset = models.Product.objects.all().filter(category__isnull=False)
    serializer_class = serializers.ProductCUDSerializer
    filter_backends = (
        DjangoFilterBackend,
        SearchFilter,
        OrderingFilter,
    )
    filter_class = ProductFilter
    search_fields = ('name',)
    ordering_fields = ('satisfaction',)

    def get_serializer_class(self):
        if self.request.method == "GET":
            return serializers.ProductRSerializer
        else:
            return super(ProductViewSet, self).get_serializer_class()

    def get_queryset(self):
        self.queryset = self.queryset.prefetch_related(
            'transact_details__transaction__evaluation',
            'category',
            'outlet',
            'scheme'
        ).annotate(
            satisfaction=Coalesce(Avg('transact_details__transaction__evaluation__product_quality_satisfaction'), 0))
        return super(ProductViewSet, self).get_queryset()

'''
class ToppingsViewSet(viewsets.ModelViewSet):
    permission_classes = (ToppingsViewSetPermission,)
    queryset = models.Toppings.objects.all()
    serializer_class = serializers.ToppingsSerializer
    filter_backends = (
        DjangoFilterBackend,
        SearchFilter,
        OrderingFilter,
    )
'''

class CategoryViewSet(viewsets.ModelViewSet):
    permission_classes = (CategoryViewSetPermission,)
    queryset = models.Category.objects.all()
    serializer_class = serializers.CategorySerializer
    filter_backends = (
        DjangoFilterBackend,
        SearchFilter,
        OrderingFilter,
    )
    filter_class = CategoryFilter
    search_fields = ('category_type',)
    ordering_fields = ('id',)


class ProductSchemeViewSet(viewsets.ModelViewSet):
    permission_classes = (ProductSchemeViewSetPermission,)
    queryset = models.ProductScheme.objects.all()
    serializer_class = serializers.ProductSchemeSerializer
    filter_backends = (
        DjangoFilterBackend,
        SearchFilter,
        OrderingFilter,
    )


class ProductTeaBaseViewSet(viewsets.ReadOnlyModelViewSet):
    permission_classes = []
    queryset = models.Product.objects.all()
    serializer_class = serializers.ProductTeaBaseSerializer
    filter_backends = (
        DjangoFilterBackend,
        SearchFilter,
        OrderingFilter,
    )

    def get_queryset(self):
        self.queryset = self.queryset.filter(tea_base__isnull=False).only('tea_base').distinct('tea_base')
        return super(ProductTeaBaseViewSet, self).get_queryset()


@api_view(['GET', 'POST'])
@authentication_classes([])
@permission_classes((AllowAny,))
def update_status(request, *args, **kwargs):
    if request.method == 'GET':

        #order_id
        id = request.query_params.get('id')
        p_status= request.query_params.get('status')
        if p_status:
            if (p_status=='0'):
                product_status=False
            else:
                product_status=True
        else:
            return Response({'msg': 'error', }, status=status.HTTP_200_OK)

        if id:
            resulat_val=models.Product.objects.filter(id=id).update(product_status=product_status)
            if resulat_val:
                return Response({'msg': 'ok', }, status=status.HTTP_200_OK)

        return Response({'msg': 'error', }, status=status.HTTP_200_OK)

@api_view(['GET', 'POST'])
@authentication_classes([])
@permission_classes((AllowAny,))
def product_sold_out(request, *args, **kwargs):
    if request.method == 'GET':

        #outlet_id
        outlet_id = request.query_params.get('outlet_id')
        p_sold_out = 0
        if outlet_id:
           ''' 
           product_sold_out_count= models.Product.objects.filter(outlet__id=outlet_id,group_name='Product',product_status=False).aggregate(count=Count('id'))
           if product_sold_out_count:
               p_sold_out=product_sold_out_count['count']
           else:
               p_sold_out=0
           if p_sold_out>0:
           '''
           cursor = connection.cursor()
           cursor.execute("select count(*) from app01_product where id in (select product_id from app01_category_product where category_id in (select category_id from app01_outlet_category where outlet_id="+outlet_id+")) and product_status = false and group_name='Product'")
           row2 = cursor.fetchall()
           if row2:
               p_sold_out=row2[0][0]

           return Response({'count': p_sold_out, }, status=status.HTTP_200_OK)

        return Response({'count': 0, }, status=status.HTTP_200_OK)

@api_view(['GET', 'POST'])
@authentication_classes([])
@permission_classes((AllowAny,))
def update_status_new(request, *args, **kwargs):
    if request.method == 'GET':

        #order_id
        id = request.query_params.get('id')
        p_status= request.query_params.get('status')
        long_sold_out=request.query_params.get('long_sold_out')
        if p_status:
            if (p_status=='0'):
                product_status=False
            else:
                product_status=True
            if (long_sold_out == '0'):
                sold_out = False
            else:
                sold_out = True

        else:
            return Response({'msg': 'error', }, status=status.HTTP_200_OK)

        if id:
            resulat_val=models.Product.objects.filter(id=id).update(product_status=product_status,long_sold_out=sold_out)
            if resulat_val:
                return Response({'msg': 'ok', }, status=status.HTTP_200_OK)

        return Response({'msg': 'error', }, status=status.HTTP_200_OK)

@api_view(['GET', 'POST'])
@authentication_classes([])
@permission_classes((AllowAny,))
def update_topping_status(request, *args, **kwargs):
    if request.method == 'GET':

        #order_id
        id = request.query_params.get('id')
        p_status= request.query_params.get('status')
        if p_status:
            if (p_status=='0'):
                product_status=False
            else:
                product_status=True
        else:
            return Response({'msg': 'error', }, status=status.HTTP_200_OK)

        if id:
            resulat_val=models.Toppings.objects.filter(id=id).update(topping_status=product_status)
            if resulat_val:
                return Response({'msg': 'ok', }, status=status.HTTP_200_OK)

        return Response({'msg': 'error', }, status=status.HTTP_200_OK)

@api_view(['GET', 'POST'])
@authentication_classes([])
@permission_classes((AllowAny,))
def outlet_toppings(request, *args, **kwargs):
    if request.method == 'GET':

        #outlet_id
        outlet_id = request.query_params.get('outlet_id')
        topping_list=[]
        if outlet_id:
           t_list=models.Toppings.objects.filter(toppings_type=0,topping_status=True).order_by('id')
           t_o_list=models.Product.objects.filter(group_name='Topping',outlet__id=outlet_id)
           for t in t_list:
               img_url=''
               for t_o in t_o_list:
                   if t.relation_name==t_o.name:
                        t.price=t_o.price
                        t.topping_status=t_o.product_status
                        t.outlet_id=t_o.outlet_id
                        img_url=t_o.thumb_image_path
                        break
               topping_list.append({'id':t.id,'name':t.name,'description':t.description,'price':t.price,'item_code':t.item_code,'relation_name':t.relation_name,'key_word':t.key_word,'outlet':t.outlet_id,'product_status':t.topping_status,'img_url':img_url})



        return Response({'results': topping_list, }, status=status.HTTP_200_OK)