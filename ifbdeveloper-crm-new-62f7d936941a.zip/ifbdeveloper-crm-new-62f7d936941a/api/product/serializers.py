from rest_framework import serializers
from app01 import models



class ProductTeaBaseSerializer(serializers.ModelSerializer):
    class Meta:
        model = models.Product
        fields = ('tea_base',)

class ProductSimpleSerializer(serializers.ModelSerializer):
    class Meta:
        model = models.Product
        exclude = ('group',)
class ToppingsSerializer(serializers.ModelSerializer):
    class Meta:
        model = models.Toppings
        fields = "__all__"

class AdvertisingSerializer(serializers.ModelSerializer):
    class Meta:
        model = models.Advertising
        fields = "__all__"
class GroupSerializer(serializers.ModelSerializer):
    class Meta:
        model = models.Group
        fields = "__all__"
        depth = 2

class TopupImgsSerializer(serializers.ModelSerializer):
    class Meta:
        model = models.TopupImgs
        fields = "__all__"

class OpenAdvertisingSerializer(serializers.ModelSerializer):
    class Meta:
        model = models.OpenAdvertising
        fields = "__all__"
class CategorySerializer(serializers.ModelSerializer):
    class Meta:
        model = models.Category
        fields = "__all__"

class TemplateSerializer(serializers.ModelSerializer):
    class Meta:
        model = models.Template
        fields = "__all__"


class ProductSchemeSerializer(serializers.ModelSerializer):
    class Meta:
        model = models.ProductScheme
        fields = "__all__"


class ProductRSerializer(serializers.ModelSerializer):
    satisfaction = serializers.FloatField(required=False, allow_null=True)
    root_product_id = serializers.SerializerMethodField()

    class Meta:
        model = models.Product
        fields = "__all__"
        depth = 2

    def get_root_product_id(self, obj):
        ret = models.Product.objects.filter(outlet__isnull=True).filter(item_code=obj.item_code)
        if (ret):
            return ret[0].id
        else:
            return 0

class ProductMobileSerializer(serializers.ModelSerializer):
    satisfaction = serializers.FloatField(required=False, allow_null=True)
    #root_product_id = serializers.SerializerMethodField()
    category= serializers.SerializerMethodField()
    category_list=models.Category.objects.all()
    class Meta:
        model = models.Product
        exclude = ("outlet","scheme",)
        #depth = 2

    def get_category(self, obj):
        category_id=obj.category_id
        category_item=None
        for item in self.category_list:
            if item.id==category_id:
                category_item=item
                break
        if (category_item):
            return CategorySerializer(category_item).data
        else:
            return None
'''
    def get_root_product_id(self, obj):
        ret = models.Product.objects.filter(outlet__isnull=True).filter(item_code=obj.item_code)
        if (ret):
            return ret[0].id
        else:
            return 0
'''
class ProductPerformanceSerializer(serializers.ModelSerializer):
    products_sold = serializers.FloatField(required=False, allow_null=True)
    products_sold_incr = serializers.FloatField(required=False, allow_null=True)
    turnover = serializers.FloatField(required=False, allow_null=True)
    turnover_incr = serializers.FloatField(required=False, allow_null=True)

    class Meta:
        model = models.Product
        fields = "__all__"
        depth = 2


class ProductCUDSerializer(serializers.ModelSerializer):

    class Meta:
        model = models.Product
        fields = "__all__"
class ProductItemSerializer(serializers.ModelSerializer):

    class Meta:
        model = models.Product
        exclude=('group',)

