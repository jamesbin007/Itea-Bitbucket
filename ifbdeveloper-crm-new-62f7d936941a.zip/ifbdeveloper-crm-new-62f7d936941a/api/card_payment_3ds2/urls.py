from django.urls import path, include
from rest_framework.routers import DefaultRouter
from . import views






card_router = DefaultRouter()
card_router.register('', views.CardViewSet)

urlpatterns = [
    path('check/', views.check, name='check'),
    path('wirecard_status/', views.wirecard_status, name='wirecard_status'),
    path('initiate_checkout/', views.initiate_checkout, name='initiate_checkout'),
    path('session/', views.session, name='session'),
    path('update_session/', views.update_session, name='update_session'),
    path('initiate_authentication/', views.initiate_authentication, name='initiate_authentication'),
    path('authentication_payer/', views.authentication_payer, name='authentication_payer'),
    path('token/', views.token, name='token'),
    path('transaction/', views.transaction, name='transaction'),
    path('payment/', views.payment, name='payment'),
    path('three_d_secure/', views.three_d_secure, name='three_d_secure'),
    path('three_d_secure_result/', views.three_d_secure_result, name='three_d_secure_result'),
    path('new_three_d_secure_result/', views.new_three_d_secure_result, name='new_three_d_secure_result'),
    path('new_three_d_secure_result_for_web/', views.new_three_d_secure_result_for_web, name='new_three_d_secure_result_for_web'),
    path('', include(card_router.urls)),

]
