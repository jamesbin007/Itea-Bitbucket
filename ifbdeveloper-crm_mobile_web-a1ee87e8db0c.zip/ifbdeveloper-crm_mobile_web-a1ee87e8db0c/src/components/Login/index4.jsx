
/* eslint-disable */
import React from 'react'
import ReactDOM from 'react-dom'
import { reqLogin } from '../../api/requrl'
import { createForm } from 'rc-form';
import { Link } from 'react-router-dom'

import Cookies from 'js-cookie';
import ReCAPTCHA from 'react-google-recaptcha'
import { Flex, List, InputItem, Toast, Button, WingBlank, WhiteSpace, NavBar, Icon } from 'antd-mobile';

import '../config.js'
import cobra_logo from '../../assets/img/logo.png'
import eye_logo from "../../assets/img/see.png";

class Login extends React.Component {
  state = {
    username: '',
    password: '',
  }

  handleLogin = async () => {
    let { username, password, isLogin } = this.state
    if (!username.trim()) {
      return Toast.info('Please input Mobile number.')
    }
    if (isNaN(username.trim()))
          return Toast.info('Please enter exact Mobile number.')
      if (username.trim().length !== 8)
          return Toast.info('Mobile number must be 8 character.')
    if (!password.trim()) {
      return Toast.info('Please input password.')
    }
    const user = {username, password}
    let id=window.location.href.split("?")[1]
    reqLogin(user).then(res => {
      global.isLogin = true
      global.username = user.username
      Cookies.set('isLogin', global.isLogin);
      Cookies.set('user', user.username);
      Cookies.set('Authorization', res.data.token)
      this.props.history.push("/profile")
    }).catch(err => {
      console.log(err.message)
      return Toast.info('Username or password error.')
    })
  }

  render() {
    const {
      username,
      password,
    } = this.state

    return (
      <div style={{cursor:'pointer'}}>
        <head><script src='https://www.google.com/recaptcha/api.js?render=6LcQbI0UAAAAADFfIF-Kdc1WlQJWsH4Ul-7IyBRg'></script></head>
        <NavBar
          mode="light"
          icon={<Icon type="left" />}
          onLeftClick={() => this.props.history.goBack()}
          rightContent={[
            <Icon key="1" type="ellipsis" />,
          ]}
        >Login</NavBar>
      <form className="form">
        <List renderHeader={() => <b>Login</b>}>
          <Flex justify="center">
            <img src={cobra_logo} height="111" width="256"></img>
          </Flex>
          <WhiteSpace size="lg" />


          <WingBlank><InputItem type="tel" placeholder="Mobile Number" onChange={(v) => this.setState({ 'username': v })} required /></WingBlank>
          <WhiteSpace size="lg" />
          <WingBlank><InputItem type="password" id="pass" placeholder="Password" onChange={(v) => this.setState({ 'password': v })}    extra={

            <img src={eye_logo} style={{float:'left'}} height="20" width="20" onClick={(v) => {if (document.getElementById('pass').type=="text") { document.getElementById('pass').type="password";  }else { document.getElementById('pass').type="text";  } }}  ></img>

            }


                                required /></WingBlank>
          <WhiteSpace size="xl" />
          <WingBlank><Button className="Login" type='primary' style={{cursor:'pointer'}} onClick={this.handleLogin}>Login</Button></WingBlank>
          <WhiteSpace size="xl" />
          <Flex justify="between">
            <WingBlank><li><Link to={"/ForgetPassword"}>Forget password</Link></li></WingBlank>
            <WingBlank><li><Link to={"/register"}>New User</Link></li></WingBlank>
          </Flex>
          <WhiteSpace size="xl" />
        </List>
      </form>
      </div>
    )
  }
} 

export default createForm()(Login) ;
