
/* eslint-disable */
import React from 'react'
import ReactDOM from 'react-dom'
import { reqLogin,reqVisit } from '../../api/requrl'
import { createForm } from 'rc-form';
import { Link } from 'react-router-dom'

import Cookies from 'js-cookie';
import ReCAPTCHA from 'react-google-recaptcha'
import { Flex, List, InputItem, Toast, Button, WingBlank, WhiteSpace, NavBar, Icon } from 'antd-mobile';

import '../config.js'
import cobra_logo from '../../assets/img/logo.png'
import eye_logo from "../../assets/img/see.png";
import sleep_logo from '../../assets/img/sleep.png'
import facebook_logo from '../../assets/img/facebook.jpg'
import twitter_logo from '../../assets/img/twitter.jpg'
import link_logo from '../../assets/img/link.jpg'
import { Popover } from 'antd-mobile';
const Item = Popover.Item;
const myImg = src => <img src={facebook_logo} className="am-icon am-icon-xs" alt="" />;
const myImg1 = src => <img src={twitter_logo} className="am-icon am-icon-xs" alt="" />;
const myImg2 = src => <img src={link_logo} className="am-icon am-icon-xs" alt="" />;

class Login extends React.Component {
  constructor(props) {
    super(props)
    this.state = {
      see_img: eye_logo,
      username: '',
      password: '',
      veri_input: true,
      dayVisit: 0,
      allVisit: 0,
       visible: false,
    selected: '',
    }
    this.getVisit=this.getVisit.bind(this)
    this.handleVisibleChange=this.handleVisibleChange.bind(this)
    this.onSelect=this.onSelect.bind(this)
  }

   async getVisit()
  {
    const Token="Token fa3c5db850ada70422a02e4638984dc08822f010"
    let req=await reqVisit(Token)
    return req
  }



  handleLogin = async () => {
    let { username, password, isLogin } = this.state
    if (!username.trim()) {
      return Toast.info('Please input Mobile number.')
    }
    if (isNaN(username.trim()))
          return Toast.info('Please enter exact Mobile number.')
      if (username.trim().length !== 8)
          return Toast.info('Mobile number must be 8 character.')
    if (!password.trim()) {
      return Toast.info('Please input password.')
    }
    const user = {username, password}
    let id=window.location.href.split("?")[1]
    reqLogin(user).then(res => {
      global.isLogin = true
      global.username = user.username
      Cookies.set('isLogin', global.isLogin);
      Cookies.set('user', user.username);
      Cookies.set('Authorization', res.data.token)
      Cookies.set('wallet', res.data.wallet_id)
      this.props.history.push("/profile")
    }).catch(err => {
      console.log(err.message)
      return Toast.info('Username or password error.')
    })
  }

onSelect = (opt) => {
    // console.log(opt.props.value);

    this.setState({
      visible: false,
      selected: opt.props.value,

    });
    if (opt.props.value==='f') {
       window.open('http://www.facebook.com/sharer.php?u=' + encodeURIComponent('https://member.itea.sg') + '&t=' + encodeURIComponent('Register send 1 Free Milk Tea Voucher'), '_blank', 'toolbar=yes, location=yes, directories=no, status=no, menubar=yes, scrollbars=yes, resizable=no, copyhistory=yes, width=600, height=450,top=100,left=350');
    }
     if (opt.props.value==='t') {
       window.open('http://twitter.com/home?status=' + encodeURIComponent('https://member.itea.sg') + ' ' + encodeURIComponent('Register send 1 Free Milk Tea Voucher'), '_blank', 'toolbar=yes, location=yes, directories=no, status=no, menubar=yes, scrollbars=yes, resizable=no, copyhistory=yes, width=600, height=450,top=100,left=350');
     }
    if (opt.props.value==='l') {
      window.open('http://www.linkedin.com/shareArticle?mini=true&url=' + encodeURIComponent('https://member.itea.sg') + '&title=' + encodeURIComponent('Register send 1 Free Milk Tea Voucher') + '&source=' + encodeURIComponent('https://member.itea.sg'), '_blank', 'toolbar=yes, location=yes, directories=no, status=no, menubar=yes, scrollbars=yes, resizable=no, copyhistory=yes, width=600, height=450,top=100,left=350');
    }

   // alert(opt.props.value)
  };
  handleVisibleChange = (visible) => {

   // console.log('ok')
/*
     if (visible.cancelable) {
        // 判断默认行为是否已经被禁用
        if (!visible.defaultPrevented) {
            visible.preventDefault();
        }
    }
*/

    this.setState({
      visible,
    });
  };

async componentDidMount() {
    //count
     let visit= await  this.getVisit()
    console.log(visit.data)
   this.setState({allVisit:visit.data.visitAll,dayVisit:visit.data.visitDay})

/*
  var supportsPassive = false;
  try {
    var opts = Object.defineProperty({}, 'passive', {
      get: function() {
        supportsPassive = true;
      }
    });
    window.addEventListener("test", null, opts);
  } catch (e) {}

*/
  // document.getElementById('pop').addEventListener('click', this.handleVisibleChange,    { passive: false })
   //document.getElementById('pop').addEventListener('select', this.onSelect,    { passive: false })


 }
  render() {
    const {
      username,
      password,
    } = this.state

    return (
      <div style={{cursor:'pointer',height:'100%',touchAction:'none'}}>
        <head><script src='https://www.google.com/recaptcha/api.js?render=6LcQbI0UAAAAADFfIF-Kdc1WlQJWsH4Ul-7IyBRg'></script></head>
        <NavBar
          mode="light"
          icon={<Icon type="left" />}
          onLeftClick={() => this.props.history.goBack()}
          rightContent={ <Popover  mask  id='pop'
            overlayClassName="fortest"
            overlayStyle={{ color: 'currentColor' }}
            visible={this.state.visible}
            overlay={[
              (<Item key="4" value="f" icon={myImg('tOtXhkIWzwotgGSeptou')} data-seed="logId">Share To Facebook
</Item>),
              (<Item key="5" value="t" icon={myImg1('PKAgAqZWJVNwKsAJSmXd')} style={{ whiteSpace: 'nowrap' }}>Share To Twitter</Item>),
              (<Item key="6" value="l" icon={myImg2('uQIYTFeRrjPELImDRrPt')}>
                <span style={{ marginRight: 5 }}>Share To Link</span>
              </Item>),
            ]}
            align={{
              overflow: { adjustY: 0, adjustX: 0 },
              offset: [-10, 0],
            }}
            onVisibleChange={this.handleVisibleChange}
           onSelect={this.onSelect}
          >
            <div style={{
              height: '100%',
              padding: '0 15px',
              marginRight: '-15px',
              display: 'flex',
              alignItems: 'center'

            }}
            >
              <Icon type="ellipsis" />
            </div>
          </Popover>}
        >Login</NavBar>
      <form className="form">
        <List renderHeader={() => <b>Login</b>}>
          <Flex justify="center">
            <img src={cobra_logo} height="111" width="256"></img>
          </Flex>
            {/* <WhiteSpace size="lg" />
           <ReCAPTCHA
            sitekey="6LfxbY0UAAAAAHttgY_gbVs1Fj9hhfwTzzt19MA2"
            onChange={(v) => this.setState({ 'veri_input': false})}
            size="normal"
          />*/}

          <WingBlank><InputItem type="tel"   placeholder="Mobile Number" onChange={(v) => this.setState({ 'username': v })} required /></WingBlank>
          <WhiteSpace size="lg" />
          <WingBlank><InputItem type="password" id="pass" placeholder="Password" onChange={(v) => this.setState({ 'password': v })}    extra={

            <img src={this.state.see_img} id='img' style={{float:'left'}} height="20" width="20" onClick={(v) => {if (document.getElementById('pass').type=="text") { document.getElementById('pass').type="password";this.setState({ 'see_img': eye_logo });  }else { document.getElementById('pass').type="text"; this.setState({ 'see_img': sleep_logo }); }} } ></img>

            }


                                required /></WingBlank>
          <WhiteSpace size="xl" />
          <WingBlank><Button className="Login" type='primary' style={{cursor:'pointer'}} onClick={this.handleLogin}>Login</Button></WingBlank>
          <WhiteSpace size="xl" />
          <Flex justify="between">
            <WingBlank><li><Link to={"/ForgetPassword"}>Forget password</Link></li></WingBlank>
            <WingBlank><li><Link to={"/register"}>New User</Link></li></WingBlank>
          </Flex>
          <WhiteSpace size="xl" />
        </List>
      </form>


      <br/><br/><br/><br/><br/><br/><br/>

        <Flex justify="center"> <div style={{align:'center',textAlign:'center',fontSize:'10px',color:'gray'}} ><table  ><tr><td>Copyright © 2019  iTea Premium Bubble Tea Singapore</td><td>  </td><td>  </td></tr>

        <tr><td colSpan="3">Today:{this.state.dayVisit} &nbsp;&nbsp;All:{this.state.allVisit} </td></tr>
       </table></div></Flex>
      </div>
    )
  }
} 

export default createForm()(Login) ;
