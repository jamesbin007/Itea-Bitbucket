
/* eslint-disable */
import React from 'react'
import ReactDOM from 'react-dom'
import { reqLogin,reqVisit } from '../../api/requrl'
import { createForm } from 'rc-form';
import { Link } from 'react-router-dom'

import Cookies from 'js-cookie';
import ReCAPTCHA from 'react-google-recaptcha'
import { Flex, List, InputItem, Toast, Button, WingBlank, WhiteSpace, NavBar, Icon } from 'antd-mobile';

import '../config.js'
import cobra_logo from '../../assets/img/logo.png'
import eye_logo from "../../assets/img/see.png";
import sleep_logo from '../../assets/img/sleep.png'
import facebook_logo from '../../assets/img/facebook.jpg'
import twitter_logo from '../../assets/img/twitter.jpg'
import link_logo from '../../assets/img/link.jpg'
import { Popover } from 'antd-mobile';
const Item = Popover.Item;
const myImg = src => <img src={facebook_logo} className="am-icon am-icon-xs" alt="" />;
const myImg1 = src => <img src={twitter_logo} className="am-icon am-icon-xs" alt="" />;
const myImg2 = src => <img src={link_logo} className="am-icon am-icon-xs" alt="" />;

class Agree extends React.Component {
  constructor(props) {
    super(props)
    this.state = {
      see_img: eye_logo,
      username: '',
      password: '',
      veri_input: true,
      dayVisit: 0,
      allVisit: 0,
       visible: false,
    selected: '',
    }

  }







onSelect = (opt) => {
    // console.log(opt.props.value);

    this.setState({
      visible: false,
      selected: opt.props.value,

    });
    if (opt.props.value==='f') {
       window.open('http://www.facebook.com/sharer.php?u=' + encodeURIComponent('https://member.itea.sg') + '&t=' + encodeURIComponent('Register send 1 Free Milk Tea Voucher'), '_blank', 'toolbar=yes, location=yes, directories=no, status=no, menubar=yes, scrollbars=yes, resizable=no, copyhistory=yes, width=600, height=450,top=100,left=350');
    }
     if (opt.props.value==='t') {
       window.open('http://twitter.com/home?status=' + encodeURIComponent('https://member.itea.sg') + ' ' + encodeURIComponent('Register send 1 Free Milk Tea Voucher'), '_blank', 'toolbar=yes, location=yes, directories=no, status=no, menubar=yes, scrollbars=yes, resizable=no, copyhistory=yes, width=600, height=450,top=100,left=350');
     }
    if (opt.props.value==='l') {
      window.open('http://www.linkedin.com/shareArticle?mini=true&url=' + encodeURIComponent('https://member.itea.sg') + '&title=' + encodeURIComponent('Register send 1 Free Milk Tea Voucher') + '&source=' + encodeURIComponent('https://member.itea.sg'), '_blank', 'toolbar=yes, location=yes, directories=no, status=no, menubar=yes, scrollbars=yes, resizable=no, copyhistory=yes, width=600, height=450,top=100,left=350');
    }

   // alert(opt.props.value)
  };
  handleVisibleChange = (visible) => {

   // console.log('ok')
/*
     if (visible.cancelable) {
        // 判断默认行为是否已经被禁用
        if (!visible.defaultPrevented) {
            visible.preventDefault();
        }
    }
*/

    this.setState({
      visible,
    });
  };


  render() {


    return (
      <div style={{cursor:'pointer',height:'100%'}}>
        <head><script src='https://www.google.com/recaptcha/api.js?render=6LcQbI0UAAAAADFfIF-Kdc1WlQJWsH4Ul-7IyBRg'></script></head>
        <NavBar
          mode="light"
          icon={<Icon type="left" />}
          onLeftClick={() => this.props.history.goBack()}
          rightContent={ <Popover  mask  id='pop'
            overlayClassName="fortest"
            overlayStyle={{ color: 'currentColor' }}
            visible={this.state.visible}
            overlay={[
              (<Item key="4" value="f" icon={myImg('tOtXhkIWzwotgGSeptou')} data-seed="logId">Share To Facebook
</Item>),
              (<Item key="5" value="t" icon={myImg1('PKAgAqZWJVNwKsAJSmXd')} style={{ whiteSpace: 'nowrap' }}>Share To Twitter</Item>),
              (<Item key="6" value="l" icon={myImg2('uQIYTFeRrjPELImDRrPt')}>
                <span style={{ marginRight: 5 }}>Share To Link</span>
              </Item>),
            ]}
            align={{
              overflow: { adjustY: 0, adjustX: 0 },
              offset: [-10, 0],
            }}
            onVisibleChange={this.handleVisibleChange}
           onSelect={this.onSelect}
          >
            <div style={{
              height: '100%',
              padding: '0 15px',
              marginRight: '-15px',
              display: 'flex',
              alignItems: 'center'

            }}
            >
              <Icon type="ellipsis" />
            </div>
          </Popover>}
        >Terms and Conditions</NavBar>
      <form className="form">
        <List renderHeader={() => <b>Terms and Conditions</b>}>




          <Flex justify="between">
              <div style={{textAlign:'left',marginLeft:'5px'}}  >
                   < p   style={{verticalAlign:'baseline' }}><span
style={{fontSize:'11px',fontFamily:'Muli-Regular',color:'#004B89' }}>Privacy
Policy</span></p>

<p   style={{textIndent:'18px',lineHeight:'18px',
verticalAlign:'baseline' }}><span   style={{fontSize:'11px',fontFamily:
'Muli-Bold',color:'#333333' }}>1.<span >&nbsp;&nbsp;
</span></span><span   style={{ fontSize:'11px',fontFamily:'Muli-Bold',
color:'#333333'  }}>Our Commitment</span></p>

<p><span   style={{fontSize:'11px',fontFamily:'Muli-Regular',
color:'#333333' }}>We, </span><span   style={{fontSize:'11px',fontFamily:
'CIDFont' }}>&nbsp;iTEA Premium Bubble Tea&nbsp;</span><span
style={{fontSize:'11px',fontFamily:'Muli-Regular',color:'#333333' }} > are
committed to protecting your personal information in accordance with the
Personal Data Protection Act 2012&nbsp;(“PDPA 2012”). This Privacy
Policy explains how we use, disclose, and protect the personal information we
collect. By providing us with your personal data, you consent to our
collection, use, disclosure (including transfer) and processing of your
personal data in accordance with this Privacy Policy. Please DO NOT provide any
personal data to us if you do not accepx this Privacy Policy.&nbsp;</span></p>

<p   style={{lineHeight:'18px',verticalAlign:'baseline' }}><span
  style={{fontSize:'11px',fontFamily:'Muli-Regular',color:'#333333' }}>We
respect the confidentiality of your personal information and will make
reasonable security arrangements to ensure that all personal information in our
possession or control is kept in a safe and secure manner, and to prevent
unauthorized access and use of your personal information.</span></p>

<p ><span
>&nbsp;</span></p>

<p  style={{textIndent:'18px',lineHeight:'18px',
verticalAlign:'baseline' }} ><span  style={{fontSize:'11px',fontFamily:
'Muli-Bold',color:'#333333' }} >2.<span >&nbsp;&nbsp;
</span></span><span   style={{fontSize:'11px',fontFamily:'Muli-Bold',
color:'#333333' }} >Types Of Information Collected</span></p>

<p   style={{lineHeight:'18px',verticalAlign:'baseline' }} ><span
  style={{fontSize:'11px',fontFamily:'Muli-Regular',color:'#333333' }} >We
collect information when you:</span></p>

<p    style={{lineHeight:'18px',verticalAlign:'baseline' }} ><span
  style={{ fontSize:'11px',fontFamily:'Muli-Regular',color:'#333333' }} >a.
use our services;</span></p>

<p    style={{lineHeight:'18px',verticalAlign:'baseline' }} ><span
  style={{ fontSize:'11px',fontFamily:'Muli-Regular',color:'#333333' }}>b.
browse our website;</span></p>

<p   style={{lineHeight:'18px',verticalAlign:'baseline' }} ><span
  style={{ fontSize:'11px',fontFamily:'Muli-Regular',color:'#333333' }}>c.
engage with us through social media;</span></p>

<p   style={{lineHeight:'18px',verticalAlign:'baseline' }}><span
  style={{ fontSize:'11px',fontFamily:'Muli-Regular',color:'#333333' }}>d.
access our website through a mobile device; or</span></p>

<p   style={{lineHeight:'18px',verticalAlign:'baseline' }}><span
  style={{ fontSize:'11px',fontFamily:'Muli-Regular',color:'#333333' }}>e.
use our mobile applications.</span></p>

<p   style={{lineHeight:'18px',verticalAlign:'baseline' }}><span
  style={{ fontSize:'11px',fontFamily:'Muli-Regular',color:'#333333' }}>The
types of personal information we collect are those which you provide to us,
such as your name, contact details. We automatically collect information sent
by your computer when you browse our website, or sent by your mobile device
when you use our website and mobile applications. This information is collected
for analysis and evaluation in order for us to improve our website, our mobile
applications, and the products and services which we provide. This information
will not be used in association with your personal information.</span></p>

<p   style={{lineHeight:'18px',verticalAlign:'baseline' }}><span
  style={{ fontSize:'11px',fontFamily:'Muli-Regular',color:'#333333' }}>&nbsp;</span></p>

<p   style={{textIndent:'18px',lineHeight:'18px',
verticalAlign:'baseline'}}><span   style={{ fontSize:'11px',fontFamily:'Muli-Regular',color:'#333333' }}>3.<span >&nbsp;&nbsp;
</span></span><span   style={{ fontSize:'11px',fontFamily:'Muli-Regular',color:'#333333' }}>Purposes for Collection, Use and Disclosure</span></p>

<p   style={{lineHeight:'18px',verticalAlign:'baseline' }}><span
  style={{ fontSize:'11px',fontFamily:'Muli-Regular',color:'#333333' }}>Personal
information which you provide to us may be used, disclosed, and/or processed by
us, and our related or affiliated co-operatives and organisations for the
purposes of facilitating your transactions with us, and to keep you informed of
updates, changes, and developments relating to us, the scope of which may
include but is not limited to:</span></p>

<p   style={{lineHeight:'18px',verticalAlign:'baseline' }}><span
  style={{ fontSize:'11px',fontFamily:'Muli-Regular',color:'#333333' }}>a.
administering and maintaining your account with us;</span></p>

<p   style={{lineHeight:'18px',verticalAlign:'baseline' }}><span
  style={{ fontSize:'11px',fontFamily:'Muli-Regular',color:'#333333' }}>b.
processing and fulfilling your order for goods and services purchased from us
and out partners.</span></p>

<p   style={{lineHeight:'18px',verticalAlign:'baseline' }}><span
  style={{ fontSize:'11px',fontFamily:'Muli-Regular',color:'#333333' }}>c.
verifying and processing payment and/or credit control when you purchase goods
and services from us and partners.</span></p>

<p   style={{lineHeight:'18px',verticalAlign:'baseline' }}><span
  style={{ fontSize:'11px',fontFamily:'Muli-Regular',color:'#333333' }}>f.
customer profiling, market analysis, and research to improve our product and
service offerings to you;</span></p>

<p   style={{lineHeight:'18px',verticalAlign:'baseline' }}><span
  style={{ fontSize:'11px',fontFamily:'Muli-Regular',color:'#333333' }}>g.
communicating with you on matters relating to your account with us, including
administering any membership benefits and entitlements;</span></p>

<p   style={{lineHeight:'18px',verticalAlign:'baseline' }}><span
  style={{ fontSize:'11px',fontFamily:'Muli-Regular',color:'#333333' }}>h.
notifying you about important changes to this Privacy Policy, and to our
policies or services which may affect you;</span></p>

<p   style={{lineHeight:'18px',verticalAlign:'baseline' }}><span
  style={{ fontSize:'11px',fontFamily:'Muli-Regular',color:'#333333' }}>i.
responding to queries or feedback from you;</span></p>

<p   style={{lineHeight:'18px',verticalAlign:'baseline' }}><span
  style={{ fontSize:'11px',fontFamily:'Muli-Regular',color:'#333333' }}>j.
enforcing our legal rights and remedies; </span></p>

<p   style={{lineHeight:'18px',verticalAlign:'baseline' }}><span
  style={{ fontSize:'11px',fontFamily:'Muli-Regular',color:'#333333' }}>k.
for such other purposes as permitted by applicable law or with your consent.</span></p>

<p   style={{lineHeight:'18px',verticalAlign:'baseline' }}><span
  style={{ fontSize:'11px',fontFamily:'Muli-Regular',color:'#333333' }}>&nbsp;</span></p>

<p   style={{lineHeight:'18px',verticalAlign:'baseline' }}><span
  style={{ fontSize:'11px',fontFamily:'Muli-Regular',color:'#333333' }}>In
compliance with the PDPA 2012, we will not send marketing messages to Singapore
telephone numbers or Singapore facsimile numbers belonging to you unless you
have given us clear and unambiguous consent to do so. If you have previously
given us consent, we will continue to send you marketing messages until you
advise us in writing that you wish to withdraw the consent.</span></p>

<p   style={{lineHeight:'18px',verticalAlign:'baseline' }}><span
  style={{ fontSize:'11px',fontFamily:'Muli-Regular',color:'#333333' }}>&nbsp;</span></p>

<p   style={{textIndent:'18px',lineHeight:'18px',
verticalAlign:'baseline'}}><span   style={{ fontSize:'11px',fontFamily:'Muli-Regular',color:'#333333' }}>4.<span >&nbsp;&nbsp;
</span></span><span   style={{ fontSize:'11px',fontFamily:'Muli-Regular',color:'#333333' }}>How Do We Use Your Data?</span></p>

<p   style={{lineHeight:'18px',verticalAlign:'baseline' }}><span
  style={{ fontSize:'11px',fontFamily:'Muli-Regular',color:'#333333' }}>If
you have consented, we may use your personal data from time to time for
marketing and promotional purposes:</span></p>

<p   style={{lineHeight:'18px',verticalAlign:'baseline' }}><span
  style={{ fontSize:'11px',fontFamily:'Muli-Regular',color:'#333333' }}>Administration
of contests, competitions and marketing campaigns in connection with the
products and services offered by us.</span></p>

<p   style={{lineHeight:'18px',verticalAlign:'baseline' }}><span
  style={{ fontSize:'11px',fontFamily:'Muli-Regular',color:'#333333' }}>Communication
of advertisements involving details of the products, services, special offers
and rewards offered by us (including but not limited to upselling, cross
selling and online marketing).</span></p>

<p   style={{lineHeight:'18px',verticalAlign:'baseline' }}><span
  style={{ fontSize:'11px',fontFamily:'Muli-Regular',color:'#333333' }}>Customisation
of your online experience according to your chosen interests and preferences
and enhance your current and future visits to the website and use of the iTEA
App and other platform of iTEA.</span></p>

<p   style={{lineHeight:'18px',verticalAlign:'baseline' }}><span
  style={{ fontSize:'11px',fontFamily:'Muli-Regular',color:'#333333' }}>For
the purpose of market research and statistical analysis.</span></p>

<p   style={{lineHeight:'18px',verticalAlign:'baseline' }}><span
  style={{ fontSize:'11px',fontFamily:'Muli-Regular',color:'#333333' }}>Inform
you of promotions, offers, surveys, events, products and services, which may be
of interest to you from iTEA.</span></p>

<p   style={{lineHeight:'18px',verticalAlign:'baseline' }}><span
  style={{ fontSize:'11px',fontFamily:'Muli-Regular',color:'#333333' }}>Matching
of Personal Data with other data collected for other purposes and from other
sources platform in connection with the provision, marketing or offering of
products and services (including promotions, loyalty and reward programmes) us.</span></p>

<p   style={{lineHeight:'18px',verticalAlign:'baseline' }}><span
  style={{ fontSize:'11px',fontFamily:'Muli-Regular',color:'#333333' }}>Notify
and invite you to events and activities organised by iTEA.</span></p>

<p   style={{lineHeight:'18px',verticalAlign:'baseline' }}><span
  style={{ fontSize:'11px',fontFamily:'Muli-Regular',color:'#333333' }}>Process
your registration to participate in or attend an event or activity and to
communicate with you regarding your attendance at the event or activity.</span></p>

<p   style={{lineHeight:'18px',verticalAlign:'baseline' }}><span
  style={{ fontSize:'11px',fontFamily:'Muli-Regular',color:'#333333' }}>Send
you alerts, newsletters, updates, mailers, promotional materials, special
privileges and festive greetings from iTEA.</span></p>

<p   style={{lineHeight:'18px',verticalAlign:'baseline' }}><span
  style={{ fontSize:'11px',fontFamily:'Muli-Regular',color:'#333333' }}>&nbsp;</span></p>

<p   style={{textIndent:'18px',lineHeight:'18px',
verticalAlign:'baseline'}}><span   style={{ fontSize:'11px',fontFamily:'Muli-Regular',color:'#333333' }}>5.<span >&nbsp;&nbsp;
</span></span><span   style={{ fontSize:'11px',fontFamily:'Muli-Regular',color:'#333333' }}>Who Do We Disclose Your Data To?</span></p>

<p   style={{lineHeight:'18px',verticalAlign:'baseline' }}><span
  style={{ fontSize:'11px',fontFamily:'Muli-Regular',color:'#333333' }}>Credit
card and payment processing companies</span></p>

<p   style={{lineHeight:'18px',verticalAlign:'baseline' }}><span
  style={{ fontSize:'11px',fontFamily:'Muli-Regular',color:'#333333' }}>&nbsp;</span></p>

<p   style={{textIndent:'18px',lineHeight:'18px',
verticalAlign:'baseline'}}><span   style={{ fontSize:'11px',fontFamily:'Muli-Regular',color:'#333333' }}>6.<span >&nbsp;&nbsp;
</span></span><span   style={{ fontSize:'11px',fontFamily:'Muli-Regular',color:'#333333' }}>Access and Correction of Personal Information</span></p>

<p   style={{lineHeight:'18px',verticalAlign:'baseline' }}><span
  style={{ fontSize:'11px',fontFamily:'Muli-Regular',color:'#333333' }}>If
you have an account with us, you may access or correct your personal
information at any time by accessing your account on our website.</span></p>

<p   style={{lineHeight:'18px',verticalAlign:'baseline' }}><span
  >&nbsp;</span></p>

<p   style={{textIndent:'18px',lineHeight:'18px',
verticalAlign:'baseline'}}><span   style={{ fontSize:'11px',fontFamily:'Muli-Regular',color:'#333333' }}>7.<span >&nbsp;&nbsp;
</span></span><span   style={{ fontSize:'11px',fontFamily:'Muli-Regular',color:'#333333' }}>Updates to this Privacy Policy</span></p>

<p   style={{lineHeight:'18px',verticalAlign:'baseline' }}><span
  style={{ fontSize:'11px',fontFamily:'Muli-Regular',color:'#333333' }}>We
reserve the right to revise this Privacy Policy from time to time. The most
current version of the Privacy Policy will govern our collection, use, and
disclosure of your personal information. In the event of any changes to this
Privacy Policy, we will post those changes here. You are encouraged to visit
this Privacy Policy regularly.</span></p>

<p   style={{lineHeight:'18px',verticalAlign:'baseline' }}><span
  style={{ fontSize:'11px',fontFamily:'Muli-Regular',color:'#333333' }}>&nbsp;</span></p>

<p   style={{lineHeight:'18px',verticalAlign:'baseline' }}><span
  style={{ fontSize:'11px',fontFamily:'Muli-Regular',color:'#333333' }}>Last
Updated on 29th March 2019</span></p>

<p  ><span   style={{fontSize:'11px'}}>&nbsp;</span></p>
              </div>
          </Flex>
          <WhiteSpace size="xl" />
            <Flex justify="center"  > <div  style={{align:'center'}} >   <div  onClick={() => this.props.history.goBack()}  style={{ textAlign:'center',border:'1px solid #108ee9',padding:'8px 12px',background:'#108ee9',width:'40px',height:'12px',borderRadius:'25px',color:'#fff',marginRight:'10px'   }}   >BACK&nbsp;&nbsp;&nbsp;</div></div></Flex>
            <br />
        </List>
      </form>


      <br/><br/><br/>

        <Flex justify="center"> <div style={{align:'center',textAlign:'center',fontSize:'10px',color:'gray'}} ><table  ><tr><td>Copyright © 2019  iTea Premium Bubble Tea Singapore</td><td>  </td><td>  </td></tr>

        <tr><td colSpan="3"> </td></tr>
       </table></div></Flex>
      </div>
    )
  }
} 

export default createForm()(Agree) ;
