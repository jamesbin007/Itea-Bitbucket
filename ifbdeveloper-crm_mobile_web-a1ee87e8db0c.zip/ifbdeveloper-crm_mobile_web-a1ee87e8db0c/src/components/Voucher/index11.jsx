import React from 'react';
import {
  Tabs, List, WhiteSpace, WingBlank, InputItem, Button, NavBar, Icon, Modal, Toast
} from 'antd-mobile';
import Cookies from 'js-cookie';
import { Dialog, } from 'zent';
import 'zent/css/index.css';
import { Login } from '../Login'
import { reqmobileinvicode, reqInvicodeRegister, requnivoucher, reqoutletvoucher } from '../../api/requrl';
import { QRCode } from 'react-qrcode-logo';
import cobra_logo from '../../assets/img/logo.png'
const { openDialog, closeDialog } = Dialog;
const Item = List.Item;
const Brief = Item.Brief;

function open(code, voucher, outlet) {
  if(outlet.length>0)
  {
     openDialog({
    dialogId: 'my_dialog', // id is used to close the dialog
    title: voucher,
    hasMore: 0,
    maskClosable: true,
    children: <QRCode size={200} value={code} logoImage={cobra_logo} logoWidth={64} logoHeight={27} ecLevel={'H'} />,
    footer: <p align="center">{'Outlets: ' + outlet}</p>,
    style: { 'textAlign': 'center', 'width': '250px'},
    onClose() {
      console.log('outer dialog closed');
    },
  });
  }

  else {
     openDialog({
    dialogId: 'my_dialog', // id is used to close the dialog
    title: voucher,
    hasMore: 0,
    maskClosable: true,
    children: <QRCode size={200} value={code} logoImage={cobra_logo} logoWidth={64} logoHeight={27} ecLevel={'H'} />,
    style: { 'textAlign': 'center', 'width': '250px'},
    onClose() {
      console.log('outer dialog closed');
    },
  });
  }
};

function open_outletless(code, voucher) {
  openDialog({
    dialogId: 'my_dialog', // id is used to close the dialog
    title: voucher,
    hasMore: 0,
    maskClosable: true,
    children: <QRCode size={200} value={code} logoImage={cobra_logo} logoWidth={64} logoHeight={27} ecLevel={'H'} />,
    footer: <p align="center">{' '}</p>,
    style: { 'textAlign': 'center', 'width': '250px'},
    onClose() {
      console.log('outer dialog closed');
    },
  });
};

export default class Demo extends React.Component {
  state = {
    visible: false,
    confirmLoading: false,
    invicode: [],
    outlets: [],
    membership: [],
    voucherdata: [],
    topping: [],
    initializing: 1,
    invicode_send:'',
    hasMore: 0,
    redeem_date:''
  }

  // componentDidMount() {
  //   this.changeTitle('User');
  // }


  handleSendInvicode = async () => {


    let { invicode_send } = this.state
    if (invicode_send.trim()==="")
    {
        alert('please enter code!');
        return false;
    }





    const Token = 'Token ' + Cookies.get('Authorization')
    const user = {
      username,
      invicode_send
    }
    user.username = Cookies.get('user')

    if (user.username){
    reqInvicodeRegister(user, Token).then(res => {
     let username = user.username
      //this.setState({stateinvicode:user.invicode_send})
      let stateinvicode = user.invicode_send
      let msg = res.data.msg

      if (msg=="success")
      {
           Toast.success(res.data.msg, 1);
      }
      else {
        //Toast.fail('Invicode is invaild!', 1)
        alert(res.data.msg);
        return  false;

      }





      //this.props.history.goBack();
    }).catch(err => {




      /*
      else{
        Toast.success('Success!', 1);
        this.props.history.goBack();
      }
      */
      this.setState({
        message: 'Unknown Error'
      })
      })


  }else{
    this.props.history.push('/login')
  }
}

  async componentWillMount() {
    let { invicode, voucherdata } = this.state
    this.setState({
      hasMore: 1,
      initializing: 2, // initialized
    });
    const Token = 'Token ' + Cookies.get('Authorization')
    let req = await reqmobileinvicode({ 'user': Cookies.get('user') }, Token)
    //let req2 = await requnivoucher({'page_size': 999}, Token)
    //let req2 = await requnivoucher({'user': Cookies.get('user'),'page_size': 999}, Token)
    //voucherdata.push(req2.data.results)
    //alert(req2.data.results)
    invicode = req.data.vouchers
    let outlet_list=req.data.outlet
    if (outlet_list&& outlet_list.length > 0)
    {
      for (let j = 0; j < outlet_list.length; j++) {

            switch (outlet_list[j][2])
            {
              case 7:
              outlet_list[j].push('201')
              break;
              case 8:
              outlet_list[j].push('828')
              break;
              case 9:
              outlet_list[j].push('OTH')
              break;
              case 10:
              outlet_list[j].push('EM')
              break;
              case 11:
              outlet_list[j].push('BK')
              break;
              case 12:
              outlet_list[j].push('Nex')
              break;
              case 13:
              outlet_list[j].push('PLS')
              break;
              case 14:
              outlet_list[j].push('TP')
              break;
              case 15:
              outlet_list[j].push('CL')
              break;
              case 16:
              outlet_list[j].push('504')
              break;
              case 17:
              outlet_list[j].push('372')
              break;
              case 18:
              outlet_list[j].push('YS')
              break;
              case 19:
              outlet_list[j].push('888')
              break;
              default:
               outlet_list[j].push('')
                break;
            }



      }
    }

    //alert(invicode)
    //return false
    //alert(outlet_list)
   // return false;
    if (invicode && invicode.length > 0){
      for(let i=0;i<invicode.length;i++){
       // const req3 = await reqoutletvoucher({'code':invicode[i][6]}, Token)
       // const outlet = req3.data.outlet
                for (let k=0;k<outlet_list.length;k++)
                {
                    if (invicode[i][0]==outlet_list[k][1])
                    {
                          invicode[i].push(outlet_list[k][3])

                    }


                }
                if(invicode[i].length===8) {
                  invicode[i].push('')
                }

           }
    }
        /*
        voucherdata[0].map( j=>{
          if (invicode[i][3] == j.id){
            invicode[i][3] = j.name
            invicode[i].push(j.effective_date)
            invicode[i].push(j.expiring_date)
            invicode[i].push(outlet_r)
          }
        })
        */

      this.setState({ invicode: invicode})
     //alert(invicode);

   // this.setState({voucherdata})
  //  this.setState({ invicode })
  }
  

  async loadInvicode() {
      let { invicode, voucherdata } = this.state
    this.setState({
      hasMore: 1,
      initializing: 2, // initialized
    });
    const Token = 'Token ' + Cookies.get('Authorization')
    let req = await reqmobileinvicode({ 'user': Cookies.get('user') }, Token)
    //let req2 = await requnivoucher({'page_size': 999}, Token)
    //let req2 = await requnivoucher({'user': Cookies.get('user'),'page_size': 999}, Token)
    //voucherdata.push(req2.data.results)
    //alert(req2.data.results)
    invicode = req.data.vouchers
    let outlet_list=req.data.outlet
    if (outlet_list&& outlet_list.length > 0)
    {
      for (let j = 0; j < outlet_list.length; j++) {

            switch (outlet_list[j][2])
            {
              case 7:
              outlet_list[j].push('201')
              break;
              case 8:
              outlet_list[j].push('828')
              break;
              case 9:
              outlet_list[j].push('OTH')
              break;
              case 10:
              outlet_list[j].push('EM')
              break;
              case 11:
              outlet_list[j].push('BK')
              break;
              case 12:
              outlet_list[j].push('Nex')
              break;
              case 13:
              outlet_list[j].push('PLS')
              break;
              case 14:
              outlet_list[j].push('TP')
              break;
              case 15:
              outlet_list[j].push('CL')
              break;
              case 16:
              outlet_list[j].push('504')
              break;
              case 17:
              outlet_list[j].push('372')
              break;
              case 18:
              outlet_list[j].push('YS')
              break;
              case 19:
              outlet_list[j].push('888')
              break;
              default:
               outlet_list[j].push('')
                break;
            }



      }
    }

    //alert(invicode)
    //return false
    //alert(outlet_list)
   // return false;
    if (invicode && invicode.length > 0){
      for(let i=0;i<invicode.length;i++){
       // const req3 = await reqoutletvoucher({'code':invicode[i][6]}, Token)
       // const outlet = req3.data.outlet
                for (let k=0;k<outlet_list.length;k++)
                {
                    if (invicode[i][0]==outlet_list[k][1])
                    {
                          invicode[i].push(outlet_list[k][3])

                    }


                }
                if(invicode[i].length()===8) {
                  invicode[i].push('')
                }

           }
    }
        /*
        voucherdata[0].map( j=>{
          if (invicode[i][3] == j.id){
            invicode[i][3] = j.name
            invicode[i].push(j.effective_date)
            invicode[i].push(j.expiring_date)
            invicode[i].push(outlet_r)
          }
        })
        */

      this.setState({ invicode: invicode})
    //alert(invicode)
   // this.setState({voucherdata})
   // this.setState({ invicode })
  }

  render() {
    let { invicode, invicode_send, voucherdata,redeem_date } = this.state
    var now = new Date();
    return (
      Cookies.get('isLogin') ? (
      <div>
        <NavBar
          mode="light"
          icon={<Icon type="left" />}
          onLeftClick={() => this.props.history.goBack()}
          rightContent={[
            <Icon key="1" type="ellipsis" />,
          ]}
        >Voucher</NavBar>
          
        <Tabs tabs={[{ title: 'VOUCHERS' }, { title: 'REDEEMED' }, { title: 'INVICODE' }]}
          renderTab={tab => tab.title}
          onTabClick={ (tab => this.loadInvicode()) }
        >
          <div style={{ alignItems: 'center', justifyContent: 'center', backgroundColor: '#fff' }}>
            {

              invicode.map((item => {
                //数字除了let red_time=item[9]，其他的超过9的都加2
                if (item[6] != 2) {
                 // alert (invicode)
                  var dateFormat = require('dateformat');
                  var start_time,cur_time,stop_time,end_time,stDate;
                  if (item[2]) {
                    start_time = new Date(item[2]);
                    cur_time = dateFormat(start_time, "dd/mm/yyyy")
                  }
                  if (item[3]) {
                    stop_time = new Date(item[3]);
                    stDate=new Date(Date.parse(item[3]))
                    end_time = dateFormat(stop_time, "dd/mm/yyyy")
                  }
                  let red_time=item[5]
                 //alert(stDate> new Date() )
                 if (stDate> new Date()) {
                    if (item[7] != '')
                    {
                      return (
                        <div>
                        <List renderHeader=' ' className="invicode-list">
                          <Item multipleLine extra='Voucher' onClick={open.bind(this, item[7], item[1], item[8])} style={{ backgroundColor: '#33FF33' }}>
                          {item[1]}<Brief>{cur_time+' ~ '+end_time}</Brief>
                          </Item>
                        </List>
                        </div>
                      )
                    }else{
                      return(
                        <div>
                        <List renderHeader=' ' className="invicode-list">
                          <Item multipleLine extra='Voucher' onClick={open_outletless.bind(this, item[8], item[1])} style={{ backgroundColor: '#33FF33' }}>
                          {item[1]} <Brief>{cur_time+' ~ '+end_time}</Brief>
                          </Item>
                        </List>
                        </div>
                        )    
                    }
                 }
              }
              }))
            }
          </div>
          <div style={{ alignItems: 'center', justifyContent: 'center', backgroundColor: '#fff' }}>
            {
              invicode.map((item => {
                if (item[6] == 2) {
                 var dateFormat = require('dateformat');
                  var start_time,cur_time,stop_time,end_time,stDate;
                  if (item[2]) {
                    start_time = new Date(item[2]);
                    cur_time = dateFormat(start_time, "dd/mm/yyyy")
                  }
                  if (item[3]) {
                    stop_time = new Date(item[3]);
                    stDate=new Date(Date.parse(item[3]))
                    end_time = dateFormat(stop_time, "dd/mm/yyyy")
                  }
                  let red_time=item[5]
                  return (
                    <List renderHeader=' ' className="invicode-list">
                      <Item multipleLine extra={ <div>redeemed<br/> {item[5]}</div>

                        } style={{ backgroundColor: '#C0C0C0' }}>
                        {item[1]} <Brief>{cur_time+' ~ '+end_time}</Brief>
                      </Item>
                    </List>
                  )
                }
              }))
            }
          </div>
          <div style={{ alignItems: 'center', justifyContent: 'center', backgroundColor: '#fff' }}>
            <WingBlank><InputItem maxLength={16} placeholder="Invitation Code" onChange={(v) => this.setState({ 'invicode_send': v })} required /></WingBlank>
            <WhiteSpace size="lg" />
            <WingBlank><Button className="Register" type='primary' onClick={this.handleSendInvicode}>Add Invicode or abbreviation</Button></WingBlank>
            <WhiteSpace size="xl" />
          </div>
        </Tabs>
      </div>) : this.props.history.push("/login") );
  }
}
