import React from 'react';
import {
 Result, Tabs, List, WhiteSpace, WingBlank, InputItem, Button, NavBar, Icon, Modal, Toast,ListView, Badge
} from 'antd-mobile';
import Cookies from 'js-cookie';
import { Dialog, } from 'zent';
import 'zent/css/index.css';
import { Login } from '../Login'
import { reqmobileinvicode, reqInvicodeRegister, requnivoucher, reqoutletvoucher } from '../../api/requrl';
import { QRCode } from 'react-qrcode-logo';
import cobra_logo from '../../assets/img/logo.png'
import back_logo from '../../assets/img/webwxgetmsgimg.jpg'
import attention_logo from '../../assets/img/attention.jpg'
import wait_logo from '../../assets/img/wait.jpg'
import mem_logo from "../../assets/img/mem.jpg";
import list_logo from "../../assets/img/Slide1.png";
import v_logo from "../../assets/img/b.png";
import r_logo from "../../assets/img/redeem.jpg";
import rd_logo from "../../assets/img/define.png";
import facebook_logo from '../../assets/img/facebook.jpg'
import twitter_logo from '../../assets/img/twitter.jpg'
import link_logo from '../../assets/img/link.jpg'
import { Popover } from 'antd-mobile';
const Item = Popover.Item;
const myImg0 = src => <img src={facebook_logo} className="am-icon am-icon-xs" alt="" />;
const myImg1 = src => <img src={twitter_logo} className="am-icon am-icon-xs" alt="" />;
const myImg2 = src => <img src={link_logo} className="am-icon am-icon-xs" alt="" />;
const { openDialog, closeDialog } = Dialog;
const Item1 = List.Item;
const Brief = Item1.Brief;
const myImg = src => <img src={src} style={{ width:'100%',height:'100%'  }} alt="" />;




function open(code, voucher, outlet) {
  if(outlet.length>0)
  {
     openDialog({
    dialogId: 'my_dialog', // id is used to close the dialog
       DataCollect:'',
    title: voucher,
    hasMore: 0,
    maskClosable: true,
    children: <QRCode size={200} value={code} logoImage={cobra_logo} logoWidth={64} logoHeight={27} ecLevel={'H'} />,
    footer: <p align="center">{'Outlets: ' + outlet}</p>,
    style: { 'textAlign': 'center', 'width': '250px','padding': '10px 35px 10px 10px'},
    onClose() {
      window.location.href='/voucher';
      console.log('outer dialog closed');
    },
  });
  }

  else {
     openDialog({
    dialogId: 'my_dialog', // id is used to close the dialog
    title: voucher,
    hasMore: 0,
    maskClosable: true,
    children: <QRCode size={200} value={code} logoImage={cobra_logo} logoWidth={64} logoHeight={27} ecLevel={'H'} />,
    footer: <p align="center">{'All Outlets'}</p>,
    style: { 'textAlign': 'center', 'width': '250px','padding': '10px 35px 10px 10px'},
    onClose() {
      window.location.href='/voucher';
      console.log('outer dialog closed');
    },
  });
  }
};

function open_outletless(code, voucher) {
  openDialog({
    dialogId: 'my_dialog', // id is used to close the dialog
    title: voucher,
    hasMore: 0,
    maskClosable: true,
    children: <QRCode size={200} value={code} logoImage={cobra_logo} logoWidth={64} logoHeight={27} ecLevel={'H'} />,
    footer: <p align="center">{' '}</p>,
    style: { 'textAlign': 'center', 'width': '250px','padding': '10px 35px 10px 10px'},
    onClose() {
       window.location.href='/voucher';
      console.log('outer dialog closed');
    },
  });
};

export default class Demo extends React.Component {

    constructor(props) {
    super(props);
    const dataSource = new ListView.DataSource({
      rowHasChanged: (row1, row2) => row1 !== row2,
    });

    this.state = {
      dataSource,
      isLoading: true,
        visible: false,
    confirmLoading: false,
    invicode: [],
    outlets: [],
    membership: [],
    voucherdata: [],
    topping: [],
    initializing: 1,
    invicode_send:'',
    hasMore: 0,
    redeem_date:'',
    showVoucherImg:'none',
    showRedemImg:'none',
    visiblePop: false,
    selected: '',
    };
  }

onSelect = (opt) => {
    console.log(opt.props.value);
    this.setState({
      visiblePop: false,
      selected: opt.props.value,
    });

  };
  handleVisibleChange = (visiblePop) => {
    this.setState({
      visiblePop,
    });
  };




  handleSendInvicode = async () => {


    let { invicode_send } = this.state
    if (invicode_send.trim()==="")
    {
        alert('please enter code!');
        return false;
    }





    const Token = 'Token ' + Cookies.get('Authorization')
    const user = {
      username,
      invicode_send
    }
    user.username = Cookies.get('user')

    if (user.username){
    reqInvicodeRegister(user, Token).then(res => {
     let username = user.username
      //this.setState({stateinvicode:user.invicode_send})
      let stateinvicode = user.invicode_send
      let msg = res.data.msg

      if (msg=="success")
      {
           Toast.success(res.data.msg, 1);
           window.location.href='/voucher';

          // alert('ik');
           //return false;
      }
      else {
        //Toast.fail('Invicode is invaild!', 1)
        alert(res.data.msg);
        return  false;

      }





      //this.props.history.goBack();
    }).catch(err => {




      /*
      else{
        Toast.success('Success!', 1);
        this.props.history.goBack();
      }
      */
      this.setState({
        message: 'Unknown Error'
      })
      })


  }else{
    this.props.history.push('/login')
  }
}

  async componentWillMount() {
    let { invicode, voucherdata } = this.state
    this.setState({
      hasMore: 1,
      initializing: 2, // initialized
    });
    const Token = 'Token ' + Cookies.get('Authorization')
    let req = await reqmobileinvicode({ 'user': Cookies.get('user') }, Token)
    //let req2 = await requnivoucher({'page_size': 999}, Token)
    //let req2 = await requnivoucher({'user': Cookies.get('user'),'page_size': 999}, Token)
    //voucherdata.push(req2.data.results)
    //alert(req2.data.results)
    invicode = req.data.vouchers
    let outlet_list=req.data.outlet
      /*
    if (outlet_list&& outlet_list.length > 0)
    {
      for (let j = 0; j < outlet_list.length; j++) {

            switch (outlet_list[j][2])
            {
              case 7:
              outlet_list[j].push('201')
              break;
              case 8:
              outlet_list[j].push('828')
              break;
              case 9:
              outlet_list[j].push('OTH')
              break;
              case 10:
              outlet_list[j].push('EM')
              break;
              case 11:
              outlet_list[j].push('BK')
              break;
              case 12:
              outlet_list[j].push('Nex')
              break;
              case 13:
              outlet_list[j].push('PLS')
              break;
              case 14:
              outlet_list[j].push('TP')
              break;
              case 15:
              outlet_list[j].push('CL')
              break;
              case 16:
              outlet_list[j].push('504')
              break;
              case 17:
              outlet_list[j].push('372')
              break;
              case 18:
              outlet_list[j].push('YS')
              break;
              case 19:
              outlet_list[j].push('888')
              break;
              default:
               outlet_list[j].push('')
                break;
            }



      }
    }
*/
    //alert(invicode)
    //return false
    //alert(outlet_list)
   // return false;
    if (invicode && invicode.length > 0){
      for(let i=0;i<invicode.length;i++){
       // const req3 = await reqoutletvoucher({'code':invicode[i][6]}, Token)
       // const outlet = req3.data.outlet
                for (let k=0;k<outlet_list.length;k++)
                {
                    if (invicode[i][0]==outlet_list[k][1])
                    {
                          invicode[i].push(outlet_list[k][3])

                    }


                }
                if(invicode[i].length===8) {
                  invicode[i].push('')
                }

           }
    }
        /*
        voucherdata[0].map( j=>{
          if (invicode[i][3] == j.id){
            invicode[i][3] = j.name
            invicode[i].push(j.effective_date)
            invicode[i].push(j.expiring_date)
            invicode[i].push(outlet_r)
          }
        })
        */

      this.setState({ invicode: invicode})
     //alert(invicode);
      // console.log(invicode)

   // this.setState({voucherdata})
  //  this.setState({ invicode })
  }
  

  async loadInvicode(tab) {
      //console.log(tab.target.title+'dd')
      let { invicode, voucherdata } = this.state
    this.setState({
      hasMore: 1,
      initializing: 2, // initialized
    });
    const Token = 'Token ' + Cookies.get('Authorization')
    let req = await reqmobileinvicode({ 'user': Cookies.get('user') }, Token)
    //let req2 = await requnivoucher({'page_size': 999}, Token)
    //let req2 = await requnivoucher({'user': Cookies.get('user'),'page_size': 999}, Token)
    //voucherdata.push(req2.data.results)
    //alert(req2.data.results)
    invicode = req.data.vouchers
    let outlet_list=req.data.outlet
      /*
    if (outlet_list&& outlet_list.length > 0)
    {
      for (let j = 0; j < outlet_list.length; j++) {

            switch (outlet_list[j][2])
            {
              case 7:
              outlet_list[j].push('201')
              break;
              case 8:
              outlet_list[j].push('828')
              break;
              case 9:
              outlet_list[j].push('OTH')
              break;
              case 10:
              outlet_list[j].push('EM')
              break;
              case 11:
              outlet_list[j].push('BK')
              break;
              case 12:
              outlet_list[j].push('Nex')
              break;
              case 13:
              outlet_list[j].push('PLS')
              break;
              case 14:
              outlet_list[j].push('TP')
              break;
              case 15:
              outlet_list[j].push('CL')
              break;
              case 16:
              outlet_list[j].push('504')
              break;
              case 17:
              outlet_list[j].push('372')
              break;
              case 18:
              outlet_list[j].push('YS')
              break;
              case 19:
              outlet_list[j].push('888')
              break;
              default:
               outlet_list[j].push('')
                break;
            }



      }
    }
*/
    //alert(invicode)
    //return false
    //alert(outlet_list)
   // return false;
    if (invicode && invicode.length > 0){
      for(let i=0;i<invicode.length;i++){
       // const req3 = await reqoutletvoucher({'code':invicode[i][6]}, Token)
       // const outlet = req3.data.outlet
                for (let k=0;k<outlet_list.length;k++)
                {
                    if (invicode[i][0]==outlet_list[k][1])
                    {
                          invicode[i].push(outlet_list[k][3])

                    }


                }
                if(invicode[i].length===8) {
                  invicode[i].push('')
                }

           }
    }
        /*
        voucherdata[0].map( j=>{
          if (invicode[i][3] == j.id){
            invicode[i][3] = j.name
            invicode[i].push(j.effective_date)
            invicode[i].push(j.expiring_date)
            invicode[i].push(outlet_r)
          }
        })
        */

      this.setState({ invicode: invicode})

    //alert(invicode)
   // this.setState({voucherdata})
   // this.setState({ invicode })
  }

  onSelect = (opt) => {
    // console.log(opt.props.value);
    this.setState({
      visible: false,
      selected: opt.props.value,

    });
    if (opt.props.value==='f') {
       window.open('http://www.facebook.com/sharer.php?u=' + encodeURIComponent('https://member.itea.sg') + '&t=' + encodeURIComponent('Register send 1 Free Milk Tea Voucher'), '_blank', 'toolbar=yes, location=yes, directories=no, status=no, menubar=yes, scrollbars=yes, resizable=no, copyhistory=yes, width=600, height=450,top=100,left=350');
    }
     if (opt.props.value==='t') {
       window.open('http://twitter.com/home?status=' + encodeURIComponent('https://member.itea.sg') + ' ' + encodeURIComponent('Register send 1 Free Milk Tea Voucher'), '_blank', 'toolbar=yes, location=yes, directories=no, status=no, menubar=yes, scrollbars=yes, resizable=no, copyhistory=yes, width=600, height=450,top=100,left=350');
     }
    if (opt.props.value==='l') {
      window.open('http://www.linkedin.com/shareArticle?mini=true&url=' + encodeURIComponent('https://member.itea.sg') + '&title=' + encodeURIComponent('Register send 1 Free Milk Tea Voucher') + '&source=' + encodeURIComponent('https://member.itea.sg'), '_blank', 'toolbar=yes, location=yes, directories=no, status=no, menubar=yes, scrollbars=yes, resizable=no, copyhistory=yes, width=600, height=450,top=100,left=350');
    }

   // alert(opt.props.value)
  };
  handleVisibleChange = (visible) => {
    this.setState({
      visible,
    });
  };



    render() {
    let { invicode, invicode_send, voucherdata,redeem_date } = this.state
    var now = new Date();
    var showVoucherImg='block';
    var showRedemImg='block';
    let rowID=1





    return (
      Cookies.get('isLogin') ? (
      <div  style={{ backgroundImage:'../../assets/img/webwxgetmsgimg.jpg',color:'gray' }} >
          <div>
        <NavBar
          mode="light"
          icon={<Icon type="left" />}

          onLeftClick={() => this.props.history.goBack()}
          rightContent={<Popover mask
            overlayClassName="fortest"
            overlayStyle={{ color: 'currentColor' }}
            visible={this.state.visible}
            overlay={[
              (<Item key="4" value="f" icon={myImg0('tOtXhkIWzwotgGSeptou')} data-seed="logId">Share To Facebook
</Item>),
              (<Item key="5" value="t" icon={myImg1('PKAgAqZWJVNwKsAJSmXd')} style={{ whiteSpace: 'nowrap' }}>Share To Twitter</Item>),
              (<Item key="6" value="l" icon={myImg2('uQIYTFeRrjPELImDRrPt')}>
                <span style={{ marginRight: 5 }}>Share To Link</span>
              </Item>),
            ]}
            align={{
              overflow: { adjustY: 0, adjustX: 0 },
              offset: [-10, 0],
            }}
            onVisibleChange={this.handleVisibleChange}
            onSelect={this.onSelect}
          >
            <div style={{
              height: '100%',
              padding: '0 15px',
              marginRight: '-15px',
              display: 'flex',
              alignItems: 'center',
            }}
            >
              <Icon type="ellipsis" />
            </div>
          </Popover>



          }
        >Voucher</NavBar></div>

        <Tabs activekey={this.state.invicode} style={{color:'gray'}} tabs={[{ title: 'VOUCHERS' }, { title: 'REDEEMED' }, { title: 'PROMOTION' }]}
          renderTab={tab => tab.title}
          onTabClick={ (tab =>{  if (tab.title==='VOUCHERS') window.location.href='/voucher'; this.loadInvicode(tab);   }   ) }
        >
          <div style={{ alignItems: 'center', justifyContent: 'center', backgroundColor: '#f5f5f9' }}>
            {

              this.state.invicode.map((item => {
                //数字除了let red_time=item[9]，其他的超过9的都加2
                if (item[6] != 2) {
                 // alert (invicode)
                  showVoucherImg='none';

                  var dateFormat = require('dateformat');
                  var start_time,cur_time,stop_time,end_time,stDate;
                  if (item[2]) {
                    start_time = new Date(item[2]);
                    cur_time = dateFormat(start_time, "dd/mm/yyyy")
                  }
                  if (item[3]) {
                    stop_time = new Date(item[3]);
                    stDate=new Date(Date.parse(item[3]))
                    end_time = dateFormat(stop_time, "dd/mm/yyyy")
                  }
                  let red_time=item[5]
                    let titleItem=item[1]
                    if (titleItem.length>19) {
                        titleItem =titleItem.substring(0,19)+"..."

                    }

                // console.log(dateFormat(stDate, "yyyy-mm-dd") +'   ' + dateFormat(new Date(),"yyyy-mm-dd") )
                   // console.log(dateFormat(stDate, "yyyy-mm-dd")>=dateFormat(new Date(),"yyyy-mm-dd"))
                 if (dateFormat(stDate, "yyyy-mm-dd")>=dateFormat(new Date(),"yyyy-mm-dd")) {
                    if (item[7] != '')
                    {
                        console.log(item[7])

                      return (
                        <div style={{backgroundColor: '#f5f5f9'}}  >
                        <List renderHeader=' ' className="invicode-list" style={{backgroundColor: '#f5f5f9'}}  >




                         <div style={{ padding: ' 3px 6px',width:'100%',height:'100%' }}>




                            {/*   <div
                                style={{
                                  lineHeight: '35px',
                                  color: '#888',
                                  fontSize: 18,

                                }}
                              >{item[1]}</div>*/}



                                <div style={{ display: '-webkit-box', marginBottom: '5px',width:'100%',height:'100%',backgroundImage:`url(${list_logo})`,backgroundRrepeat:'no-repeat',backgroundSize: 'cover'  }}>

                        {/*  <div style={{ display: '-webkit-box', display: 'flex'  }}> */}
                                    <table style={{width:'100%'}}><tr>


                                        <td  style={{width:'80%'}}>

                                  <div   style={{ width:'100%' }} onClick={open.bind(this, item[7], item[1], item[8])}  >
                                      <table><tr><td  style={{textAlign:'center',verticalAlign: 'middle',paddingLeft:'5px'}}  >  <br/> <img src={v_logo} style={{width:'50px',height:'50px'}} /></td><td  >
                                      <div   >
                                      <br/>
                                <span  style={{ fontSize: '17px', color: '#e47435',textAlign:'right' }} >&nbsp; {titleItem}
                                  </span><br/>
                                      <span  style={{ fontSize: '15px', color: '#b7adae' }} >&nbsp;&nbsp;Outlet Voucher</span>
                                      <br />
                                  <span  style={{ fontSize: '10px', color: '#b7adae' }} >&nbsp;&nbsp;&nbsp;{cur_time+' ~ '+end_time}</span>
                                      </div></td></tr></table>

                                </div></td><td  style={{width:'20%'}} >



                                <div style={{ lineHeight: 1,width:'100%' }}>
                                    {/*<div style={{ marginBottom: '8px', fontWeight: 'bold' }}></div>*/}
                                    <div style={{ fontSize: '12px',textAlign:'center' }}><br/>
                                        <br/>   <div  onClick={open.bind(this, item[7], item[1], item[8])}  style={{ textAlign:'right',border:'1px solid #f85e08',padding:'8px 12px',background:'#f85e08',width:'70px',height:'30px',borderRadius:'25px',color:'#fff',marginRight:'10px'   }}   >REDEEM&nbsp;&nbsp;&nbsp;</div>

      </div>
                                </div></td></tr></table>



                                 </div>



                            </div>







                        </List>
                        </div>
                      )
                    }else{
                      return(


                        <div style={{backgroundColor: '#f5f5f9'}}  >
                        <List renderHeader=' ' className="invicode-list" style={{backgroundColor: '#f5f5f9'}}  >




                         <div style={{ padding: ' 3px 6px',width:'100%',height:'100%' }}>




                            {/*   <div
                                style={{
                                  lineHeight: '35px',
                                  color: '#888',
                                  fontSize: 18,

                                }}
                              >{item[1]}</div>*/}



                                <div style={{ display: '-webkit-box', marginBottom: '5px',width:'100%',height:'100%',backgroundImage:`url(${list_logo})`,backgroundRrepeat:'no-repeat',backgroundSize: 'cover'  }}>

                        {/*  <div style={{ display: '-webkit-box', display: 'flex'  }}> */}
                                    <table style={{width:'100%'}}><tr>


                                        <td  style={{width:'80%'}}>

                                  <div   style={{ width:'100%' }} onClick={open_outletless.bind(this, item[8], item[1])}  >
                                      <table><tr><td  style={{textAlign:'center',verticalAlign: 'middle',paddingLeft:'5px'}}  >  <br/> <img src={v_logo} style={{width:'50px',height:'50px'}} /></td><td  >
                                      <div   >
                                      <br/>
                                <span  style={{ fontSize: '17px', color: '#e47435',textAlign:'right' }} >&nbsp; {titleItem}
                                  </span><br/>
                                      <span  style={{ fontSize: '15px', color: '#b7adae' }} >&nbsp;&nbsp;Outlet Voucher</span>
                                      <br />
                                  <span  style={{ fontSize: '10px', color: '#b7adae' }} >&nbsp;&nbsp;&nbsp;{cur_time+' ~ '+end_time}</span>
                                      </div></td></tr></table>

                                </div></td><td  style={{width:'20%'}} >



                                <div style={{ lineHeight: 1,width:'100%' }}>
                                    {/*<div style={{ marginBottom: '8px', fontWeight: 'bold' }}></div>*/}
                                    <div style={{ fontSize: '12px',textAlign:'center' }}><br/>
                                        <br/>   <div  onClick={open_outletless.bind(this, item[8], item[1])}  style={{ textAlign:'right',border:'1px solid #f85e08',padding:'8px 12px',background:'#f85e08',width:'70px',height:'30px',borderRadius:'25px',color:'#fff',marginRight:'10px'   }}   >REDEEM&nbsp;&nbsp;&nbsp;</div>

      </div>
                                </div></td></tr></table>



                                 </div>



                            </div>







                        </List>
                        </div>





                        )
                    }
                 }
              }
              }))




            }




<div  style={{display:showVoucherImg,backgroundColor: '#f5f5f9',width:'100%',height:'100%' } }  >
  {/* <div style={{ color: '#888',fontSize: '14px', padding: '30px 0 18px 0', marginLeft: '15px'  } }>等待处理</div>*/}
 {/*  <Result
    img={myImg(attention_logo)}
    title=""
    message=""
  />*/}

        <img src={wait_logo} style={{backgroundColor: '#f5f5f9', width: '100%', height: '100%', textAlign: 'center'}}/>

</div>
         {/*  <div  style={{display:showVoucherImg,textAlign:'center',width:'100%',backgroundImage:back_logo } }  >
             <img src={back_logo} style={{display:showVoucherImg,textAlign:'center',width:'100%'} }  /> </div>*/}
          </div>
          <div style={{ alignItems: 'center', justifyContent: 'center', backgroundColor: '#f5f5f9' }}>
            {
              this.state.invicode.map((item => {
                if (item[6] == 2) {
                  showRedemImg='none';
                 var dateFormat = require('dateformat');
                  var start_time,cur_time,stop_time,end_time,stDate;
                  if (item[2]) {
                    start_time = new Date(item[2]);
                    cur_time = dateFormat(start_time, "dd/mm/yyyy")
                  }
                  if (item[3]) {
                    stop_time = new Date(item[3]);
                    stDate=new Date(Date.parse(item[3]))
                    end_time = dateFormat(stop_time, "dd/mm/yyyy")
                  }
                  let red_time=item[5]
                  let titleItem=item[1]
                    if (titleItem.length>19) {
                        titleItem = titleItem.substring(0, 19) + "..."
                    }

                  return (


                       <div style={{backgroundColor: '#f5f5f9'}}  >
                        <List renderHeader=' ' className="invicode-list" style={{backgroundColor: '#f5f5f9'}}  >




                         <div style={{ padding: ' 2px 4px',width:'100%',height:'100%' }}>




                            {/*   <div
                                style={{
                                  lineHeight: '35px',
                                  color: '#888',
                                  fontSize: 18,

                                }}
                              >{item[1]}</div>*/}



                                <div style={{ display: '-webkit-box', marginBottom: '5px',width:'100%',height:'100%',backgroundImage:`url(${r_logo})`,backgroundRrepeat:'no-repeat',backgroundSize: 'cover'  }}>

                        {/*  <div style={{ display: '-webkit-box', display: 'flex'  }}> */}
                                    <table style={{width:'100%'}}><tr>


                                        <td  style={{width:'80%'}}>

                                  <div   style={{ width:'100%' }}   >
                                      <table><tr><td  style={{textAlign:'center',verticalAlign: 'middle',paddingLeft:'5px'}}  >  <br/> <img src={v_logo} style={{width:'50px',height:'50px',background:'#f0f0f0',filter:'alpha(Opacity=70)',mozOpacity:'0.7',opacity: '0.7'}} /></td><td  >
                                      <div   >
                                      <br/>
                                <span  style={{ fontSize: '17px', color: '#b7adae',textAlign:'right' }} >&nbsp; {titleItem}
                                  </span><br/>
                                      <span  style={{ fontSize: '15px', color: '#b7adae' }} >&nbsp;&nbsp;Outlet Voucher</span>
                                      <br />
                                  <span  style={{ fontSize: '10px', color: '#b7adae' }} >&nbsp;&nbsp;&nbsp;{cur_time+' ~ '+end_time}</span>
                                      </div></td></tr></table>

                                </div></td><td  style={{width:'20%'}} >



                                <div style={{ lineHeight: 1,width:'100%' }}>
                                    {/*<div style={{ marginBottom: '8px', fontWeight: 'bold' }}></div>*/}
                                    <div style={{ fontSize: '12px',textAlign:'center' }}><br/>
                                          <div    style={{ textAlign:'right',border:'1px solid #c5c5c9',padding:'8px 12px',background:'#d5d5d9',width:'85px',height:'30px',borderRadius:'25px',color:'#fff',marginRight:'10px',transform: 'rotate(20deg)'   }}   >REDEEMED&nbsp;&nbsp;</div>
                                       {/* <div><img src={rd_logo} style={{width:'30px',height:'30px'}} /></div>*/}
                                        <br/>
                                        <div  style={{textAlign:'left', color: '#b7adae',fontSize: '10px' }} >  {dateFormat(item[5], "dd/mm/yyyy HH:MM")} &nbsp;</div>

      </div>
                                </div></td></tr></table>



                                 </div>



                            </div>







                        </List>
                        </div>













                  )
                }
              }))
            }
            <div  style={{display:showRedemImg,backgroundColor: '#f5f5f9',width:'100%',height:'100%' } }  >
  {/* <div style={{ color: '#888',fontSize: '14px', padding: '30px 0 18px 0', marginLeft: '15px'  } }>等待处理</div>*/}
  <img src={attention_logo} style={{backgroundColor: '#f5f5f9',width:'100%',height:'100%',textAlign:'center' } } />
  {/* <Result
    img={myImg(wait_logo)}
    title=""
    message=""
  />*/}</div>
          </div>
          <div style={{ alignItems: 'center', justifyContent: 'center', backgroundColor: '#f5f5f9' }}>
            <WingBlank><InputItem maxLength={16} placeholder="Promotion Code(case-sentivite)" onChange={(v) => this.setState({ 'invicode_send': v })} required /></WingBlank>
            <WhiteSpace size="lg" />
            <WingBlank><Button className="Register" type='primary' onClick={this.handleSendInvicode}>Add Promotion Code</Button></WingBlank>
            <WhiteSpace size="xl" />
              <img src={mem_logo} style={{backgroundColor: '#f5f5f9',width:'100%',height:'100%',textAlign:'center' } } />
          </div>
        </Tabs>
      </div>) : this.props.history.push("/login") );
  }
}
