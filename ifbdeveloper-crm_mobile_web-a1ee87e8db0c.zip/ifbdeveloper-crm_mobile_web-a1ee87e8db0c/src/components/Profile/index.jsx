import React from 'react'
import ReactDOM from 'react-dom'
import {  reqMember } from '../../api/requrl'
import { createForm } from 'rc-form';
import { Link } from 'react-router-dom'
import Cookies from 'js-cookie';
import voucher_logo from '../../assets/img/coupon.png'
import {
    Card,
    Flex,
    List,
    InputItem,
    Toast,
    Button,
    WingBlank,
    WhiteSpace,
    NavBar,
    Icon,
    Grid,
    Result
} from 'antd-mobile';
import wait_logo from "../../assets/img/mem.jpg";
import facebook_logo from '../../assets/img/facebook.jpg'
import twitter_logo from '../../assets/img/twitter.jpg'
import link_logo from '../../assets/img/link.jpg'
import { Popover } from 'antd-mobile';
const Item = Popover.Item;
const myImg0 = src => <img src={facebook_logo} className="am-icon am-icon-xs" alt="" />;
const myImg1 = src => <img src={twitter_logo} className="am-icon am-icon-xs" alt="" />;
const myImg2 = src => <img src={link_logo} className="am-icon am-icon-xs" alt="" />;

const myImg = src => <img src={src} style={{ width:'300px',height:'300px'  }} alt="" />;
export default class Demo extends React.Component {
    state = {
      visible: false,
      confirmLoading: false,
      invicode: [],
      outlets: [],
      membership: [],
      voucherdata: [],
      topping: [],
      initializing: 1,
      hasMore: 0
    }
  
    async componentWillMount() {
      let { membership } = this.state
      this.setState({
        hasMore: 1,
        initializing: 2, // initialized
      });
      const Token = 'Token ' + Cookies.get('Authorization')
      let req = await reqMember(Token)
      membership = req.data.results
      console.log(membership[0].mobile_no)
      this.setState({ membership })
    }
  onSelect = (opt) => {
    // console.log(opt.props.value);
    this.setState({
      visible: false,
      selected: opt.props.value,

    });
    if (opt.props.value==='f') {
       window.open('http://www.facebook.com/sharer.php?u=' + encodeURIComponent('https://member.itea.sg') + '&t=' + encodeURIComponent('Register send 1 Free Milk Tea Voucher'), '_blank', 'toolbar=yes, location=yes, directories=no, status=no, menubar=yes, scrollbars=yes, resizable=no, copyhistory=yes, width=600, height=450,top=100,left=350');
    }
     if (opt.props.value==='t') {
       window.open('http://twitter.com/home?status=' + encodeURIComponent('https://member.itea.sg') + ' ' + encodeURIComponent('Register send Free 1 Milk Tea Voucher'), '_blank', 'toolbar=yes, location=yes, directories=no, status=no, menubar=yes, scrollbars=yes, resizable=no, copyhistory=yes, width=600, height=450,top=100,left=350');
     }
    if (opt.props.value==='l') {
      window.open('http://www.linkedin.com/shareArticle?mini=true&url=' + encodeURIComponent('https://member.itea.sg') + '&title=' + encodeURIComponent('Register send 1 Free Milk Tea Voucher') + '&source=' + encodeURIComponent('https://member.itea.sg'), '_blank', 'toolbar=yes, location=yes, directories=no, status=no, menubar=yes, scrollbars=yes, resizable=no, copyhistory=yes, width=600, height=450,top=100,left=350');
    }

   // alert(opt.props.value)
  };
  handleVisibleChange = (visible) => {
    this.setState({
      visible,
    });
  };
    render() {
      let { membership } = this.state
      let now = new Date();
      let user = Cookies.get('user')
      const data = Array.from(new Array(1)).map((_val, i) => ({
        icon: voucher_logo,
        text: `Voucher`,
      }));
      return (
        Cookies.get('isLogin') ? (
        <div>
          <NavBar
            mode="light"
            icon={<Icon type="left" />}
            onLeftClick={() => this.props.history.goBack()}
            rightContent={<Popover mask
            overlayClassName="fortest"
            overlayStyle={{ color: 'currentColor' }}
            visible={this.state.visible}
            overlay={[
              (<Item key="4" value="f" icon={myImg0('tOtXhkIWzwotgGSeptou')} data-seed="logId">Share To Facebook
</Item>),
              (<Item key="5" value="t" icon={myImg1('PKAgAqZWJVNwKsAJSmXd')} style={{ whiteSpace: 'nowrap' }}>Share To Twitter</Item>),
              (<Item key="6" value="l" icon={myImg2('uQIYTFeRrjPELImDRrPt')}>
                <span style={{ marginRight: 5 }}>Share To Link</span>
              </Item>),
            ]}
            align={{
              overflow: { adjustY: 0, adjustX: 0 },
              offset: [-10, 0],
            }}
            onVisibleChange={this.handleVisibleChange}
            onSelect={this.onSelect}
          >
            <div style={{
              height: '100%',
              padding: '0 15px',
              marginRight: '-15px',
              display: 'flex',
              alignItems: 'center',
            }}
            >
              <Icon type="ellipsis" />
            </div>
          </Popover>}
          >Profile</NavBar>
          {membership.map((member => {
            return(            
            <div>
              <WingBlank size="lg">
              <WhiteSpace size="lg" />
              <Card full>
                <Card.Header
                  title={member.mobile_no}
                  thumb="https://gw.alipayobjects.com/zos/rmsportal/MRhHctKOineMbKAZslML.jpg"
                  extra={<span>Points:{member.total_points}</span>}
                />
                <Card.Body>
                  <div><br />{member.membership.name}</div>
                </Card.Body>
                  {/* <Card.Footer content="other things" extra={<div></div>} />*/}
              </Card>
              <WhiteSpace size="lg" />
              </WingBlank>
            </div>)}
            ))}
            <Grid data={data} activeStyle={true} columnNum={3} onClick={_el => this.props.history.push("/voucher")}/>

             <div  style={{backgroundColor: '#fff',width:'100%',height:'100%',textAlign:'center' } }  >
  {/* <div style={{ color: '#888',fontSize: '14px', padding: '30px 0 18px 0', marginLeft: '15px'  } }>等待处理</div>
  <Result

    img={myImg(wait_logo)}
    title=""
    message=""
  />*/}
<img src={wait_logo} style={{backgroundColor: '#fff',width:'100%',height:'100%',textAlign:'center' } } />

  </div>




        </div>


        ) : this.props.history.push("/login") );
    }
  }
  