
/* eslint-disable */
import React from 'react'
import {reqGetcode,reqGetcode1, reqModPass, reqCheckMobile} from '../../api/requrl'
import { createForm } from 'rc-form';
import { Link } from 'react-router-dom'
import {Flex, List, InputItem, Toast, Button, WingBlank, WhiteSpace, NavBar, Icon, Checkbox} from 'antd-mobile';

import '../config.js'
import cobra_logo from '../../assets/img/logo.png'
import eye_logo from '../../assets/img/see.png'
import ReCAPTCHA from 'react-google-recaptcha'
import { flatten } from 'zent/lib/sku/utils';

const Token = 'Token ' + '62c366bacc6365c035fad818d2a77be51097e95d'
class ForgetPassword extends React.Component {
  constructor(props){
    super(props);
     this.state = {
    username: '',
    password: '',
       password1: '',
       password_disable:true,
       button_disable:true,
    mobile_no: '',
    invicode: '',
    vericode: '',
    vericode_local: '',
    verified: false,
    count: 60, // 秒数初始化为60秒
    liked: true,
    veri_input: false,
    is_position:false,
       veri_input_code:true
  };
  this.inputCode=this.inputCode.bind(this);


  }



  inputCode(event) {
      //event.persist()
       //const val= this.refs.myInput.refs.input.value ;
      // alert(val);
      this.setState({vericode:event});
      const localCode=this.state.vericode_local;
      const code=this.state.vericode;
     //alert(localCode+'  hh   '+code+(parseInt(localCode,10)===parseInt(code,10)) );
      if (parseInt(localCode,10)===parseInt(code,10))
      {
          //alert('ik');
           this.setState({
              password_disable:false,
              button_disable:false
           })
      }

  }

  getVerifyCode =  () =>{
      let { mobile_no } = this.state
      if (mobile_no.length == 0)
      {
          return Toast.info('Mobile number is null.')

      }
      if (isNaN(mobile_no))
          return Toast.info('Mobile number must be numeric.')
      if (mobile_no.length !== 8)
          return Toast.info('Mobile number must be 8 character.')
    this.setState(
    {
      liked: false
    }
    )
    let { count,liked } = this.state


    const timer = setInterval(() => {
      this.setState({ 
     count: (count--)
     }, () => {
     if (count === 0) {
         clearInterval(timer);
         this.setState({
           liked: true ,
           count: 60
         })
       }
      });
    }, 1000);
    if (mobile_no.length == 8)
    {


      reqCheckMobile({'mobile_no':mobile_no}, Token).then(res => {
        //Mobile number不存在时，提示注册
        alert('Mobile number has not register,please register.');
          window.location.href="/register";




      }).catch( err => {
           // const queryresult = await QueryTest(mobile_no);
        //Mobile number存在时，发送验证码
          //this.setState({is_position:true});
        //同步阻塞获取code
       console.log("SUCCESS")
       const  get= reqGetcode1(mobile_no).then(  res => {
                //alert(res.data.message);


                this.setState({veri_input_code:false,vericode_local: res.data.message})

              })

      })
    }else{
      return Toast.info('Mobile number error')
    }
     console.log(mobile_no);
    if(this.state.is_position) {



    }
  }

  handleRegister = async () => {

    let { username, password, password1,mobile_no, invicode, vericode, vericode_local, verified } = this.state


      if ((mobile_no.length == 0) || (mobile_no.length !== 8))
      {
          return Toast.info('Mobile number is error.')

      }
      /*
      if(!isNumber(mobile_no))
          return Toast.info('Mobile number must be numeric.')
     */
      if (isNaN(mobile_no))
          return Toast.info('Mobile number must be numeric.')
     // alert(vericode+'   h   '+vericode_local)
      if((vericode=='') ||(vericode_local=='')){
         return Toast.info('OTP verify code error.')
    }
      /*
      if(!isNumber(vericode))
          return Toast.info('OTP verify code must be numeric.')
       */
      if (isNaN(vericode))
          return Toast.info('OTP verify code must be numeric.')
    if(vericode!=vericode_local){
         return Toast.info('OTP verify code error.')
    }else{
      this.setState({
        verified:true
      })
    }
    if ((password.trim()==="") || (password1.trim()===""))
           return Toast.info('password is blank.')
    if(password!==password1)
          return Toast.info('password is different.')
    //alert(vericode+'   '+vericode_local+'  '+password+'   '+password1);

    mobile_no=mobile_no.trim();
    password= password.trim();
    const user = {
      username,
      mobile_no,
      password,
      invicode,
        vericode
    }
    //alert(mobile_no+' '+password+'  '+invicode);
    //return Toast.info('password is different.')
    let req2 = reqModPass(user,Token).then(res => {
     let msg = res.data.msg
       if (msg=='ok')
          alert('password modify success!');

         else
           alert('password modify false!');

    }).catch(err => {
      this.setState({
        message: 'Unknown Error'
      })
    })
    //alert('password modify success!');
    this.props.history.push("/login");
  }

  render() {

      let tableStyle = {  //定义style变量


             width:'100%'

        }

   let mobileStyle = {  //定义style变量


             width:'95%'

        }
    let codeStyle = {  //定义style变量

            float: 'left',
             width:'5%'

        }


    const {
      username,
      mobile_no,
      password,
      invicode,
      vericode,
    } = this.state

    return (
      <div>
        <NavBar
          mode="light"
          icon={<Icon type="left" />}
          onLeftClick={() => this.props.history.goBack()}
          rightContent={[
            <Icon key="1" type="ellipsis" />,
          ]}
        >Forget Password</NavBar>
      <form className="form">
        <List renderHeader={() => <b>Forget Password</b>}>
          <Flex justify="center">
            <img src={cobra_logo} height="111" width="256"></img>
          </Flex>
          <WhiteSpace size="lg" />
            <WingBlank    ><table style={tableStyle} ><tr><td  style={ mobileStyle }  >
           <InputItem type="tel"      maxLength={8} placeholder="Mobile Number" onChange={(v) => this.setState({ 'mobile_no': v })}
              required /> </td><td  style={codeStyle}>  {
              this.state.liked
              ?
                   <Button inline size="small"       className="Getcode" type="ghost" disable={this.state.veri_input} onClick={this.getVerifyCode}>OTP</Button>
              :
                    <Button inline size="small"    loading disabled className="Getcode" onClick={this.getVerifyCode}>{this.state.count + 's'}</Button>
            } </td></tr></table> </WingBlank>
          <WhiteSpace size="lg" />
          <WingBlank>
            <InputItem 
              maxLength={6} 
              placeholder="Verify Code" 
              onChange={(v) =>{ this.setState({ 'vericode': v })}}

             ref="myInput"
              required 
              />
            </WingBlank>
          <WhiteSpace size="lg" />
          <WhiteSpace size="lg" />

          <WingBlank><InputItem id="pass" type="password" maxLength={16}    placeholder="New Password" onChange={(v) => this.setState({ 'password': v })}   extra={

            <img src={eye_logo} style={{float:'left'}} height="20" width="20" onClick={(v) => {if (document.getElementById('pass').type=="text") { document.getElementById('pass').type="password";document.getElementById('cpass').type="password";  }else { document.getElementById('pass').type="text";document.getElementById('cpass').type="text";  } }}  ></img>  }   required /></WingBlank>
          <WhiteSpace size="lg" />
          <WingBlank><InputItem id="cpass" type="password" maxLength={16}     placeholder="Confirm Password" onChange={(v) => this.setState({ 'password1': v })} required /></WingBlank>
          <WhiteSpace size="lg" />
          <WingBlank><Button className="Register"     type='primary' onClick={this.handleRegister}>Submit</Button></WingBlank>
          <WhiteSpace size="xl" />
           <WingBlank><li><Link to={"/register"}>New User</Link></li></WingBlank>
          <WhiteSpace size="xl" />
        </List>
      </form>
      </div>
    )
  }
}

export default createForm()(ForgetPassword);
