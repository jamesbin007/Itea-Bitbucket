
/* eslint-disable */
import React from 'react'
import {reqGetcode,reqGetcode1, reqModPass, reqCheckMobile} from '../../api/requrl'
import { createForm } from 'rc-form';
import { Link } from 'react-router-dom'
import {Flex, List, InputItem, Toast, Button, WingBlank, WhiteSpace, NavBar, Icon, Checkbox} from 'antd-mobile';

import '../config.js'
import cobra_logo from '../../assets/img/logo.png'
import eye_logo from '../../assets/img/see.png'
import sleep_logo from '../../assets/img/sleep.png'
import ReCAPTCHA from 'react-google-recaptcha'
import { flatten } from 'zent/lib/sku/utils';
import facebook_logo from '../../assets/img/facebook.jpg'
import twitter_logo from '../../assets/img/twitter.jpg'
import link_logo from '../../assets/img/link.jpg'
import { Popover } from 'antd-mobile';
const Item = Popover.Item;
const myImg = src => <img src={facebook_logo} className="am-icon am-icon-xs" alt="" />;
const myImg1 = src => <img src={twitter_logo} className="am-icon am-icon-xs" alt="" />;
const myImg2 = src => <img src={link_logo} className="am-icon am-icon-xs" alt="" />;

const Token = 'Token ' + '62c366bacc6365c035fad818d2a77be51097e95d'
class ForgetPassword extends React.Component {
  constructor(props){
    super(props);
     this.state = {
    username: '',
    password: '',
       password1: '',
       password_disable:true,
       button_disable:true,
    mobile_no: '',
    invicode: '',
    vericode: '',
    vericode_local: '',
    verified: false,
    count: 60, // 秒数初始化为60秒
    liked: true,
    veri_input: false,
    is_position:false,
         see_img:eye_logo,
       veri_input_code:true
  };
  this.inputCode=this.inputCode.bind(this);


  }



  inputCode(event) {
      //event.persist()
       //const val= this.refs.myInput.refs.input.value ;
      // alert(val);
      this.setState({vericode:event});
      const localCode=this.state.vericode_local;
      const code=this.state.vericode;
     //alert(localCode+'  hh   '+code+(parseInt(localCode,10)===parseInt(code,10)) );
      if (parseInt(localCode,10)===parseInt(code,10))
      {
          //alert('ik');
           this.setState({
              password_disable:false,
              button_disable:false
           })
      }

  }

  getVerifyCode =  () =>{
      let { mobile_no } = this.state
      if (mobile_no.length == 0)
      {
          return Toast.info('Mobile number is null.')

      }
      if (isNaN(mobile_no))
          return Toast.info('Mobile number must be numeric.')
      if (mobile_no.length !== 8)
          return Toast.info('Mobile number must be 8 character.')
    this.setState(
    {
      liked: false
    }
    )
    let { count,liked } = this.state


    const timer = setInterval(() => {
      this.setState({ 
     count: (count--)
     }, () => {
     if (count === 0) {
         clearInterval(timer);
         this.setState({
           liked: true ,
           count: 60
         })
       }
      });
    }, 1000);
    if (mobile_no.length == 8)
    {


      reqCheckMobile({'mobile_no':mobile_no}, Token).then(res => {
        //Mobile number不存在时，提示注册
        alert('Mobile number has not register,please register.');
          window.location.href="/register";




      }).catch( err => {
           // const queryresult = await QueryTest(mobile_no);
        //Mobile number存在时，发送验证码
          //this.setState({is_position:true});
        //同步阻塞获取code
       console.log("SUCCESS")
       const  get= reqGetcode1(mobile_no).then(  res => {
                //alert(res.data.message);


                this.setState({veri_input_code:false,vericode_local: res.data.message})

              })

      })
    }else{
      return Toast.info('Mobile number error')
    }
     console.log(mobile_no);
    if(this.state.is_position) {



    }
  }

  handleRegister = async () => {

    let { username, password, password1,mobile_no, invicode, vericode, vericode_local, verified } = this.state


      if ((mobile_no.length == 0) || (mobile_no.length !== 8))
      {
          return Toast.info('Mobile number is error.')

      }
      /*
      if(!isNumber(mobile_no))
          return Toast.info('Mobile number must be numeric.')
     */
      if (isNaN(mobile_no))
          return Toast.info('Mobile number must be numeric.')
     // alert(vericode+'   h   '+vericode_local)
      if((vericode=='') ||(vericode_local=='')){
         return Toast.info('OTP verify code error.')
    }
      /*
      if(!isNumber(vericode))
          return Toast.info('OTP verify code must be numeric.')
       */
      if (isNaN(vericode))
          return Toast.info('OTP verify code must be numeric.')
    if(vericode!=vericode_local){
         return Toast.info('OTP verify code error.')
    }else{
      this.setState({
        verified:true
      })
    }
    if ((password.trim()==="") || (password1.trim()===""))
           return Toast.info('password is blank.')
    if(password!==password1)
          return Toast.info('password is different.')
    //alert(vericode+'   '+vericode_local+'  '+password+'   '+password1);

    mobile_no=mobile_no.trim();
    password= password.trim();
    const user = {
      username,
      mobile_no,
      password,
      invicode,
        vericode
    }
    //alert(mobile_no+' '+password+'  '+invicode);
    //return Toast.info('password is different.')
    let req2 = reqModPass(user,Token).then(res => {
     let msg = res.data.msg
       if (msg=='ok') {
           alert('password modify success!');
           window.location.href="/login"
       }
         else
           alert('password modify false!');

    }).catch(err => {
      this.setState({
        message: 'Unknown Error'
      })
    })
    //alert('password modify success!');
   // this.props.history.push("/login");
  }

  onSelect = (opt) => {
    // console.log(opt.props.value);
    this.setState({
      visible: false,
      selected: opt.props.value,

    });
    if (opt.props.value==='f') {
       window.open('http://www.facebook.com/sharer.php?u=' + encodeURIComponent('https://member.itea.sg') + '&t=' + encodeURIComponent('Register send 1 Free Milk Tea Voucher'), '_blank', 'toolbar=yes, location=yes, directories=no, status=no, menubar=yes, scrollbars=yes, resizable=no, copyhistory=yes, width=600, height=450,top=100,left=350');
    }
     if (opt.props.value==='t') {
       window.open('http://twitter.com/home?status=' + encodeURIComponent('https://member.itea.sg') + ' ' + encodeURIComponent('Register send 1 Free Milk Tea Voucher'), '_blank', 'toolbar=yes, location=yes, directories=no, status=no, menubar=yes, scrollbars=yes, resizable=no, copyhistory=yes, width=600, height=450,top=100,left=350');
     }
    if (opt.props.value==='l') {
      window.open('http://www.linkedin.com/shareArticle?mini=true&url=' + encodeURIComponent('https://member.itea.sg') + '&title=' + encodeURIComponent('Register send 1 Free Milk Tea Voucher') + '&source=' + encodeURIComponent('https://member.itea.sg'), '_blank', 'toolbar=yes, location=yes, directories=no, status=no, menubar=yes, scrollbars=yes, resizable=no, copyhistory=yes, width=600, height=450,top=100,left=350');
    }

   // alert(opt.props.value)
  };
  handleVisibleChange = (visible) => {
    this.setState({
      visible,
    });
  };


  render() {

      let tableStyle = {  //定义style变量


             width:'100%'

        }

   let mobileStyle = {  //定义style变量


             width:'95%'

        }
    let codeStyle = {  //定义style变量

            float: 'left',
             width:'5%'

        }


    const {
      username,
      mobile_no,
      password,
      invicode,
      vericode,
    } = this.state

    return (
      <div>
        <NavBar
          mode="light"
          icon={<Icon type="left" />}
          onLeftClick={() => this.props.history.goBack()}
          rightContent={<Popover mask
            overlayClassName="fortest"
            overlayStyle={{ color: 'currentColor' }}
            visible={this.state.visible}
            overlay={[
              (<Item key="4" value="f" icon={myImg('tOtXhkIWzwotgGSeptou')} data-seed="logId">Share To Facebook
</Item>),
              (<Item key="5" value="t" icon={myImg1('PKAgAqZWJVNwKsAJSmXd')} style={{ whiteSpace: 'nowrap' }}>Share To Twitter</Item>),
              (<Item key="6" value="l" icon={myImg2('uQIYTFeRrjPELImDRrPt')}>
                <span style={{ marginRight: 5 }}>Share To Link</span>
              </Item>),
            ]}
            align={{
              overflow: { adjustY: 0, adjustX: 0 },
              offset: [-10, 0],
            }}
            onVisibleChange={this.handleVisibleChange}
            onSelect={this.onSelect}
          >
            <div style={{
              height: '100%',
              padding: '0 15px',
              marginRight: '-15px',
              display: 'flex',
              alignItems: 'center',
            }}
            >
              <Icon type="ellipsis" />
            </div>
          </Popover>}
        >Forget Password</NavBar>
      <form className="form">
        <List renderHeader={() => <b>Forget Password</b>}>
          <Flex justify="center">
            <img src={cobra_logo} height="111" width="256"></img>
          </Flex>
          <WhiteSpace size="lg" />
            <WingBlank    >
           <InputItem type="tel"      maxLength={8} placeholder="Mobile Number" onChange={(v) => this.setState({ 'mobile_no': v })}
              required />  </WingBlank>
          <WhiteSpace size="lg" />
          <WingBlank>
              <table style={tableStyle} ><tr><td  style={ mobileStyle }  >

            <InputItem 
              maxLength={6} 
              placeholder="Verify Code" 
              onChange={(v) =>{ this.setState({ 'vericode': v })}}

             ref="myInput"
              required 
              /></td><td  style={codeStyle}>  {
              this.state.liked
              ?
                   <Button inline size="small"       className="Getcode" type="ghost" disable={this.state.veri_input} onClick={this.getVerifyCode}>OTP</Button>
              :
                    <Button inline size="small"    loading disabled className="Getcode" onClick={this.getVerifyCode}>{this.state.count + 's'}</Button>
            } </td></tr></table>
            </WingBlank>
          <WhiteSpace size="lg" />
          <WhiteSpace size="lg" />

          <WingBlank><InputItem id="pass" type="password" maxLength={16}    placeholder="New Password" onChange={(v) => this.setState({ 'password': v })}   extra={

            <img src={this.state.see_img} id='img' style={{float:'left'}} height="20" width="20" onClick={(v) => {if (document.getElementById('pass').type=="text") { document.getElementById('pass').type="password";document.getElementById('cpass').type="password";this.setState({ 'see_img': eye_logo });  }else { document.getElementById('pass').type="text";document.getElementById('cpass').type="text"; this.setState({ 'see_img': sleep_logo }); }} } ></img>


          }   required /></WingBlank>
          <WhiteSpace size="lg" />
          <WingBlank><InputItem id="cpass" type="password" maxLength={16}     placeholder="Confirm Password" onChange={(v) => this.setState({ 'password1': v })} required /></WingBlank>
          <WhiteSpace size="lg" />
          <WingBlank><Button className="Register"     type='primary' onClick={this.handleRegister}>Submit</Button></WingBlank>
          <WhiteSpace size="xl" />
           <WingBlank><li><Link to={"/register"}>New User</Link></li></WingBlank>
          <WhiteSpace size="xl" />
        </List>
      </form>

           <Flex justify="center"><div style={{align:'center',textAlign:'center',fontSize:'10px',color:'gray'}} ><table  ><tr><td>Copyright © 2019  iTea Premium Bubble Tea Singapore</td><td>  </td><td>  </td></tr>


        </table></div></Flex>
      </div>
    )
  }
}

export default createForm()(ForgetPassword);
