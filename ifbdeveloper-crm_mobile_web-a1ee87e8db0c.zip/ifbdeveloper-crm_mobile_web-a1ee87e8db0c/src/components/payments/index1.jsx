import React, {Component} from 'react';
import {Elements, StripeProvider} from 'react-stripe-elements';
import CheckoutForm from './CheckoutForm';
import {reqGetcode,reqGetcode1, reqModPass, reqCheckMobile} from '../../api/requrl'
import { createForm } from 'rc-form';
import { Link } from 'react-router-dom'
import {Flex, List, InputItem, Toast, Button, WingBlank, WhiteSpace, NavBar, Icon, Checkbox} from 'antd-mobile';

import '../config.js'
import cobra_logo from '../../assets/img/logo.png'
import eye_logo from '../../assets/img/see.png'
import sleep_logo from '../../assets/img/sleep.png'
import ReCAPTCHA from 'react-google-recaptcha'
import { flatten } from 'zent/lib/sku/utils';

const Token = 'Token ' + '62c366bacc6365c035fad818d2a77be51097e95d'
class payments extends Component {
  render() {
    return (
      <StripeProvider apiKey="pk_test_3J6YTaU97yUFcIjj8gLlFL7P">
        <div className="example">
          <h1>React Stripe Elements Example</h1>
          <Elements>
            <CheckoutForm />
          </Elements>
        </div>
      </StripeProvider>
    );
  }
}

export default createForm()(payments);