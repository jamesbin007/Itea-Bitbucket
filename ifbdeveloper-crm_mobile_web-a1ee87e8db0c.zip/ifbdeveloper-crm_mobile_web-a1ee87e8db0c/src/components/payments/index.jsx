import React, {Component} from 'react';
import {Elements, StripeProvider} from 'react-stripe-elements';
import CheckoutForm from './CheckoutForm';
import {reqGetcode,reqGetcode1, reqModPass, reqCheckMobile} from '../../api/requrl'
import { createForm } from 'rc-form';
import { Link,browserHistory } from 'react-router-dom'
import {Flex, List, InputItem, Toast, Button, WingBlank, WhiteSpace, NavBar, Icon, Checkbox,SegmentedControl} from 'antd-mobile';
import { withRouter } from 'react-router'
import '../config.js'
import cobra_logo from '../../assets/img/logo.png'
import eye_logo from '../../assets/img/see.png'
import sleep_logo from '../../assets/img/sleep.png'
import ReCAPTCHA from 'react-google-recaptcha'
import { flatten } from 'zent/lib/sku/utils';
import Cookies from 'js-cookie';
const Token = 'Token ' + '62c366bacc6365c035fad818d2a77be51097e95d'
class payments extends Component {
    constructor(props)
    {
       super(props)
       this.state={amount:1000}
    }

  onChange = (e) => {
    console.log(`selectedIndex:${e.nativeEvent.selectedSegmentIndex}`);
   // this.setState({amount:e.nativeEvent.selectedSegmentIndex})
  }
  onValueChange = (value) => {

    console.log(value);
  }
 onSubmit=()=>{
        var data = {amount:this.state.amount};
        var path = {
          pathname:'/payotp',
          query:data,
        }
      //  this.props.history.push('/pay', {query: { data: this.state.amount }} );
     window.location.href="/payotp?data="+this.state.amount

 }

  render() {
      if (!Cookies.get('isLogin'))
      {
          window.location.href="/login"
          return false
      }
    return (
        <div style={{backgroundColor:'#fff'}}>
         <NavBar
      mode="dark"
      leftContent="Back"
      rightContent={[

        <Icon key="1" type="ellipsis" />,
      ]}
    >Charge</NavBar>

<Flex justify="center">
            <img src={cobra_logo} height="111" width="256"></img>
          </Flex>
 <WhiteSpace size="lg" />

           <WingBlank size="lg" className="sc-example">


        <p className="sub-title">Select Charge Amount</p>
           <WhiteSpace size="lg" />
        <SegmentedControl
            id='amount'
          values={['10', '20', '50']}

          style={{ height: '40px', width: '250px' }}


          onValueChange={(value) => { this.setState({amount:value*100}) }}
        />


      </WingBlank>
          <WhiteSpace size="lg" />
       <Flex justify="center">       <button  onClick={this.onSubmit}   style={{ padding: '10px' }} className="am-button-borderfix">Submit</button>

       </Flex>

 </div>

    );
  }
}

export default createForm()( withRouter( payments));