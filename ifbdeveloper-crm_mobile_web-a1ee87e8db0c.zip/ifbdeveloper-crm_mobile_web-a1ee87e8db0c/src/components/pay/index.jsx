import React, {Component} from 'react';
import {Elements, StripeProvider} from 'react-stripe-elements';



import CheckoutForm from './CheckoutForm';
import PaymentRequestForm from './PaymentRequestForm';
//import PaymentForm from './paymentForm';
import {reqGetcode,reqGetcode1, reqModPass, reqCheckMobile} from '../../api/requrl'
import { createForm } from 'rc-form';
import { Link,browserHistory } from 'react-router-dom'
import {Flex, List, InputItem, Toast, Button, WingBlank, WhiteSpace, NavBar, Icon, Checkbox,SegmentedControl} from 'antd-mobile';
import { withRouter } from 'react-router'
import '../config.js'
import cobra_logo from '../../assets/img/logo.png'
import eye_logo from '../../assets/img/see.png'
import sleep_logo from '../../assets/img/sleep.png'
import ReCAPTCHA from 'react-google-recaptcha'
import { flatten } from 'zent/lib/sku/utils';

const Token = 'Token ' + '62c366bacc6365c035fad818d2a77be51097e95d'
var amount
class pay extends Component {
  componentWillMount()
{
     let varVal=window.location.search.replace('?data=','');
     if (isNaN(varVal))
     {
         amount=10;
         }
      else {
       amount = varVal;
     }


}
  render() {
    return (

         <div style={{backgroundColor:'#fff'}}>
         <NavBar
      mode="dark"
      leftContent="Back"
      rightContent={[

        <Icon key="1" type="ellipsis" />,
      ]}
    >Charge</NavBar>

<Flex justify="center">
            <img src={cobra_logo} height="111" width="256"></img>
          </Flex>
 <WhiteSpace size="lg" />

           <WingBlank size="lg" className="sc-example">


        <p className="sub-title">Fill Bank Info</p>
           <WhiteSpace size="lg" />
            <StripeProvider apiKey="pk_live_8HqZHu7JH6euijJH9VndlQeX">
        <div className="example">

          <Elements>
            <CheckoutForm  amount={amount} />
          {/*  <PaymentRequestForm amount={amount} />*/}
          </Elements>
        </div>
      </StripeProvider>


      </WingBlank>
          <WhiteSpace size="lg" />


 </div>




    );
  }
}

export default createForm()( withRouter( pay));