import React, {Component} from 'react';
import {CardElement, injectStripe} from 'react-stripe-elements';
import {Flex, List, InputItem, Toast, Button, WingBlank, WhiteSpace, NavBar, Icon, Checkbox,SegmentedControl} from 'antd-mobile';
import {reqStripe} from '../../api/requrl'
class CheckoutForm extends Component {
  constructor(props) {
  super(props);
  this.state = {complete: false,
  resp_message: "",
    card_errors: ""
  };
  this.submit = this.submit.bind(this);
}

componentWillMount()
{


}



handleCardErrors = card_dets => {
    console.log("Card Section dets", card_dets);
    if (card_dets.error) {
      this.setState({ card_errors: card_dets.error.message });
    } else {
      this.setState({ card_errors: "" });
    }
  };

  async submit(ev) {




      {/*
  let {token} = await this.props.stripe.createToken({name: "name"});

  const user = {
      username,
      mobile_no,
      password,
      invicode,
        vericode
    }

  let response = await fetch("http://127.0.0.1:8000/api/v1/payments/charge/", {
    method: "POST",
    headers: {
              accept: "application/json",
              Authorization: "Token 62c366bacc6365c035fad818d2a77be51097e95d",
            },
    body: token.id
  });

  if (response.ok) console.log("Purchase Complete!")
  */}
}

handleSubmit = e => {
    e.preventDefault();
    this.setState({ card_errors: "", resp_message: "" });
    /*
    Within the context of Elements, this call to createToken knows which
    Element to tokenize, since there's only one in this group.
    */
    return this.props.stripe
      .createToken({ type: "card", name: "Borislav Hadzhiev" })
      .then(result => {
        if (result.error) {
          console.log("THERE IS AN ERROR IN YOUR FORM", result.error);
          return this.setState({ card_errors: result.error.message });
        } else {
          console.log(
            "Received Stripe token ---> SENDING TO SERVER: ",
            result.token
          );
          let formData = new FormData();
          formData.append("description", "My form description");
          formData.append("currency", "sgd");
          //formData.append("currency", "usd");
         // formData.append("amount", parseInt(this.props.amount,10));
            formData.append("amount", 10);
          formData.append("source", result.token.id);
          //return fetch(`http://127.0.0.1:8000/api/v1/wallet/charge/`, {
            return fetch(`http://127.0.0.1:8000/api/v1/payments/charge/`, {
            method: "POST",
            headers: {
              accept: "application/json",
              Authorization: "Token 62c366bacc6365c035fad818d2a77be51097e95d",
            },
            body: formData
          })
            .then(resp => resp.json())
            .then(json => this.setState({ resp_message: json.message }));
        }
      });
  };



  render() {

    return (
      <div className="checkout">
          {this.state.resp_message && <h1>{this.state.resp_message}</h1>}

           <form onSubmit={this.handleSubmit}>
           <label>
        <CardElement

        style={{
                base: {
                  color: "#32325d",

                  fontFamily: '"Helvetica Neue", Helvetica, sans-serif',
                  fontSmoothing: "antialiased",
                  fontSize: "16px",
                  "::placeholder": {
                    color: "#aab7c4"
                  }
                },
                invalid: {
                  color: "#fa755a",
                  iconColor: "#fa755a"
                }
              }}
              onChange={this.handleCardErrors}
        />
           <div role="alert">
              <h2>{this.state.card_errors}</h2>
            </div>
  </label>
                <WhiteSpace size="lg" />
         <Flex justify="center">       <button     style={{ margin: '10px' }} className="am-button-borderfix">Confirm Order</button>

       </Flex>
                </form>
      </div>
    );
  }
}

export default injectStripe(CheckoutForm);