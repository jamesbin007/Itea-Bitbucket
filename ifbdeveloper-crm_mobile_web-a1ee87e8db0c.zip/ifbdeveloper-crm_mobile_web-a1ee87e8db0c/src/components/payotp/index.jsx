import React, {Component} from 'react';
import {Elements, StripeProvider} from 'react-stripe-elements';

import Cookies from 'js-cookie';

import CheckoutForm from './CheckoutForm';
import PaymentRequestForm from './PaymentRequestForm';
//import PaymentForm from './paymentForm';
import {reqGetcode,reqGetcode1, reqModPass, reqCheckMobile} from '../../api/requrl'
import { createForm } from 'rc-form';
import { Link,browserHistory } from 'react-router-dom'
import {Flex, List, InputItem, Toast, Button, WingBlank, WhiteSpace, NavBar, Icon, Checkbox,SegmentedControl} from 'antd-mobile';
import { withRouter } from 'react-router'
import '../config.js'
import cobra_logo from '../../assets/img/logo.png'
import eye_logo from '../../assets/img/see.png'
import sleep_logo from '../../assets/img/sleep.png'
import ReCAPTCHA from 'react-google-recaptcha'
import { flatten } from 'zent/lib/sku/utils';

const Token = 'Token ' + '62c366bacc6365c035fad818d2a77be51097e95d'
var amount,search,arrSearch
class pay extends React.Component {
  componentWillMount()
{
     let varVal=window.location.search.replace('?data=','');
     if (isNaN(varVal))
     {
          const query = this.props.location.search
           if (query && query.indexOf("secret")!==-1) {

                let  search=this.props.location.hash
                  console.log(search)
                   if (search)
                      arrSearch =search.split("?")
                   if (arrSearch && arrSearch.length>1)
                   {
                       amount=arrSearch[1].replace("amount=","")

                   }

           }
           else {
               amount = 1000;
           }
         }
      else {
       amount = varVal;
     }


}
  render() {

      if (!Cookies.get('isLogin'))
      {
          window.location.href="/login"
          return false
      }
       if (!Cookies.get('wallet') || Cookies.get('wallet')==="0")
      {
          alert('Please log  ,do not forbidden cookie!');
          window.location.href="/login"
          return false
      }

    return (

         <div style={{backgroundColor:'#fff'}}>
         <NavBar
      mode="dark"
      leftContent="Back"
      rightContent={[

        <Icon key="1" type="ellipsis" />,
      ]}
    >Charge</NavBar>

<Flex justify="center">
            <img src={cobra_logo} height="111" width="256"></img>
          </Flex>
 <WhiteSpace size="lg" />

           <WingBlank size="lg" className="sc-example">


        <p className="sub-title">Fill Bank Info</p>
           <WhiteSpace size="lg" />
              {/*  <StripeProvider apiKey="pk_live_8HqZHu7JH6euijJH9VndlQeX">*/}
                <StripeProvider apiKey="pk_test_3J6YTaU97yUFcIjj8gLlFL7P">
        <div className="example">

          <Elements>
            <CheckoutForm  amount={amount}  />
          {/*  <PaymentRequestForm amount={amount} />*/}
          </Elements>
        </div>
      </StripeProvider>


      </WingBlank>
          <WhiteSpace size="lg" />


 </div>




    );
  }
}

export default createForm()( withRouter( pay));