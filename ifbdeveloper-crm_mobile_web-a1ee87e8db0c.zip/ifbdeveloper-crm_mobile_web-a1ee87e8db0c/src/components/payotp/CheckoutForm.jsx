import React, {Component} from 'react';
import {CardElement, injectStripe} from 'react-stripe-elements';
import {Flex, List, InputItem, Toast, Button, WingBlank, WhiteSpace, NavBar, Icon, Checkbox,SegmentedControl} from 'antd-mobile';
import {reqStripe} from '../../api/requrl'
import { withRouter } from 'react-router'
import Cookies from 'js-cookie';
var flag=""
class CheckoutForm extends Component {
  constructor(props) {
  super(props);

  this.state = {complete: false,
  resp_message: "",
    card_errors: "",

  };
  this.submit = this.submit.bind(this);
   this.handleData = this.handleData.bind(this);
   //console.log(this.props.location.search)
}



componentWillMount()
{

    const user = {
      username,

    }
    user.username = Cookies.get('user')
    let wallet=Cookies.get('wallet')
    const query = this.props.location.search
    if (query && query.indexOf("secret")!==-1) {
        var client_secret,sourceID,amount
        const arr = query.replace("?","").split('&')
        console.log(query.replace("?",""))
        if (arr) {
            for (var i = 0; i < arr.length; i++) {
                console.log(arr[i])
                if (arr[i].indexOf("client_secret=")!==-1)
                    client_secret = arr[i].replace("client_secret=","")
                if (arr[i].indexOf("source=")!==-1)
                    sourceID = arr[i].replace("source=","")
                if (arr[i].indexOf("amount=")!==-1)
                    amount = arr[i].replace("amount=","")

            }
        }
       // const client_secret = arr[0].substr(15)
       // const livemode = arr[1].substr(10)
       // const sourceID = arr[2].substr(7)
        console.log(this.props.location.hash)
        var search,arrSearch
        if (!amount && this.props.location.hash)
        {
                   search=this.props.location.hash
                  console.log(search)
                   if (search)
                      arrSearch =search.split("?")
                   if (arrSearch && arrSearch.length>1)
                   {
                       amount=arrSearch[1].replace("amount=","")

                   }
                  // amount = this.props.location.hash.replace("#/?amount=", "")

                    if (isNaN(amount)) {
                        console.log("amount:"+amount)
                        return this.setState({resp_message: "charge amount is not a numeric!"});
                    }
                    amount=parseInt(amount,10)
                    console.log(amount)
        }
        console.log(client_secret + ' haha  ' + sourceID+"   amount:"+amount)
        let source = this.props.stripe.retrieveSource({
            id: sourceID,
            client_secret: client_secret,
        }).then(result => {

            // Handle result.error or result.source
            if (result.error) {
                console.log("THERE IS AN ERROR IN YOUR CHARGE", result.error);
                return this.setState({resp_message: result.error.message});
            } else {
                console.log(
                    "Received Stripe source---> SENDING TO SERVER: ",
                    result.token
                );
                //根据source状态处理
                let source = result.source;
                if (source.status === 'chargeable') {

                     console.log('ok')

                    let formData = new FormData();
                      formData.append("description", "Itea Charge");
                      formData.append("currency", "sgd");
                       formData.append("user", user.username);
                      //formData.append("currency", "usd");
                      formData.append("amount", amount);
                       formData.append("money", amount);
                       formData.append("wallet", wallet);
                      //测试$0.5
                       // formData.append("amount", 50);
                       // formData.append("amount", parseInt(this.props.amount,10));
                      formData.append("source", sourceID);
                     //  return fetch(`http://127.0.0.1:8000/api/v1/payments/charge/`, {
            return fetch(`https://crm.itea.sg/api/v1/payments/charge/`, {
                        method: "POST",
                        headers: {
                          accept: "application/json",
                          Authorization: "Token 62c366bacc6365c035fad818d2a77be51097e95d",
                        },
                        body: formData
                      })
                         .then(resp =>  resp.json())



                        .then(json => this.setState({ resp_message: json.message }));
                        // window.location.href="/login"
                        // .then(json => flag= json.message );
                }
                else
                {
                    console.log(source.status)
                    if (source.status) {
                        this.setState({resp_message: "Charge authentication failed!"})
                        flag = "Charge authentication error!"
                    }

                }


            }


        });
    }

    }
componentDidMount()
{
      // console.log(flag+"  kk")
       if (flag)
       {
           this.setState({ resp_message: flag })
          // alert('ik')
       }


}





handleCardErrors = card_dets => {
    console.log("Card Section dets", card_dets);
    if (card_dets.error) {
      this.setState({ card_errors: card_dets.error.message });
    } else {
      this.setState({ card_errors: "" });
    }
  };

  async submit(ev) {




      {/*
  let {token} = await this.props.stripe.createToken({name: "name"});

  const user = {
      username,
      mobile_no,
      password,
      invicode,
        vericode
    }

  let response = await fetch("http://127.0.0.1:8000/api/v1/payments/charge/", {
    method: "POST",
    headers: {
              accept: "application/json",
              Authorization: "Token 62c366bacc6365c035fad818d2a77be51097e95d",
            },
    body: token.id
  });

  if (response.ok) console.log("Purchase Complete!")
  */}
}

handleSubmit = e => {
       var amount
       const query = this.props.location.search
    console.log(query)
    if(!this.props.amount)
     {

             if (query && query.indexOf("amount=") !== -1) {

            const arr = query.replace("?", "").split('&')
            console.log(query.replace("?", ""))
            if (arr) {
                for (var i = 0; i < arr.length; i++) {
                    console.log(arr[i])

                    if (arr[i].indexOf("amount=") !== -1)
                        amount = arr[i].replace("amount=", "")

                }
            }
        }


     }
     else {
         amount=this.props.amount
     }

    e.preventDefault();
    this.setState({ card_errors: "", resp_message: "" });
    /*
    Within the context of Elements, this call to createToken knows which
    Element to tokenize, since there's only one in this group.
    */
      const user = {
      username,

    }
    user.username = Cookies.get('user')
     let wallet=Cookies.get('wallet')
    return this.props.stripe
      .createToken({ type: "card", name: user.username })
      .then(result => {
        if (result.error) {
          console.log("THERE IS AN ERROR IN YOUR FORM", result.error);
          return this.setState({ card_errors: result.error.message });
        } else {
          console.log(
            "Received Stripe token ---> SENDING TO SERVER: ",
            result.token
          );
          let formData = new FormData();
          formData.append("description", "Itea Charge");
          formData.append("currency", "sgd");
          formData.append("user", user.username);
          //name:user.username
          //formData.append("currency", "usd");
          formData.append("amount", amount);
          formData.append("money", amount);
          formData.append("wallet", wallet);
           // formData.append("amount", parseInt(this.props.amount,10));
          formData.append("source", result.token.id);
         //  return fetch(`http://127.0.0.1:8000/api/v1/payments/charge/`, {
           return fetch(`https://crm.itea.sg/api/v1/payments/charge/`, {
            method: "POST",
            headers: {
              accept: "application/json",
              Authorization: "Token 62c366bacc6365c035fad818d2a77be51097e95d",
            },
            body: formData
          })
            .then(resp => resp.json())
            .then(json => this.setState({ resp_message: json.message }));
        }
      });
  };

handleData = e => {
    e.preventDefault();
    var url=""
    var urlArr=[]
    var amount
     url=window.location.href
                                 urlArr=url.split("?")
                                if (urlArr)
                                {
                                    url=urlArr[0]
                                }
      const user = {
      username,

    }
    user.username = Cookies.get('user')
    this.setState({ card_errors: "", resp_message: "" });
     //获取amount
     const query = this.props.location.search
     if(!this.props.amount)
     {

             if (query && query.indexOf("amount=") !== -1) {

            const arr = query.replace("?", "").split('&')
            console.log(query.replace("?", ""))
            if (arr) {
                for (var i = 0; i < arr.length; i++) {
                    console.log(arr[i])

                    if (arr[i].indexOf("amount=") !== -1)
                        amount = arr[i].replace("amount=", "")

                }
            }
        }


     }
     else {
         amount=this.props.amount
     }


  this.props.stripe.createSource({type: 'card',
                currency: "sgd",
               // amount: this.props.amount ,
                amount: amount ,
                // amount:50000,
                owner: {
                   // name: user.username,
                   // email: user.email
                    name:user.username,
                    email:"wangziyi20192019@gmail.com"
                }
            }).then(response => {
                if (response.error) {
                    this.setState({resp_message: response.error.message});
                } else {
                    let source = response.source;
                    if (source.card.three_d_secure === 'not_supported' &&
                        source.status === 'chargeable') {

                        this.handleSubmit(document.getElementById('myForm'));

                        // SEND TO SERVER -> CHARGE
                    } else if (source.card.three_d_secure === 'required' ||
                        source.card.three_d_secure === 'recommended' ||
                        source.card.three_d_secure === 'optional') {
                        //let url=window.location.pathname
                        //let urlGet=url.replace(url,'payotp','payok')

                        this.props.stripe.createSource({type: 'three_d_secure',
                            currency: "sgd",
                            //测试$0.5
                          //  amount: this.props.amount ,
                           // amount:50,
                             amount: amount ,
                            three_d_secure: {
                                card: source.id
                            },
                            redirect: {
                                 //测试用$0.5
                                //return_url: "http://localhost/payotp"+"?amount="+50

                               // return_url: url+"?amount="+50
                               //  return_url: window.location.href+"?amount="+50
                               // return_url: url+"?amount="+this.props.amount
                                return_url: url+"?amount="+amount
                            },
                            owner: {
                                //name: user.username,
                               // email: user.email
                                name:user.username,
                                email:"wangziyi20192019@gmail.com"
                            }
                        }).then(response => {
                            if (response.error) {
                                this.setState({resp_message: response.error.message});
                            } else {
                                let redirect = response.source.redirect;
                                window.location=redirect.url

                                // REDIRECT USER TO redirect.url
                                // CALLBACK ??
                                console.log(redirect);
                            }
                        });

                    }
                }
            });
};



  render() {

    return (
      <div className="checkout">
          {this.state.resp_message && <h1>{this.state.resp_message}</h1>}

           <form onSubmit={this.handleData} id="myForm">
           <label>
        <CardElement

        style={{
                base: {
                  color: "#32325d",

                  fontFamily: '"Helvetica Neue", Helvetica, sans-serif',
                  fontSmoothing: "antialiased",
                  fontSize: "16px",
                  "::placeholder": {
                    color: "#aab7c4"
                  }
                },
                invalid: {
                  color: "#fa755a",
                  iconColor: "#fa755a"
                }
              }}
              onChange={this.handleCardErrors}
        />
           <div role="alert">
              <h2>{this.state.card_errors}</h2>
            </div>
  </label>
                <WhiteSpace size="lg" />
         <Flex justify="center">       <button     style={{ padding: '10px' }} className="am-button-borderfix">Confirm Order</button>

       </Flex>
                </form>
      </div>
    );
  }
}

export default injectStripe(withRouter(CheckoutForm));