import React from 'react';
import ReactDOM from 'react-dom';
 import { BrowserRouter as Router,IndexRoute, Route, Link, Switch, Redirect } from 'react-router-dom';
  //import { IndexRoute } from 'react-router';
{/*import {
    Router as HashRouter , // 或者是HashRouter、MemoryRouter
    Route,   // 这是基本的路由块
    Link,    // 这是a标签
    Switch ,  // 这是监听空路由的
    Redirect, // 这是重定向
    Prompt   // 防止转换
} from 'react-router-dom'*/}
import createHistory from 'history/createHashHistory'

import './index.less';
import Login from './components/Login';
import Voucher from './components/Voucher'
import Register from './components/Register';
import Profile from './components/Profile';
import ForgetPassword from './components/ForgetPassword';
//import payments from './components/payments';
const history = createHistory();
{/*
class Index extends React.Component {
  render() {
    return (
      <div className="body">
      </div>
    );
  }
}
*/}
ReactDOM.render(
    <Router>
   {/*  <HashRouter   history={history}>*/}


    <div>

     {/* <Route path="/" component={Login} />*/}
     <Route exact path="/" component={Login} />
      <Route path="/voucher" component={Voucher} />
      <Route path="/register" component={Register} />
      <Route path="/profile" component={Profile} />

      <Route path="/forgetPassword" component={ForgetPassword} />
      

      {/*  <Redirect from="/" to="/payments"></Redirect>*/}
     {/*   <Redirect from="/" to="/"></Redirect>*/}
    </div>

   {/*  </HashRouter >*/}
</Router>
  , document.getElementById('example'));
