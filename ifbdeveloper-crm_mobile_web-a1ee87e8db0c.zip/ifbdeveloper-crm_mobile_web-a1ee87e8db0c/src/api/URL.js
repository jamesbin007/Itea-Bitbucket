export const URL = 'https://crm.itea.sg/api/v1/'
//export const URL = 'http://127.0.0.1:8000/api/v1/'
export const OtpURL = 'https://crm.itea.sg/api/'