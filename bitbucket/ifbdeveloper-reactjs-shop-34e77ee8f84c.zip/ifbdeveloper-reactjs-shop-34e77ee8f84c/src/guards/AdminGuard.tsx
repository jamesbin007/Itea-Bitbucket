import { ReactNode } from 'react';
import { Navigate } from 'react-router-dom';
// hooks
import useAuth from '../hooks/useAuth';
// routes
import { PATH_DASHBOARD } from '../routes/paths';
// components
import LoadingScreen from '../components/LoadingScreen';
import Login from 'src/pages/auth/Login';
import Page403 from '../pages/Page403';

// ----------------------------------------------------------------------

type GuestGuardProps = {
  children: ReactNode;
};

export default function GuestGuard({ children }: GuestGuardProps) {
  const { isAuthenticated, isInitialized,user } = useAuth();

  if (!isInitialized || !isAuthenticated) {
    return <Login />;
  }

  if(user === null || user.role !== 'admin'){
    return <Page403 />
  }

  return <>{children}</>;
}
