// @mui
import { List, Box } from '@mui/material';
// hooks
import useLocales from '../../../hooks/useLocales';
//
import { NavSectionProps,NavSubItems } from '../type';
import { ListSubheaderStyle } from './style';
import NavList from './NavList';
import RoleBasedGuard from 'src/guards/RoleBasedGuard';
// ----------------------------------------------------------------------
function NavSectionVerticalGuard({ item, isCollapse}: NavSubItems) {
  const { translate } = useLocales();
  const { subheader,items,roles } = item;
  const renderContent = (
      <List key={subheader} disablePadding sx={{ px: 2 }}>
          <ListSubheaderStyle
            disableGutters
            sx={{
              ...(isCollapse && {
                opacity: 0,
              }),
            }}
          >
           {translate(subheader)}
          </ListSubheaderStyle>
          {items.map((list) => (
            <NavList
              key={list.title + list.path}
              data={list}
              depth={1}
              hasChildren={!!list.children}
              isCollapse={isCollapse}
            />
          ))}
      </List>
  );
  return <RoleBasedGuard roles={roles}>{renderContent}</RoleBasedGuard>
}


export default function NavSectionVertical({ navConfig, isCollapse, ...other }: NavSectionProps) {
  return (
    <Box {...other}>
      {navConfig.map((group) => (
        <NavSectionVerticalGuard item={group} isCollapse={isCollapse} key={group.subheader}/>
      ))}
    </Box>
  );
}
