import { memo } from 'react';
// @mui
import { Stack } from '@mui/material';
//
import { NavListProps, NavSectionProps, NavSubItems} from '../type';
import NavList from './NavList';

import RoleBasedGuard from 'src/guards/RoleBasedGuard';
// ----------------------------------------------------------------------

const hideScrollbar = {
  msOverflowStyle: 'none',
  scrollbarWidth: 'none',
  overflowY: 'scroll',
  '&::-webkit-scrollbar': {
    display: 'none',
  },
} as const;

function NavSectionHorizontalGuard({ item }: NavSubItems) {
  const { subheader,items,roles } = item;
  const renderContent = (
    <Stack key={subheader} direction="row" flexShrink={0}>
    {items.map((list) => (
      <NavList
        key={list.title + list.path}
        data={list}
        depth={1}
        hasChildren={!!list.children}
      />
    ))}
  </Stack>
  );
  return <RoleBasedGuard roles={roles}>{renderContent}</RoleBasedGuard>
}

function NavSectionHorizontal({ navConfig }: NavSectionProps) {
  return (
    <Stack
      direction="row"
      justifyContent="center"
      sx={{ bgcolor: 'background.neutral', borderRadius: 1, px: 0.5 }}
    >
      <Stack direction="row" sx={{ ...hideScrollbar, py: 1 }}>
        {navConfig.map((group) => (
          <NavSectionHorizontalGuard item={group} key={group.subheader}/>
        ))}
      </Stack>
    </Stack>
  );
}

export default memo(NavSectionHorizontal);
