import { ReactElement } from 'react';
import { BoxProps } from '@mui/material';
import { type } from 'os';

// ----------------------------------------------------------------------

export type NavListProps = {
  title: string;
  path: string;
  icon?: ReactElement;
  info?: ReactElement;
  caption?: string;
  disabled?: boolean;
  roles?: string[];
  children?: any;
};

export type NavItemProps = {
  item: NavListProps;
  depth: number;
  open: boolean;
  active: boolean;
  isCollapse?: boolean;
};

export type NavSubItems = {
  isCollapse?: boolean;
  item: {
    subheader: string;
    items: NavListProps[];
    roles?: string[];
  }
};

export interface NavSectionProps extends BoxProps {
  isCollapse?: boolean;
  navConfig: {
    subheader: string;
    items: NavListProps[];
    roles?: string[];
  }[];
}
